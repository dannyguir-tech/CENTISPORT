"""Tests for funding intelligence service."""

from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from centinela.services.funding_intelligence import (
    _detect_coordinated_market_bursts,
    _detect_new_wallet_bursts,
    _recent_coordinated_market_event_exists,
    _to_utc,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_wallet(id: int, date_added: datetime | None = None, is_active: bool = True):
    w = MagicMock()
    w.id = id
    w.date_added = date_added
    w.is_active = is_active
    return w


def _make_trade(wallet_id: int, market_name: str, size: float = 100.0, ts: datetime | None = None):
    t = MagicMock()
    t.wallet_id = wallet_id
    t.market_name = market_name
    t.size = size
    t.timestamp = ts or datetime.now(tz=timezone.utc)
    return t


def _make_funding_event(event_type: str, details: dict | None = None, ts: datetime | None = None):
    e = MagicMock()
    e.event_type = event_type
    e.details = details or {}
    e.timestamp = ts or datetime.now(tz=timezone.utc)
    return e


# ---------------------------------------------------------------------------
# _to_utc
# ---------------------------------------------------------------------------

class TestToUtc:
    def test_none_returns_none(self):
        assert _to_utc(None) is None

    def test_naive_gets_utc(self):
        naive = datetime(2025, 1, 1, 12, 0, 0)
        result = _to_utc(naive)
        assert result is not None
        assert result.tzinfo is timezone.utc

    def test_aware_preserved(self):
        aware = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        result = _to_utc(aware)
        assert result == aware


# ---------------------------------------------------------------------------
# new_wallet_burst: date_added=None must NOT create event
# ---------------------------------------------------------------------------

class TestNewWalletBurst:
    @pytest.mark.asyncio
    async def test_date_added_none_skipped(self):
        """Wallet with date_added=None must NOT generate a new_wallet_burst event."""
        session = AsyncMock()
        # _recent_event_exists won't be reached, but set up session.execute to
        # return empty results in case it is called
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute = AsyncMock(return_value=mock_result)

        wallet = _make_wallet(id=1, date_added=None)
        trades = {1: [_make_trade(1, "Market A"), _make_trade(1, "Market B"), _make_trade(1, "Market C")]}

        events = await _detect_new_wallet_bursts(session, [wallet], trades)
        assert len(events) == 0, "date_added=None should not produce new_wallet_burst"

    @pytest.mark.asyncio
    async def test_recent_wallet_creates_event(self):
        """Wallet added 12 hours ago with 3+ trades should produce an event."""
        session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None  # no existing event
        session.execute = AsyncMock(return_value=mock_result)

        recent = datetime.now(tz=timezone.utc) - timedelta(hours=12)
        wallet = _make_wallet(id=2, date_added=recent)
        trades = {
            2: [
                _make_trade(2, "Market A"),
                _make_trade(2, "Market B"),
                _make_trade(2, "Market C"),
            ]
        }

        events = await _detect_new_wallet_bursts(session, [wallet], trades)
        assert len(events) == 1
        assert events[0].event_type == "new_wallet_burst"

    @pytest.mark.asyncio
    async def test_old_wallet_skipped(self):
        """Wallet added 72 hours ago (outside window) should not produce an event."""
        session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute = AsyncMock(return_value=mock_result)

        old = datetime.now(tz=timezone.utc) - timedelta(hours=72)
        wallet = _make_wallet(id=3, date_added=old)
        trades = {3: [_make_trade(3, "M") for _ in range(5)]}

        events = await _detect_new_wallet_bursts(session, [wallet], trades)
        assert len(events) == 0


# ---------------------------------------------------------------------------
# coordinated_market_burst: market-scoped dedupe
# ---------------------------------------------------------------------------

class TestCoordinatedMarketBurst:
    @pytest.mark.asyncio
    async def test_two_markets_both_create_events(self):
        """Two different markets with same wallets should each produce events (not suppress second)."""
        session = AsyncMock()

        # Mock _recent_coordinated_market_event_exists to return False for all
        # (no prior events exist) — we patch the helper directly
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = []  # no existing events
        session.execute = AsyncMock(return_value=mock_result)

        now = datetime.now(tz=timezone.utc)
        wallets = [_make_wallet(id=i) for i in range(1, 4)]  # 3 wallets
        trades_by_wallet = {}
        for w in wallets:
            trades_by_wallet[w.id] = [
                _make_trade(w.id, "Market_Alpha", ts=now - timedelta(hours=1)),
                _make_trade(w.id, "Market_Beta", ts=now - timedelta(hours=2)),
            ]

        events = await _detect_coordinated_market_bursts(session, wallets, trades_by_wallet)

        # Should have events for BOTH markets (3 wallets × 2 markets = 6 events)
        market_keys = {e.details["market_key"] for e in events}
        assert "Market_Alpha" in market_keys, "Market_Alpha should have coordinated burst events"
        assert "Market_Beta" in market_keys, "Market_Beta should have coordinated burst events"
        assert len(events) == 6  # 3 wallets × 2 markets

    @pytest.mark.asyncio
    async def test_existing_event_for_one_market_does_not_suppress_other(self):
        """If wallet already has a coordinated event for Market_A, Market_B events should still fire.

        We patch _recent_coordinated_market_event_exists to return True for
        Market_Alpha and False for Market_Beta, verifying that market-scoped
        dedupe only suppresses the matching market.
        """
        session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = []
        session.execute = AsyncMock(return_value=mock_result)

        now = datetime.now(tz=timezone.utc)
        wallets = [_make_wallet(id=i) for i in range(1, 4)]
        trades_by_wallet = {}
        for w in wallets:
            trades_by_wallet[w.id] = [
                _make_trade(w.id, "Market_Alpha", ts=now - timedelta(hours=1)),
                _make_trade(w.id, "Market_Beta", ts=now - timedelta(hours=2)),
            ]

        # Patch the helper: Alpha already exists, Beta does not
        async def mock_dedupe(sess, wid, market_key, within_hours=12):
            return market_key == "Market_Alpha"

        with patch(
            "centinela.services.funding_intelligence._recent_coordinated_market_event_exists",
            side_effect=mock_dedupe,
        ):
            events = await _detect_coordinated_market_bursts(session, wallets, trades_by_wallet)

        market_keys = [e.details["market_key"] for e in events]
        alpha_count = market_keys.count("Market_Alpha")
        beta_count = market_keys.count("Market_Beta")
        assert alpha_count == 0, "Market_Alpha should be suppressed (existing event)"
        assert beta_count == 3, "Market_Beta should create 3 events (one per wallet)"


class TestRecentCoordinatedMarketEventExists:
    @pytest.mark.asyncio
    async def test_no_events_returns_false(self):
        """No existing events → returns False."""
        session = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = []
        session.execute = AsyncMock(return_value=mock_result)

        result = await _recent_coordinated_market_event_exists(session, 1, "Market_X")
        assert result is False

    @pytest.mark.asyncio
    async def test_matching_market_returns_true(self):
        """Existing event with matching market_key → returns True."""
        session = AsyncMock()
        existing = _make_funding_event(
            "coordinated_market_burst",
            details={"market_key": "Market_X"},
        )
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = [existing]
        session.execute = AsyncMock(return_value=mock_result)

        result = await _recent_coordinated_market_event_exists(session, 1, "Market_X")
        assert result is True

    @pytest.mark.asyncio
    async def test_different_market_returns_false(self):
        """Existing event for different market_key → returns False."""
        session = AsyncMock()
        existing = _make_funding_event(
            "coordinated_market_burst",
            details={"market_key": "Market_Y"},
        )
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = [existing]
        session.execute = AsyncMock(return_value=mock_result)

        result = await _recent_coordinated_market_event_exists(session, 1, "Market_X")
        assert result is False
