"""Polymarket Gamma API client — market discovery and metadata.

Endpoints:
  GET /markets — list markets with filtering
  GET /markets/{id} — single market detail
  GET /events — event grouping
"""

import structlog
import httpx

from centinela.config import settings
from centinela.utils.rate_limiter import RateLimiter

logger = structlog.get_logger()

_rate_limiter = RateLimiter(rate=3.0, burst=10)


class PolymarketGammaClient:
    def __init__(self):
        self.base_url = settings.polymarket_gamma_api
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=15.0,
                headers={"Accept": "application/json"},
            )
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def get_markets(
        self,
        active: bool = True,
        limit: int = 100,
        offset: int = 0,
        tag: str | None = None,
    ) -> list[dict]:
        """Fetch market list from Gamma API."""
        await _rate_limiter.acquire()
        params: dict = {"limit": limit, "offset": offset, "active": active}
        if tag:
            params["tag"] = tag
        try:
            resp = await self.client.get("/markets", params=params)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error("polymarket_gamma.markets_error", error=str(e))
            return []

    async def get_market(self, market_id: str) -> dict | None:
        """Fetch a single market by condition_id or slug."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get(f"/markets/{market_id}")
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error("polymarket_gamma.market_error", market_id=market_id, error=str(e))
            return None

    async def search_markets(self, query: str, limit: int = 20) -> list[dict]:
        """Search markets by keyword."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get(
                "/markets", params={"_q": query, "limit": limit, "active": True}
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error("polymarket_gamma.search_error", query=query, error=str(e))
            return []


# Module-level singleton
polymarket_gamma = PolymarketGammaClient()
