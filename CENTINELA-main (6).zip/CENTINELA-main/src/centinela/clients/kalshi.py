"""Kalshi REST API client — market data and pricing.

Endpoints:
  GET /markets — list markets
  GET /markets/{ticker} — single market with current price
  GET /markets/{ticker}/orderbook — order book
"""

import structlog
import httpx

from centinela.config import settings
from centinela.utils.rate_limiter import RateLimiter

logger = structlog.get_logger()

_rate_limiter = RateLimiter(rate=5.0, burst=10)


class KalshiClient:
    def __init__(self):
        self.base_url = settings.kalshi_api_base
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=15.0,
                headers={"Accept": "application/json"},
            )
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def get_market(self, ticker: str) -> dict | None:
        """Fetch a single Kalshi market by ticker."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get(f"/markets/{ticker}")
            resp.raise_for_status()
            data = resp.json()
            return data.get("market", data)
        except httpx.HTTPError as e:
            logger.error("kalshi.market_error", ticker=ticker, error=str(e))
            return None

    async def get_market_price(self, ticker: str) -> float | None:
        """Get current YES price for a Kalshi market (0-1 scale)."""
        market = await self.get_market(ticker)
        if not market:
            return None

        # Kalshi prices are in cents (0-100), convert to 0-1
        yes_price = market.get("yes_ask", market.get("last_price", market.get("yes_bid")))
        if yes_price is None:
            return None
        try:
            price = float(yes_price)
            return price / 100.0 if price > 1 else price
        except (TypeError, ValueError):
            return None

    async def search_markets(self, query: str, limit: int = 20) -> list[dict]:
        """Search Kalshi markets by keyword."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get(
                "/markets",
                params={"limit": limit, "status": "open"},
            )
            resp.raise_for_status()
            data = resp.json()
            markets = data.get("markets", [])
            # Client-side filter by query since Kalshi search is limited
            if query:
                query_lower = query.lower()
                markets = [
                    m for m in markets
                    if query_lower in m.get("title", "").lower()
                    or query_lower in m.get("ticker", "").lower()
                ]
            return markets[:limit]
        except httpx.HTTPError as e:
            logger.error("kalshi.search_error", query=query, error=str(e))
            return []


# Module-level singleton
kalshi_client = KalshiClient()
