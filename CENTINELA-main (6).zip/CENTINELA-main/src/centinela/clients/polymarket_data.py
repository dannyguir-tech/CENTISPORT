"""Polymarket Data API client — primary source for wallet tracking.

Endpoints:
  GET /activity?user={address}&type=TRADE — trade history
  GET /positions?user={address} — current positions
  GET /leaderboard — top wallets by PnL/volume
"""

import structlog
import httpx

from centinela.config import settings
from centinela.utils.rate_limiter import RateLimiter

logger = structlog.get_logger()

_rate_limiter = RateLimiter(rate=2.0, burst=5)


class PolymarketDataClient:
    def __init__(self):
        self.base_url = settings.polymarket_data_api
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=15.0,
                headers={"Accept": "application/json"},
            )
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def get_activity(
        self,
        address: str,
        trade_type: str = "TRADE",
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """Fetch trade activity for a wallet address.

        Returns list of trade dicts with keys like:
        conditionId, side, size, price, timestamp, transactionHash, etc.
        """
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get(
                "/activity",
                params={
                    "user": address,
                    "type": trade_type,
                    "limit": limit,
                    "offset": offset,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            # Data API may return a list directly or wrapped in a "history" key
            if isinstance(data, list):
                return data
            return data.get("history", data.get("data", []))
        except httpx.HTTPError as e:
            logger.error("polymarket_data.activity_error", address=address, error=str(e))
            return []

    async def get_all_activity(self, address: str, max_trades: int = 500) -> list[dict]:
        """Paginate through all trade activity up to max_trades."""
        all_trades: list[dict] = []
        offset = 0
        page_size = 100
        while offset < max_trades:
            page = await self.get_activity(address, limit=page_size, offset=offset)
            if not page:
                break
            all_trades.extend(page)
            if len(page) < page_size:
                break
            offset += page_size
        return all_trades[:max_trades]

    async def get_positions(self, address: str) -> list[dict]:
        """Fetch current open positions for a wallet."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get("/positions", params={"user": address})
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, list):
                return data
            return data.get("positions", data.get("data", []))
        except httpx.HTTPError as e:
            logger.error("polymarket_data.positions_error", address=address, error=str(e))
            return []

    async def get_leaderboard(self, metric: str = "profit", limit: int = 200) -> list[dict]:
        """Fetch the Polymarket leaderboard of top traders.

        metric: "profit" (top winners) or "loss" (biggest losers — dumb money candidates).
        Returns list of dicts with at least `address` field; may include pnl, volume, win_rate.
        """
        await _rate_limiter.acquire()
        try:
            sort_param = "pnl" if metric == "profit" else "pnl_asc"
            resp = await self.client.get(
                "/leaderboard",
                params={"sort": sort_param, "limit": limit},
            )
            resp.raise_for_status()
            data = resp.json()
            # Accept list or wrapped payloads
            if isinstance(data, list):
                return data
            return data.get("leaderboard", data.get("data", data.get("users", [])))
        except httpx.HTTPError as e:
            logger.error("polymarket_data.leaderboard_error", metric=metric, error=str(e))
            return []


# Module-level singleton
polymarket_data = PolymarketDataClient()
