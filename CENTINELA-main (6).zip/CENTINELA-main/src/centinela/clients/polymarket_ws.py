"""Polymarket CLOB WebSocket client — real-time price updates.

Connects to wss://ws-subscriptions-clob.polymarket.com/ws/market
Subscribes to token IDs for markets where tracked wallets hold positions.

NOTE: This WebSocket does NOT expose trader addresses.
It is used for live price context only, NOT trade detection.
Trade detection uses Data API polling (see trade_detector.py).
"""

import asyncio
import json
import time

import structlog
import websockets

from centinela.config import settings

logger = structlog.get_logger()

CACHE_TTL_SECONDS = 60  # stale price fallback to CLOB
PRICE_HISTORY_MAX = 60  # keep last N ticks for pre-move/reversal calculations


class PolymarketWebSocket:
    """WebSocket client for real-time market price updates."""

    def __init__(self):
        self.url = settings.polymarket_ws_url
        self._ws = None
        self._subscribed_tokens: set[str] = set()
        self._price_cache: dict[str, float] = {}
        self._price_ts: dict[str, float] = {}  # token_id -> monotonic last-update time
        self._price_history: dict[str, list[tuple[float, float]]] = {}  # token_id -> [(ts, price)]
        self._running = False
        self._task = None

    @property
    def prices(self) -> dict[str, float]:
        """Snapshot of all currently fresh prices."""
        now = time.time()
        return {
            tid: p for tid, p in self._price_cache.items()
            if now - self._price_ts.get(tid, 0) < CACHE_TTL_SECONDS
        }

    def get_price(self, token_id: str) -> float | None:
        """Return cached price if fresh (<60s old), else None."""
        if token_id not in self._price_cache:
            return None
        if time.time() - self._price_ts.get(token_id, 0) >= CACHE_TTL_SECONDS:
            return None
        return self._price_cache[token_id]

    def get_price_history(self, token_id: str, seconds_ago: float) -> float | None:
        """Return price at approximately seconds_ago, or None if not in history."""
        history = self._price_history.get(token_id)
        if not history:
            return None
        target = time.time() - seconds_ago
        # Find the closest entry at or before target
        best = None
        for ts, price in history:
            if ts <= target:
                best = price
            else:
                break
        return best

    def is_alive(self) -> bool:
        return self._running and self._ws is not None

    async def connect(self, token_ids: list[str]) -> None:
        """Connect and subscribe to market updates for given token IDs.

        Max 10 tokens per connection per Polymarket docs.
        """
        self._running = True
        self._subscribed_tokens = set(token_ids[:10])

        while self._running:
            try:
                async with websockets.connect(self.url) as ws:
                    self._ws = ws
                    logger.info("ws.connected", tokens=len(self._subscribed_tokens))

                    # Subscribe to each token
                    for token_id in self._subscribed_tokens:
                        subscribe_msg = {
                            "type": "subscribe",
                            "channel": "market",
                            "assets_ids": [token_id],
                        }
                        await ws.send(json.dumps(subscribe_msg))

                    # Listen for messages
                    async for raw_msg in ws:
                        try:
                            msg = json.loads(raw_msg)
                            self._handle_message(msg)
                        except json.JSONDecodeError:
                            continue

            except websockets.ConnectionClosed:
                logger.warning("ws.disconnected", msg="Reconnecting in 5s...")
                await asyncio.sleep(5)
            except Exception as e:
                logger.error("ws.error", error=str(e))
                await asyncio.sleep(10)

    def _handle_message(self, msg) -> None:
        """Process incoming WebSocket message and update price cache + history.

        Tolerates: single dicts, lists of dicts (batch updates), heartbeats
        (strings, empty dicts), and unknown envelopes. Never raises.
        """
        # Batch / list payloads — recurse into each item
        if isinstance(msg, list):
            for item in msg:
                try:
                    self._handle_message(item)
                except Exception:
                    continue
            return

        # Non-dict payloads (heartbeats, protocol messages) — ignore
        if not isinstance(msg, dict):
            return

        msg_type = msg.get("type", "") or msg.get("event", "")

        if msg_type in ("price_change", "trade", "book"):
            asset_id = msg.get("asset_id") or msg.get("assetId") or ""
            price = msg.get("price")
            if price is None:
                price = msg.get("mid")
            if price is None:
                # Some shapes use best_bid/best_ask — derive mid
                bid = msg.get("best_bid") or msg.get("bid")
                ask = msg.get("best_ask") or msg.get("ask")
                try:
                    if bid is not None and ask is not None:
                        price = (float(bid) + float(ask)) / 2.0
                except (TypeError, ValueError):
                    price = None
            if asset_id and price is not None:
                try:
                    price_f = float(price)
                    now = time.time()
                    self._price_cache[asset_id] = price_f
                    self._price_ts[asset_id] = now
                    # Append to history, trim to last PRICE_HISTORY_MAX entries
                    hist = self._price_history.setdefault(asset_id, [])
                    hist.append((now, price_f))
                    if len(hist) > PRICE_HISTORY_MAX:
                        del hist[0:len(hist) - PRICE_HISTORY_MAX]
                except (TypeError, ValueError):
                    pass

    async def start_background(self, token_ids: list[str]) -> None:
        """Launch connect() as a background task and return immediately."""
        if self._task and not self._task.done():
            logger.info("ws.already_running")
            return
        self._task = asyncio.create_task(self.connect(token_ids))

    async def disconnect(self) -> None:
        self._running = False
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
        if self._task:
            self._task.cancel()


# Module-level singleton
polymarket_ws = PolymarketWebSocket()
