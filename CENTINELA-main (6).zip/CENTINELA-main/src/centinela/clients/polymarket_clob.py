"""Polymarket CLOB API client — order book, pricing, spreads.

Endpoints:
  GET /midpoint?token_id={id} — current midpoint price
  GET /price?token_id={id}&side=buy — bid/ask price
  GET /book?token_id={id} — full order book depth
"""

import structlog
import httpx

from centinela.config import settings
from centinela.utils.rate_limiter import RateLimiter

logger = structlog.get_logger()

_rate_limiter = RateLimiter(rate=2.0, burst=5)


class PolymarketClobClient:
    def __init__(self):
        self.base_url = settings.polymarket_clob_api
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=15.0,
                headers={"Accept": "application/json"},
            )
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def get_midpoint(self, token_id: str) -> float | None:
        """Get current midpoint price for a token."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get("/midpoint", params={"token_id": token_id})
            resp.raise_for_status()
            data = resp.json()
            mid = data.get("mid")
            return float(mid) if mid is not None else None
        except (httpx.HTTPError, ValueError) as e:
            logger.error("clob.midpoint_error", token_id=token_id, error=str(e))
            return None

    async def get_order_book(self, token_id: str) -> dict | None:
        """Get full order book (bids + asks) for a token."""
        await _rate_limiter.acquire()
        try:
            resp = await self.client.get("/book", params={"token_id": token_id})
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error("clob.orderbook_error", token_id=token_id, error=str(e))
            return None

    async def get_spread(self, token_id: str) -> dict | None:
        """Get spread info (best bid, best ask, spread %)."""
        book = await self.get_order_book(token_id)
        if not book:
            return None
        bids = book.get("bids", [])
        asks = book.get("asks", [])
        best_bid = float(bids[0]["price"]) if bids else 0.0
        best_ask = float(asks[0]["price"]) if asks else 1.0
        spread = best_ask - best_bid
        return {"best_bid": best_bid, "best_ask": best_ask, "spread": spread}


# Module-level singleton
polymarket_clob = PolymarketClobClient()
