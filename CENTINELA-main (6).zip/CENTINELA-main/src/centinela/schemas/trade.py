from datetime import datetime

from pydantic import BaseModel


class TradeOut(BaseModel):
    id: int
    wallet_id: int
    market_name: str
    side: str
    size: float
    price: float
    timestamp: datetime
    is_first_entry: bool
    transaction_hash: str | None = None

    model_config = {"from_attributes": True}
