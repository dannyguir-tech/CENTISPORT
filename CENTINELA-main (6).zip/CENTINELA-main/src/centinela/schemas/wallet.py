from datetime import datetime

from pydantic import BaseModel


class WalletCreate(BaseModel):
    address: str
    handle: str | None = None
    categories: list[str] = []
    notes: str | None = None


class WalletUpdate(BaseModel):
    handle: str | None = None
    categories: list[str] | None = None
    notes: str | None = None
    is_active: bool | None = None


class TradeOut(BaseModel):
    market: str
    side: str
    size: float
    time: str  # relative time like "2h ago"
    priceAtEntry: float
    currentPrice: float | None = None


class WalletOut(BaseModel):
    """Response matching polyscan-v3.jsx frontend contract."""

    address: str
    handle: str | None
    pnl: float
    winRate: float  # 0-1
    trades: int
    avgSize: float
    age: int  # days
    categories: list[str]
    insiderScore: float  # 0-100
    classification: str | None
    recentTrades: list[TradeOut] = []
    streak: int = 0
    maxDrawdown: float = 0.0
    avgHoldTime: str = "0d"
    entryTiming: str = "Unknown"
    pnlHistory: list[float] = []
    isActive: bool = True
    dateAdded: datetime | None = None

    model_config = {"from_attributes": True}
