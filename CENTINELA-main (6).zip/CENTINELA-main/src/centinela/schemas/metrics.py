from pydantic import BaseModel


class MetricsSummary(BaseModel):
    totalWallets: int
    topInsidersCount: int  # score >= 85
    combinedPnl: float
    avgWinRate: float
