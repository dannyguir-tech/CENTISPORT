"""Scheduled job: system health heartbeat."""

import structlog

from centinela.db.session import engine
from centinela.dependencies import get_redis

logger = structlog.get_logger()


async def run_health_check():
    """Check DB and Redis connectivity."""
    status = {"db": "ok", "redis": "ok"}

    try:
        async with engine.connect() as conn:
            await conn.execute(__import__("sqlalchemy").text("SELECT 1"))
    except Exception as e:
        status["db"] = f"error: {e}"
        logger.error("health.db_error", error=str(e))

    try:
        redis = await get_redis()
        await redis.ping()
    except Exception as e:
        status["redis"] = f"error: {e}"
        logger.error("health.redis_error", error=str(e))

    return status
