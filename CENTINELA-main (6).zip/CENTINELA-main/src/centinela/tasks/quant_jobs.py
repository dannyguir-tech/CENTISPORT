"""Phase 4 scheduled jobs: edge monitoring, calibration, discovery, clusters, leaders, position building."""

import structlog

from centinela.db.session import async_session
from centinela.services.telegram_bot import send_message, send_state_change_alert

logger = structlog.get_logger()


async def run_edge_monitoring():
    """Evaluate edge state (GREEN/YELLOW/RED) and alert on changes."""
    from centinela.services.edge_monitoring import evaluate_edge_state

    async with async_session() as session:
        try:
            new_state, context = await evaluate_edge_state(session)
            if context:  # State changed
                await send_state_change_alert(
                    session, old_state="", new_state=new_state, context=context
                )
            await session.commit()
        except Exception as e:
            logger.error("edge_monitoring.error", error=str(e))


async def run_scoring_calibration():
    """Recalibrate scoring weights every 4 weeks."""
    from centinela.services.scoring_calibration import calibrate_weights, format_calibration_alert

    async with async_session() as session:
        try:
            new_weights = await calibrate_weights(session)
            if new_weights:
                from centinela.services.scoring_engine import DEFAULT_WEIGHTS
                alert_text = format_calibration_alert(DEFAULT_WEIGHTS, new_weights)
                await send_message(f"\U0001F4CA CENTINELA \u2014 SCORING CALIBRATION\n\n{alert_text}")
                # Update the default weights in memory
                DEFAULT_WEIGHTS.update(new_weights)
                await session.commit()
        except Exception as e:
            logger.error("calibration.error", error=str(e))


async def run_wallet_discovery():
    """Weekly leaderboard scan for new wallet candidates."""
    from centinela.services.wallet_discovery import discover_wallets

    async with async_session() as session:
        try:
            results = await discover_wallets(session)
            if results["smart_found"] or results["dumb_found"]:
                await send_message(
                    f"\U0001F50D CENTINELA \u2014 WALLET DISCOVERY\n\n"
                    f"Smart candidates: {results['smart_found']}\n"
                    f"Dumb candidates: {results['dumb_found']}\n"
                    f"Auto-added: {results['auto_added']}"
                )
            await session.commit()
        except Exception as e:
            logger.error("discovery.error", error=str(e))


async def run_cluster_detection():
    """Compute pairwise link scores and build wallet clusters."""
    from centinela.services.cluster_detection import compute_all_pairs

    async with async_session() as session:
        try:
            pairs = await compute_all_pairs(session)
            if pairs > 0:
                logger.info("cluster_detection.complete", pairs=pairs)
        except Exception as e:
            logger.error("cluster_detection.error", error=str(e))


async def run_leader_detection():
    """Compute leader/follower scores for all smart wallets."""
    from centinela.services.leader_detection import compute_leader_scores

    async with async_session() as session:
        try:
            updated = await compute_leader_scores(session)
            if updated > 0:
                logger.info("leader_detection.complete", wallets=updated)
        except Exception as e:
            logger.error("leader_detection.error", error=str(e))


async def run_copyability_scoring():
    """Compute copyability scores for all active smart wallets."""
    from sqlalchemy import select
    from centinela.db.models.execution import EntryQuality
    from centinela.db.models.wallet import Wallet
    from centinela.services.copyability import compute_copyability

    async with async_session() as session:
        try:
            result = await session.execute(
                select(Wallet).where(Wallet.is_active == True).where(Wallet.wallet_type == "smart")  # noqa: E712
            )
            wallets = result.scalars().all()
            updated = 0
            for wallet in wallets:
                # Derive time-to-move samples from EntryQuality records
                eq_result = await session.execute(
                    select(EntryQuality).where(EntryQuality.wallet_id == wallet.id)
                )
                entries = list(eq_result.scalars().all())

                # Use edge_retention from stored values, default 0.5
                edge_retentions = [e.edge_retention_pct for e in entries if e.edge_retention_pct is not None]
                avg_er = sum(edge_retentions) / len(edge_retentions) if edge_retentions else 0.5

                # Compute copyability (uses defaults for t3/t5/t10 if no samples)
                score = await compute_copyability(session, wallet, edge_retention=avg_er)
                updated += 1

            await session.commit()
            if updated > 0:
                logger.info("copyability_scoring.complete", wallets=updated)
        except Exception as e:
            logger.error("copyability_scoring.error", error=str(e))


async def run_pre_signal_scan():
    """Scan active markets for pre-signal conditions."""
    from sqlalchemy import select
    from centinela.db.models.market import Market
    from centinela.db.models.trade import Trade
    from centinela.db.models.wallet import Wallet
    from centinela.services.pre_signal import compute_pre_signal, record_pre_signal

    async with async_session() as session:
        try:
            result = await session.execute(
                select(Market).where(Market.status == "active")
            )
            markets = result.scalars().all()
            flagged = 0
            from datetime import datetime, timezone, timedelta
            now = datetime.now(tz=timezone.utc)
            cutoff_6h = now - timedelta(hours=6)
            cutoff_1h = now - timedelta(hours=1)
            cutoff_2h = now - timedelta(hours=2)
            cutoff_5h = now - timedelta(hours=5)
            for market in markets:
                # Count recent smart wallet activity in this market
                smart_count_result = await session.execute(
                    select(Trade)
                    .join(Wallet, Trade.wallet_id == Wallet.id)
                    .where(Trade.market_id == market.id)
                    .where(Trade.timestamp >= cutoff_6h)
                    .where(Wallet.wallet_type == "smart")
                    .where(Wallet.insider_score >= 60)
                )
                smart_trades = list(smart_count_result.scalars().all())
                related_smart = min(len(smart_trades) / 3.0, 1.0)  # Normalize: 3+ = max

                # Compute vol_growth and price_drift from Trade table
                all_trades_result = await session.execute(
                    select(Trade)
                    .where(Trade.market_id == market.id)
                    .where(Trade.timestamp >= cutoff_6h)
                    .order_by(Trade.timestamp.desc())
                )
                all_trades = list(all_trades_result.scalars().all())

                trades_last_1h = [t for t in all_trades if t.timestamp >= cutoff_1h]
                trades_prev_1h = [t for t in all_trades if cutoff_2h <= t.timestamp < cutoff_1h]
                prev_count = max(len(trades_prev_1h), 1)
                vol_growth_raw = (len(trades_last_1h) / prev_count - 1.0) * 100
                vol_growth = max(0.0, min(200.0, vol_growth_raw))  # cap at +200%

                # price_drift = |avg(prices_last_1h) - avg(prices_5h_to_6h_ago)| as %
                prices_last_1h = [t.price for t in trades_last_1h if t.price is not None]
                prices_old = [t.price for t in all_trades
                              if t.timestamp < cutoff_5h and t.price is not None]
                if prices_last_1h and prices_old:
                    avg_recent = sum(prices_last_1h) / len(prices_last_1h)
                    avg_old = sum(prices_old) / len(prices_old)
                    price_drift = abs(avg_recent - avg_old) * 100  # as %
                else:
                    price_drift = 0.0

                # liq_growth stays 0 — needs MarketVolumeSnapshot table (Tier C future)
                liq_growth = 0.0
                spread_tightening = 0.0
                if market.spread is not None:
                    spread_tightening = max(0, (0.05 - market.spread) / 0.05) * 100  # Tighter than 5% = positive

                confidence, is_flagged = compute_pre_signal(
                    liq_growth=liq_growth,
                    spread_tightening=spread_tightening,
                    vol_growth=vol_growth,
                    price_drift=price_drift,
                    related_smart_activity=related_smart,
                )

                if is_flagged:
                    await record_pre_signal(
                        session=session,
                        market_id=market.id,
                        market_name=market.question,
                        liq_growth=liq_growth,
                        spread_tightening=spread_tightening,
                        vol_growth=vol_growth,
                        price_drift=price_drift,
                        related_smart_activity=related_smart,
                    )
                    flagged += 1

            await session.commit()
            if flagged > 0:
                logger.info("pre_signal_scan.complete", flagged=flagged)
        except Exception as e:
            logger.error("pre_signal_scan.error", error=str(e))


async def _compute_regime_features(session, market_id):
    """Compute regime classifier inputs from Trade table for one market.

    Returns dict: rv, spread_med, vol_spike, directional_drift.
    depth_instability stays 0 until WebSocket feed is wired.
    """
    from datetime import datetime, timezone, timedelta
    from sqlalchemy import select
    from centinela.db.models.trade import Trade

    now = datetime.now(tz=timezone.utc)
    cutoff_24h = now - timedelta(hours=24)
    cutoff_1h = now - timedelta(hours=1)

    result = await session.execute(
        select(Trade).where(Trade.market_id == market_id).where(Trade.timestamp >= cutoff_24h)
    )
    trades_24h = list(result.scalars().all())

    if len(trades_24h) < 3:
        return {"rv": 0.0, "vol_spike": 0.0, "directional_drift": 0.0}

    # rv = stddev of prices over 24h
    prices = [t.price for t in trades_24h if t.price is not None]
    if len(prices) >= 2:
        mean = sum(prices) / len(prices)
        var = sum((p - mean) ** 2 for p in prices) / len(prices)
        rv = var ** 0.5
    else:
        rv = 0.0

    # vol_spike = trades_last_1h / avg_hourly_24h
    trades_1h = [t for t in trades_24h if t.timestamp >= cutoff_1h]
    avg_hourly = len(trades_24h) / 24.0
    vol_spike = (len(trades_1h) / avg_hourly) if avg_hourly > 0 else 0.0

    # directional_drift = (yes_volume - no_volume) / total_volume
    yes_vol = sum(t.size for t in trades_24h if t.side == "YES")
    no_vol = sum(t.size for t in trades_24h if t.side == "NO")
    total = yes_vol + no_vol
    directional_drift = ((yes_vol - no_vol) / total) if total > 0 else 0.0

    return {"rv": rv, "vol_spike": vol_spike, "directional_drift": directional_drift}


async def run_regime_detection():
    """Classify market regime (high_vol/low_vol/trending/manipulated) for active markets."""
    from sqlalchemy import select
    from centinela.db.models.market import Market
    from centinela.db.models.quant_intelligence import MarketRegime
    from centinela.services.regime_detection import classify_regime

    async with async_session() as session:
        try:
            result = await session.execute(select(Market).where(Market.status == "active"))  # noqa: E712
            markets = result.scalars().all()
            updated = 0
            for market in markets:
                feats = await _compute_regime_features(session, market.id)
                regime = classify_regime(
                    rv=feats["rv"],
                    spread_med=market.spread or 0.0,
                    depth_instability=0.0,  # TODO: Tier B — WebSocket order book
                    vol_spike=feats["vol_spike"],
                    directional_drift=feats["directional_drift"],
                )
                row = MarketRegime(
                    market_id=market.id,
                    regime_label=regime.label,
                    regime_confidence=regime.confidence,
                    raw_scores=regime.raw_scores,
                    rv=feats["rv"],
                    spread_med=market.spread,
                    vol_spike=feats["vol_spike"],
                    directional_drift=feats["directional_drift"],
                    chase_multiplier=regime.chase_multiplier,
                    position_multiplier=regime.position_multiplier,
                    min_score_adjustment=regime.min_score_adjustment,
                )
                session.add(row)
                updated += 1
            await session.commit()
            if updated > 0:
                logger.info("regime_detection.complete", markets=updated)
        except Exception as e:
            logger.error("regime_detection.error", error=str(e))


async def run_adaptive_polling():
    """Compute per-market poll priority and update polling tiers."""
    from datetime import datetime, timezone, timedelta
    from sqlalchemy import select, func
    from centinela.db.models.market import Market
    from centinela.db.models.trade import Trade
    from centinela.db.models.wallet import Wallet
    from centinela.db.models.cross_platform import CrossPlatformMarket, CrossPlatformPrice
    from centinela.db.models.quant_intelligence import PollPriority, PreSignalFlag
    from centinela.services.adaptive_polling import compute_poll_priority

    async with async_session() as session:
        try:
            result = await session.execute(select(Market).where(Market.status == "active"))
            markets = result.scalars().all()
            cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=6)
            updated = 0

            # Get volume stats for percentile ranking
            vol_result = await session.execute(
                select(Market.daily_volume).where(Market.status == "active").where(Market.daily_volume.isnot(None))
            )
            all_volumes = sorted([v for (v,) in vol_result.all()])

            for market in markets:
                # Pre-signal confidence for this market
                pre_conf = 0.0
                ps_result = await session.execute(
                    select(PreSignalFlag)
                    .where(PreSignalFlag.market_id == market.id)
                    .where(PreSignalFlag.flagged_at >= cutoff)
                    .order_by(PreSignalFlag.flagged_at.desc())
                    .limit(1)
                )
                ps = ps_result.scalar_one_or_none()
                if ps:
                    pre_conf = ps.pre_signal_confidence

                # Active tracked wallets trading this market recently
                wallet_count_result = await session.execute(
                    select(func.count(func.distinct(Trade.wallet_id)))
                    .join(Wallet, Trade.wallet_id == Wallet.id)
                    .where(Trade.market_id == market.id)
                    .where(Trade.timestamp >= cutoff)
                    .where(Wallet.is_active == True)  # noqa: E712
                )
                active_wallets = wallet_count_result.scalar() or 0

                # Volume percentile
                vol_pct = 0.0
                if market.daily_volume and all_volumes:
                    rank = sum(1 for v in all_volumes if v <= market.daily_volume)
                    vol_pct = rank / len(all_volumes)

                # Cross-platform gap
                xplat_gap = 0.0
                xp_result = await session.execute(
                    select(CrossPlatformPrice)
                    .join(CrossPlatformMarket, CrossPlatformPrice.cross_platform_market_id == CrossPlatformMarket.id)
                    .where(CrossPlatformMarket.polymarket_market_id == market.id)
                    .order_by(CrossPlatformPrice.timestamp.desc())
                    .limit(1)
                )
                xp = xp_result.scalar_one_or_none()
                if xp:
                    xplat_gap = xp.price_gap

                score, tier, interval = compute_poll_priority(
                    pre_signal_confidence=pre_conf,
                    active_tracked_wallets=active_wallets,
                    recent_volume_percentile=vol_pct,
                    cross_platform_gap=xplat_gap,
                )

                # Upsert poll priority
                existing = await session.execute(
                    select(PollPriority).where(PollPriority.market_id == market.id)
                )
                row = existing.scalar_one_or_none()
                if row:
                    row.poll_priority_score = score
                    row.polling_tier = tier
                else:
                    session.add(PollPriority(
                        market_id=market.id,
                        poll_priority_score=score,
                        polling_tier=tier,
                    ))
                updated += 1
            await session.commit()
            if updated > 0:
                logger.info("adaptive_polling.complete", markets=updated)
        except Exception as e:
            logger.error("adaptive_polling.error", error=str(e))


async def run_position_building_check():
    """Check if any 50% positions should be topped up."""
    from centinela.services.position_building import check_position_additions, execute_topup

    async with async_session() as session:
        try:
            topups = await check_position_additions(session)
            for t in topups:
                pos = await execute_topup(session, t["position_id"])
                if pos:
                    await send_message(
                        f"\U0001F528 CENTINELA \u2014 POSITION BUILD\n\n"
                        f"\U0001F4CA {pos.market_name}\n"
                        f"   Insider added to position \u2192 topping up to 100%\n"
                        f"   New size: ${pos.current_size:,.0f}"
                    )
            if topups:
                await session.commit()
        except Exception as e:
            logger.error("position_building.error", error=str(e))
