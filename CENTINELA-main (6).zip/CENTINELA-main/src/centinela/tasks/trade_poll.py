"""Scheduled job: poll Data API for new trades."""

import structlog

from centinela.db.session import async_session
from centinela.dependencies import get_redis
from centinela.services.trade_detector import poll_all_wallets

logger = structlog.get_logger()


async def run_trade_poll():
    """Scheduled task that polls for new trades across all tracked wallets."""
    redis = await get_redis()
    async with async_session() as session:
        try:
            new_count = await poll_all_wallets(session, redis)
            if new_count > 0:
                logger.info("trade_poll.found", new_trades=new_count)
        except Exception as e:
            logger.error("trade_poll.error", error=str(e))
