"""Scheduled job: check open positions for TP/SL/time exits."""

import structlog

from centinela.db.session import async_session
from centinela.services.position_manager import check_all_positions
from centinela.services.telegram_bot import send_position_event

logger = structlog.get_logger()


async def run_position_check():
    """Check all open positions for exit conditions and send alerts."""
    async with async_session() as session:
        try:
            events = await check_all_positions(session)
            for event in events:
                alert_type = {
                    "tp1": "tp", "tp2": "tp",
                    "sl_conditional": "sl", "sl_hard": "sl",
                    "time_warning": "exit", "time_urgent": "exit",
                    "insider_exit": "exit",
                }.get(event.event_type, "exit")

                await send_position_event(
                    session=session,
                    message=event.message,
                    priority=event.priority,
                    alert_type=alert_type,
                )
            if events:
                await session.commit()
                logger.info("position_check.events", count=len(events))
        except Exception as e:
            logger.error("position_check.error", error=str(e))
