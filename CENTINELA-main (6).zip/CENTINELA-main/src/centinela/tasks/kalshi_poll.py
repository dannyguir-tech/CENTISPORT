"""Scheduled job: poll Kalshi prices for cross-platform divergence."""

import structlog

from centinela.db.session import async_session
from centinela.services.kalshi_service import poll_all_pairs

logger = structlog.get_logger()


async def run_kalshi_poll():
    """Poll Kalshi prices and check for cross-platform divergences."""
    async with async_session() as session:
        try:
            divergences = await poll_all_pairs(session)
            if divergences > 0:
                logger.info("kalshi_poll.divergences", count=divergences)
        except Exception as e:
            logger.error("kalshi_poll.error", error=str(e))
