"""Scheduled job: recalculate all wallet scores."""

import structlog

from centinela.db.session import async_session
from centinela.services.scoring_engine import recalculate_all_scores

logger = structlog.get_logger()


async def run_score_recalc():
    """Full recalculation of insider scores for all active wallets."""
    async with async_session() as session:
        try:
            updated = await recalculate_all_scores(session)
            logger.info("score_recalc.complete", wallets_updated=updated)
        except Exception as e:
            logger.error("score_recalc.error", error=str(e))
