"""Scheduled job: sync market metadata from Gamma API."""

import structlog

from centinela.db.session import async_session
from centinela.services.market_service import sync_markets

logger = structlog.get_logger()


async def run_market_sync():
    """Sync active market metadata from Polymarket Gamma API."""
    async with async_session() as session:
        try:
            count = await sync_markets(session)
            if count > 0:
                logger.info("market_sync.complete", markets=count)
        except Exception as e:
            logger.error("market_sync.error", error=str(e))
