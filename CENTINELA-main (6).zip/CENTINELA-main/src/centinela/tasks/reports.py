"""Scheduled reporting: weekly and monthly performance reports via Telegram."""

import structlog

from centinela.db.session import async_session
from centinela.services.reporting import generate_performance_report, format_report_for_telegram
from centinela.services.telegram_bot import send_message

logger = structlog.get_logger()


async def run_weekly_report():
    """Generate and send weekly performance report."""
    async with async_session() as session:
        try:
            report = await generate_performance_report(session, "weekly")
            if report["tradesTotal"] > 0:
                text = format_report_for_telegram(report)
                await send_message(text)
                logger.info("reports.weekly_sent", trades=report["tradesTotal"])
        except Exception as e:
            logger.error("reports.weekly_error", error=str(e))


async def run_monthly_report():
    """Generate and send monthly performance report."""
    async with async_session() as session:
        try:
            report = await generate_performance_report(session, "monthly")
            if report["tradesTotal"] > 0:
                text = format_report_for_telegram(report)
                await send_message(text)
                logger.info("reports.monthly_sent", trades=report["tradesTotal"])
        except Exception as e:
            logger.error("reports.monthly_error", error=str(e))
