"""Scheduled jobs for Phase 3 edge expansion:
- Consensus detection (3+ insiders same side)
- Convergence detection (smart + dumb opposite sides)
- Dumb money scoring
- Wash trade scanning
"""

import structlog

from centinela.db.session import async_session
from centinela.dependencies import get_redis
from centinela.services.cluster_detection import consensus_cluster_discount
from centinela.services.consensus import detect_consensus, detect_convergence
from centinela.services.dumb_money import score_dumb_wallets
from centinela.services.shadow_tracking import record_shadow
from centinela.services.signal_throttle import can_send_alert, record_alert_sent
from centinela.services.telegram_bot import send_consensus_alert, send_convergence_alert
from centinela.services.wash_trade_filter import scan_all_wallets

logger = structlog.get_logger()


async def run_consensus_scan():
    """Scan for consensus (3+ insiders) and convergence (smart+dumb) signals."""
    async with async_session() as session:
        try:
            # Consensus detection
            consensus_signals = await detect_consensus(session)
            redis = await get_redis()

            for signal in consensus_signals:
                # Apply cluster discount — wallets in same cluster count less
                from sqlalchemy import select
                from centinela.db.models.quant import WalletCluster
                from centinela.db.models.wallet import Wallet
                from centinela.db.models.trade import Trade

                cluster_rows = await session.execute(
                    select(WalletCluster).where(WalletCluster.wallet_id.in_(signal.wallet_ids))
                )
                cluster_memberships = {
                    row.wallet_id: row.cluster_id for row in cluster_rows.scalars().all()
                }
                cluster_discount = consensus_cluster_discount(signal.wallet_ids, cluster_memberships)
                adjusted_score = signal.combined_score * cluster_discount

                allowed, _ = await can_send_alert(redis, "high", adjusted_score)
                if allowed:
                    # Build wallet info for alert
                    wallets_info = []
                    for wid in signal.wallet_ids:
                        w_result = await session.execute(select(Wallet).where(Wallet.id == wid))
                        w = w_result.scalar_one_or_none()
                        if w:
                            # Get their latest trade size in this market
                            t_result = await session.execute(
                                select(Trade)
                                .where(Trade.wallet_id == wid)
                                .where(Trade.market_name == signal.market_name)
                                .order_by(Trade.timestamp.desc())
                                .limit(1)
                            )
                            t = t_result.scalar_one_or_none()
                            size = t.size if t else 0
                            wallets_info.append((w.handle, w.insider_score, size))

                    alert = await send_consensus_alert(
                        session=session,
                        market_name=signal.market_name,
                        side=signal.side,
                        wallets=wallets_info,
                        combined_score=adjusted_score,
                        total_capital=signal.total_capital,
                    )
                    signal.alert_id = alert.id
                    await record_alert_sent(redis)
                    await record_shadow(session, alert.id, "consensus", was_taken=None)

            # Convergence detection
            convergence_signals = await detect_convergence(session)
            for signal in convergence_signals:
                allowed, _ = await can_send_alert(redis, "critical", 95)
                if allowed:
                    from sqlalchemy import select
                    from centinela.db.models.wallet import Wallet
                    from centinela.db.models.trade import Trade

                    smart_info = []
                    for wid in signal.smart_wallet_ids:
                        w_result = await session.execute(select(Wallet).where(Wallet.id == wid))
                        w = w_result.scalar_one_or_none()
                        if w:
                            t_result = await session.execute(
                                select(Trade)
                                .where(Trade.wallet_id == wid)
                                .where(Trade.market_name == signal.market_name)
                                .order_by(Trade.timestamp.desc()).limit(1)
                            )
                            t = t_result.scalar_one_or_none()
                            smart_info.append((w.handle, w.insider_score, t.size if t else 0))

                    dumb_info = []
                    for wid in signal.dumb_wallet_ids:
                        w_result = await session.execute(select(Wallet).where(Wallet.id == wid))
                        w = w_result.scalar_one_or_none()
                        if w:
                            t_result = await session.execute(
                                select(Trade)
                                .where(Trade.wallet_id == wid)
                                .where(Trade.market_name == signal.market_name)
                                .order_by(Trade.timestamp.desc()).limit(1)
                            )
                            t = t_result.scalar_one_or_none()
                            dumb_info.append((w.handle, w.inverse_score, t.size if t else 0))

                    alert = await send_convergence_alert(
                        session=session,
                        market_name=signal.market_name,
                        smart_side=signal.smart_side,
                        smart_wallets=smart_info,
                        dumb_wallets=dumb_info,
                        cross_platform_gap=signal.cross_platform_gap,
                    )
                    signal.alert_id = alert.id
                    await record_alert_sent(redis)
                    await record_shadow(session, alert.id, "convergence", was_taken=None)

            await session.commit()

            if consensus_signals or convergence_signals:
                logger.info(
                    "edge_scan.complete",
                    consensus=len(consensus_signals),
                    convergence=len(convergence_signals),
                )
        except Exception as e:
            logger.error("edge_scan.error", error=str(e))


async def run_dumb_money_scoring():
    """Rescore all wallets for dumb money classification."""
    async with async_session() as session:
        try:
            count = await score_dumb_wallets(session)
            if count > 0:
                logger.info("dumb_money_scoring.complete", dumb_wallets=count)
        except Exception as e:
            logger.error("dumb_money_scoring.error", error=str(e))


async def run_wash_trade_scan():
    """Scan all wallets for wash trading patterns."""
    async with async_session() as session:
        try:
            flagged = await scan_all_wallets(session)
            if flagged > 0:
                logger.warning("wash_trade_scan.complete", flagged=flagged)
        except Exception as e:
            logger.error("wash_trade_scan.error", error=str(e))
