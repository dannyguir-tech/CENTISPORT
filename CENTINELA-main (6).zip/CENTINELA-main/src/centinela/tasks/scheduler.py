"""APScheduler setup — registers all background jobs."""

import structlog
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from centinela.config import settings

logger = structlog.get_logger()

scheduler = AsyncIOScheduler()


def setup_scheduler() -> AsyncIOScheduler:
    """Configure and return the scheduler with all jobs registered."""
    from centinela.tasks.trade_poll import run_trade_poll
    from centinela.tasks.health_check import run_health_check
    from centinela.tasks.market_sync import run_market_sync
    from centinela.tasks.score_recalc import run_score_recalc
    from centinela.tasks.kalshi_poll import run_kalshi_poll
    from centinela.tasks.position_check import run_position_check
    from centinela.tasks.edge_scan import (
        run_consensus_scan,
        run_dumb_money_scoring,
        run_wash_trade_scan,
    )
    from centinela.tasks.quant_jobs import (
        run_adaptive_polling,
        run_copyability_scoring,
        run_edge_monitoring,
        run_pre_signal_scan,
        run_regime_detection,
        run_scoring_calibration,
        run_wallet_discovery,
        run_cluster_detection,
        run_leader_detection,
        run_position_building_check,
    )
    from centinela.tasks.reports import run_weekly_report, run_monthly_report

    scheduler.add_job(
        run_trade_poll,
        "interval",
        seconds=settings.trade_poll_interval,
        id="trade_poll",
        name="Poll for new trades",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_health_check,
        "interval",
        seconds=settings.health_check_interval,
        id="health_check",
        name="System health check",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_market_sync,
        "interval",
        seconds=settings.market_sync_interval,
        id="market_sync",
        name="Sync market metadata",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_score_recalc,
        "interval",
        seconds=settings.score_recalc_interval,
        id="score_recalc",
        name="Recalculate wallet scores",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_kalshi_poll,
        "interval",
        seconds=settings.kalshi_poll_interval,
        id="kalshi_poll",
        name="Poll Kalshi prices",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_position_check,
        "interval",
        seconds=settings.position_check_interval,
        id="position_check",
        name="Check positions for TP/SL/time exits",
        max_instances=1,
        coalesce=True,
    )

    # Phase 3: Edge expansion jobs
    scheduler.add_job(
        run_consensus_scan,
        "interval",
        seconds=60,  # Check every minute for consensus/convergence
        id="consensus_scan",
        name="Scan for consensus and convergence signals",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_dumb_money_scoring,
        "interval",
        seconds=21600,  # Every 6 hours (alongside score recalc)
        id="dumb_money_scoring",
        name="Rescore dumb money wallets",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_wash_trade_scan,
        "interval",
        seconds=86400,  # Daily
        id="wash_trade_scan",
        name="Scan for wash trading",
        max_instances=1,
        coalesce=True,
    )

    # Phase 4: Quant foundation jobs
    scheduler.add_job(
        run_edge_monitoring,
        "interval",
        seconds=3600,  # Hourly
        id="edge_monitoring",
        name="Edge state evaluation (GREEN/YELLOW/RED)",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_scoring_calibration,
        "interval",
        seconds=2419200,  # Every 4 weeks
        id="scoring_calibration",
        name="Recalibrate scoring weights",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_wallet_discovery,
        "interval",
        seconds=604800,  # Weekly
        id="wallet_discovery",
        name="Leaderboard wallet discovery",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_cluster_detection,
        "interval",
        seconds=86400,  # Daily
        id="cluster_detection",
        name="Wallet cluster detection",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_leader_detection,
        "interval",
        seconds=21600,  # Every 6 hours
        id="leader_detection",
        name="Leader/follower scoring",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_copyability_scoring,
        "interval",
        seconds=21600,  # Every 6 hours (alongside score recalc)
        id="copyability_scoring",
        name="Copyability score computation",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_pre_signal_scan,
        "interval",
        seconds=300,  # Every 5 minutes
        id="pre_signal_scan",
        name="Pre-signal flag detection",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_position_building_check,
        "interval",
        seconds=300,  # Every 5 minutes
        id="position_building",
        name="Check 50% positions for topup",
        max_instances=1,
        coalesce=True,
    )

    # Phase 5: Quant intelligence jobs
    scheduler.add_job(
        run_regime_detection,
        "interval",
        seconds=300,  # Every 5 minutes
        id="regime_detection",
        name="Market regime classification",
        max_instances=1,
        coalesce=True,
    )

    scheduler.add_job(
        run_adaptive_polling,
        "interval",
        seconds=300,  # Every 5 minutes
        id="adaptive_polling",
        name="Adaptive poll priority tiers",
        max_instances=1,
        coalesce=True,
    )

    # Phase 6: Reporting
    scheduler.add_job(
        run_weekly_report,
        "cron",
        day_of_week="mon",
        hour=8,
        minute=0,
        id="weekly_report",
        name="Weekly performance report",
        max_instances=1,
    )

    scheduler.add_job(
        run_monthly_report,
        "cron",
        day=1,
        hour=8,
        minute=0,
        id="monthly_report",
        name="Monthly performance report",
        max_instances=1,
    )

    logger.info(
        "scheduler.configured",
        trade_poll=f"{settings.trade_poll_interval}s",
        market_sync=f"{settings.market_sync_interval}s",
        score_recalc=f"{settings.score_recalc_interval}s",
        kalshi_poll=f"{settings.kalshi_poll_interval}s",
        position_check=f"{settings.position_check_interval}s",
        consensus_scan="60s",
        dumb_money_scoring="6h",
        wash_trade_scan="daily",
        regime_detection="300s",
        adaptive_polling="300s",
    )
    return scheduler
