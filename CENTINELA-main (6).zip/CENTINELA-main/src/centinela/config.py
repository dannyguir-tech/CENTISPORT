from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql+asyncpg://centinela:changeme@localhost:5432/centinela"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Telegram (empty = disabled)
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # Kalshi
    kalshi_api_base: str = "https://trading-api.kalshi.com/trade-api/v2"

    # Polymarket APIs
    polymarket_data_api: str = "https://data-api.polymarket.com"
    polymarket_gamma_api: str = "https://gamma-api.polymarket.com"
    polymarket_clob_api: str = "https://clob.polymarket.com"
    polymarket_ws_url: str = "wss://ws-subscriptions-clob.polymarket.com/ws/market"

    # Polling intervals (seconds)
    trade_poll_interval: int = 10
    kalshi_poll_interval: int = 60
    market_sync_interval: int = 300
    score_recalc_interval: int = 21600  # 6 hours
    health_check_interval: int = 30
    position_check_interval: int = 30  # check TP/SL/time exits

    # Chase risk
    chase_risk_default_threshold: float = 0.03  # 3%
    chase_risk_volatility_multiplier: float = 1.5
    signal_max_age_seconds: int = 900  # 15 minutes

    # Slippage
    max_slippage_pct: float = 0.02  # 2%
    slippage_hard_cap_pct: float = 0.05  # 5% = signal expires

    # Bankroll defaults
    default_total_capital: float = 10000.0
    default_kelly_fraction: float = 0.25

    # Signal throttling
    max_alerts_per_hour: int = 5
    max_alerts_per_day: int = 20
    quality_floor: float = 70.0  # min combined_score to send alert
    quiet_hours_start: int = 23  # 11pm
    quiet_hours_end: int = 7    # 7am

    # CORS — comma-separated list of allowed origins when credentials are needed.
    # Empty (default) → wildcard origin with credentials disabled.
    cors_origins: str = ""

    # Trade management
    tp1_pct: float = 0.20  # +20%
    tp2_pct: float = 0.35  # +35%
    sl_conditional_pct: float = 0.15  # -15% if insider exited
    sl_hard_pct: float = 0.30         # -30% hard floor

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.telegram_bot_token and self.telegram_chat_id)

    model_config = {"env_file": ".env", "extra": "ignore"}


settings = Settings()
