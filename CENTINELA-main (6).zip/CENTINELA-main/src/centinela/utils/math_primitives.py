"""Math primitives used across the scoring engine and signal calculations.

All outputs are bounded and production-safe. No unbounded results.
"""

import math


def clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    """Clamp value to [lo, hi] range."""
    return max(lo, min(hi, value))


def safe_div(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Safe division that returns default on zero denominator."""
    if denominator == 0:
        return default
    return numerator / denominator


def score100(raw: float) -> float:
    """Normalize any raw value to 0-100 range using clamp."""
    return clamp(raw, 0.0, 100.0)


def sigmoid(x: float, midpoint: float = 0.0, steepness: float = 1.0) -> float:
    """Sigmoid function mapping (-inf, inf) to (0, 1)."""
    try:
        return 1.0 / (1.0 + math.exp(-steepness * (x - midpoint)))
    except OverflowError:
        return 0.0 if x < midpoint else 1.0


def confidence_multiplier(trade_count: int, max_trades: int = 200) -> float:
    """Confidence multiplier based on sample size: sqrt(min(n, max) / max)."""
    return math.sqrt(min(trade_count, max_trades) / max_trades)


def herfindahl_index(distribution: dict[str, int]) -> float:
    """Herfindahl-Hirschman Index for measuring concentration.

    Returns 0-1 where 1 = all trades in one category (specialist).
    """
    total = sum(distribution.values())
    if total == 0:
        return 0.0
    return sum((count / total) ** 2 for count in distribution.values())


def sharpe_ratio(returns: list[float]) -> float:
    """Sharpe ratio: mean / std of returns. Returns 0 if insufficient data."""
    if len(returns) < 2:
        return 0.0
    mean = sum(returns) / len(returns)
    variance = sum((r - mean) ** 2 for r in returns) / (len(returns) - 1)
    std = math.sqrt(variance) if variance > 0 else 0.0
    return safe_div(mean, std)


def decay(dt: float, tau: float) -> float:
    """Exponential decay: exp(-dt / tau)."""
    if tau <= 0:
        return 0.0
    return math.exp(-dt / tau)


def z_clamped(x: float, mu: float, sigma: float, zmax: float = 3.0) -> float:
    """Z-score clamped to [-zmax, zmax]."""
    return clamp(safe_div(x - mu, sigma, 0.0), -zmax, zmax)


def sample_conf(n: int, n_ref: int) -> float:
    """Sample confidence: sqrt(clamp(n / n_ref, 0, 1))."""
    return math.sqrt(clamp(n / n_ref, 0.0, 1.0))
