"""Token bucket rate limiter for API calls."""

import asyncio
import time


class RateLimiter:
    """Simple token bucket rate limiter.

    Args:
        rate: Maximum requests per second.
        burst: Maximum burst size (bucket capacity).
    """

    def __init__(self, rate: float = 2.0, burst: int = 5):
        self.rate = rate
        self.burst = burst
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        """Wait until a token is available, then consume it."""
        async with self._lock:
            while True:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return
                # Wait for one token to be available
                wait_time = (1.0 - self._tokens) / self.rate
                await asyncio.sleep(wait_time)

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.burst, self._tokens + elapsed * self.rate)
        self._last_refill = now
