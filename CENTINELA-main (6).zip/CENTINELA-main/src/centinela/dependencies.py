from typing import Annotated

import redis.asyncio as aioredis
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.config import settings
from centinela.db.session import get_session

SessionDep = Annotated[AsyncSession, Depends(get_session)]

_redis_pool: aioredis.Redis | None = None


async def get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _redis_pool


RedisDep = Annotated[aioredis.Redis, Depends(get_redis)]
