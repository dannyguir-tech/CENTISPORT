"""Edge decay monitoring — GREEN/YELLOW/RED strategy state with auto-response.

GREEN: rolling 30d PnL positive AND avg edge > 0 AND win rate > 52%
  → Normal trading, normal sizes

YELLOW: rolling 30d PnL declining 20%+ from peak OR WR < 52%
  → Reduce ALL sizes 50%, alert daily

RED: rolling 30d PnL negative OR avg edge < 0 for 2+ weeks
  → HALT all new trade alerts, monitoring only
"""

from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.execution import Bankroll, Position
from centinela.db.models.quant import EdgeMonitoring
from centinela.services.bankroll import get_or_create_bankroll

logger = structlog.get_logger()


async def evaluate_edge_state(session: AsyncSession) -> tuple[str, str | None]:
    """Evaluate the current edge state based on rolling metrics.

    Returns (new_state, context_text_if_changed).
    """
    bankroll = await get_or_create_bankroll(session)

    # Get closed positions from last 30 days for metrics
    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=30)
    result = await session.execute(
        select(Position)
        .where(Position.status == "closed")
        .where(Position.time_entered >= cutoff)
    )
    closed = list(result.scalars().all())

    # Calculate rolling metrics
    total_pnl = sum(p.realized_pnl or 0 for p in closed)
    wins = sum(1 for p in closed if (p.realized_pnl or 0) > 0)
    total = len(closed) if closed else 1
    win_rate = wins / total
    avg_edge = total_pnl / total if total > 0 else 0

    # Get previous state
    prev_result = await session.execute(
        select(EdgeMonitoring).order_by(EdgeMonitoring.timestamp.desc()).limit(1)
    )
    prev = prev_result.scalar_one_or_none()
    prev_state = prev.strategy_state if prev else "green"
    pnl_peak = prev.rolling_30d_pnl_peak if prev else 0

    # Track PnL peak
    pnl_peak = max(pnl_peak, total_pnl)

    # Evaluate state
    new_state = "green"
    context = ""

    # RED: rolling 30d PnL negative OR avg edge < 0 for 2+ weeks
    two_weeks_ago = datetime.now(tz=timezone.utc) - timedelta(weeks=2)
    has_two_weeks_data = any(
        p.time_entered and p.time_entered <= two_weeks_ago for p in closed
    ) if closed else False

    if total_pnl < 0 or (avg_edge < 0 and len(closed) >= 10 and has_two_weeks_data):
        new_state = "red"
        context = (
            f"Rolling 30d PnL: ${total_pnl:+,.0f} (negative)\n"
            f"   Win rate: {win_rate*100:.0f}% | Avg edge: ${avg_edge:+,.0f}/trade"
        )
    elif pnl_peak > 0 and total_pnl < pnl_peak * 0.80:
        # PnL declined 20%+ from peak
        new_state = "yellow"
        decline_pct = (1 - total_pnl / pnl_peak) * 100 if pnl_peak > 0 else 0
        context = (
            f"Rolling 30d PnL: ${total_pnl:+,.0f} ({decline_pct:.0f}% below peak)\n"
            f"   Win rate: {win_rate*100:.0f}% | Avg edge: ${avg_edge:+,.0f}/trade"
        )
    elif win_rate < 0.52 and len(closed) >= 10:
        new_state = "yellow"
        context = (
            f"Win rate dropped to {win_rate*100:.0f}% (below 52%)\n"
            f"   Rolling 30d PnL: ${total_pnl:+,.0f}"
        )

    # Determine size multiplier
    multiplier = {"green": 1.0, "yellow": 0.5, "red": 0.0}[new_state]

    # Record monitoring snapshot
    snapshot = EdgeMonitoring(
        rolling_30d_pnl=total_pnl,
        rolling_30d_pnl_peak=pnl_peak,
        avg_edge_per_trade=avg_edge,
        win_rate=win_rate,
        strategy_state=new_state,
        prev_state=prev_state,
        position_size_multiplier=multiplier,
    )
    session.add(snapshot)

    # Update bankroll state
    bankroll.strategy_state = new_state
    await session.flush()

    # Return state change info if changed
    if new_state != prev_state:
        logger.warning(
            "edge_monitoring.state_change",
            old=prev_state,
            new=new_state,
            pnl=f"${total_pnl:+,.0f}",
            wr=f"{win_rate*100:.0f}%",
        )
        return new_state, context

    return new_state, None
