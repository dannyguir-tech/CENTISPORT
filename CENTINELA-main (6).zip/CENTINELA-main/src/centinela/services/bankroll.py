"""Bankroll manager — capital limits, daily/weekly lockout, strategy state.

Rules:
- max_per_market: 5% of bankroll
- max_per_category: 30% of bankroll
- max_concurrent_positions: 12
- Daily loss -5% -> LOCKOUT until next day
- Weekly loss -10% -> LOCKOUT until Monday
- Strategy state: GREEN/YELLOW/RED circuit breaker
"""

from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.config import settings
from centinela.db.models.execution import Bankroll, Position

logger = structlog.get_logger()


async def get_or_create_bankroll(session: AsyncSession) -> Bankroll:
    """Get the singleton bankroll record, creating if needed."""
    result = await session.execute(select(Bankroll).limit(1))
    bankroll = result.scalar_one_or_none()
    if bankroll is None:
        bankroll = Bankroll(
            total_capital=settings.default_total_capital,
            available_capital=settings.default_total_capital,
        )
        session.add(bankroll)
        await session.flush()
    return bankroll


async def get_open_positions(session: AsyncSession) -> list[Position]:
    """Get all currently open positions."""
    result = await session.execute(
        select(Position).where(Position.status.in_(["open", "partial"]))
    )
    return list(result.scalars().all())


async def check_lockout(session: AsyncSession) -> tuple[bool, str | None]:
    """Check if we're in lockout. Returns (is_locked, reason)."""
    bankroll = await get_or_create_bankroll(session)

    # Check if existing lockout has expired
    if bankroll.is_locked_out and bankroll.lockout_until:
        now = datetime.now(tz=timezone.utc)
        lockout_until = bankroll.lockout_until
        if lockout_until.tzinfo is None:
            lockout_until = lockout_until.replace(tzinfo=timezone.utc)
        if now >= lockout_until:
            bankroll.is_locked_out = False
            bankroll.lockout_until = None
            bankroll.lockout_reason = None
            await session.flush()
            return False, None

    if bankroll.is_locked_out:
        return True, bankroll.lockout_reason

    # Check daily loss limit
    daily_loss_pct = abs(bankroll.daily_pnl) / bankroll.total_capital if bankroll.daily_pnl < 0 else 0
    if daily_loss_pct >= bankroll.daily_loss_limit:
        tomorrow = datetime.now(tz=timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        ) + timedelta(days=1)
        bankroll.is_locked_out = True
        bankroll.lockout_until = tomorrow
        bankroll.lockout_reason = f"Daily loss limit reached ({bankroll.daily_pnl:+.0f})"
        await session.flush()
        return True, bankroll.lockout_reason

    # Check weekly loss limit
    weekly_loss_pct = abs(bankroll.weekly_pnl) / bankroll.total_capital if bankroll.weekly_pnl < 0 else 0
    if weekly_loss_pct >= bankroll.weekly_loss_limit:
        now = datetime.now(tz=timezone.utc)
        days_until_monday = (7 - now.weekday()) % 7 or 7
        next_monday = now.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) + timedelta(days=days_until_monday)
        bankroll.is_locked_out = True
        bankroll.lockout_until = next_monday
        bankroll.lockout_reason = f"Weekly loss limit reached ({bankroll.weekly_pnl:+.0f})"
        await session.flush()
        return True, bankroll.lockout_reason

    return False, None


async def check_strategy_state(session: AsyncSession) -> str:
    """Get current strategy state (green/yellow/red)."""
    bankroll = await get_or_create_bankroll(session)
    return bankroll.strategy_state


async def check_portfolio_limits(
    session: AsyncSession,
    market_id: int | None,
    category: str | None,
    position_size: float,
    signal_score: float,
) -> tuple[bool, str | None]:
    """Check portfolio-level limits before opening a new position.

    Returns (ok, warning_message).
    """
    bankroll = await get_or_create_bankroll(session)
    positions = await get_open_positions(session)

    # Check max concurrent positions
    if len(positions) >= bankroll.max_concurrent_positions:
        if signal_score < 85:
            return False, f"Max positions reached ({len(positions)}/{bankroll.max_concurrent_positions}) — need score > 85"
        # Allow override for very high scores

    # Check market exposure
    market_exposure = sum(p.current_size for p in positions if p.market_id == market_id)
    max_market = bankroll.total_capital * bankroll.max_per_market_pct
    if market_exposure + position_size > max_market:
        return False, f"Market exposure ${market_exposure + position_size:,.0f} exceeds {bankroll.max_per_market_pct*100:.0f}% limit (${max_market:,.0f})"

    # Check category exposure
    warning = None
    if category:
        cat_exposure = sum(p.current_size for p in positions if p.category == category)
        max_cat = bankroll.total_capital * bankroll.max_per_category_pct
        cat_pct = (cat_exposure + position_size) / bankroll.total_capital * 100
        if cat_exposure + position_size > max_cat:
            return False, f"{category} exposure ${cat_exposure + position_size:,.0f} exceeds {bankroll.max_per_category_pct*100:.0f}% limit"
        elif cat_pct > 20:
            warning = f"This increases {category} concentration to {cat_pct:.0f}%"

    # Check strategy state
    state = bankroll.strategy_state
    if state == "red":
        return False, "Strategy state RED — all new signals halted"

    return True, warning


async def update_deployed_capital(session: AsyncSession) -> None:
    """Recalculate deployed vs available capital from open positions."""
    bankroll = await get_or_create_bankroll(session)
    positions = await get_open_positions(session)
    deployed = sum(p.current_size for p in positions)
    bankroll.deployed_capital = deployed
    bankroll.available_capital = bankroll.total_capital - deployed
    await session.flush()


def format_bankroll_line(bankroll: Bankroll, open_count: int) -> str:
    """Format bankroll status for inclusion in alerts."""
    deployed_pct = (bankroll.deployed_capital / bankroll.total_capital * 100) if bankroll.total_capital > 0 else 0
    state_emoji = {"green": "\U0001F7E2", "yellow": "\U0001F7E1", "red": "\U0001F6D1"}.get(bankroll.strategy_state, "\U0001F7E2")
    return (
        f"\U0001F4CB Bankroll: ${bankroll.total_capital:,.0f} | "
        f"Deployed: {deployed_pct:.0f}% | "
        f"Positions: {open_count}/{bankroll.max_concurrent_positions}\n"
        f"   Daily P&L: {bankroll.daily_pnl:+,.0f} | State: {state_emoji} {bankroll.strategy_state.upper()}"
    )
