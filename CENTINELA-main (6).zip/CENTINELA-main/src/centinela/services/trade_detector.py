"""Trade detector — polls Data API for new trades from tracked wallets.

Architecture:
- Maintains per-wallet last-seen timestamp in Redis
- Every poll cycle, queries Data API for trades newer than last seen
- Deduplicates by polymarket_trade_id
- Inserts new trades and publishes events to Redis pub/sub
"""

from datetime import datetime, timezone

import redis.asyncio as aioredis
import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_data import polymarket_data
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.services.wallet_tracker import _extract_trade_id, _parse_float, _parse_timestamp

logger = structlog.get_logger()

LAST_TS_PREFIX = "centinela:wallet_last_ts:"
NEW_TRADE_CHANNEL = "centinela:new_trade"


async def poll_all_wallets(session: AsyncSession, redis: aioredis.Redis) -> int:
    """Poll Data API for new trades across all active wallets.

    Returns total number of new trades detected.
    """
    result = await session.execute(select(Wallet).where(Wallet.is_active == True))  # noqa: E712
    wallets = result.scalars().all()

    total_new = 0
    for wallet in wallets:
        try:
            count = await poll_wallet(session, redis, wallet)
            total_new += count
        except Exception as e:
            logger.error("trade_detector.poll_error", wallet=wallet.address, error=str(e))

    if total_new > 0:
        await session.commit()
        logger.info("trade_detector.poll_complete", new_trades=total_new, wallets=len(wallets))

    return total_new


async def poll_wallet(
    session: AsyncSession, redis: aioredis.Redis, wallet: Wallet
) -> int:
    """Poll for new trades from a single wallet.

    Returns number of new trades found.
    """
    # Get last-seen timestamp from Redis
    last_ts_str = await redis.get(f"{LAST_TS_PREFIX}{wallet.address}")
    last_ts = float(last_ts_str) if last_ts_str else 0.0

    # Fetch recent activity
    raw_trades = await polymarket_data.get_activity(wallet.address, limit=50)
    if not raw_trades:
        return 0

    new_count = 0
    latest_ts = last_ts

    for raw in raw_trades:
        trade_id = _extract_trade_id(raw)
        if not trade_id:
            continue

        # Parse timestamp and check if newer
        timestamp = _parse_timestamp(raw.get("timestamp", raw.get("createdAt", "")))
        trade_ts = timestamp.timestamp()
        if trade_ts <= last_ts:
            continue

        # Dedup check in DB
        exists = await session.execute(
            select(Trade.id).where(Trade.polymarket_trade_id == trade_id)
        )
        if exists.scalar_one_or_none() is not None:
            latest_ts = max(latest_ts, trade_ts)
            continue

        # Determine if first entry in this market
        condition_id = raw.get("conditionId", raw.get("condition_id", ""))
        market_name = raw.get("title", raw.get("question", raw.get("market", "Unknown")))

        existing_in_market = await session.execute(
            select(Trade.id)
            .where(Trade.wallet_id == wallet.id)
            .where(Trade.market_name == market_name)
            .limit(1)
        )
        is_first = existing_in_market.scalar_one_or_none() is None

        # Resolve market_id from condition_id or token_id
        market_id = None
        if condition_id:
            market_result = await session.execute(
                select(Market).where(
                    (Market.polymarket_id == condition_id)
                    | (Market.token_id_yes == condition_id)
                    | (Market.token_id_no == condition_id)
                ).limit(1)
            )
            market_row = market_result.scalar_one_or_none()
            if market_row:
                market_id = market_row.id

        side = raw.get("side", raw.get("outcome", "YES")).upper()
        if side not in ("YES", "NO"):
            side = "YES"

        trade = Trade(
            wallet_id=wallet.id,
            polymarket_trade_id=trade_id,
            market_name=market_name,
            market_id=market_id,
            side=side,
            size=_parse_float(raw.get("size", raw.get("amount", 0))),
            price=_parse_float(raw.get("price", raw.get("avgPrice", 0))),
            timestamp=timestamp,
            is_first_entry=is_first,
            transaction_hash=raw.get("transactionHash", raw.get("transaction_hash")),
        )
        session.add(trade)
        await session.flush()  # get trade.id
        new_count += 1
        latest_ts = max(latest_ts, trade_ts)

        # Publish new trade event
        await redis.publish(
            NEW_TRADE_CHANNEL,
            f"{wallet.id}:{wallet.address}:{trade_id}:{market_name}:{side}",
        )

        logger.info(
            "trade_detector.new_trade",
            wallet=wallet.handle,
            market=market_name,
            side=side,
            size=trade.size,
        )

        # Run signal pipeline (decision engine + alert)
        try:
            from centinela.services.signal_pipeline import process_new_trade

            decision = await process_new_trade(session, redis, trade, wallet)
            logger.info(
                "trade_detector.signal_result",
                wallet=wallet.handle,
                market=market_name,
                decision=decision,
            )
        except Exception as e:
            logger.error("trade_detector.pipeline_error", error=str(e))

    # Update last-seen timestamp
    if latest_ts > last_ts:
        await redis.set(f"{LAST_TS_PREFIX}{wallet.address}", str(latest_ts))

    # Update wallet last_trade_at
    if new_count > 0:
        wallet.total_trades = (wallet.total_trades or 0) + new_count
        wallet.last_trade_at = datetime.now(tz=timezone.utc)

    return new_count
