"""Wash trade filter — detect fake/inflated wallets.

Flag wallet if ANY of:
- > 20% of trades have an immediate opposing trade within 5 minutes
- Net exposure across all positions is consistently near zero
- High-frequency trading (> 100 trades/day) with near-zero net PnL

Action: exclude from watchlist, mark wash_suspected=True in database.
Do not score. Do not alert.
"""

from collections import defaultdict
from datetime import timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()

OPPOSING_TRADE_WINDOW_SECONDS = 300  # 5 minutes
OPPOSING_TRADE_THRESHOLD = 0.20  # 20%
HFT_DAILY_THRESHOLD = 100


async def check_wash_trading(session: AsyncSession, wallet: Wallet) -> bool:
    """Analyze a wallet's trades for wash trading patterns.

    Returns True if wash trading is suspected.
    """
    result = await session.execute(
        select(Trade)
        .where(Trade.wallet_id == wallet.id)
        .order_by(Trade.timestamp.asc())
    )
    trades = list(result.scalars().all())

    if len(trades) < 20:
        return False

    # Check 1: Opposing trades within 5 minutes
    opposing_count = _count_opposing_trades(trades)
    opposing_ratio = opposing_count / len(trades) if trades else 0
    if opposing_ratio > OPPOSING_TRADE_THRESHOLD:
        logger.info("wash_filter.opposing_trades", wallet=wallet.handle, ratio=f"{opposing_ratio:.1%}")
        return True

    # Check 2: High frequency with near-zero P&L
    if _is_hft_zero_pnl(trades):
        logger.info("wash_filter.hft_zero_pnl", wallet=wallet.handle)
        return True

    # Check 3: Net exposure near zero
    if _is_net_zero_exposure(trades):
        logger.info("wash_filter.net_zero_exposure", wallet=wallet.handle)
        return True

    return False


async def scan_all_wallets(session: AsyncSession) -> int:
    """Scan all active wallets for wash trading. Returns count flagged."""
    result = await session.execute(
        select(Wallet).where(Wallet.is_active == True)  # noqa: E712
    )
    wallets = result.scalars().all()
    flagged = 0

    for wallet in wallets:
        is_wash = await check_wash_trading(session, wallet)
        if is_wash and not wallet.wash_suspected:
            wallet.wash_suspected = True
            flagged += 1
            logger.warning("wash_filter.flagged", wallet=wallet.handle)
        elif not is_wash and wallet.wash_suspected:
            wallet.wash_suspected = False  # Clear if no longer suspicious

    await session.commit()
    return flagged


def _count_opposing_trades(trades: list[Trade]) -> int:
    """Count trades that have an immediate opposing trade in the same market
    within 5 minutes."""
    count = 0
    for i, t1 in enumerate(trades):
        for t2 in trades[i + 1:]:
            if t2.market_name != t1.market_name:
                continue
            t1_ts = t1.timestamp
            t2_ts = t2.timestamp
            if hasattr(t1_ts, 'timestamp') and hasattr(t2_ts, 'timestamp'):
                delta = abs(t2_ts.timestamp() - t1_ts.timestamp())
            else:
                delta = abs((t2_ts - t1_ts).total_seconds())
            if delta > OPPOSING_TRADE_WINDOW_SECONDS:
                break  # trades are sorted by time, no more matches
            if t2.side != t1.side:
                count += 1
                break
    return count


def _is_hft_zero_pnl(trades: list[Trade]) -> bool:
    """Check if wallet is high-frequency with near-zero net P&L."""
    if len(trades) < 50:
        return False

    # Group trades by day
    daily_counts: dict[str, int] = defaultdict(int)
    for t in trades:
        day = t.timestamp.strftime("%Y-%m-%d") if hasattr(t.timestamp, 'strftime') else "unknown"
        daily_counts[day] += 1

    if not daily_counts:
        return False

    avg_daily = sum(daily_counts.values()) / len(daily_counts)

    # High frequency: > 100 trades/day average
    if avg_daily < HFT_DAILY_THRESHOLD:
        return False

    # Near-zero net P&L: total buy value ≈ total sell value
    total_buy = sum(t.size for t in trades if t.side == "YES")
    total_sell = sum(t.size for t in trades if t.side == "NO")
    total = total_buy + total_sell
    if total == 0:
        return False

    imbalance = abs(total_buy - total_sell) / total
    return imbalance < 0.05  # < 5% imbalance = likely wash


def _is_net_zero_exposure(trades: list[Trade]) -> bool:
    """Check if net exposure across positions is consistently near zero."""
    # Group by market, compute net direction
    market_exposure: dict[str, float] = defaultdict(float)
    for t in trades:
        direction = 1.0 if t.side == "YES" else -1.0
        market_exposure[t.market_name] += t.size * direction

    if not market_exposure:
        return False

    # Calculate what fraction of markets have near-zero exposure
    near_zero = sum(1 for exp in market_exposure.values() if abs(exp) < 100)  # < $100 net
    ratio = near_zero / len(market_exposure)
    return ratio > 0.7  # > 70% of markets have near-zero exposure
