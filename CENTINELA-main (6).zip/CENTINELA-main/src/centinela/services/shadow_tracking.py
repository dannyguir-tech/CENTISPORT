"""Shadow tracking — phantom PnL on skipped signals, missed opportunity cost.

For every signal:
1. Log: was it taken? (from Telegram TOOK/SKIP reply)
2. Track outcome regardless
3. Compute:
   - execution_rate = taken / total
   - missed_opportunity = sum of skipped signals that won
   - regret_cost = sum of taken signals that lost

Monthly insight: "You took 34 of 67 signals (51%). Actual PnL: +$2,400.
If you took all: +$4,100. Net missed opportunity: $1,700."
"""

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.alert import Alert
from centinela.db.models.execution import Position
from centinela.db.models.quant import ShadowTracking

logger = structlog.get_logger()


async def record_shadow(
    session: AsyncSession,
    alert_id: int | None,
    signal_type: str,
    was_taken: bool | None,
    skip_reason: str | None = None,
) -> ShadowTracking:
    """Record a shadow tracking entry.

    alert_id may be None for skipped/throttled signals (no Alert row was created).
    Do NOT pass 0 as a sentinel — that causes MultipleResultsFound on update.
    """
    # Coerce legacy sentinel 0 to None for backward compatibility
    if alert_id == 0:
        alert_id = None
    shadow = ShadowTracking(
        alert_id=alert_id,
        signal_type=signal_type,
        was_taken=was_taken,
        skip_reason=skip_reason,
    )
    session.add(shadow)
    return shadow


async def update_shadow_pnl(
    session: AsyncSession,
    alert_id: int | None,
    phantom_pnl: float,
    actual_pnl: float | None = None,
) -> None:
    """Update phantom and actual PnL for a shadow tracking entry.

    No-op if alert_id is None/0 — those are skipped signals with no Alert.
    Uses .first() not .scalar_one_or_none() as a defensive guard against
    any legacy rows with duplicate sentinel alert_ids.
    """
    if not alert_id:
        return
    result = await session.execute(
        select(ShadowTracking).where(ShadowTracking.alert_id == alert_id).limit(1)
    )
    shadow = result.scalars().first()
    if shadow:
        shadow.phantom_pnl = phantom_pnl
        shadow.actual_pnl = actual_pnl
        if shadow.was_taken is False and phantom_pnl > 0:
            shadow.missed_opportunity = phantom_pnl  # Profit you left on table


async def get_shadow_summary(session: AsyncSession, days: int = 30) -> dict:
    """Get shadow tracking summary for the last N days.

    Returns execution metrics matching the spec's monthly insight format.
    """
    from datetime import datetime, timezone, timedelta

    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=days)

    result = await session.execute(
        select(ShadowTracking).where(ShadowTracking.timestamp >= cutoff)
    )
    entries = list(result.scalars().all())

    total = len(entries)
    taken = sum(1 for e in entries if e.was_taken is True)
    skipped = sum(1 for e in entries if e.was_taken is False)

    # PnL metrics
    taken_pnl = sum(e.actual_pnl or 0 for e in entries if e.was_taken is True)
    phantom_pnl = sum(e.phantom_pnl or 0 for e in entries if e.phantom_pnl is not None)
    all_signals_pnl = sum(e.phantom_pnl or 0 for e in entries)

    missed_wins = sum(
        e.phantom_pnl or 0
        for e in entries
        if e.was_taken is False and (e.phantom_pnl or 0) > 0
    )
    skipped_saves = sum(
        abs(e.phantom_pnl or 0)
        for e in entries
        if e.was_taken is False and (e.phantom_pnl or 0) < 0
    )

    return {
        "period_days": days,
        "total_signals": total,
        "taken": taken,
        "skipped": skipped,
        "execution_rate": taken / total if total > 0 else 0,
        "actual_pnl": taken_pnl,
        "all_signals_pnl": all_signals_pnl,
        "missed_opportunity": missed_wins,
        "skipped_saves": skipped_saves,
        "net_missed": missed_wins - skipped_saves,
    }
