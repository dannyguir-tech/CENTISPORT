"""Funding intelligence — detect new-wallet bursts and coordinated market bursts.

Event types:
  new_wallet_burst:          Wallet added recently AND trading aggressively early.
  coordinated_market_burst:  Multiple tracked wallets hit the same market within a short window.
"""

from datetime import datetime, timedelta, timezone

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import FundingEvent
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()

NEW_WALLET_WINDOW_HOURS = 48
COORDINATED_BURST_WINDOW_HOURS = 6
COORDINATED_MIN_WALLETS = 3
DEDUPE_WINDOW_HOURS = 12


def _to_utc(dt: datetime | None) -> datetime | None:
    """Normalize a datetime to UTC. Returns None if dt is None."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


async def _recent_event_exists(
    session: AsyncSession,
    wallet_id: int,
    event_type: str,
    within_hours: float = DEDUPE_WINDOW_HOURS,
) -> bool:
    """Check if a recent event of the given type already exists for this wallet."""
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=within_hours)
    result = await session.execute(
        select(FundingEvent.id)
        .where(FundingEvent.wallet_id == wallet_id)
        .where(FundingEvent.event_type == event_type)
        .where(FundingEvent.timestamp >= cutoff)
        .limit(1)
    )
    return result.scalar_one_or_none() is not None


async def _recent_coordinated_market_event_exists(
    session: AsyncSession,
    wallet_id: int,
    market_key: str,
    within_hours: float = DEDUPE_WINDOW_HOURS,
) -> bool:
    """Check if a recent coordinated_market_burst already exists for this wallet+market."""
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=within_hours)
    result = await session.execute(
        select(FundingEvent)
        .where(FundingEvent.wallet_id == wallet_id)
        .where(FundingEvent.event_type == "coordinated_market_burst")
        .where(FundingEvent.timestamp >= cutoff)
    )
    events = result.scalars().all()
    return any(e.details.get("market_key") == market_key for e in events)


async def _detect_new_wallet_bursts(
    session: AsyncSession,
    wallets: list[Wallet],
    trades_by_wallet: dict[int, list[Trade]],
) -> list[FundingEvent]:
    """Detect wallets that were added recently and are trading aggressively."""
    events: list[FundingEvent] = []
    now = datetime.now(tz=timezone.utc)
    cutoff = now - timedelta(hours=NEW_WALLET_WINDOW_HOURS)

    for wallet in wallets:
        date_added = _to_utc(wallet.date_added)
        if date_added is None:
            continue
        if date_added < cutoff:
            continue

        trades = trades_by_wallet.get(wallet.id, [])
        if len(trades) < 3:
            continue

        if await _recent_event_exists(session, wallet.id, "new_wallet_burst"):
            continue

        total_size = sum(t.size for t in trades)
        event = FundingEvent(
            wallet_id=wallet.id,
            event_type="new_wallet_burst",
            severity="warning",
            details={
                "trade_count": len(trades),
                "total_size": round(total_size, 2),
                "hours_since_added": round((now - date_added).total_seconds() / 3600, 1),
            },
        )
        session.add(event)
        events.append(event)

    return events


async def _detect_coordinated_market_bursts(
    session: AsyncSession,
    wallets: list[Wallet],
    trades_by_wallet: dict[int, list[Trade]],
) -> list[FundingEvent]:
    """Detect multiple wallets trading the same market within a burst window."""
    events: list[FundingEvent] = []
    now = datetime.now(tz=timezone.utc)
    cutoff = now - timedelta(hours=COORDINATED_BURST_WINDOW_HOURS)

    # Build market → wallets mapping from recent trades
    market_wallets: dict[str, list[int]] = {}
    for wallet in wallets:
        for trade in trades_by_wallet.get(wallet.id, []):
            ts = _to_utc(trade.timestamp)
            if ts is None or ts < cutoff:
                continue
            key = trade.market_name
            if key not in market_wallets:
                market_wallets[key] = []
            if wallet.id not in market_wallets[key]:
                market_wallets[key].append(wallet.id)

    # Fire events for markets with enough coordinated wallets
    for market_key, wallet_ids in market_wallets.items():
        if len(wallet_ids) < COORDINATED_MIN_WALLETS:
            continue

        for wid in wallet_ids:
            if await _recent_coordinated_market_event_exists(
                session, wid, market_key, DEDUPE_WINDOW_HOURS
            ):
                continue

            event = FundingEvent(
                wallet_id=wid,
                event_type="coordinated_market_burst",
                severity="critical",
                details={
                    "market_key": market_key,
                    "coordinated_wallet_ids": wallet_ids,
                    "wallet_count": len(wallet_ids),
                },
            )
            session.add(event)
            events.append(event)

    return events


async def run_funding_intelligence_scan(session: AsyncSession) -> dict:
    """Run all funding intelligence detections. Returns summary counts."""
    result = await session.execute(
        select(Wallet).where(Wallet.is_active == True)  # noqa: E712
    )
    wallets = list(result.scalars().all())

    # Fetch recent trades per wallet
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=max(
        NEW_WALLET_WINDOW_HOURS, COORDINATED_BURST_WINDOW_HOURS
    ))
    trades_by_wallet: dict[int, list[Trade]] = {}
    for wallet in wallets:
        trade_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == wallet.id)
            .where(Trade.timestamp >= cutoff)
            .order_by(Trade.timestamp.desc())
        )
        trades_by_wallet[wallet.id] = list(trade_result.scalars().all())

    new_wallet_events = await _detect_new_wallet_bursts(session, wallets, trades_by_wallet)
    coordinated_events = await _detect_coordinated_market_bursts(session, wallets, trades_by_wallet)

    await session.flush()

    total = len(new_wallet_events) + len(coordinated_events)
    if total > 0:
        logger.info(
            "funding_intelligence.scan_complete",
            new_wallet_bursts=len(new_wallet_events),
            coordinated_bursts=len(coordinated_events),
        )

    return {
        "new_wallet_bursts": len(new_wallet_events),
        "coordinated_market_bursts": len(coordinated_events),
    }


async def get_funding_events(
    session: AsyncSession,
    event_type: str | None = None,
    limit: int = 50,
) -> list[FundingEvent]:
    """Fetch funding events with optional type filter."""
    query = select(FundingEvent).order_by(FundingEvent.timestamp.desc()).limit(limit)
    if event_type:
        query = query.where(FundingEvent.event_type == event_type)
    result = await session.execute(query)
    return list(result.scalars().all())


async def get_ranked_funding_events(
    session: AsyncSession,
    limit: int = 25,
) -> list[dict]:
    """Return funding events ranked by severity (critical > warning > info)."""
    severity_order = {"critical": 0, "warning": 1, "info": 2}
    events = await get_funding_events(session, limit=limit * 2)
    ranked = sorted(events, key=lambda e: (severity_order.get(e.severity, 9), -(e.timestamp.timestamp() if e.timestamp else 0)))
    return [
        {
            "id": e.id,
            "walletId": e.wallet_id,
            "eventType": e.event_type,
            "severity": e.severity,
            "details": e.details,
            "timestamp": e.timestamp.isoformat() if e.timestamp else None,
        }
        for e in ranked[:limit]
    ]
