"""Wallet discovery — auto-seed from Polymarket leaderboard.

Weekly scan:
- Top 200 by profit → smart money candidates
- Bottom 100 by P&L → dumb money candidates
- Auto-score and classify
- Add above thresholds (insider_score >= 70 or inverse_score >= 70)
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_data import polymarket_data
from centinela.db.models.quant import DiscoveryCandidate
from centinela.db.models.wallet import Wallet
from centinela.services.dumb_money import calculate_inverse_score
from centinela.utils.math_primitives import confidence_multiplier, score100

logger = structlog.get_logger()

SMART_SCORE_THRESHOLD = 70
DUMB_SCORE_THRESHOLD = 70


async def discover_wallets(session: AsyncSession) -> dict:
    """Scan Polymarket leaderboard for new wallet candidates.

    Calls the real /leaderboard endpoint for both top performers (smart)
    and bottom performers (dumb). Evaluates each candidate and returns summary.

    Returns {"smart_found": N, "dumb_found": N, "auto_added": N}.
    """
    smart_found = 0
    dumb_found = 0
    auto_added = 0

    # Get already tracked / discovered addresses to avoid duplicates
    tracked_result = await session.execute(select(Wallet.address))
    tracked = {row[0] for row in tracked_result.all()}

    discovered_result = await session.execute(select(DiscoveryCandidate.address))
    discovered = {row[0] for row in discovered_result.all()}

    def _address_from(entry: dict) -> str | None:
        # Tolerate various response shapes: {address, proxyWallet, user, wallet}
        return (
            entry.get("address")
            or entry.get("proxyWallet")
            or entry.get("user")
            or entry.get("wallet")
            or entry.get("userId")
        )

    # Top performers → smart money candidates
    top_list = await polymarket_data.get_leaderboard(metric="profit", limit=200)
    for entry in top_list:
        addr = _address_from(entry)
        if not addr or addr in tracked or addr in discovered:
            continue
        handle = entry.get("username") or entry.get("handle") or addr[:10]
        candidate = await evaluate_candidate(session, addr, handle=handle)
        if candidate:
            smart_found += 1
            if candidate.auto_score >= SMART_SCORE_THRESHOLD:
                auto_added += 1

    # Bottom performers → dumb money candidates
    bottom_list = await polymarket_data.get_leaderboard(metric="loss", limit=100)
    for entry in bottom_list:
        addr = _address_from(entry)
        if not addr or addr in tracked or addr in discovered:
            continue
        handle = entry.get("username") or entry.get("handle") or addr[:10]
        candidate = await evaluate_candidate(session, addr, handle=handle)
        if candidate:
            dumb_found += 1
            if candidate.inverse_score >= DUMB_SCORE_THRESHOLD:
                auto_added += 1

    await session.commit()

    logger.info(
        "wallet_discovery.scan_complete",
        tracked=len(tracked),
        smart_found=smart_found,
        dumb_found=dumb_found,
        auto_added=auto_added,
    )

    return {
        "smart_found": smart_found,
        "dumb_found": dumb_found,
        "auto_added": auto_added,
    }


async def evaluate_candidate(
    session: AsyncSession,
    address: str,
    handle: str | None = None,
) -> DiscoveryCandidate | None:
    """Evaluate a single wallet as a candidate for tracking."""
    # Skip if already tracked
    existing = await session.execute(
        select(Wallet).where(Wallet.address == address)
    )
    if existing.scalar_one_or_none():
        return None

    # Fetch activity
    trades = await polymarket_data.get_all_activity(address, max_trades=200)
    if not trades:
        return None

    total_trades = len(trades)
    if total_trades < 30:
        return None

    # Quick stats
    wins = sum(1 for t in trades if float(t.get("profit", t.get("pnl", 0))) > 0)
    win_rate = wins / total_trades if total_trades > 0 else 0.5

    # Score as smart
    conf = confidence_multiplier(total_trades)
    auto_score = score100(win_rate * conf * 100)

    # Score as dumb
    inv_score = calculate_inverse_score(win_rate, total_trades)

    # Classify
    if auto_score >= SMART_SCORE_THRESHOLD:
        wallet_type = "smart"
        classification = "MOMENTUM"  # Default until full scoring
    elif inv_score >= DUMB_SCORE_THRESHOLD:
        wallet_type = "dumb"
        classification = "DUMB_MONEY"
    else:
        wallet_type = "neutral"
        classification = None

    candidate = DiscoveryCandidate(
        address=address,
        handle=handle or address[:10],
        auto_score=auto_score,
        inverse_score=inv_score,
        classification=classification,
        wallet_type_suggestion=wallet_type,
        score_breakdown={
            "win_rate": win_rate,
            "total_trades": total_trades,
            "confidence": conf,
        },
        status="pending",
    )
    session.add(candidate)
    await session.flush()

    logger.info(
        "discovery.candidate",
        address=address[:10],
        type=wallet_type,
        auto_score=f"{auto_score:.0f}",
        inverse=f"{inv_score:.0f}",
    )
    return candidate


async def approve_candidate(session: AsyncSession, candidate_id: int) -> Wallet | None:
    """Approve a discovery candidate and add to watchlist."""
    result = await session.execute(
        select(DiscoveryCandidate).where(DiscoveryCandidate.id == candidate_id)
    )
    candidate = result.scalar_one_or_none()
    if not candidate or candidate.status != "pending":
        return None

    from centinela.services.wallet_tracker import add_wallet

    wallet = await add_wallet(
        session,
        address=candidate.address,
        handle=candidate.handle,
        categories=[],
        notes=f"Auto-discovered. Score: {candidate.auto_score:.0f}, Inverse: {candidate.inverse_score:.0f}",
    )

    wallet.wallet_type = candidate.wallet_type_suggestion
    if candidate.wallet_type_suggestion == "dumb":
        wallet.classification = "DUMB_MONEY"
        wallet.inverse_score = candidate.inverse_score

    candidate.status = "approved"
    await session.commit()
    return wallet
