"""Signal throttling — max alerts/hour, quality floor, quiet hours.

Limits:
- max_alerts_per_hour: 5
- max_alerts_per_day: 20
- quality_floor: only send signals with combined_score >= 70

CRITICAL alerts (lockout, system offline) bypass all throttles.

Quiet hours (configurable):
- Default: 11pm - 7am
- During quiet hours: only CRITICAL and HIGH priority
- Standard/Info alerts batched for morning summary
"""

from datetime import datetime, timezone

import redis.asyncio as aioredis
import structlog

from centinela.config import settings

logger = structlog.get_logger()

HOUR_KEY = "centinela:alerts:hour"
DAY_KEY = "centinela:alerts:day"


async def can_send_alert(
    redis: aioredis.Redis,
    priority: str,
    signal_score: float,
) -> tuple[bool, str | None]:
    """Check if an alert can be sent through the throttle.

    Returns (allowed, reason_if_blocked).
    Critical alerts always pass.
    """
    # Critical alerts bypass everything
    if priority == "critical":
        return True, None

    # Quality floor
    if signal_score < settings.quality_floor:
        return False, f"Below quality floor ({signal_score:.0f} < {settings.quality_floor:.0f})"

    # Quiet hours
    now = datetime.now(tz=timezone.utc)
    hour = now.hour
    is_quiet = False
    if settings.quiet_hours_start > settings.quiet_hours_end:
        # Wraps midnight: e.g. 23-7
        is_quiet = hour >= settings.quiet_hours_start or hour < settings.quiet_hours_end
    else:
        is_quiet = settings.quiet_hours_start <= hour < settings.quiet_hours_end

    if is_quiet and priority not in ("critical", "high"):
        return False, f"Quiet hours ({settings.quiet_hours_start}:00-{settings.quiet_hours_end}:00) — standard alerts suppressed"

    # Hourly limit
    hour_count = await redis.get(HOUR_KEY)
    if hour_count and int(hour_count) >= settings.max_alerts_per_hour:
        if priority != "high":
            return False, f"Hourly limit reached ({settings.max_alerts_per_hour}/hr)"

    # Daily limit
    day_count = await redis.get(DAY_KEY)
    if day_count and int(day_count) >= settings.max_alerts_per_day:
        if priority != "high":
            return False, f"Daily limit reached ({settings.max_alerts_per_day}/day)"

    return True, None


async def record_alert_sent(redis: aioredis.Redis) -> None:
    """Increment alert counters after sending."""
    pipe = redis.pipeline()
    pipe.incr(HOUR_KEY)
    pipe.expire(HOUR_KEY, 3600)  # TTL 1 hour
    pipe.incr(DAY_KEY)
    pipe.expire(DAY_KEY, 86400)  # TTL 24 hours
    await pipe.execute()
