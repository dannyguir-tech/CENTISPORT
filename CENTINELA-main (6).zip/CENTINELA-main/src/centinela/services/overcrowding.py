"""Overcrowding detection — detect when too many people copy a wallet.

Detection signals:
1. Price moves > 5% within 60 seconds of wallet's trade
2. Reaction speed to this wallet's trades is shrinking week over week

Action:
- If crowding detected → downgrade insider score by 15-25 points
- Alert user with the data
- Do NOT auto-remove — let user decide
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.edge_expansion import OvercrowdingMetric
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()

# Thresholds
FAST_REACTION_THRESHOLD = 30.0  # seconds — if price reacts in < 30s, it's crowded
WORSENING_THRESHOLD = 0.5  # if current reaction is < 50% of previous, trend is bad
SCORE_PENALTY_MAX = 25.0


async def update_crowding_metrics(
    session: AsyncSession,
    wallet: Wallet,
    reaction_time_seconds: float,
) -> OvercrowdingMetric:
    """Update overcrowding metrics for a wallet after observing price reaction.

    reaction_time_seconds: time for price to move 3% after wallet's trade.
    """
    # Get previous measurement
    prev_result = await session.execute(
        select(OvercrowdingMetric)
        .where(OvercrowdingMetric.wallet_id == wallet.id)
        .order_by(OvercrowdingMetric.measured_at.desc())
        .limit(1)
    )
    prev = prev_result.scalar_one_or_none()
    prev_time = prev.avg_price_reaction_seconds if prev else None

    # Determine trend
    if prev_time is None:
        trend = "stable"
    elif reaction_time_seconds < prev_time * WORSENING_THRESHOLD:
        trend = "worsening"  # Price reacting faster = more crowded
    elif reaction_time_seconds > prev_time * 1.5:
        trend = "improving"  # Price reacting slower = less crowded
    else:
        trend = "stable"

    # Calculate penalty
    penalty = 0.0
    if reaction_time_seconds < FAST_REACTION_THRESHOLD:
        # Linear penalty: 0 at 30s, 25 at 0s
        penalty = min(SCORE_PENALTY_MAX, (FAST_REACTION_THRESHOLD - reaction_time_seconds) / FAST_REACTION_THRESHOLD * SCORE_PENALTY_MAX)

    metric = OvercrowdingMetric(
        wallet_id=wallet.id,
        avg_price_reaction_seconds=reaction_time_seconds,
        prev_reaction_seconds=prev_time,
        trend_direction=trend,
        score_penalty=penalty,
    )
    session.add(metric)

    # Update wallet crowding score
    wallet.crowding_score = penalty

    if trend == "worsening" and penalty > 10:
        logger.warning(
            "overcrowding.worsening",
            wallet=wallet.handle,
            reaction=f"{reaction_time_seconds:.0f}s",
            prev=f"{prev_time:.0f}s" if prev_time else "N/A",
            penalty=f"-{penalty:.0f}",
        )

    return metric


async def get_crowding_alert_text(wallet: Wallet, metric: OvercrowdingMetric) -> str | None:
    """Generate alert text if overcrowding is concerning. Returns None if OK."""
    if metric.score_penalty < 10:
        return None

    prev_text = f"was {metric.prev_reaction_seconds:.0f}s" if metric.prev_reaction_seconds else "first measurement"

    return (
        f"\U0001F4C9 Wallet {wallet.handle} is getting crowded\n"
        f"   Price now moves within {metric.avg_price_reaction_seconds:.0f}s of their trades ({prev_text})\n"
        f"   Edge retention dropping. Insider score reduced by {metric.score_penalty:.0f} points.\n"
        f"   Consider removing if trend continues."
    )
