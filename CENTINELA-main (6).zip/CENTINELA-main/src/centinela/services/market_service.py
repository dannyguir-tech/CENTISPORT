"""Market service — sync and cache market metadata from Gamma API."""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone

from centinela.clients.polymarket_gamma import polymarket_gamma
from centinela.db.models.market import Market

logger = structlog.get_logger()


async def sync_markets(session: AsyncSession, limit: int = 100) -> int:
    """Fetch active markets from Gamma API and upsert into DB.

    Returns count of new/updated markets.
    """
    raw_markets = await polymarket_gamma.get_markets(active=True, limit=limit)
    if not raw_markets:
        return 0

    count = 0
    for raw in raw_markets:
        condition_id = raw.get("conditionId", raw.get("condition_id", ""))
        if not condition_id:
            continue

        result = await session.execute(
            select(Market).where(Market.polymarket_id == condition_id)
        )
        market = result.scalar_one_or_none()

        question = raw.get("question", raw.get("title", ""))
        category = raw.get("category", raw.get("tag", None))

        # Extract token IDs from outcomes/tokens
        tokens = raw.get("tokens", raw.get("clobTokenIds", []))
        token_yes = None
        token_no = None
        if isinstance(tokens, list):
            if len(tokens) >= 1:
                if isinstance(tokens[0], dict):
                    token_yes = tokens[0].get("token_id")
                else:
                    token_yes = str(tokens[0])
            if len(tokens) >= 2:
                if isinstance(tokens[1], dict):
                    token_no = tokens[1].get("token_id")
                else:
                    token_no = str(tokens[1])

        if market is None:
            market = Market(
                polymarket_id=condition_id,
                gamma_id=raw.get("id", raw.get("gamma_id")),
                question=question,
                category=category,
                status="active",
                odds_yes=_parse_float(raw.get("outcomePrices", [None, None])[0]),
                odds_no=_parse_float(raw.get("outcomePrices", [None, None])[1]) if len(raw.get("outcomePrices", [])) > 1 else None,
                daily_volume=_parse_float(raw.get("volume24hr", raw.get("volume"))),
                spread=_parse_float(raw.get("spread")),
                token_id_yes=token_yes,
                token_id_no=token_no,
                last_synced_at=datetime.now(tz=timezone.utc),
            )
            session.add(market)
            count += 1
        else:
            # Update existing
            market.question = question or market.question
            if category:
                market.category = category
            market.odds_yes = _parse_float(raw.get("outcomePrices", [None])[0]) or market.odds_yes
            market.daily_volume = _parse_float(raw.get("volume24hr", raw.get("volume"))) or market.daily_volume
            market.spread = _parse_float(raw.get("spread")) or market.spread
            if token_yes:
                market.token_id_yes = token_yes
            if token_no:
                market.token_id_no = token_no
            market.last_synced_at = datetime.now(tz=timezone.utc)
            count += 1

    await session.commit()
    logger.info("market_service.synced", markets=count)
    return count


def _parse_float(val) -> float | None:
    if val is None:
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        return None
