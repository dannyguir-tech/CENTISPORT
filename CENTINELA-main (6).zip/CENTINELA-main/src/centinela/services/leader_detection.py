"""Smart Money Leader Detection — Module 6 (exact spec formulas).

Per-wallet metrics:
  leader_events   = markets where wallet entered FIRST and another top wallet followed within 6h
  follower_events = markets where wallet FOLLOWED another top wallet
  avg_follow_quality = avg normalized score of wallets that followed i (0-1)
  median_lead_time = median minutes between i's entry and follower entry (cap 360)
  lead_time_n = 1 - clamp(median_lead_time / 360, 0, 1)

Leader formula:
  leader_raw = 0.45 * safe_div(leader_events, leader+follower, 0.5)
             + 0.30 * avg_follow_quality
             + 0.25 * lead_time_n

  leader_adj = leader_raw * (0.60 + 0.40 * sample_conf(leader+follower, 30))
  leader_score = score100(leader_adj)

Integration:
  wallet_score_final = 0.80*base + 0.10*copyability + 0.10*leader

  If leader_score >= 80 AND informational trade AND confidence >= 0.70:
    → +6 bonus to signal quality (tier-1 signal)
"""

from collections import defaultdict
from datetime import timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant import LeaderMetric
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.utils.math_primitives import clamp, confidence_multiplier, safe_div, score100

logger = structlog.get_logger()

FOLLOW_WINDOW_HOURS = 6
LEADER_BONUS = 6


async def compute_leader_scores(session: AsyncSession) -> int:
    """Compute leader/follower metrics for all active smart wallets.

    Returns count updated.
    """
    result = await session.execute(
        select(Wallet)
        .where(Wallet.is_active == True)  # noqa: E712
        .where(Wallet.wallet_type == "smart")
        .where(Wallet.insider_score >= 50)
    )
    wallets = list(result.scalars().all())
    wallet_map = {w.id: w for w in wallets}

    if len(wallets) < 2:
        return 0

    # Build per-wallet per-market first-entry timestamps
    market_entries: dict[str, list[tuple[int, float, float]]] = defaultdict(list)
    # market_name -> [(wallet_id, timestamp_epoch, insider_score)]

    for w in wallets:
        t_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == w.id)
            .where(Trade.is_first_entry == True)  # noqa: E712
            .order_by(Trade.timestamp.asc())
        )
        for t in t_result.scalars().all():
            ts = t.timestamp.timestamp() if hasattr(t.timestamp, 'timestamp') else 0
            market_entries[t.market_name].append((w.id, ts, w.insider_score))

    # Count leader/follower events per wallet
    leader_events: dict[int, int] = defaultdict(int)
    follower_events: dict[int, int] = defaultdict(int)
    follow_qualities: dict[int, list[float]] = defaultdict(list)
    lead_times: dict[int, list[float]] = defaultdict(list)

    window_seconds = FOLLOW_WINDOW_HOURS * 3600

    for market, entries in market_entries.items():
        if len(entries) < 2:
            continue
        # Sort by timestamp
        entries.sort(key=lambda x: x[1])

        first_id, first_ts, first_score = entries[0]
        for follower_id, follower_ts, follower_score in entries[1:]:
            delta = follower_ts - first_ts
            if delta <= 0 or delta > window_seconds:
                continue

            leader_events[first_id] += 1
            follower_events[follower_id] += 1
            follow_qualities[first_id].append(follower_score / 100.0)
            lead_times[first_id].append(delta / 60.0)  # minutes

    # Compute leader scores
    updated = 0
    for w in wallets:
        wid = w.id
        l_events = leader_events.get(wid, 0)
        f_events = follower_events.get(wid, 0)
        total_events = l_events + f_events

        # avg_follow_quality
        fq = follow_qualities.get(wid, [])
        avg_fq = sum(fq) / len(fq) if fq else 0.0

        # median_lead_time (capped at 360 min)
        lt = lead_times.get(wid, [])
        if lt:
            lt_sorted = sorted(lt)
            median_lt = lt_sorted[len(lt_sorted) // 2]
        else:
            median_lt = 360.0  # max
        median_lt = min(median_lt, 360.0)
        lead_time_n = 1 - clamp(median_lt / 360, 0, 1)

        # Leader formula (spec exact)
        leader_raw = (
            0.45 * safe_div(l_events, l_events + f_events, 0.5)
            + 0.30 * avg_fq
            + 0.25 * lead_time_n
        )

        # Confidence adjustment
        sample_conf = confidence_multiplier(total_events, max_trades=30)
        leader_adj = leader_raw * (0.60 + 0.40 * sample_conf)
        leader_score = score100(leader_adj * 100)

        # Persist
        existing = await session.execute(
            select(LeaderMetric).where(LeaderMetric.wallet_id == wid)
        )
        metric = existing.scalar_one_or_none()
        if metric is None:
            metric = LeaderMetric(wallet_id=wid)
            session.add(metric)

        metric.leader_events = l_events
        metric.follower_events = f_events
        metric.avg_follow_quality = avg_fq
        metric.median_lead_time_min = median_lt
        metric.leader_score = leader_score
        updated += 1

    await session.commit()
    return updated


def apply_leader_bonus(leader_score: float, base_signal_score: float) -> float:
    """Apply +6 leader bonus for tier-1 signals.

    Condition: leader_score >= 80
    """
    if leader_score >= 80:
        return base_signal_score + LEADER_BONUS
    return base_signal_score


def integrate_quant_scores(
    base_score: float,
    copyability_score: float = 50.0,
    leader_score: float = 50.0,
) -> float:
    """Integrate copyability and leader scores into final wallet score.

    wallet_score_final = 0.80*base + 0.10*copyability + 0.10*leader
    """
    return (
        0.80 * base_score
        + 0.10 * copyability_score
        + 0.10 * leader_score
    )
