"""Module 8: Latency Optimization — adaptive polling tiers (exact spec formulas).

Per-market priority:
  poll_priority_raw = 0.35*pre_signal_confidence
                    + 0.25*clamp(active_wallets/5, 0, 1)
                    + 0.20*clamp(volume_percentile, 0, 1)
                    + 0.20*clamp(xplat_gap/15, 0, 1)

Tiers:
  >= 75: Tier 1 → 2 seconds
  50-74: Tier 2 → 5 seconds
  30-49: Tier 3 → 15 seconds
  < 30:  Tier 4 → 60 seconds

Detection confidence:
  0.45*ws_alive + 0.35*polling_freshness + 0.20*source_redundancy
  < 0.60 → suppress high-urgency alerts (except cross-platform)
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import DetectionHealth, PollPriority
from centinela.utils.math_primitives import clamp, score100

logger = structlog.get_logger()

TIER_INTERVALS = {1: 2, 2: 5, 3: 15, 4: 60}


def compute_poll_priority(
    pre_signal_confidence: float = 0.0,
    active_tracked_wallets: int = 0,
    recent_volume_percentile: float = 0.0,
    cross_platform_gap: float = 0.0,
) -> tuple[float, int, int]:
    """Compute poll priority score and tier.

    Returns (score, tier, interval_seconds).
    """
    raw = (
        0.35 * clamp(pre_signal_confidence, 0, 1)
        + 0.25 * clamp(active_tracked_wallets / 5, 0, 1)
        + 0.20 * clamp(recent_volume_percentile, 0, 1)
        + 0.20 * clamp(cross_platform_gap / 15, 0, 1)
    )
    score = score100(raw * 100)

    if score >= 75:
        tier = 1
    elif score >= 50:
        tier = 2
    elif score >= 30:
        tier = 3
    else:
        tier = 4

    return score, tier, TIER_INTERVALS[tier]


def compute_detection_confidence(
    websocket_alive: bool,
    seconds_since_last_poll: float,
    poll_interval: float,
    both_sources_active: bool,
) -> float:
    """Compute detection confidence (exact spec formula).

    Returns 0-1. Below 0.60 = suppress high-urgency alerts.
    """
    ws = 1.0 if websocket_alive else 0.0
    freshness = 1 - clamp(seconds_since_last_poll / max(poll_interval, 1), 0, 1)
    redundancy = 1.0 if both_sources_active else 0.6

    return clamp(
        0.45 * ws + 0.35 * freshness + 0.20 * redundancy,
        0, 1,
    )


async def update_poll_priority(
    session: AsyncSession,
    market_id: int,
    score: float,
    tier: int,
    interval: int,
) -> PollPriority:
    """Upsert poll priority for a market."""
    result = await session.execute(
        select(PollPriority).where(PollPriority.market_id == market_id)
    )
    pp = result.scalar_one_or_none()
    if pp is None:
        pp = PollPriority(market_id=market_id)
        session.add(pp)

    pp.poll_priority_score = score
    pp.polling_tier = tier
    pp.poll_interval_seconds = interval
    return pp


async def record_detection_health(
    session: AsyncSession,
    websocket_alive: bool,
    polling_freshness: float,
    source_redundancy: float,
) -> DetectionHealth:
    """Record system detection confidence."""
    conf = clamp(
        0.45 * (1.0 if websocket_alive else 0.0)
        + 0.35 * polling_freshness
        + 0.20 * source_redundancy,
        0, 1,
    )
    health = DetectionHealth(
        websocket_alive=websocket_alive,
        polling_freshness=polling_freshness,
        source_redundancy=source_redundancy,
        detection_confidence=conf,
    )
    session.add(health)
    return health
