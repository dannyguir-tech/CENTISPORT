"""Trade journal + performance reports.

Trade journal: pre/post notes, pattern analysis, Telegram quick-entry.
Performance reports: automated weekly/monthly broken down by signal type,
intent type, regime, wallet, and category.
"""

from collections import defaultdict
from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.alert import Alert
from centinela.db.models.execution import Position
from centinela.db.models.quant import ShadowTracking

logger = structlog.get_logger()


async def generate_performance_report(
    session: AsyncSession, period: str = "weekly"
) -> dict:
    """Generate automated performance report.

    period: "weekly" (7 days) or "monthly" (30 days).
    """
    days = 7 if period == "weekly" else 30
    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=days)

    # Closed positions in period
    result = await session.execute(
        select(Position)
        .where(Position.status == "closed")
        .where(Position.time_entered >= cutoff)
    )
    closed = list(result.scalars().all())

    total_pnl = sum(p.realized_pnl or 0 for p in closed)
    wins = [p for p in closed if (p.realized_pnl or 0) > 0]
    losses = [p for p in closed if (p.realized_pnl or 0) <= 0]

    # By signal source
    pnl_by_source: dict[str, float] = defaultdict(float)
    count_by_source: dict[str, int] = defaultdict(int)
    for p in closed:
        src = p.signal_source or "unknown"
        pnl_by_source[src] += p.realized_pnl or 0
        count_by_source[src] += 1

    # By category
    pnl_by_category: dict[str, float] = defaultdict(float)
    for p in closed:
        cat = p.category or "Other"
        pnl_by_category[cat] += p.realized_pnl or 0

    # Shadow tracking
    shadow_result = await session.execute(
        select(ShadowTracking).where(ShadowTracking.timestamp >= cutoff)
    )
    shadows = list(shadow_result.scalars().all())
    taken = sum(1 for s in shadows if s.was_taken is True)
    skipped = sum(1 for s in shadows if s.was_taken is False)
    missed_opp = sum(s.missed_opportunity or 0 for s in shadows if s.was_taken is False and (s.phantom_pnl or 0) > 0)

    # Best and worst trades
    best = max(closed, key=lambda p: p.realized_pnl or 0) if closed else None
    worst = min(closed, key=lambda p: p.realized_pnl or 0) if closed else None

    report = {
        "period": period,
        "days": days,
        "totalPnl": round(total_pnl, 2),
        "tradesTotal": len(closed),
        "wins": len(wins),
        "losses": len(losses),
        "winRate": len(wins) / len(closed) if closed else 0,
        "avgPnlPerTrade": round(total_pnl / len(closed), 2) if closed else 0,
        "pnlBySource": dict(pnl_by_source),
        "countBySource": dict(count_by_source),
        "pnlByCategory": dict(pnl_by_category),
        "signalsTaken": taken,
        "signalsSkipped": skipped,
        "missedOpportunity": round(missed_opp, 2),
        "bestTrade": {
            "market": best.market_name if best else None,
            "pnl": best.realized_pnl if best else 0,
        },
        "worstTrade": {
            "market": worst.market_name if worst else None,
            "pnl": worst.realized_pnl if worst else 0,
        },
    }

    return report


def format_report_for_telegram(report: dict) -> str:
    """Format a performance report for Telegram delivery."""
    period_label = "WEEKLY" if report["period"] == "weekly" else "MONTHLY"
    wr = report["winRate"] * 100

    lines = [
        f"\U0001F4CA CENTINELA \u2014 {period_label} REPORT",
        f"",
        f"P&L: ${report['totalPnl']:+,.0f}",
        f"Trades: {report['tradesTotal']} ({report['wins']}W / {report['losses']}L) \u2014 {wr:.0f}% WR",
        f"Avg per trade: ${report['avgPnlPerTrade']:+,.0f}",
        f"",
    ]

    if report["pnlBySource"]:
        lines.append("BY SIGNAL TYPE:")
        for src, pnl in sorted(report["pnlBySource"].items(), key=lambda x: x[1], reverse=True):
            count = report["countBySource"].get(src, 0)
            lines.append(f"  {src}: ${pnl:+,.0f} ({count} trades)")
        lines.append("")

    if report["pnlByCategory"]:
        lines.append("BY CATEGORY:")
        for cat, pnl in sorted(report["pnlByCategory"].items(), key=lambda x: x[1], reverse=True):
            lines.append(f"  {cat}: ${pnl:+,.0f}")
        lines.append("")

    if report["bestTrade"]["market"]:
        lines.append(f"\U0001F3C6 Best: {report['bestTrade']['market']} (${report['bestTrade']['pnl']:+,.0f})")
    if report["worstTrade"]["market"]:
        lines.append(f"\U0001F4A9 Worst: {report['worstTrade']['market']} (${report['worstTrade']['pnl']:+,.0f})")

    lines.extend([
        "",
        f"Signals taken: {report['signalsTaken']} | Skipped: {report['signalsSkipped']}",
        f"Missed opportunity: ${report['missedOpportunity']:+,.0f}",
    ])

    return "\n".join(lines)


# --- Trade Journal ---

async def add_journal_entry(
    session: AsyncSession,
    position_id: int,
    pre_notes: str | None = None,
    post_notes: str | None = None,
) -> Position | None:
    """Add journal notes to a position."""
    result = await session.execute(select(Position).where(Position.id == position_id))
    pos = result.scalar_one_or_none()
    if not pos:
        return None

    if pre_notes is not None:
        pos.journal_pre = pre_notes
    if post_notes is not None:
        pos.journal_post = post_notes

    return pos
