"""Module 4: Pre-Position Detection — early warning flags (exact spec formulas).

Detects markets where smart money is ABOUT to enter before the trade fires.

pre_signal_raw = 0.30*liq_n + 0.20*spread_n + 0.25*vol_n
               + 0.15*quiet_price_n + 0.10*related_smart
pre_signal_flag = 1 if confidence >= 0.68

If flag=1: raise to Tier 1 polling, soft alert
If insider later enters: +7 bonus to signal quality
"""

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import PreSignalFlag
from centinela.utils.math_primitives import clamp

logger = structlog.get_logger()

PRE_SIGNAL_THRESHOLD = 0.68
PRE_SIGNAL_BONUS = 7


def compute_pre_signal(
    liq_growth: float,
    spread_tightening: float,
    vol_growth: float,
    price_drift: float,
    related_smart_activity: float,
) -> tuple[float, bool]:
    """Compute pre-signal confidence (exact spec formula).

    Returns (confidence, is_flagged).
    """
    liq_n = clamp(liq_growth / 100, 0, 1)
    spread_n = clamp(spread_tightening / 100, 0, 1)
    vol_n = clamp(vol_growth / 200, 0, 1)
    quiet_price_n = 1 - clamp(price_drift / 10, 0, 1)

    pre_signal_raw = (
        0.30 * liq_n
        + 0.20 * spread_n
        + 0.25 * vol_n
        + 0.15 * quiet_price_n
        + 0.10 * clamp(related_smart_activity, 0, 1)
    )

    confidence = clamp(pre_signal_raw, 0, 1)
    flagged = confidence >= PRE_SIGNAL_THRESHOLD

    return confidence, flagged


async def record_pre_signal(
    session: AsyncSession,
    market_id: int,
    market_name: str | None,
    liq_growth: float,
    spread_tightening: float,
    vol_growth: float,
    price_drift: float,
    related_smart_activity: float,
) -> PreSignalFlag | None:
    """Compute and record a pre-signal flag if threshold met."""
    confidence, flagged = compute_pre_signal(
        liq_growth, spread_tightening, vol_growth, price_drift, related_smart_activity
    )

    if not flagged:
        return None

    flag = PreSignalFlag(
        market_id=market_id,
        market_name=market_name,
        pre_signal_confidence=confidence,
        liq_growth=liq_growth,
        spread_tightening=spread_tightening,
        vol_growth=vol_growth,
        price_drift=price_drift,
        related_smart_activity=related_smart_activity,
    )
    session.add(flag)

    logger.info(
        "pre_signal.flagged",
        market=market_name,
        confidence=f"{confidence:.2f}",
    )
    return flag


async def check_pre_signal_for_market(
    session: AsyncSession, market_id: int
) -> tuple[bool, float | None]:
    """Check if a market was pre-flagged. Returns (was_flagged, delay_minutes)."""
    from sqlalchemy import select
    from datetime import datetime, timezone, timedelta

    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=2)
    result = await session.execute(
        select(PreSignalFlag)
        .where(PreSignalFlag.market_id == market_id)
        .where(PreSignalFlag.flagged_at >= cutoff)
        .where(PreSignalFlag.insider_entered_after == False)  # noqa: E712
        .order_by(PreSignalFlag.flagged_at.desc())
        .limit(1)
    )
    flag = result.scalar_one_or_none()
    if not flag:
        return False, None

    # Mark as confirmed
    flag.insider_entered_after = True
    now = datetime.now(tz=timezone.utc)
    flagged_at = flag.flagged_at
    if flagged_at.tzinfo is None:
        flagged_at = flagged_at.replace(tzinfo=timezone.utc)
    delay_minutes = (now - flagged_at).total_seconds() / 60
    flag.insider_entry_delay_minutes = delay_minutes
    flag.was_useful = True

    return True, delay_minutes
