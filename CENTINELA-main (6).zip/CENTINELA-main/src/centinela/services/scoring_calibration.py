"""Scoring weight calibration — recalibrate every 4 weeks from signal feedback.

Process:
1. For each scoring component, correlate with actual copy PnL from signal feedback
2. Components that predict profitable signals get higher weight
3. Components that don't predict outcomes get lower weight
4. Store weight history
5. Alert on changes
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.alert import Alert
from centinela.db.models.quant import ScoringCalibration
from centinela.db.models.wallet import WalletScoreHistory
from centinela.services.scoring_engine import DEFAULT_WEIGHTS

logger = structlog.get_logger()


async def calibrate_weights(session: AsyncSession) -> dict | None:
    """Recalibrate scoring weights based on signal feedback data.

    Looks at alerts where was_taken=True and has actual_pnl,
    correlates each component score with outcome.

    Returns new weights dict, or None if insufficient data.
    """
    # Get alerts with outcome data
    result = await session.execute(
        select(Alert)
        .where(Alert.was_taken == True)  # noqa: E712
        .where(Alert.actual_pnl != None)  # noqa: E711
        .where(Alert.wallet_id != None)  # noqa: E711
    )
    alerts = list(result.scalars().all())

    if len(alerts) < 20:
        logger.info("calibration.insufficient_data", alerts=len(alerts))
        return None

    # For each alert, get the wallet's component scores at the time
    component_outcomes: dict[str, list[tuple[float, float]]] = {
        k: [] for k in DEFAULT_WEIGHTS
    }

    for alert in alerts:
        # Get closest score history entry
        score_result = await session.execute(
            select(WalletScoreHistory)
            .where(WalletScoreHistory.wallet_id == alert.wallet_id)
            .where(WalletScoreHistory.timestamp <= alert.sent_at)
            .order_by(WalletScoreHistory.timestamp.desc())
            .limit(1)
        )
        history = score_result.scalar_one_or_none()
        if not history or not history.component_scores:
            continue

        pnl = alert.actual_pnl or 0
        outcome = 1.0 if pnl > 0 else 0.0  # Binary: profitable or not

        for component, score in history.component_scores.items():
            if component in component_outcomes:
                component_outcomes[component].append((score, outcome))

    # Calculate correlation strength for each component
    old_weights = dict(DEFAULT_WEIGHTS)
    correlations: dict[str, float] = {}

    for component, pairs in component_outcomes.items():
        if len(pairs) < 10:
            correlations[component] = 0.5  # Neutral if insufficient data
            continue
        # Simple correlation: average score of winning signals vs losing
        win_scores = [s for s, o in pairs if o > 0]
        lose_scores = [s for s, o in pairs if o <= 0]

        win_avg = sum(win_scores) / len(win_scores) if win_scores else 50
        lose_avg = sum(lose_scores) / len(lose_scores) if lose_scores else 50

        # Higher gap = more predictive
        gap = (win_avg - lose_avg) / 100.0  # Normalize to 0-1
        correlations[component] = max(0.1, 0.5 + gap)  # Bounded

    # Normalize to weights summing to 1.0
    total_corr = sum(correlations.values())
    if total_corr <= 0:
        return None

    new_weights = {k: v / total_corr for k, v in correlations.items()}

    # Smooth: blend 70% new with 30% old to avoid wild swings
    blended = {
        k: 0.7 * new_weights.get(k, 0.125) + 0.3 * old_weights.get(k, 0.125)
        for k in old_weights
    }
    # Re-normalize
    total = sum(blended.values())
    blended = {k: v / total for k, v in blended.items()}

    # Record calibration
    calibration = ScoringCalibration(
        old_weights=old_weights,
        new_weights=blended,
        correlation_data=correlations,
    )
    session.add(calibration)

    logger.info(
        "calibration.complete",
        changes={k: f"{old_weights[k]*100:.1f}% → {blended[k]*100:.1f}%" for k in blended},
    )
    return blended


def format_calibration_alert(old_weights: dict, new_weights: dict) -> str:
    """Format weight change alert for Telegram."""
    lines = ["Scoring weights updated:\n"]
    for k in sorted(old_weights):
        old = old_weights[k] * 100
        new = new_weights.get(k, old / 100) * 100
        arrow = "\u2191" if new > old + 0.5 else ("\u2193" if new < old - 0.5 else "\u2192")
        lines.append(f"  {k}: {old:.1f}% {arrow} {new:.1f}%")
    return "\n".join(lines)
