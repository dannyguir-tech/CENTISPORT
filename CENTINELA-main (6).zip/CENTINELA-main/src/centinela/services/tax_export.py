"""Tax export — cost basis tracking, realized gains, CSV export."""

import csv
import io
from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.execution import Position

logger = structlog.get_logger()


async def export_tax_csv(
    session: AsyncSession,
    year: int | None = None,
) -> str:
    """Export realized trades as CSV for tax filing.

    Columns: Date Acquired, Date Sold, Market, Side, Cost Basis,
    Proceeds, Realized Gain/Loss, Holding Period (days)
    """
    query = select(Position).where(Position.status == "closed")
    if year:
        start = datetime(year, 1, 1, tzinfo=timezone.utc)
        end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
        query = query.where(Position.time_entered >= start).where(Position.time_entered < end)
    query = query.order_by(Position.time_entered.asc())

    result = await session.execute(query)
    positions = result.scalars().all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Date Acquired", "Date Sold", "Market", "Side",
        "Cost Basis ($)", "Proceeds ($)", "Realized Gain/Loss ($)",
        "Holding Period (days)", "Signal Source", "Category",
    ])

    for p in positions:
        entry_date = p.time_entered.strftime("%Y-%m-%d") if p.time_entered else ""
        exit_date = p.last_updated.strftime("%Y-%m-%d") if p.last_updated else ""
        cost_basis = p.size
        proceeds = p.size + (p.realized_pnl or 0)
        gain_loss = p.realized_pnl or 0

        entry_ts = p.time_entered
        exit_ts = p.last_updated
        if entry_ts and exit_ts:
            if entry_ts.tzinfo is None:
                entry_ts = entry_ts.replace(tzinfo=timezone.utc)
            if exit_ts.tzinfo is None:
                exit_ts = exit_ts.replace(tzinfo=timezone.utc)
            holding_days = (exit_ts - entry_ts).days
        else:
            holding_days = 0

        writer.writerow([
            entry_date, exit_date, p.market_name, p.side,
            f"{cost_basis:.2f}", f"{proceeds:.2f}", f"{gain_loss:.2f}",
            holding_days, p.signal_source or "", p.category or "",
        ])

    return output.getvalue()


async def get_tax_summary(session: AsyncSession, year: int) -> dict:
    """Get tax summary for a given year."""
    start = datetime(year, 1, 1, tzinfo=timezone.utc)
    end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)

    result = await session.execute(
        select(Position)
        .where(Position.status == "closed")
        .where(Position.time_entered >= start)
        .where(Position.time_entered < end)
    )
    positions = list(result.scalars().all())

    total_gains = sum(p.realized_pnl for p in positions if (p.realized_pnl or 0) > 0)
    total_losses = sum(p.realized_pnl for p in positions if (p.realized_pnl or 0) < 0)
    net = total_gains + total_losses

    short_term = [p for p in positions
                  if p.time_entered and p.last_updated
                  and (p.last_updated - p.time_entered).days <= 365]
    long_term = [p for p in positions
                 if p.time_entered and p.last_updated
                 and (p.last_updated - p.time_entered).days > 365]

    return {
        "year": year,
        "totalTrades": len(positions),
        "totalGains": round(total_gains or 0, 2),
        "totalLosses": round(total_losses or 0, 2),
        "netGainLoss": round(net or 0, 2),
        "shortTermTrades": len(short_term),
        "longTermTrades": len(long_term),
        "shortTermNet": round(sum(p.realized_pnl or 0 for p in short_term), 2),
        "longTermNet": round(sum(p.realized_pnl or 0 for p in long_term), 2),
    }
