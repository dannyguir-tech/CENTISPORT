"""Position building — gradual entry for sniper first entries.

Rules from spec:
  FIRST_ENTRY from sniper:
    → Enter 50% of recommended size
    → If insider ADDS within 48h → add remaining 50%
    → If insider doesn't add → hold at 50%, reassess

  CONSENSUS: full size
  CONVERGENCE: full size
  CROSS_PLATFORM: full size
  DUMB_MONEY_FADE: 60% of recommended size
"""

from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.execution import Position
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.services.bankroll import get_or_create_bankroll

logger = structlog.get_logger()


async def check_position_additions(session: AsyncSession) -> list[dict]:
    """Check if any 50% positions should be topped up to 100%.

    Looks for positions at 50% build phase where the insider
    has added to their position within the last 48 hours.

    Returns list of positions to top up.
    """
    result = await session.execute(
        select(Position)
        .where(Position.status == "open")
        .where(Position.build_phase == "50%")
    )
    positions = list(result.scalars().all())

    topups: list[dict] = []
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=48)

    for pos in positions:
        if not pos.wallet_id:
            continue

        # Check if the insider added to their position recently
        add_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == pos.wallet_id)
            .where(Trade.market_name == pos.market_name)
            .where(Trade.side == pos.side)
            .where(Trade.timestamp >= cutoff)
            .where(Trade.is_first_entry == False)  # noqa: E712 — adding, not first
            .order_by(Trade.timestamp.desc())
        )
        additions = list(add_result.scalars().all())

        if additions:
            topups.append({
                "position_id": pos.id,
                "market_name": pos.market_name,
                "current_size": pos.current_size,
                "original_size": pos.size,
                "insider_additions": len(additions),
            })

    return topups


async def execute_topup(session: AsyncSession, position_id: int) -> Position | None:
    """Top up a 50% position to 100%."""
    result = await session.execute(
        select(Position).where(Position.id == position_id)
    )
    pos = result.scalar_one_or_none()
    if not pos or pos.build_phase != "50%":
        return None

    additional = pos.size  # Original size = 50%, so another 50% = same amount
    bankroll = await get_or_create_bankroll(session)

    # Check if we have available capital
    if bankroll.available_capital < additional:
        logger.info(
            "position_building.insufficient_capital",
            market=pos.market_name,
            needed=additional,
            available=bankroll.available_capital,
        )
        return None

    pos.current_size += additional
    pos.size += additional
    pos.build_phase = "100%"

    bankroll.deployed_capital += additional
    bankroll.available_capital -= additional

    await session.flush()

    logger.info(
        "position_building.topup",
        market=pos.market_name,
        new_size=f"${pos.current_size:,.0f}",
    )
    return pos
