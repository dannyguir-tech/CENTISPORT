"""Position manager — TP ladder, conditional SL, time exits, insider exit tracking.

Trade Management Rules:
  TP1: price >= +20% -> exit 50%
  TP2: price >= +35% -> exit remaining
  SL1 (conditional): price <= -15% AND insider exited -> exit full
  SL2 (hard floor): price <= -30% -> exit regardless
  Time exit: if time_held > 50% of resolution window AND P&L < 5% -> warn
  Insider exit: immediate HIGH priority alert if copied insider exits
"""

from datetime import datetime, timezone

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_clob import polymarket_clob
from centinela.config import settings
from centinela.db.models.execution import Bankroll, Position
from centinela.db.models.market import Market
from centinela.services.bankroll import get_or_create_bankroll
from centinela.services.shadow_tracking import update_shadow_pnl

logger = structlog.get_logger()


class PositionEvent:
    """Represents a trade management event (TP, SL, time warning, etc.)."""

    def __init__(self, event_type: str, position: Position, message: str, priority: str = "high"):
        self.event_type = event_type  # tp1/tp2/sl_conditional/sl_hard/time_warning/time_urgent/insider_exit
        self.position = position
        self.message = message
        self.priority = priority


async def open_position(
    session: AsyncSession,
    alert_id: int | None,
    market: Market | None,
    wallet_id: int | None,
    market_name: str,
    side: str,
    size: float,
    entry_price: float,
    signal_source: str = "insider",
    build_phase: str = "100%",
) -> Position:
    """Open a new tracked position."""
    tp1 = entry_price * (1 + settings.tp1_pct)
    tp2 = entry_price * (1 + settings.tp2_pct)
    sl_cond = entry_price * (1 - settings.sl_conditional_pct)
    sl_hard = entry_price * (1 - settings.sl_hard_pct)

    pos = Position(
        alert_id=alert_id,
        market_id=market.id if market else None,
        wallet_id=wallet_id,
        market_name=market_name,
        side=side,
        size=size,
        current_size=size,
        entry_price=entry_price,
        current_price=entry_price,
        resolution_date=market.resolution_date if market else None,
        tp1_price=tp1,
        tp2_price=tp2,
        sl_conditional_price=sl_cond,
        sl_hard_price=sl_hard,
        category=market.category if market else None,
        signal_source=signal_source,
        build_phase=build_phase,
        status="open",
    )
    session.add(pos)
    await session.flush()

    # Update bankroll deployed capital
    bankroll = await get_or_create_bankroll(session)
    bankroll.deployed_capital += size
    bankroll.available_capital = bankroll.total_capital - bankroll.deployed_capital

    logger.info(
        "position.opened",
        market=market_name,
        side=side,
        size=f"${size:,.0f}",
        tp1=f"${tp1:.2f}",
        sl_hard=f"${sl_hard:.2f}",
    )
    return pos


async def check_all_positions(session: AsyncSession) -> list[PositionEvent]:
    """Check all open positions for TP/SL/time exit conditions.

    Returns list of events that need alerts.
    """
    result = await session.execute(
        select(Position).where(Position.status.in_(["open", "partial"]))
    )
    positions = list(result.scalars().all())
    events: list[PositionEvent] = []

    for pos in positions:
        pos_events = await _check_position(session, pos)
        events.extend(pos_events)

    if events:
        await session.flush()

    return events


async def _check_position(session: AsyncSession, pos: Position) -> list[PositionEvent]:
    """Check a single position for exit conditions."""
    events: list[PositionEvent] = []

    # Get current price
    current_price = await _get_current_price(pos, session)
    if current_price is None:
        return events

    # Calculate P&L
    if pos.side == "YES":
        pnl_pct = (current_price - pos.entry_price) / pos.entry_price
    else:
        pnl_pct = (pos.entry_price - current_price) / pos.entry_price

    pos.pnl_pct = pnl_pct
    pos.unrealized_pnl = pos.current_size * pnl_pct

    # Check TP2 first (full exit)
    if pos.status == "partial" and pos.tp2_price:
        if (pos.side == "YES" and current_price >= pos.tp2_price) or \
           (pos.side == "NO" and current_price <= (pos.entry_price - (pos.tp2_price - pos.entry_price))):
            realized = pos.current_size * pnl_pct
            events.append(PositionEvent(
                "tp2", pos,
                f"\U0001F4B0 CENTINELA \u2014 TAKE PROFIT\n\n"
                f"\U0001F4CA {pos.market_name}\n"
                f"   TP2 hit: {pnl_pct*100:+.1f}% \u2192 fully exited\n"
                f"   Entry: ${pos.entry_price:.2f} \u2192 Current: ${current_price:.2f}\n"
                f"   Realized: ${realized:+,.0f}\n\n"
                f"Position fully closed.",
            ))
            await _close_position(session, pos, current_price, realized)
            return events

    # Check TP1 (partial exit)
    if pos.status == "open" and pos.tp1_price:
        if (pos.side == "YES" and current_price >= pos.tp1_price) or \
           (pos.side == "NO" and current_price <= (pos.entry_price - (pos.tp1_price - pos.entry_price))):
            half = pos.current_size / 2
            realized = half * pnl_pct
            events.append(PositionEvent(
                "tp1", pos,
                f"\U0001F4B0 CENTINELA \u2014 TAKE PROFIT\n\n"
                f"\U0001F4CA {pos.market_name}\n"
                f"   TP1 hit: {pnl_pct*100:+.1f}% \u2192 selling 50%\n"
                f"   Entry: ${pos.entry_price:.2f} \u2192 Current: ${current_price:.2f}\n"
                f"   Realized: ${realized:+,.0f} | Remaining: ${half:,.0f}\n\n"
                f"Holding rest for TP2 ({settings.tp2_pct*100:+.0f}%) or resolution.",
            ))
            pos.current_size = half
            pos.status = "partial"
            # Credit bankroll
            bankroll = await get_or_create_bankroll(session)
            bankroll.deployed_capital -= half
            bankroll.available_capital += half
            bankroll.daily_pnl += realized
            bankroll.weekly_pnl += realized

    # Check hard stop (unconditional)
    if pos.sl_hard_price and pnl_pct <= -settings.sl_hard_pct:
        loss = pos.current_size * pnl_pct
        events.append(PositionEvent(
            "sl_hard", pos,
            f"\U0001F534 CENTINELA \u2014 HARD STOP\n\n"
            f"\U0001F4CA {pos.market_name}\n"
            f"   Price: {pnl_pct*100:+.1f}%. Exiting regardless.\n"
            f"   Entry: ${pos.entry_price:.2f} \u2192 Current: ${current_price:.2f}\n"
            f"   Loss: ${loss:+,.0f}\n\n"
            f"Protecting capital. -30% is too much to recover.",
            priority="critical",
        ))
        await _close_position(session, pos, current_price, loss)
        return events

    # Check conditional stop (insider exited + price down 15%+)
    if pos.sl_conditional_price and not pos.insider_still_holds and pnl_pct <= -settings.sl_conditional_pct:
        loss = pos.current_size * pnl_pct
        events.append(PositionEvent(
            "sl_conditional", pos,
            f"\U0001F534 CENTINELA \u2014 STOP LOSS\n\n"
            f"\U0001F4CA {pos.market_name}\n"
            f"   Price: {pnl_pct*100:+.1f}% AND insider EXITED\n"
            f"   Entry: ${pos.entry_price:.2f} \u2192 Current: ${current_price:.2f}\n"
            f"   Loss: ${loss:+,.0f}\n\n"
            f"Thesis invalidated \u2014 insider no longer holds.",
        ))
        await _close_position(session, pos, current_price, loss)
        return events

    # Check time-based exit
    time_events = _check_time_exit(pos, pnl_pct)
    events.extend(time_events)

    return events


def _check_time_exit(pos: Position, pnl_pct: float) -> list[PositionEvent]:
    """Check time-based exit conditions."""
    events: list[PositionEvent] = []
    if not pos.resolution_date:
        return events

    now = datetime.now(tz=timezone.utc)
    entry_time = pos.time_entered
    if entry_time.tzinfo is None:
        entry_time = entry_time.replace(tzinfo=timezone.utc)
    res_date = pos.resolution_date
    if res_date.tzinfo is None:
        res_date = res_date.replace(tzinfo=timezone.utc)

    total_window = (res_date - entry_time).total_seconds()
    if total_window <= 0:
        return events

    time_held = (now - entry_time).total_seconds()
    time_ratio = time_held / total_window

    if time_ratio > 0.75 and pnl_pct < 0:
        events.append(PositionEvent(
            "time_urgent", pos,
            f"\u23F0 CENTINELA \u2014 URGENT TIME CHECK\n\n"
            f"\U0001F4CA {pos.market_name}\n"
            f"   75% of time elapsed, position is {pnl_pct*100:+.1f}%\n"
            f"   Strongly consider exiting.",
            priority="high",
        ))
    elif time_ratio > 0.5 and pnl_pct < 0.05:
        events.append(PositionEvent(
            "time_warning", pos,
            f"\u23F0 CENTINELA \u2014 TIME CHECK\n\n"
            f"\U0001F4CA {pos.market_name}\n"
            f"   Holding for {time_ratio*100:.0f}% of window with {pnl_pct*100:+.1f}%\n"
            f"   Capital might work harder elsewhere.",
            priority="standard",
        ))

    return events


async def _get_current_price(pos: Position, session: AsyncSession) -> float | None:
    """Get current price: WebSocket cache → CLOB midpoint → stored value.

    WebSocket is preferred because it's real-time with no HTTP cost.
    CLOB is a 200-500ms fallback. Stored is final fallback for failed fetches.
    """
    if pos.market_id:
        result = await session.execute(select(Market).where(Market.id == pos.market_id))
        market = result.scalar_one_or_none()
        if market:
            token_id = market.token_id_yes if pos.side == "YES" else market.token_id_no
            if token_id:
                # 1. Try WebSocket cache (fresh = <60s old)
                from centinela.clients.polymarket_ws import polymarket_ws
                ws_price = polymarket_ws.get_price(token_id)
                if ws_price is not None:
                    pos.current_price = ws_price
                    return ws_price

                # 2. Fallback to CLOB
                live_price = await polymarket_clob.get_midpoint(token_id)
                if live_price is not None:
                    pos.current_price = live_price
                    return live_price
    # 3. Fallback to stored price
    return pos.current_price


async def _close_position(
    session: AsyncSession,
    pos: Position,
    exit_price: float,
    realized_pnl: float,
) -> None:
    """Close a position and update bankroll."""
    pos.status = "closed"
    pos.exit_price = exit_price
    pos.realized_pnl = realized_pnl

    bankroll = await get_or_create_bankroll(session)
    bankroll.deployed_capital -= pos.current_size
    bankroll.available_capital += pos.current_size
    bankroll.daily_pnl += realized_pnl
    bankroll.weekly_pnl += realized_pnl
    bankroll.total_capital += realized_pnl

    # Update shadow tracking with actual PnL
    if pos.alert_id:
        await update_shadow_pnl(session, pos.alert_id, phantom_pnl=realized_pnl, actual_pnl=realized_pnl)

    # Attribute win/loss back to the insider wallet we copied
    if pos.wallet_id:
        from centinela.db.models.wallet import Wallet
        wallet_row = await session.execute(select(Wallet).where(Wallet.id == pos.wallet_id))
        wallet = wallet_row.scalar_one_or_none()
        if wallet:
            wallet.pnl = (wallet.pnl or 0.0) + realized_pnl
            # Recompute win_rate from closed positions for this wallet
            closed_result = await session.execute(
                select(Position)
                .where(Position.wallet_id == pos.wallet_id)
                .where(Position.status == "closed")
                .where(Position.realized_pnl.isnot(None))
            )
            closed = list(closed_result.scalars().all())
            if closed:
                wins = sum(1 for p in closed if (p.realized_pnl or 0) > 0)
                wallet.win_rate = wins / len(closed)

    pos.current_size = 0

    logger.info(
        "position.closed",
        market=pos.market_name,
        pnl=f"${realized_pnl:+,.0f}",
    )
