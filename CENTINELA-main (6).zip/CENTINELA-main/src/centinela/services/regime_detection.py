"""Module 7: Market Regime Detection — exact spec formulas.

Classifies markets into 4 regimes:
  HIGH_VOLATILITY: chase×0.85, size×0.75, min_score+4
  LOW_VOLATILITY:  chase×1.10, size×1.00
  TRENDING:        chase×1.00, size×1.10 (leaders), momentum penalty reduced
  MANIPULATED:     chase×0.70, size×0.50, min_score+8, REQUIRE trap<50

Uses z-score normalization against per-category historical baselines.
"""

from dataclasses import dataclass

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import MarketRegime, RegimeBaseline
from centinela.utils.math_primitives import clamp, z_clamped

logger = structlog.get_logger()


@dataclass
class RegimeResult:
    label: str  # high_vol/low_vol/trending/manipulated
    confidence: float
    raw_scores: dict[str, float]
    chase_multiplier: float
    position_multiplier: float
    min_score_adjustment: int


def classify_regime(
    rv: float,
    spread_med: float,
    depth_instability: float,
    vol_spike: float,
    directional_drift: float,
    baseline: RegimeBaseline | None = None,
) -> RegimeResult:
    """Classify market regime using exact spec formulas.

    Uses z-score normalization against category baselines when available.
    """
    # Default baselines if none provided
    if baseline:
        rv_mu, rv_sigma = baseline.rv_mu, baseline.rv_sigma
        sp_mu, sp_sigma = baseline.spread_mu, baseline.spread_sigma
        dp_mu, dp_sigma = baseline.depth_mu, baseline.depth_sigma
        vl_mu, vl_sigma = baseline.vol_mu, baseline.vol_sigma
    else:
        rv_mu, rv_sigma = 0.02, 0.01
        sp_mu, sp_sigma = 0.02, 0.01
        dp_mu, dp_sigma = 0.3, 0.15
        vl_mu, vl_sigma = 1.0, 0.5

    # Normalize using z-score then map to 0-1 (spec exact)
    rv_n = clamp((z_clamped(rv, rv_mu, rv_sigma) + 3) / 6, 0, 1)
    spread_n = clamp((z_clamped(spread_med, sp_mu, sp_sigma) + 3) / 6, 0, 1)
    depth_n = clamp((z_clamped(depth_instability, dp_mu, dp_sigma) + 3) / 6, 0, 1)
    vol_n = clamp((z_clamped(vol_spike, vl_mu, vl_sigma) + 3) / 6, 0, 1)
    drift_n = clamp(directional_drift / 3, 0, 1)

    # Four regime scores (spec exact)
    scores = {
        "high_vol": 0.40 * rv_n + 0.20 * vol_n + 0.20 * spread_n + 0.20 * depth_n,
        "low_vol": 0.50 * (1 - rv_n) + 0.20 * (1 - spread_n) + 0.20 * (1 - depth_n) + 0.10 * (1 - vol_n),
        "trending": 0.45 * drift_n + 0.25 * vol_n + 0.15 * (1 - spread_n) + 0.15 * (1 - depth_n),
        "manipulated": 0.30 * spread_n + 0.30 * depth_n + 0.20 * vol_n + 0.20 * (1 - drift_n),
    }

    # Classification (spec exact)
    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    label = sorted_scores[0][0]
    top1 = sorted_scores[0][1]
    top2 = sorted_scores[1][1]
    confidence = clamp(0.55 * top1 + 0.45 * (top1 - top2), 0, 1)

    # Regime-based adjustments (spec exact)
    adjustments = {
        "high_vol": (0.85, 0.75, 4),
        "low_vol": (1.10, 1.00, 0),
        "trending": (1.00, 1.10, 0),
        "manipulated": (0.70, 0.50, 8),
    }
    chase_mult, pos_mult, min_adj = adjustments[label]

    return RegimeResult(
        label=label,
        confidence=confidence,
        raw_scores=scores,
        chase_multiplier=chase_mult,
        position_multiplier=pos_mult,
        min_score_adjustment=min_adj,
    )


async def get_baseline(session: AsyncSession, category: str) -> RegimeBaseline | None:
    """Get historical baseline for a category."""
    result = await session.execute(
        select(RegimeBaseline).where(RegimeBaseline.category == category)
    )
    return result.scalar_one_or_none()


async def upsert_baseline(
    session: AsyncSession,
    category: str,
    rv_mu: float, rv_sigma: float,
    spread_mu: float, spread_sigma: float,
    depth_mu: float, depth_sigma: float,
    vol_mu: float, vol_sigma: float,
    sample_size: int,
) -> RegimeBaseline:
    """Create or update a regime baseline for a category."""
    existing = await get_baseline(session, category)
    if existing:
        existing.rv_mu, existing.rv_sigma = rv_mu, rv_sigma
        existing.spread_mu, existing.spread_sigma = spread_mu, spread_sigma
        existing.depth_mu, existing.depth_sigma = depth_mu, depth_sigma
        existing.vol_mu, existing.vol_sigma = vol_mu, vol_sigma
        existing.sample_size = sample_size
        return existing

    baseline = RegimeBaseline(
        category=category,
        rv_mu=rv_mu, rv_sigma=rv_sigma,
        spread_mu=spread_mu, spread_sigma=spread_sigma,
        depth_mu=depth_mu, depth_sigma=depth_sigma,
        vol_mu=vol_mu, vol_sigma=vol_sigma,
        sample_size=sample_size,
    )
    session.add(baseline)
    return baseline


async def record_regime(
    session: AsyncSession,
    market_id: int,
    result: RegimeResult,
    rv: float = 0, spread_med: float = 0,
    depth_instability: float = 0, vol_spike: float = 0,
    directional_drift: float = 0,
) -> MarketRegime:
    """Persist regime classification."""
    regime = MarketRegime(
        market_id=market_id,
        regime_label=result.label,
        regime_confidence=result.confidence,
        raw_scores=result.raw_scores,
        rv=rv,
        spread_med=spread_med,
        depth_instability=depth_instability,
        vol_spike=vol_spike,
        directional_drift=directional_drift,
        chase_multiplier=result.chase_multiplier,
        position_multiplier=result.position_multiplier,
        min_score_adjustment=result.min_score_adjustment,
    )
    session.add(regime)
    return regime
