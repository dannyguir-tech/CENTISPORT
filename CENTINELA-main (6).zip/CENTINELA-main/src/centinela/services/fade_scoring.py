"""Fade signal scoring — 5-component composite formula.

FADE_SIGNAL_SCORE = (
    inverse_score        × 0.30    ← how reliably this wallet loses overall
  + category_inverse     × 0.25    ← how bad they are in THIS market's category
  + smart_confirmation   × 0.25    ← are insiders on the OPPOSITE side?
  + cross_platform_conf  × 0.10    ← does Kalshi agree with the fade?
  + dumb_consensus       × 0.10    ← are OTHER dumb wallets also on the losing side?
)

Worked example from spec:
  inverse_score: 88, category_inverse: 82, smart_confirmation: 93,
  cross_platform: 30, dumb_consensus: 33
  SCORE = 88*0.30 + 82*0.25 + 93*0.25 + 30*0.10 + 33*0.10
        = 26.4 + 20.5 + 23.25 + 3.0 + 3.3 = 76.45 → PASS

CRITICAL RULE: If insiders are on SAME side as dumb money → SUPPRESS entirely.
"""

from dataclasses import dataclass

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.cross_platform import CrossPlatformMarket, CrossPlatformPrice
from centinela.db.models.edge_expansion import DumbMoneySignal
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.services.dumb_money import calculate_category_inverse, calculate_inverse_score
from centinela.utils.math_primitives import score100

logger = structlog.get_logger()

# Weights from the spec
W_INVERSE = 0.30
W_CATEGORY = 0.25
W_SMART = 0.25
W_XPLAT = 0.10
W_CONSENSUS = 0.10

FADE_THRESHOLD = 70.0


@dataclass
class FadeScoreResult:
    score: float
    inverse_score: float
    category_inverse: float
    smart_confirmation: float
    cross_platform_conf: float
    dumb_consensus: float
    suppressed: bool
    suppress_reason: str | None
    fade_side: str  # opposite of dumb money's side
    confirming_insiders: list[int]  # wallet IDs of insiders confirming the fade
    conflicting_insiders: list[int]  # wallet IDs on same side as dumb money


async def calculate_fade_score(
    session: AsyncSession,
    dumb_wallet: Wallet,
    trade: Trade,
    market: Market | None,
) -> FadeScoreResult:
    """Calculate the 5-component fade signal score.

    Returns FadeScoreResult with score, components, and suppression status.
    """
    fade_side = "NO" if trade.side == "YES" else "YES"
    category = market.category if market else "Other"

    # 1. INVERSE SCORE (0-100)
    inv_score = calculate_inverse_score(dumb_wallet.win_rate, dumb_wallet.total_trades)

    # 2. CATEGORY INVERSE (0-100)
    cat_inv = calculate_category_inverse(dumb_wallet, category)

    # 3. SMART MONEY CONFIRMATION (0-100)
    smart_conf, confirming, conflicting = await _smart_money_check(
        session, trade.market_name, trade.side, fade_side
    )

    # CRITICAL: If smart money is on SAME side as dumb money → SUPPRESS
    if conflicting:
        return FadeScoreResult(
            score=0.0,
            inverse_score=inv_score,
            category_inverse=cat_inv,
            smart_confirmation=0.0,
            cross_platform_conf=0.0,
            dumb_consensus=0.0,
            suppressed=True,
            suppress_reason=f"Smart money conflict — insiders on same side",
            fade_side=fade_side,
            confirming_insiders=[],
            conflicting_insiders=conflicting,
        )

    # 4. CROSS-PLATFORM CONFIRMATION (0-100)
    xplat_conf = await _cross_platform_check(session, market, fade_side)

    # 5. DUMB CONSENSUS (0-100)
    dumb_cons = await _dumb_consensus_check(
        session, trade.market_name, trade.side, dumb_wallet.id
    )

    # Calculate composite score
    score = (
        inv_score * W_INVERSE
        + cat_inv * W_CATEGORY
        + smart_conf * W_SMART
        + xplat_conf * W_XPLAT
        + dumb_cons * W_CONSENSUS
    )

    return FadeScoreResult(
        score=score,
        inverse_score=inv_score,
        category_inverse=cat_inv,
        smart_confirmation=smart_conf,
        cross_platform_conf=xplat_conf,
        dumb_consensus=dumb_cons,
        suppressed=False,
        suppress_reason=None,
        fade_side=fade_side,
        confirming_insiders=confirming,
        conflicting_insiders=[],
    )


async def record_fade_signal(
    session: AsyncSession,
    dumb_wallet: Wallet,
    trade: Trade,
    market: Market | None,
    result: FadeScoreResult,
    alert_id: int | None = None,
) -> DumbMoneySignal:
    """Persist a dumb money fade signal to the database."""
    signal = DumbMoneySignal(
        wallet_id=dumb_wallet.id,
        market_id=market.id if market else None,
        market_name=trade.market_name,
        dumb_side=trade.side,
        fade_side=result.fade_side,
        inverse_score_component=result.inverse_score,
        category_inverse_component=result.category_inverse,
        smart_confirmation_component=result.smart_confirmation,
        cross_platform_component=result.cross_platform_conf,
        dumb_consensus_component=result.dumb_consensus,
        fade_signal_score=result.score,
        smart_money_conflict=result.suppressed,
        conflicting_wallet_ids=result.conflicting_insiders,
        suppressed=result.suppressed,
        suppress_reason=result.suppress_reason,
        alert_id=alert_id,
    )
    session.add(signal)
    return signal


# ---------------------------------------------------------------------------
# Component calculations
# ---------------------------------------------------------------------------


async def _smart_money_check(
    session: AsyncSession,
    market_name: str,
    dumb_side: str,
    fade_side: str,
) -> tuple[float, list[int], list[int]]:
    """Check if tracked insiders have positions in this market.

    Returns (smart_confirmation_score, confirming_ids, conflicting_ids).
    """
    # Find all smart wallet trades in this market (latest first per wallet)
    result = await session.execute(
        select(Trade, Wallet)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.market_name == market_name)
        .where(Wallet.wallet_type == "smart")
        .where(Wallet.is_active == True)  # noqa: E712
        .where(Wallet.insider_score >= 60)
        .order_by(Trade.timestamp.desc())
    )
    rows = result.all()

    if not rows:
        return 50.0, [], []  # Neutral — no insiders present

    # Group by wallet, get their latest side
    wallet_sides: dict[int, tuple[str, float]] = {}  # wallet_id -> (side, score)
    for trade, wallet in rows:
        # Keep the most recent trade per wallet
        if wallet.id not in wallet_sides:
            wallet_sides[wallet.id] = (trade.side, wallet.insider_score)

    confirming: list[int] = []  # insiders on OPPOSITE side of dumb money (confirm fade)
    conflicting: list[int] = []  # insiders on SAME side as dumb money

    for wid, (side, score) in wallet_sides.items():
        if side == fade_side:
            confirming.append(wid)
        elif side == dumb_side:
            conflicting.append(wid)

    if conflicting:
        # Smart money on SAME side as dumb money → suppress
        return 0.0, [], conflicting

    if confirming:
        # Average insider scores of confirming wallets
        scores = [wallet_sides[wid][1] for wid in confirming]
        return sum(scores) / len(scores), confirming, []

    return 50.0, [], []  # No insiders in this specific market


async def _cross_platform_check(
    session: AsyncSession,
    market: Market | None,
    fade_side: str,
) -> float:
    """Check if Kalshi pricing supports the fade direction.

    Returns 0-100 score.
    """
    if not market:
        return 40.0  # Can't confirm

    # Check for matching Kalshi pair
    result = await session.execute(
        select(CrossPlatformMarket)
        .where(CrossPlatformMarket.polymarket_market_id == market.id)
        .where(CrossPlatformMarket.is_active == True)  # noqa: E712
    )
    pair = result.scalar_one_or_none()
    if not pair:
        return 40.0  # No matching Kalshi market

    # Get latest price
    price_result = await session.execute(
        select(CrossPlatformPrice)
        .where(CrossPlatformPrice.cross_platform_market_id == pair.id)
        .order_by(CrossPlatformPrice.timestamp.desc())
        .limit(1)
    )
    latest = price_result.scalar_one_or_none()
    if not latest:
        return 40.0

    # Check if Kalshi agrees with the fade direction
    gap = latest.price_gap  # already in points
    poly_price = latest.polymarket_price
    kalshi_price = latest.kalshi_price

    if fade_side == "NO":
        # Fading dumb YES — Kalshi should have lower YES price (higher NO)
        if kalshi_price < poly_price:
            return min(gap * 10, 100)  # Kalshi agrees dumb is wrong
        else:
            return 0.0  # Kalshi agrees WITH dumb money
    else:
        # Fading dumb NO — Kalshi should have higher YES price
        if kalshi_price > poly_price:
            return min(gap * 10, 100)
        else:
            return 0.0

    return 40.0


async def _dumb_consensus_check(
    session: AsyncSession,
    market_name: str,
    dumb_side: str,
    exclude_wallet_id: int,
) -> float:
    """Count OTHER dumb money wallets on the same losing side.

    dumb_consensus = min(count × 33, 100)
    0 others = 0, 1 = 33, 2 = 66, 3+ = 100
    """
    result = await session.execute(
        select(Trade)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.market_name == market_name)
        .where(Trade.side == dumb_side)
        .where(Wallet.wallet_type == "dumb")
        .where(Wallet.id != exclude_wallet_id)
        .where(Wallet.is_active == True)  # noqa: E712
    )
    others = result.scalars().all()

    # Deduplicate by wallet
    unique_wallets = {t.wallet_id for t in others}
    count = len(unique_wallets)
    return min(count * 33, 100)
