"""First entry + position build phase detection.

For each new trade from a tracked wallet:
1. No existing position → FIRST_ENTRY (priority: HIGH)
2. Existing position:
   - Current size < 33% of avg size in category → EARLY build
   - 33-66% of avg → MID build
   - > 66% of avg → LATE build

Signal priority:
- FIRST_ENTRY → highest, send immediately
- EARLY → high
- MID → standard
- LATE → low (most of edge already captured)
"""

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()


class BuildPhaseResult:
    def __init__(self, phase: str, priority: str, label: str, current_pct: float = 0.0):
        self.phase = phase  # first_entry/early/mid/late
        self.priority = priority  # high/standard/low
        self.label = label  # human-readable for alert
        self.current_pct = current_pct  # % of typical size


async def detect_build_phase(
    session: AsyncSession,
    wallet: Wallet,
    trade: Trade,
) -> BuildPhaseResult:
    """Determine where the insider is in their position-building process."""

    # Check if they already have trades in this market
    existing = await session.execute(
        select(Trade)
        .where(Trade.wallet_id == wallet.id)
        .where(Trade.market_name == trade.market_name)
        .where(Trade.id != trade.id)
        .order_by(Trade.timestamp.asc())
    )
    prior_trades = list(existing.scalars().all())

    if not prior_trades:
        return BuildPhaseResult(
            phase="first_entry",
            priority="high",
            label="\U0001F539 First entry \u2014 new position",
        )

    # Calculate current accumulated size in this market
    current_size = sum(t.size for t in prior_trades) + trade.size

    # Get avg position size for this wallet in this category
    category = _infer_category(trade.market_name)
    avg_size = await _get_avg_category_size(session, wallet.id, category)

    if avg_size <= 0:
        avg_size = wallet.avg_size or trade.size

    pct = current_size / avg_size if avg_size > 0 else 0

    if pct < 0.33:
        return BuildPhaseResult(
            phase="early",
            priority="high",
            label=f"\U0001F538 Adding to position (early build, {pct*100:.0f}% of typical size)",
            current_pct=pct * 100,
        )
    elif pct < 0.66:
        return BuildPhaseResult(
            phase="mid",
            priority="standard",
            label=f"\U0001F538 Adding to position (mid-build, {pct*100:.0f}% of typical size)",
            current_pct=pct * 100,
        )
    else:
        return BuildPhaseResult(
            phase="late",
            priority="low",
            label=f"\U0001F538 Adding to position (late build, {pct*100:.0f}% of typical size)",
            current_pct=pct * 100,
        )


async def _get_avg_category_size(
    session: AsyncSession, wallet_id: int, category: str
) -> float:
    """Get the average total position size for a wallet in a given category."""
    # Group trades by market, sum sizes per market, then average
    result = await session.execute(
        select(func.sum(Trade.size))
        .where(Trade.wallet_id == wallet_id)
        .group_by(Trade.market_name)
    )
    market_totals = [row[0] for row in result.all() if row[0]]
    if not market_totals:
        return 0.0
    return sum(market_totals) / len(market_totals)


def _infer_category(market_name: str) -> str:
    """Infer market category from name keywords."""
    name_lower = market_name.lower()
    if any(kw in name_lower for kw in ["president", "election", "congress", "senate", "trump", "biden", "fed ", "rate"]):
        return "Politics"
    if any(kw in name_lower for kw in ["bitcoin", "btc", "eth", "crypto", "solana"]):
        return "Crypto"
    if any(kw in name_lower for kw in ["nba", "nfl", "mlb", "soccer", "lakers", "finals"]):
        return "Sports"
    return "Other"
