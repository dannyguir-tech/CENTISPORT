"""Wallet tracker — add/remove wallets, backfill trade history from Data API."""

from datetime import datetime, timezone

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_data import polymarket_data
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()


async def add_wallet(
    session: AsyncSession,
    address: str,
    handle: str | None = None,
    categories: list[str] | None = None,
    notes: str | None = None,
) -> Wallet:
    """Add a wallet to the tracker and backfill its trade history."""
    # Check if wallet already exists
    existing = await session.execute(select(Wallet).where(Wallet.address == address))
    wallet = existing.scalar_one_or_none()
    if wallet:
        # Reactivate if previously deactivated
        if not wallet.is_active:
            wallet.is_active = True
            await session.commit()
        return wallet

    wallet = Wallet(
        address=address,
        handle=handle or address[:10],
        categories=categories or [],
        notes=notes,
        is_active=True,
    )
    session.add(wallet)
    await session.flush()  # get wallet.id

    # Backfill trade history
    trade_count = await backfill_trades(session, wallet)
    logger.info(
        "wallet_tracker.added",
        address=address,
        handle=wallet.handle,
        trades_backfilled=trade_count,
    )

    await session.commit()
    return wallet


async def backfill_trades(session: AsyncSession, wallet: Wallet) -> int:
    """Fetch trade history from Data API and insert into DB."""
    raw_trades = await polymarket_data.get_all_activity(wallet.address, max_trades=500)
    if not raw_trades:
        return 0

    inserted = 0
    seen_markets: set[str] = set()

    for raw in raw_trades:
        trade_id = _extract_trade_id(raw)
        if not trade_id:
            continue

        # Skip duplicates
        exists = await session.execute(
            select(Trade.id).where(Trade.polymarket_trade_id == trade_id)
        )
        if exists.scalar_one_or_none() is not None:
            continue

        condition_id = raw.get("conditionId", raw.get("condition_id", ""))
        market_name = raw.get("title", raw.get("question", raw.get("market", "Unknown")))
        side = raw.get("side", raw.get("outcome", "YES")).upper()
        if side not in ("YES", "NO"):
            side = "YES"

        size = _parse_float(raw.get("size", raw.get("amount", 0)))
        price = _parse_float(raw.get("price", raw.get("avgPrice", 0)))
        timestamp = _parse_timestamp(raw.get("timestamp", raw.get("createdAt", "")))

        is_first = condition_id not in seen_markets
        seen_markets.add(condition_id)

        trade = Trade(
            wallet_id=wallet.id,
            polymarket_trade_id=trade_id,
            market_name=market_name,
            side=side,
            size=size,
            price=price,
            timestamp=timestamp,
            is_first_entry=is_first,
            transaction_hash=raw.get("transactionHash", raw.get("transaction_hash")),
        )
        session.add(trade)
        inserted += 1

    # Update wallet stats from backfilled data
    if inserted > 0:
        await _update_wallet_stats(session, wallet)

    return inserted


async def _update_wallet_stats(session: AsyncSession, wallet: Wallet) -> None:
    """Recompute denormalized wallet stats from trades table."""
    result = await session.execute(
        select(Trade).where(Trade.wallet_id == wallet.id).order_by(Trade.timestamp.desc())
    )
    trades = result.scalars().all()
    if not trades:
        return

    wallet.total_trades = len(trades)
    wallet.avg_size = sum(t.size for t in trades) / len(trades) if trades else 0.0
    wallet.last_trade_at = trades[0].timestamp if trades else None

    # Basic win rate placeholder — needs market resolution data for real calculation
    # For now, use position data from Data API or set to 0
    wallet.pnl = 0.0
    wallet.win_rate = 0.0


def _extract_trade_id(raw: dict) -> str | None:
    """Extract a unique trade identifier for dedup."""
    # Try various field names the Data API might use
    for key in ("id", "tradeId", "trade_id", "transactionHash", "transaction_hash"):
        val = raw.get(key)
        if val:
            return str(val)
    # Fallback: composite key
    addr = raw.get("user", raw.get("address", ""))
    cond = raw.get("conditionId", raw.get("condition_id", ""))
    ts = raw.get("timestamp", raw.get("createdAt", ""))
    size = raw.get("size", raw.get("amount", ""))
    if addr and cond and ts:
        return f"{addr}:{cond}:{ts}:{size}"
    return None


def _parse_float(val) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0


def _parse_timestamp(val) -> datetime:
    if isinstance(val, datetime):
        return val
    if isinstance(val, (int, float)):
        return datetime.fromtimestamp(val, tz=timezone.utc)
    if isinstance(val, str) and val:
        try:
            return datetime.fromisoformat(val.replace("Z", "+00:00"))
        except ValueError:
            pass
        try:
            return datetime.fromtimestamp(float(val), tz=timezone.utc)
        except (ValueError, OSError):
            pass
    return datetime.now(tz=timezone.utc)
