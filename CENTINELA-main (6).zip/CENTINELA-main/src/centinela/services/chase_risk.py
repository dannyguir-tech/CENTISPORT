"""Chase risk filter + signal expiration.

The #1 way copy traders lose money: chasing a price that already moved.

Logic:
1. Insider enters at price P
2. At alert time T, check current price P_now
3. Calculate move: (P_now - P) / P
4. Dynamic threshold: max(3%, 1.5 * avg_1min_volatility)
5. If move > threshold -> EXPIRE signal
6. No override. No exceptions.

Signals also expire when:
- More than 15 minutes since insider entry
- Slippage estimate > 5%
- Market liquidity below minimum
"""

from datetime import datetime, timezone

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_clob import polymarket_clob
from centinela.config import settings
from centinela.db.models.execution import EntryQuality, SignalExpiration
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()


class ChaseRiskResult:
    def __init__(self, expired: bool, reason: str | None = None,
                 price_move_pct: float = 0.0, current_price: float = 0.0):
        self.expired = expired
        self.reason = reason
        self.price_move_pct = price_move_pct
        self.current_price = current_price


async def check_chase_risk(
    trade: Trade,
    market: Market | None,
) -> ChaseRiskResult:
    """Check if a signal should be expired due to chase risk.

    Returns ChaseRiskResult with expired=True if signal is dead.
    """
    # 1. Check time since insider entry
    now = datetime.now(tz=timezone.utc)
    trade_ts = trade.timestamp
    if trade_ts.tzinfo is None:
        trade_ts = trade_ts.replace(tzinfo=timezone.utc)
    elapsed = (now - trade_ts).total_seconds()

    if elapsed > settings.signal_max_age_seconds:
        return ChaseRiskResult(
            expired=True,
            reason="timeout",
            price_move_pct=0.0,
        )

    # 2. Get current price — WebSocket cache first, then CLOB fallback
    current_price = None
    if market:
        token_id = market.token_id_yes if trade.side == "YES" else market.token_id_no
        if token_id:
            from centinela.clients.polymarket_ws import polymarket_ws
            current_price = polymarket_ws.get_price(token_id)
            if current_price is None:
                current_price = await polymarket_clob.get_midpoint(token_id)
    if current_price is None:
        # Can't check price — allow the signal through (fail open)
        return ChaseRiskResult(expired=False, current_price=trade.price)

    # 3. Calculate price move
    insider_price = trade.price
    if insider_price <= 0:
        return ChaseRiskResult(expired=False, current_price=current_price)

    price_move = abs(current_price - insider_price) / insider_price
    # For YES side, only care about price going UP (harder to enter)
    # For NO side, only care about price going DOWN
    if trade.side == "YES":
        directional_move = (current_price - insider_price) / insider_price
    else:
        directional_move = (insider_price - current_price) / insider_price

    # 4. Dynamic threshold: max(3%, 1.5 * spread-derived volatility proxy)
    threshold = settings.chase_risk_default_threshold  # 3% base
    if market and market.spread is not None and market.spread > 0:
        # Use spread as volatility proxy — wider spreads imply higher vol
        vol_proxy = market.spread  # spread is already a decimal (e.g., 0.05 = 5%)
        vol_threshold = settings.chase_risk_volatility_multiplier * vol_proxy
        threshold = max(threshold, vol_threshold)

    # 5. Check against threshold
    if directional_move > threshold:
        return ChaseRiskResult(
            expired=True,
            reason="chase",
            price_move_pct=directional_move * 100,
            current_price=current_price,
        )

    return ChaseRiskResult(
        expired=False,
        price_move_pct=directional_move * 100,
        current_price=current_price,
    )


async def record_expiration(
    session: AsyncSession,
    trade: Trade,
    wallet: Wallet,
    result: ChaseRiskResult,
    alert_id: int | None = None,
) -> SignalExpiration:
    """Log a signal expiration to the database."""
    exp = SignalExpiration(
        alert_id=alert_id,
        reason=result.reason or "unknown",
        insider_price=trade.price,
        expiration_price=result.current_price,
        price_move_pct=result.price_move_pct,
        market_name=trade.market_name,
        wallet_handle=wallet.handle,
    )
    session.add(exp)
    logger.info(
        "chase_risk.expired",
        reason=result.reason,
        wallet=wallet.handle,
        market=trade.market_name,
        move=f"{result.price_move_pct:.1f}%",
    )
    return exp


async def record_entry_quality(
    session: AsyncSession,
    alert_id: int,
    wallet: Wallet,
    trade: Trade,
    market: Market | None,
    current_price: float,
) -> EntryQuality:
    """Record entry quality metrics for post-analysis."""
    eq = EntryQuality(
        alert_id=alert_id,
        wallet_id=wallet.id,
        market_id=market.id if market else None,
        insider_entry_price=trade.price,
        alert_price=current_price,
    )
    session.add(eq)
    return eq
