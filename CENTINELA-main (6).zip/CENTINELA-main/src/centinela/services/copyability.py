"""Copyability Score — Time-to-Move Model (Module 3, exact spec formulas).

Per-wallet metrics:
  t3  = median seconds to 3% move in trade direction
  t5  = median seconds to 5% move
  t10 = median seconds to 10% move
  er  = average edge retention (0-1)
  cv_t5 = std(t5) / mean(t5)
  stability = 1 - clamp(cv_t5 / 1.5, 0, 1)

Normalize against copy thresholds:
  t3_norm  = clamp(t3 / 180, 0, 1)    ← 3 min = fully copyable
  t5_norm  = clamp(t5 / 300, 0, 1)    ← 5 min
  t10_norm = clamp(t10 / 600, 0, 1)   ← 10 min

copyability_raw = 0.25*t3_norm + 0.30*t5_norm + 0.20*t10_norm + 0.15*er + 0.10*stability
copyability_adj = copyability_raw * (0.65 + 0.35 * sample_conf(n_signals, 40))
copyability_score = score100(copyability_adj)

Action:
  80-100: boost priority one level
  60-79: normal
  40-59: reduce size 35%
  <40: suppress unless cross-platform >= 12pt
"""

import math

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant import CopyabilityMetric
from centinela.db.models.wallet import Wallet
from centinela.utils.math_primitives import clamp, confidence_multiplier, score100

logger = structlog.get_logger()


async def compute_copyability(
    session: AsyncSession,
    wallet: Wallet,
    t3_samples: list[float] | None = None,
    t5_samples: list[float] | None = None,
    t10_samples: list[float] | None = None,
    edge_retention: float = 0.5,
) -> float:
    """Compute copyability score for a wallet (Module 3 exact formula).

    t3/t5/t10_samples: lists of seconds-to-move measurements.
    Returns copyability_score (0-100).
    """
    # Calculate medians
    t3 = _median(t3_samples) if t3_samples else 120.0  # default 2 min
    t5 = _median(t5_samples) if t5_samples else 240.0
    t10 = _median(t10_samples) if t10_samples else 480.0

    # cv_t5 = std(t5) / mean(t5)
    cv_t5 = 0.5  # default
    if t5_samples and len(t5_samples) >= 3:
        mean_t5 = sum(t5_samples) / len(t5_samples)
        if mean_t5 > 0:
            var = sum((x - mean_t5) ** 2 for x in t5_samples) / len(t5_samples)
            cv_t5 = math.sqrt(var) / mean_t5

    # stability = 1 - clamp(cv_t5 / 1.5, 0, 1)
    stability = 1 - clamp(cv_t5 / 1.5, 0, 1)

    # Normalize against copy thresholds
    t3_norm = clamp(t3 / 180, 0, 1)    # 3 minutes
    t5_norm = clamp(t5 / 300, 0, 1)    # 5 minutes
    t10_norm = clamp(t10 / 600, 0, 1)  # 10 minutes
    er = clamp(edge_retention, 0, 1)

    # Copyability formula (spec exact)
    copyability_raw = (
        0.25 * t3_norm
        + 0.30 * t5_norm
        + 0.20 * t10_norm
        + 0.15 * er
        + 0.10 * stability
    )

    # Confidence adjustment
    n_signals = len(t5_samples) if t5_samples else 0
    sample_conf = confidence_multiplier(n_signals, max_trades=40)
    copyability_adj = copyability_raw * (0.65 + 0.35 * sample_conf)

    score = score100(copyability_adj * 100)

    # Persist
    existing = await session.execute(
        select(CopyabilityMetric).where(CopyabilityMetric.wallet_id == wallet.id)
    )
    metric = existing.scalar_one_or_none()
    if metric is None:
        metric = CopyabilityMetric(wallet_id=wallet.id)
        session.add(metric)

    metric.t3_median = t3
    metric.t5_median = t5
    metric.t10_median = t10
    metric.edge_retention = edge_retention
    metric.cv_t5 = cv_t5
    metric.stability = stability
    metric.copyability_raw = copyability_raw
    metric.copyability_score = score
    metric.n_signals_evaluated = n_signals

    logger.info(
        "copyability.computed",
        wallet=wallet.handle,
        score=f"{score:.0f}",
        t5=f"{t5:.0f}s",
        stability=f"{stability:.2f}",
    )
    return score


def get_copyability_action(score: float) -> dict:
    """Get action based on copyability score.

    80-100: boost priority one level
    60-79: normal
    40-59: reduce size 35%
    <40: suppress unless cross-platform >= 12pt
    """
    if score >= 80:
        return {"action": "boost", "size_mult": 1.0, "priority_boost": 1}
    elif score >= 60:
        return {"action": "normal", "size_mult": 1.0, "priority_boost": 0}
    elif score >= 40:
        return {"action": "reduce", "size_mult": 0.65, "priority_boost": 0}
    else:
        return {"action": "suppress", "size_mult": 0.0, "priority_boost": 0}


def _median(values: list[float]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    if n % 2 == 1:
        return s[n // 2]
    return (s[n // 2 - 1] + s[n // 2]) / 2
