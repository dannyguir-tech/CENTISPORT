"""Wallet Clustering / Hidden Syndicates — Module 2 (exact spec formulas).

Pairwise link scoring (wallets i and j over rolling 30 days):

  co_market_rate   = shared markets / union of all markets
  same_side_rate   = matching direction fraction in shared markets
  timing_corr      = entries within 120 seconds fraction
  size_similarity  = 1 - clamp(abs(log(safe_div(median_i, median_j, 1))) / log(3), 0, 1)
  repeat_pair_rate = repeated same-market same-side co-occurrences / max(shared, 1)

  pair_link_score = 0.30*co_market + 0.25*same_side + 0.25*timing + 0.10*size + 0.10*repeat
  pair_confidence = pair_link_score * sample_conf(n_shared, 25)

Graph: edge if pair_confidence >= 0.68
Consensus discount:
  effective_count = unique_clusters + 0.35 * (total - unique_clusters)
  adjustment = clamp(effective / total, 0.4, 1.0)
"""

import math
from collections import defaultdict
from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant import ClusterPair, WalletCluster
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.utils.math_primitives import clamp, confidence_multiplier, safe_div

logger = structlog.get_logger()

CLUSTER_EDGE_THRESHOLD = 0.68


async def compute_all_pairs(session: AsyncSession) -> int:
    """Compute pairwise link scores for all active smart wallets.

    Returns number of pairs computed.
    """
    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=30)

    result = await session.execute(
        select(Wallet)
        .where(Wallet.is_active == True)  # noqa: E712
        .where(Wallet.wallet_type == "smart")
    )
    wallets = list(result.scalars().all())

    if len(wallets) < 2:
        return 0

    # Load trades per wallet
    wallet_trades: dict[int, list[Trade]] = {}
    for w in wallets:
        t_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == w.id)
            .where(Trade.timestamp >= cutoff)
            .order_by(Trade.timestamp.asc())
        )
        wallet_trades[w.id] = list(t_result.scalars().all())

    pair_count = 0
    for i, wa in enumerate(wallets):
        for wb in wallets[i + 1:]:
            score = _compute_pair_score(
                wallet_trades.get(wa.id, []),
                wallet_trades.get(wb.id, []),
            )
            if score is None:
                continue

            # Upsert pair
            existing = await session.execute(
                select(ClusterPair)
                .where(ClusterPair.wallet_a_id == wa.id)
                .where(ClusterPair.wallet_b_id == wb.id)
            )
            pair = existing.scalar_one_or_none()
            if pair is None:
                pair = ClusterPair(wallet_a_id=wa.id, wallet_b_id=wb.id)
                session.add(pair)

            pair.co_market_rate = score["co_market_rate"]
            pair.same_side_rate = score["same_side_rate"]
            pair.timing_corr = score["timing_corr"]
            pair.size_similarity = score["size_similarity"]
            pair.repeat_pair_rate = score["repeat_pair_rate"]
            pair.pair_link_score = score["pair_link_score"]
            pair.pair_confidence = score["pair_confidence"]
            pair.n_shared_events = score["n_shared"]
            pair.last_calculated = datetime.now(tz=timezone.utc)
            pair_count += 1

    # Build clusters from high-confidence pairs
    await _build_clusters(session, wallets)
    await session.commit()
    return pair_count


def _compute_pair_score(
    trades_a: list[Trade], trades_b: list[Trade]
) -> dict | None:
    """Compute pairwise link score between two wallets (exact spec formula)."""
    # Build market → trades mapping
    markets_a: dict[str, list[Trade]] = defaultdict(list)
    markets_b: dict[str, list[Trade]] = defaultdict(list)
    for t in trades_a:
        markets_a[t.market_name].append(t)
    for t in trades_b:
        markets_b[t.market_name].append(t)

    shared_markets = set(markets_a.keys()) & set(markets_b.keys())
    union_markets = set(markets_a.keys()) | set(markets_b.keys())

    if not shared_markets or not union_markets:
        return None

    # co_market_rate
    co_market_rate = len(shared_markets) / len(union_markets)

    # same_side_rate, timing_corr, repeat_pair_rate
    same_side_count = 0
    timing_match_count = 0
    repeat_count = 0
    total_shared_events = 0

    for market in shared_markets:
        ta_list = markets_a[market]
        tb_list = markets_b[market]
        total_shared_events += min(len(ta_list), len(tb_list))

        for ta in ta_list:
            for tb in tb_list:
                if ta.side == tb.side:
                    same_side_count += 1
                    repeat_count += 1

                # timing: within 120 seconds
                ta_ts = ta.timestamp.timestamp() if hasattr(ta.timestamp, 'timestamp') else 0
                tb_ts = tb.timestamp.timestamp() if hasattr(tb.timestamp, 'timestamp') else 0
                if abs(ta_ts - tb_ts) <= 120:
                    timing_match_count += 1

    n_comparisons = max(total_shared_events, 1)
    same_side_rate = same_side_count / n_comparisons
    timing_corr = timing_match_count / n_comparisons
    repeat_pair_rate = repeat_count / max(total_shared_events, 1)

    # size_similarity = 1 - clamp(abs(log(safe_div(median_i, median_j, 1))) / log(3), 0, 1)
    sizes_a = sorted(t.size for t in trades_a if t.size > 0)
    sizes_b = sorted(t.size for t in trades_b if t.size > 0)
    med_a = sizes_a[len(sizes_a) // 2] if sizes_a else 1
    med_b = sizes_b[len(sizes_b) // 2] if sizes_b else 1
    log_ratio = abs(math.log(safe_div(med_a, med_b, 1.0))) / math.log(3) if med_b > 0 else 1
    size_similarity = 1 - clamp(log_ratio, 0, 1)

    # pair_link_score (spec weights)
    pair_link_score = (
        0.30 * co_market_rate
        + 0.25 * same_side_rate
        + 0.25 * timing_corr
        + 0.10 * size_similarity
        + 0.10 * repeat_pair_rate
    )

    # pair_confidence = pair_link_score * sample_conf(n_shared, 25)
    n_shared = total_shared_events
    sample_conf = confidence_multiplier(n_shared, max_trades=25)
    pair_confidence = pair_link_score * sample_conf

    return {
        "co_market_rate": co_market_rate,
        "same_side_rate": same_side_rate,
        "timing_corr": timing_corr,
        "size_similarity": size_similarity,
        "repeat_pair_rate": repeat_pair_rate,
        "pair_link_score": pair_link_score,
        "pair_confidence": pair_confidence,
        "n_shared": n_shared,
    }


async def _build_clusters(session: AsyncSession, wallets: list[Wallet]) -> None:
    """Build connected components from high-confidence pairs."""
    # Get all pairs above threshold
    result = await session.execute(
        select(ClusterPair).where(ClusterPair.pair_confidence >= CLUSTER_EDGE_THRESHOLD)
    )
    pairs = list(result.scalars().all())

    # Union-Find for connected components
    parent: dict[int, int] = {}

    def find(x):
        while parent.get(x, x) != x:
            parent[x] = parent.get(parent[x], parent[x])
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for pair in pairs:
        union(pair.wallet_a_id, pair.wallet_b_id)

    # Assign cluster IDs
    clusters: dict[int, list[int]] = defaultdict(list)
    for w in wallets:
        root = find(w.id)
        clusters[root].append(w.id)

    # Only keep clusters with 2+ members
    cluster_id = 1
    for root, members in clusters.items():
        if len(members) < 2:
            continue

        # Calculate cluster confidence
        member_confs = []
        for pair in pairs:
            if pair.wallet_a_id in members and pair.wallet_b_id in members:
                member_confs.append(pair.pair_confidence)

        avg_conf = sum(member_confs) / len(member_confs) if member_confs else 0

        for wid in members:
            # Upsert cluster membership
            existing = await session.execute(
                select(WalletCluster).where(WalletCluster.wallet_id == wid)
            )
            wc = existing.scalar_one_or_none()
            if wc is None:
                wc = WalletCluster(wallet_id=wid, cluster_id=cluster_id, cluster_confidence=avg_conf)
                session.add(wc)
            else:
                wc.cluster_id = cluster_id
                wc.cluster_confidence = avg_conf

        cluster_id += 1


def consensus_cluster_discount(
    wallet_ids: list[int],
    cluster_memberships: dict[int, int],  # wallet_id → cluster_id
) -> float:
    """Calculate consensus discount for clustered wallets.

    effective_count = unique_clusters + 0.35 * (total - unique_clusters)
    adjustment = clamp(effective / total, 0.4, 1.0)
    """
    total = len(wallet_ids)
    if total <= 1:
        return 1.0

    clusters_seen: set[int] = set()
    unclustered = 0
    for wid in wallet_ids:
        cid = cluster_memberships.get(wid)
        if cid is not None:
            clusters_seen.add(cid)
        else:
            unclustered += 1

    unique_clusters = len(clusters_seen) + unclustered
    effective = unique_clusters + 0.35 * (total - unique_clusters)
    return clamp(effective / total, 0.4, 1.0)
