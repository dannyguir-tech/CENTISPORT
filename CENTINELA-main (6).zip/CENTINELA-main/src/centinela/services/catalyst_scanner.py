"""AI catalyst scanner (Claude API) + news integration (RSS).

Catalyst scanner: use Claude API to estimate probability impact
of upcoming events on active markets.

News integration: fetch RSS feeds for catalyst timestamping.
"""

import structlog
import httpx

from centinela.config import settings

logger = structlog.get_logger()


# --- AI Catalyst Scanner ---

async def scan_catalyst_impact(
    market_question: str,
    upcoming_event: str,
    current_price: float,
) -> dict | None:
    """Use Claude API to estimate probability impact of an event on a market.

    Returns {"impact_estimate": float, "direction": str, "reasoning": str}
    or None if unavailable.
    """
    # Check for Anthropic API key in environment
    import os
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.debug("catalyst.no_api_key")
        return None

    prompt = (
        f"You are a prediction market analyst. A market asks: '{market_question}'. "
        f"The current YES price is ${current_price:.2f} ({current_price*100:.0f}%). "
        f"An upcoming event: '{upcoming_event}'. "
        f"Estimate: 1) Will this event move the market? 2) In which direction (YES higher or NO higher)? "
        f"3) By approximately how many percentage points? "
        f"Respond in JSON: {{\"impact_points\": number, \"direction\": \"yes_up\" or \"no_up\", \"confidence\": 0-1, \"reasoning\": \"brief\"}}"
    )

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 300,
                    "messages": [{"role": "user", "content": prompt}],
                },
            )
            resp.raise_for_status()
            data = resp.json()
            content = data.get("content", [{}])[0].get("text", "")
            # Try to parse JSON from response
            import json
            # Find JSON in response
            start = content.find("{")
            end = content.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(content[start:end])
    except Exception as e:
        logger.error("catalyst.api_error", error=str(e))

    return None


# --- News / RSS Integration ---

async def fetch_rss_headlines(feed_url: str, limit: int = 20) -> list[dict]:
    """Fetch headlines from an RSS feed for catalyst timestamping."""
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(feed_url)
            resp.raise_for_status()

        # Simple XML parsing for RSS
        content = resp.text
        items: list[dict] = []

        # Basic RSS <item> extraction
        import re
        item_blocks = re.findall(r"<item>(.*?)</item>", content, re.DOTALL)
        for block in item_blocks[:limit]:
            title = _extract_tag(block, "title")
            link = _extract_tag(block, "link")
            pub_date = _extract_tag(block, "pubDate")
            description = _extract_tag(block, "description")
            items.append({
                "title": title,
                "link": link,
                "pubDate": pub_date,
                "description": description[:200] if description else None,
            })

        return items
    except Exception as e:
        logger.error("rss.fetch_error", feed=feed_url, error=str(e))
        return []


def _extract_tag(xml: str, tag: str) -> str | None:
    """Extract content from an XML tag."""
    import re
    match = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", xml, re.DOTALL)
    if match:
        content = match.group(1).strip()
        # Strip CDATA
        content = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", content, flags=re.DOTALL)
        # Strip HTML tags
        content = re.sub(r"<[^>]+>", "", content)
        return content.strip()
    return None


# Common RSS feeds for prediction market catalysts
DEFAULT_FEEDS = {
    "reuters_top": "https://feeds.reuters.com/reuters/topNews",
    "ap_top": "https://rsshub.app/apnews/topics/apf-topnews",
    "polymarket_blog": "https://polymarket.com/blog/rss",
}
