"""Position size calculator — fractional Kelly + slippage cap.

Sizing formula:
1. Kelly % = (WR * avg_win/avg_loss - (1 - WR)) / (avg_win/avg_loss)
2. kelly_size = kelly_pct * available_capital * fraction (0.25 = quarter Kelly)
3. slippage_cap = max position where slippage <= 2%
4. bankroll_cap = max_per_market_pct * total_capital
5. final_size = min(kelly_size, slippage_cap, bankroll_cap)

Position building:
- FIRST_ENTRY from sniper: 50% of recommended
- CONSENSUS: full size
- CONVERGENCE: full size
- CROSS_PLATFORM: full size
- DUMB_MONEY_FADE: 60% of recommended
"""

import math

import structlog

from centinela.db.models.execution import Bankroll
from centinela.db.models.wallet import Wallet
from centinela.services.slippage import get_slippage_cap

logger = structlog.get_logger()


def kelly_criterion(
    win_rate: float,
    avg_win: float = 0.35,
    avg_loss: float = 0.25,
) -> float:
    """Calculate Kelly percentage.

    Returns fraction of bankroll to bet (0-1, can be negative if no edge).
    """
    if avg_loss <= 0 or win_rate <= 0:
        return 0.0
    win_loss_ratio = avg_win / avg_loss
    kelly = (win_rate * win_loss_ratio - (1 - win_rate)) / win_loss_ratio
    return max(0.0, kelly)


async def calculate_position_size(
    bankroll: Bankroll,
    wallet: Wallet,
    token_id: str | None,
    signal_type: str = "insider",
    is_first_entry: bool = False,
) -> dict:
    """Calculate recommended position sizes (conservative/standard/aggressive).

    Returns dict with sizing details.
    """
    # 1. Kelly calculation (None-safe)
    wr = float(wallet.win_rate or 0.0)
    win_rate = wr if wr > 0 else 0.55
    kelly_pct = kelly_criterion(win_rate)
    kelly_size = kelly_pct * bankroll.available_capital * bankroll.kelly_fraction

    # 2. Slippage cap
    slippage_cap = float("inf")
    if token_id:
        cap = await get_slippage_cap(token_id)
        if cap > 0:
            slippage_cap = cap

    # 3. Bankroll cap (max per market)
    bankroll_cap = bankroll.total_capital * bankroll.max_per_market_pct

    # 4. Base size = min of all three
    base_size = min(kelly_size, slippage_cap, bankroll_cap)
    base_size = max(0.0, base_size)

    # 5. Strategy state multiplier
    state_mult = 1.0
    if bankroll.strategy_state == "yellow":
        state_mult = 0.5  # Reduce 50% in yellow
    elif bankroll.strategy_state == "red":
        state_mult = 0.0  # No new positions in red

    base_size *= state_mult

    # 6. Signal type multiplier
    type_mult = _signal_type_multiplier(signal_type, is_first_entry)
    standard_size = base_size * type_mult

    # 7. Conservative / Aggressive tiers
    conservative = standard_size * 0.5
    aggressive = min(standard_size * 1.6, bankroll_cap)

    return {
        "conservative": round(conservative, 2),
        "standard": round(standard_size, 2),
        "aggressive": round(aggressive, 2),
        "kelly_pct": round(kelly_pct * 100, 2),
        "kelly_size": round(kelly_size, 2),
        "slippage_cap": round(slippage_cap, 2) if slippage_cap != float("inf") else None,
        "bankroll_cap": round(bankroll_cap, 2),
        "state_multiplier": state_mult,
        "type_multiplier": type_mult,
    }


def _signal_type_multiplier(signal_type: str, is_first_entry: bool) -> float:
    """Get position build multiplier by signal type."""
    if signal_type == "insider" and is_first_entry:
        return 0.5  # 50% on first entry, hold rest for confirmation
    if signal_type == "dumb_money_fade":
        return 0.6  # Contrarian = slightly smaller
    # consensus, convergence, cross_platform = full size
    return 1.0


def format_sizing_block(sizing: dict, bankroll: Bankroll) -> str:
    """Format position sizing for alert message."""
    conservative_pct = (sizing["conservative"] / bankroll.total_capital * 100) if bankroll.total_capital > 0 else 0
    standard_pct = (sizing["standard"] / bankroll.total_capital * 100) if bankroll.total_capital > 0 else 0
    aggressive_pct = (sizing["aggressive"] / bankroll.total_capital * 100) if bankroll.total_capital > 0 else 0

    return (
        f"\U0001F4B0 ENTRY:\n"
        f"   Conservative: ${sizing['conservative']:,.0f} ({conservative_pct:.1f}%)\n"
        f"   Standard:     ${sizing['standard']:,.0f} ({standard_pct:.1f}%)\n"
        f"   Aggressive:   ${sizing['aggressive']:,.0f} ({aggressive_pct:.1f}%)"
    )
