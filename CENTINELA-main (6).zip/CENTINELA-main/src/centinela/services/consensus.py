"""Consensus signals (3+ insiders on same side) and convergence detection
(smart + dumb on opposite sides = highest conviction).

Consensus:
  3+ tracked insiders with score >= 60 on same side of same market
  within an 18-hour window → CONSENSUS signal.

Convergence:
  Smart money on one side AND dumb money on the other
  + optional cross-platform confirmation
  = Highest conviction signal in the system.
"""

from collections import defaultdict
from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.cross_platform import CrossPlatformMarket, CrossPlatformPrice
from centinela.db.models.edge_expansion import ConsensusSignal, ConvergenceSignal
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()

CONSENSUS_MIN_WALLETS = 3
CONSENSUS_WINDOW_HOURS = 18
CONSENSUS_MIN_SCORE = 60


async def detect_consensus(session: AsyncSession) -> list[ConsensusSignal]:
    """Scan recent trades for consensus signals (3+ insiders same side).

    Returns list of new ConsensusSignal records.
    """
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=CONSENSUS_WINDOW_HOURS)

    # Get recent trades from smart wallets with decent scores
    result = await session.execute(
        select(Trade, Wallet)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.timestamp >= cutoff)
        .where(Wallet.wallet_type == "smart")
        .where(Wallet.insider_score >= CONSENSUS_MIN_SCORE)
        .where(Wallet.is_active == True)  # noqa: E712
        .order_by(Trade.timestamp.desc())
    )
    rows = result.all()

    # Group by (market_name, side) → list of (wallet_id, score, capital)
    market_sides: dict[tuple[str, str], list[tuple[int, float, float]]] = defaultdict(list)
    seen: set[tuple[int, str, str]] = set()

    for trade, wallet in rows:
        key = (wallet.id, trade.market_name, trade.side)
        if key in seen:
            continue
        seen.add(key)
        market_sides[(trade.market_name, trade.side)].append(
            (wallet.id, wallet.insider_score, trade.size)
        )

    # Check for existing consensus signals to avoid duplicates
    new_signals: list[ConsensusSignal] = []
    for (market_name, side), entries in market_sides.items():
        if len(entries) < CONSENSUS_MIN_WALLETS:
            continue

        wallet_ids = [e[0] for e in entries]
        scores = [e[1] for e in entries]
        capitals = [e[2] for e in entries]

        # Check if we already have a consensus signal for this market+side
        existing = await session.execute(
            select(ConsensusSignal)
            .where(ConsensusSignal.market_name == market_name)
            .where(ConsensusSignal.side == side)
            .where(ConsensusSignal.timestamp >= cutoff)
        )
        if existing.scalar_one_or_none():
            continue

        combined_score = sum(scores) / len(scores)
        total_capital = sum(capitals)

        signal = ConsensusSignal(
            market_name=market_name,
            side=side,
            wallet_ids=wallet_ids,
            wallet_count=len(entries),
            combined_score=combined_score,
            total_capital=total_capital,
        )
        session.add(signal)
        new_signals.append(signal)

        logger.info(
            "consensus.detected",
            market=market_name,
            side=side,
            wallets=len(entries),
            combined_score=f"{combined_score:.0f}",
            capital=f"${total_capital:,.0f}",
        )

    if new_signals:
        await session.flush()

    return new_signals


async def detect_convergence(session: AsyncSession) -> list[ConvergenceSignal]:
    """Detect convergence: smart money + dumb money on opposite sides.

    This is the highest conviction signal in the system.
    """
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=24)

    # Get recent smart money positions (ordered by time desc so first-seen = latest)
    smart_result = await session.execute(
        select(Trade, Wallet)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.timestamp >= cutoff)
        .where(Wallet.wallet_type == "smart")
        .where(Wallet.insider_score >= CONSENSUS_MIN_SCORE)
        .where(Wallet.is_active == True)  # noqa: E712
        .order_by(Trade.timestamp.desc())
    )
    smart_rows = smart_result.all()

    # Get recent dumb money positions (ordered by time desc)
    dumb_result = await session.execute(
        select(Trade, Wallet)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.timestamp >= cutoff)
        .where(Wallet.wallet_type == "dumb")
        .where(Wallet.inverse_score >= 70)
        .where(Wallet.is_active == True)  # noqa: E712
        .order_by(Trade.timestamp.desc())
    )
    dumb_rows = dumb_result.all()

    # Build market → side → wallet mapping
    smart_by_market: dict[str, dict[str, list[tuple[int, float]]]] = defaultdict(lambda: defaultdict(list))
    dumb_by_market: dict[str, dict[str, list[tuple[int, float]]]] = defaultdict(lambda: defaultdict(list))

    seen_smart: set[tuple[int, str]] = set()
    for trade, wallet in smart_rows:
        key = (wallet.id, trade.market_name)
        if key in seen_smart:
            continue
        seen_smart.add(key)
        smart_by_market[trade.market_name][trade.side].append(
            (wallet.id, wallet.insider_score)
        )

    seen_dumb: set[tuple[int, str]] = set()
    for trade, wallet in dumb_rows:
        key = (wallet.id, trade.market_name)
        if key in seen_dumb:
            continue
        seen_dumb.add(key)
        dumb_by_market[trade.market_name][trade.side].append(
            (wallet.id, wallet.inverse_score)
        )

    # Find markets where smart and dumb are on opposite sides
    new_signals: list[ConvergenceSignal] = []
    for market_name in set(smart_by_market.keys()) & set(dumb_by_market.keys()):
        for smart_side in ("YES", "NO"):
            dumb_side = "NO" if smart_side == "YES" else "YES"

            smart_entries = smart_by_market[market_name].get(smart_side, [])
            dumb_entries = dumb_by_market[market_name].get(dumb_side, [])

            if not smart_entries or not dumb_entries:
                continue

            # Check for existing convergence signal
            existing = await session.execute(
                select(ConvergenceSignal)
                .where(ConvergenceSignal.market_name == market_name)
                .where(ConvergenceSignal.smart_side == smart_side)
                .where(ConvergenceSignal.timestamp >= cutoff)
            )
            if existing.scalar_one_or_none():
                continue

            smart_ids = [e[0] for e in smart_entries]
            smart_scores = [e[1] for e in smart_entries]
            dumb_ids = [e[0] for e in dumb_entries]
            dumb_scores = [e[1] for e in dumb_entries]

            # Look up cross-platform gap for this market
            xplat_gap = None
            market_row = await session.execute(
                select(Market).where(Market.question == market_name).limit(1)
            )
            mkt = market_row.scalar_one_or_none()
            if mkt:
                xplat_row = await session.execute(
                    select(CrossPlatformPrice)
                    .join(CrossPlatformMarket, CrossPlatformPrice.cross_platform_market_id == CrossPlatformMarket.id)
                    .where(CrossPlatformMarket.polymarket_market_id == mkt.id)
                    .order_by(CrossPlatformPrice.timestamp.desc())
                    .limit(1)
                )
                xplat = xplat_row.scalar_one_or_none()
                if xplat:
                    xplat_gap = xplat.price_gap

            # Count edge sources: smart + dumb = 2, + xplat = 3
            edge_sources = 2
            if xplat_gap is not None and xplat_gap >= 10:
                edge_sources = 3

            signal = ConvergenceSignal(
                market_name=market_name,
                smart_wallet_ids=smart_ids,
                smart_side=smart_side,
                smart_combined_score=sum(smart_scores) / len(smart_scores),
                dumb_wallet_ids=dumb_ids,
                dumb_side=dumb_side,
                dumb_combined_inverse_score=sum(dumb_scores) / len(dumb_scores),
                cross_platform_gap=xplat_gap,
                total_edge_sources=edge_sources,
            )
            session.add(signal)
            new_signals.append(signal)

            logger.info(
                "convergence.detected",
                market=market_name,
                smart_side=smart_side,
                smart_wallets=len(smart_entries),
                dumb_wallets=len(dumb_entries),
            )

    if new_signals:
        await session.flush()

    return new_signals
