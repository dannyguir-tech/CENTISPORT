"""Kalshi service — poll prices and detect cross-platform divergence.

Polls Kalshi prices every 60s for matched market pairs.
Triggers alert when price gap >= 10 points.
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

import redis.asyncio as aioredis

from centinela.clients.kalshi import kalshi_client
from centinela.clients.polymarket_clob import polymarket_clob
from centinela.db.models.cross_platform import CrossPlatformMarket, CrossPlatformPrice
from centinela.db.models.market import Market
from centinela.dependencies import get_redis
from centinela.services.telegram_bot import send_divergence_alert

logger = structlog.get_logger()

DIVERGENCE_THRESHOLD = 10.0  # points
DIVERGENCE_COOLDOWN_SECONDS = 3600  # 1 hour between alerts for same pair
DIVERGENCE_ALERT_KEY_PREFIX = "centinela:divergence_alerted:"


async def poll_all_pairs(session: AsyncSession) -> int:
    """Poll Kalshi prices for all active cross-platform pairs.

    Returns number of divergences detected.
    """
    result = await session.execute(
        select(CrossPlatformMarket).where(CrossPlatformMarket.is_active == True)  # noqa: E712
    )
    pairs = result.scalars().all()

    divergences = 0
    for pair in pairs:
        try:
            gap = await check_pair(session, pair)
            if gap is not None and gap >= DIVERGENCE_THRESHOLD:
                divergences += 1
        except Exception as e:
            logger.error("kalshi.pair_error", pair_id=pair.id, error=str(e))

    return divergences


async def check_pair(session: AsyncSession, pair: CrossPlatformMarket) -> float | None:
    """Check a single cross-platform pair for divergence.

    Returns the price gap in points, or None if prices unavailable.
    """
    # Get Kalshi price
    kalshi_price = await kalshi_client.get_market_price(pair.kalshi_ticker)
    if kalshi_price is None:
        return None

    # Get Polymarket price
    market_result = await session.execute(
        select(Market).where(Market.id == pair.polymarket_market_id)
    )
    market = market_result.scalar_one_or_none()
    if not market:
        return None

    # Try CLOB midpoint first, fall back to stored odds
    poly_price = None
    if market.token_id_yes:
        poly_price = await polymarket_clob.get_midpoint(market.token_id_yes)
    if poly_price is None:
        poly_price = market.odds_yes
    if poly_price is None:
        return None

    # Calculate gap in points
    gap = abs(poly_price - kalshi_price) * 100

    # Store price snapshot
    price_record = CrossPlatformPrice(
        cross_platform_market_id=pair.id,
        polymarket_price=poly_price,
        kalshi_price=kalshi_price,
        price_gap=gap,
    )
    session.add(price_record)

    # Alert if divergence threshold met (with deduplication)
    if gap >= DIVERGENCE_THRESHOLD:
        redis = await get_redis()
        alert_key = f"{DIVERGENCE_ALERT_KEY_PREFIX}{pair.id}"
        already_alerted = await redis.get(alert_key)

        if not already_alerted:
            logger.info(
                "kalshi.divergence_detected",
                market=market.question,
                poly=f"{poly_price:.2f}",
                kalshi=f"{kalshi_price:.2f}",
                gap=f"{gap:.1f}pt",
            )
            await send_divergence_alert(
                session=session,
                market_question=market.question,
                polymarket_price=poly_price,
                kalshi_price=kalshi_price,
                gap=gap,
                market_id=market.id,
            )
            await redis.set(alert_key, "1", ex=DIVERGENCE_COOLDOWN_SECONDS)

    await session.commit()
    return gap
