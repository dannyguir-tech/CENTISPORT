"""Signal pipeline — orchestrates the full flow from detected trade to alert.

When a new trade is detected:
1. Route by wallet type (smart → insider flow, dumb → fade flow)
2. Check signal throttle (rate limits, quiet hours)
3. For smart wallets: decision engine waterfall, sizing, alert, open position
4. For dumb wallets: fade scoring (5-component), smart money conflict check, alert
5. After each poll cycle: scan for consensus (3+ insiders) and convergence (smart+dumb)
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

import redis.asyncio as aioredis

from centinela.db.models.market import Market
from centinela.db.models.quant import CopyabilityMetric, LeaderMetric, WalletCluster
from centinela.db.models.quant_intelligence import MarketRegime
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.services.bankroll import get_or_create_bankroll, get_open_positions
from centinela.services.chase_risk import record_entry_quality, record_expiration
from centinela.services.decision_engine import run_decision_waterfall
from centinela.services.fade_scoring import calculate_fade_score, record_fade_signal, FADE_THRESHOLD
from centinela.services.intent_detection import classify_intent, build_features_from_trade, record_intent
from centinela.services.position_build import detect_build_phase
from centinela.services.position_manager import open_position
from centinela.services.position_sizer import calculate_position_size
from centinela.services.pre_signal import check_pre_signal_for_market
from centinela.services.shadow_tracking import record_shadow
from centinela.services.signal_throttle import can_send_alert, record_alert_sent
from centinela.services.telegram_bot import (
    send_expired_signal,
    send_fade_alert,
    send_insider_alert,
)
from centinela.services.unified_score import compute_unified_score, UnifiedScoreInputs

logger = structlog.get_logger()

# Wallet classifications that should never generate copy signals
EXCLUDED_CLASSIFICATIONS = {"MARKET_MAKER", "HEDGER", "NOISE"}


async def process_new_trade(
    session: AsyncSession,
    redis: aioredis.Redis,
    trade: Trade,
    wallet: Wallet,
) -> str:
    """Process a newly detected trade through the full signal pipeline.

    Routes to insider flow or dumb money fade flow based on wallet_type.
    Returns the decision output: "execute", "skip", "throttled", or "fade_execute".
    """
    # Skip wash-suspected wallets
    if wallet.wash_suspected:
        return "skip"

    # Route by wallet type
    if wallet.wallet_type == "dumb":
        return await _process_dumb_money_trade(session, redis, trade, wallet)
    elif wallet.classification in EXCLUDED_CLASSIFICATIONS:
        logger.debug("pipeline.excluded", wallet=wallet.handle, classification=wallet.classification)
        return "skip"
    else:
        return await _process_insider_trade(session, redis, trade, wallet)


async def _process_insider_trade(
    session: AsyncSession,
    redis: aioredis.Redis,
    trade: Trade,
    wallet: Wallet,
) -> str:
    """Process a trade from a smart/insider wallet."""
    # Detect build phase
    build = await detect_build_phase(session, wallet, trade)

    # Module 1: Intent classification (Trade-table + WebSocket features)
    ctx = await _compute_intent_context(session, trade, wallet)
    ws_features = await _compute_ws_intent_features(session, trade)
    intent_features = build_features_from_trade(
        trade_size=trade.size,
        median_size=wallet.avg_size or trade.size,
        seq_same_dir=ctx["seq_same_dir"],
        seq_alt_dir=ctx["seq_alt_dir"],
        related_opp_positions=ctx["related_opp_positions"],
        inventory_reduction=ctx["inventory_reduction"],
        dt_move_5_seconds=ws_features["dt_move_5_seconds"],
        pre_move_5_pct=ws_features["pre_move_5_pct"],
    )
    intent_result = classify_intent(intent_features)
    await record_intent(session, trade.id, wallet.id, trade.market_id, intent_result)

    # Resolve market
    market = None
    if trade.market_id:
        result = await session.execute(select(Market).where(Market.id == trade.market_id))
        market = result.scalar_one_or_none()

    # First-run safety: require market context. Without it, liquidity/slippage
    # checks silently no-op, trap detection gets zeros, and signals would
    # execute without guardrails. Log and record shadow but do NOT execute.
    token_id = None
    if market:
        token_id = market.token_id_yes if trade.side == "YES" else market.token_id_no

    if market is None or token_id is None:
        logger.info(
            "pipeline.market_context_missing",
            wallet=wallet.handle,
            market=trade.market_name,
            market_id=trade.market_id,
            reason="no market row or token_id — signal held",
        )
        await record_shadow(
            session, None, "insider",
            was_taken=False,
            skip_reason="missing_market_context",
        )
        await session.commit()
        return "skip"

    # Get bankroll context
    bankroll = await get_or_create_bankroll(session)
    positions = await get_open_positions(session)
    open_count = len(positions)

    sizing = await calculate_position_size(
        bankroll=bankroll,
        wallet=wallet,
        token_id=token_id,
        signal_type="insider",
        is_first_entry=(build.phase == "first_entry"),
    )
    recommended_size = sizing["standard"]

    # Look up quant metrics for this wallet (copyability + leader)
    copy_row = await session.execute(
        select(CopyabilityMetric).where(CopyabilityMetric.wallet_id == wallet.id)
    )
    copy_metric = copy_row.scalar_one_or_none()
    # When unknown, use neutral (100) — don't penalize untested wallets
    copyability_score = copy_metric.copyability_score if copy_metric else 100.0

    leader_row = await session.execute(
        select(LeaderMetric).where(LeaderMetric.wallet_id == wallet.id)
    )
    leader_metric = leader_row.scalar_one_or_none()
    leader_score = leader_metric.leader_score if leader_metric else 100.0

    # Run decision engine waterfall (includes trap detection)
    decision = await run_decision_waterfall(
        session=session,
        trade=trade,
        wallet=wallet,
        market=market,
        signal_type="insider",
        recommended_size=recommended_size,
    )

    # Module 4: Pre-signal check
    pre_signal_flag = False
    if market and market.id:
        pre_signal_flag, _ = await check_pre_signal_for_market(session, market.id)

    # Module 7: Look up latest regime for this market
    # Neutral defaults (1.0 confidence, low_vol) when regime data is absent
    regime_confidence = 1.0
    regime_label = "low_vol"
    regime_min_adj = 0
    if market and market.id:
        regime_row = await session.execute(
            select(MarketRegime)
            .where(MarketRegime.market_id == market.id)
            .order_by(MarketRegime.timestamp.desc())
            .limit(1)
        )
        regime = regime_row.scalar_one_or_none()
        if regime:
            regime_confidence = regime.regime_confidence
            regime_label = regime.regime_label
            regime_min_adj = regime.min_score_adjustment

    # Module 2: Cluster discount for this wallet (solo insider = 1.0)
    cluster_discount = 1.0
    cluster_row = await session.execute(
        select(WalletCluster).where(WalletCluster.wallet_id == wallet.id)
    )
    wallet_cluster = cluster_row.scalar_one_or_none()

    # Compute unified score (ALL quant modules integrated) — defensive None defaults
    unified = compute_unified_score(UnifiedScoreInputs(
        base_signal_score=float(wallet.insider_score or 0.0),
        intent_multiplier=float(intent_result.multiplier or 1.0),
        intent_type=intent_result.intent_type or "informational",
        intent_confidence=float(intent_result.confidence or 0.5),
        cluster_discount=float(cluster_discount or 1.0),
        copyability_score=float(copyability_score or 50.0),
        pre_signal_flag=bool(pre_signal_flag),
        trap_risk_score=float(decision.trap_risk_score or 0.0),
        leader_score=float(leader_score or 50.0),
        regime_confidence=float(regime_confidence or 0.5),
        regime_label=regime_label or "low_vol",
        regime_min_score_adjustment=int(regime_min_adj or 0),
    ))

    # Execution gating based on unified score
    if unified.execution_gate == "no_alert":
        logger.info(
            "pipeline.unified_gate_skip",
            wallet=wallet.handle,
            market=trade.market_name,
            final_score=f"{unified.final_score:.1f}",
            gate=unified.execution_gate,
        )
        await record_shadow(session, None, "insider", was_taken=False, skip_reason="unified_score_below_threshold")
        await session.commit()
        return "skip"

    # Apply size adjustment from unified gating
    if unified.size_multiplier < 1.0:
        recommended_size = recommended_size * unified.size_multiplier
        sizing["standard"] = recommended_size

    # Check throttle using unified final score
    allowed, throttle_reason = await can_send_alert(
        redis=redis,
        priority=build.priority,
        signal_score=unified.final_score,
    )

    if decision.output == "execute":
        if not allowed:
            logger.info("pipeline.throttled", wallet=wallet.handle, reason=throttle_reason)
            await record_shadow(session, None, "insider", was_taken=False, skip_reason=f"throttled: {throttle_reason}")
            await session.commit()
            return "throttled"

        alert = await send_insider_alert(
            session=session,
            trade=trade,
            wallet=wallet,
            market=market,
            sizing=sizing,
            bankroll=bankroll,
            open_positions=open_count,
            decision_output="execute",
            warning=decision.warning,
        )
        await record_alert_sent(redis)

        build_phase_str = "50%" if sizing.get("type_multiplier", 1.0) == 0.5 else "100%"
        await open_position(
            session=session,
            alert_id=alert.id,
            market=market,
            wallet_id=wallet.id,
            market_name=trade.market_name,
            side=trade.side,
            size=recommended_size,
            entry_price=trade.price,
            signal_source="insider",
            build_phase=build_phase_str,
        )

        if alert and decision.chase_result:
            await record_entry_quality(
                session=session,
                alert_id=alert.id,
                wallet=wallet,
                trade=trade,
                market=market,
                current_price=decision.chase_result.current_price,
            )

        # Module 9: Shadow tracking — record the executed signal
        await record_shadow(session, alert.id, "insider", was_taken=None)

        await session.commit()
        return "execute"

    elif decision.output == "skip":
        if decision.chase_result and decision.chase_result.expired:
            await send_expired_signal(
                session=session,
                trade=trade,
                wallet=wallet,
                reason=decision.chase_result.reason or "unknown",
                price_move_pct=decision.chase_result.price_move_pct,
                current_price=decision.chase_result.current_price,
            )
            await record_expiration(session, trade, wallet, decision.chase_result)

            # Shadow tracking — expired signal
            await record_shadow(session, None, "insider", was_taken=False, skip_reason=decision.chase_result.reason)
        else:
            logger.info(
                "pipeline.skip",
                wallet=wallet.handle,
                market=trade.market_name,
                reason=decision.fail_reason,
            )
            # Shadow tracking — skipped signal
            await record_shadow(session, None, "insider", was_taken=False, skip_reason=decision.fail_reason)
        await session.commit()
        return "skip"

    return decision.output


async def _process_dumb_money_trade(
    session: AsyncSession,
    redis: aioredis.Redis,
    trade: Trade,
    wallet: Wallet,
) -> str:
    """Process a trade from a dumb money wallet → fade signal scoring."""
    # Resolve market
    market = None
    if trade.market_id:
        result = await session.execute(select(Market).where(Market.id == trade.market_id))
        market = result.scalar_one_or_none()

    # Calculate 5-component fade score
    fade_result = await calculate_fade_score(session, wallet, trade, market)

    # Record the signal regardless of outcome
    await record_fade_signal(session, wallet, trade, market, fade_result)

    # SUPPRESSED: smart money conflict
    if fade_result.suppressed:
        logger.info(
            "pipeline.fade_suppressed",
            wallet=wallet.handle,
            market=trade.market_name,
            reason=fade_result.suppress_reason,
        )
        await record_shadow(session, None, "dumb_money_fade", was_taken=False, skip_reason=fade_result.suppress_reason)
        await session.commit()
        return "skip"

    # Below threshold: log but don't alert
    if fade_result.score < FADE_THRESHOLD:
        logger.info(
            "pipeline.fade_below_threshold",
            wallet=wallet.handle,
            market=trade.market_name,
            score=f"{fade_result.score:.1f}",
        )
        await record_shadow(session, None, "dumb_money_fade", was_taken=False, skip_reason="below_threshold")
        await session.commit()
        return "skip"

    # Score passes! Check throttle
    allowed, throttle_reason = await can_send_alert(
        redis=redis,
        priority="standard",
        signal_score=fade_result.score,
    )
    if not allowed:
        logger.info("pipeline.fade_throttled", reason=throttle_reason)
        await record_shadow(session, None, "dumb_money_fade", was_taken=False, skip_reason=f"throttled: {throttle_reason}")
        await session.commit()
        return "throttled"

    # Get sizing (60% of normal for fades)
    bankroll = await get_or_create_bankroll(session)
    token_id = None
    if market:
        token_id = market.token_id_yes if fade_result.fade_side == "YES" else market.token_id_no

    sizing = await calculate_position_size(
        bankroll=bankroll,
        wallet=wallet,
        token_id=token_id,
        signal_type="dumb_money_fade",
        is_first_entry=True,
    )

    # Send fade alert
    alert = await send_fade_alert(
        session=session,
        dumb_wallet=wallet,
        trade=trade,
        fade_result=fade_result,
        sizing=sizing,
        bankroll=bankroll,
    )
    await record_alert_sent(redis)

    # Open position on fade side
    await open_position(
        session=session,
        alert_id=alert.id,
        market=market,
        wallet_id=wallet.id,
        market_name=trade.market_name,
        side=fade_result.fade_side,
        size=sizing["standard"],
        entry_price=1.0 - trade.price,  # Fade side price
        signal_source="dumb_money_fade",
    )

    # Shadow tracking — record the fade execution
    await record_shadow(session, alert.id, "dumb_money_fade", was_taken=None)

    await session.commit()
    logger.info(
        "pipeline.fade_execute",
        wallet=wallet.handle,
        market=trade.market_name,
        fade_side=fade_result.fade_side,
        score=f"{fade_result.score:.1f}",
    )
    return "fade_execute"


async def _compute_intent_context(session, trade, wallet):
    """Compute Trade-table-derived features for intent classification.

    Returns dict with seq_same_dir, seq_alt_dir, related_opp_positions, inventory_reduction.
    WebSocket-dependent features (dt_move_5_seconds, spread_cross, passive_fill,
    pre_move_5_pct) are left as their build_features defaults.
    """
    from datetime import datetime, timezone, timedelta

    # Last 10 trades by this wallet (exclude current trade)
    prior_result = await session.execute(
        select(Trade)
        .where(Trade.wallet_id == wallet.id)
        .where(Trade.id != trade.id)
        .order_by(Trade.timestamp.desc())
        .limit(10)
    )
    prior_trades = list(prior_result.scalars().all())

    # seq_same_dir: consecutive prior trades on the same side as this trade
    seq_same_dir = 0
    for t in prior_trades:
        if t.side == trade.side:
            seq_same_dir += 1
        else:
            break

    # seq_alt_dir: count of direction flips in recent history (last 10)
    seq_alt_dir = 0
    if prior_trades:
        last_side = prior_trades[0].side
        for t in prior_trades[1:]:
            if t.side != last_side:
                seq_alt_dir += 1
                last_side = t.side

    # related_opp_positions: other smart wallets on opposite side in same market (last 24h)
    related_opp_positions = 0.0
    if trade.market_id:
        cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=24)
        opp_side = "NO" if trade.side == "YES" else "YES"
        opp_result = await session.execute(
            select(Trade)
            .where(Trade.market_id == trade.market_id)
            .where(Trade.wallet_id != wallet.id)
            .where(Trade.side == opp_side)
            .where(Trade.timestamp >= cutoff)
        )
        opp_count = len(list(opp_result.scalars().all()))
        related_opp_positions = min(opp_count / 5.0, 1.0)  # normalize: 5+ = max

    # inventory_reduction: fraction of prior position reduced in last 30 min
    inventory_reduction = 0.0
    if trade.market_id:
        recent_cutoff = datetime.now(tz=timezone.utc) - timedelta(minutes=30)
        recent_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == wallet.id)
            .where(Trade.market_id == trade.market_id)
            .where(Trade.timestamp >= recent_cutoff)
            .where(Trade.id != trade.id)
        )
        recent = list(recent_result.scalars().all())
        if recent:
            opp_side = "NO" if trade.side == "YES" else "YES"
            reduced = sum(t.size for t in recent if t.side == opp_side)
            total = sum(t.size for t in recent)
            inventory_reduction = (reduced / total) if total > 0 else 0.0

    return {
        "seq_same_dir": seq_same_dir,
        "seq_alt_dir": seq_alt_dir,
        "related_opp_positions": related_opp_positions,
        "inventory_reduction": inventory_reduction,
    }


async def compute_insider_inventory_reduction(session, wallet_id, market_id, within_minutes=30):
    """Shared helper for trap detection: fraction of insider's position reduced in window.

    Returns float in [0.0, 1.0].
    """
    from datetime import datetime, timezone, timedelta

    if not market_id:
        return 0.0

    cutoff = datetime.now(tz=timezone.utc) - timedelta(minutes=within_minutes)
    result = await session.execute(
        select(Trade)
        .where(Trade.wallet_id == wallet_id)
        .where(Trade.market_id == market_id)
        .where(Trade.timestamp >= cutoff)
    )
    trades = list(result.scalars().all())
    if not trades:
        return 0.0

    # Treat trades on opposite sides as "reductions" of the main position
    # (crude heuristic: minority side / total)
    yes_vol = sum(t.size for t in trades if t.side == "YES")
    no_vol = sum(t.size for t in trades if t.side == "NO")
    total = yes_vol + no_vol
    if total == 0:
        return 0.0
    minority = min(yes_vol, no_vol)
    return minority / total


async def _compute_ws_intent_features(session, trade):
    """Compute WebSocket-fed features for intent detection.

    Returns dict with dt_move_5_seconds, pre_move_5_pct.
    If WebSocket has no data for this token, returns defaults (900.0, 0.0).
    """
    from centinela.clients.polymarket_ws import polymarket_ws

    result = {"dt_move_5_seconds": 900.0, "pre_move_5_pct": 0.0}

    if not trade.market_id:
        return result

    market_result = await session.execute(select(Market).where(Market.id == trade.market_id))
    market = market_result.scalar_one_or_none()
    if not market:
        return result

    token_id = market.token_id_yes if trade.side == "YES" else market.token_id_no
    if not token_id:
        return result

    # pre_move_5_pct: price change in the 5 minutes BEFORE the trade
    price_now = polymarket_ws.get_price(token_id)
    price_5m_ago = polymarket_ws.get_price_history(token_id, seconds_ago=300)
    if price_now and price_5m_ago and price_5m_ago > 0:
        result["pre_move_5_pct"] = abs((price_now - price_5m_ago) / price_5m_ago) * 100

    # dt_move_5_seconds: time between trade.price and first post-trade tick with >=5% move
    # (approximated: if price moved 5%+ in last 60s, dt is low; otherwise high)
    if price_now and trade.price > 0:
        move = abs(price_now - trade.price) / trade.price
        if move >= 0.05:
            result["dt_move_5_seconds"] = 60.0  # rough: moved within window
        elif move >= 0.02:
            result["dt_move_5_seconds"] = 300.0

    return result
