"""Trade decision engine — 7-step waterfall.

Every signal passes through this waterfall. If it fails ANY step, it's killed.

Step 1: CHECK STATUS — signal not expired, chase risk not triggered
Step 2: CHECK LIQUIDITY — market_liquidity >= max(10000, position_size * 10)
Step 3: CHECK SLIPPAGE — estimated_slippage <= 2%
Step 4: CHECK TRAP RISK — invalidate/reduce/deduct based on trap score
Step 5: CHECK WALLET QUALITY — score thresholds by signal type
Step 6: CHECK PORTFOLIO LIMITS — positions, exposure, lockout, strategy state
Step 7: CHECK CORRELATION — warn if category concentration high

Output: EXECUTE | SKIP | WAIT
"""

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.execution import Bankroll, DecisionLog
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.services.bankroll import (
    check_lockout,
    check_portfolio_limits,
    get_or_create_bankroll,
    get_open_positions,
)
from centinela.services.chase_risk import check_chase_risk, ChaseRiskResult
from centinela.services.slippage import check_slippage_ok
from centinela.services.trap_detection import compute_trap_risk, apply_trap_to_signal, record_trap_event

logger = structlog.get_logger()


class DecisionResult:
    def __init__(
        self,
        output: str,  # execute/skip/wait
        step_reached: str,
        fail_reason: str | None = None,
        chase_result: ChaseRiskResult | None = None,
        slippage_pct: float | None = None,
        recommended_size: float | None = None,
        warning: str | None = None,
        trap_risk_score: float = 0.0,
    ):
        self.output = output
        self.step_reached = step_reached
        self.fail_reason = fail_reason
        self.chase_result = chase_result
        self.slippage_pct = slippage_pct
        self.recommended_size = recommended_size
        self.warning = warning
        self.trap_risk_score = trap_risk_score


async def run_decision_waterfall(
    session: AsyncSession,
    trade: Trade,
    wallet: Wallet,
    market: Market | None,
    signal_type: str = "insider",
    recommended_size: float = 0.0,
) -> DecisionResult:
    """Run the 7-step decision waterfall on a signal.

    Returns DecisionResult with output (execute/skip/wait) and context.
    """

    # Step 1: CHECK STATUS — chase risk + expiration
    chase_result = await check_chase_risk(trade, market)
    if chase_result.expired:
        result = DecisionResult(
            output="skip",
            step_reached="status",
            fail_reason=f"Signal expired: {chase_result.reason} ({chase_result.price_move_pct:+.1f}%)",
            chase_result=chase_result,
        )
        await _log_decision(session, result, wallet, trade)
        return result

    # Step 2: CHECK LIQUIDITY
    if market and market.daily_volume is not None:
        min_liquidity = max(10000, recommended_size * 10)
        if market.daily_volume < min_liquidity:
            result = DecisionResult(
                output="skip",
                step_reached="liquidity",
                fail_reason=f"Low liquidity — market volume ${market.daily_volume:,.0f}, need ${min_liquidity:,.0f}",
            )
            await _log_decision(session, result, wallet, trade)
            return result

    # Step 3: CHECK SLIPPAGE
    token_id = None
    if market:
        token_id = market.token_id_yes if trade.side == "YES" else market.token_id_no
    if recommended_size > 0 and token_id:
        slippage_ok, slippage_pct = await check_slippage_ok(token_id, recommended_size)
        if not slippage_ok:
            result = DecisionResult(
                output="skip",
                step_reached="slippage",
                fail_reason=f"Slippage too high — estimated {slippage_pct:.1f}% on ${recommended_size:,.0f}",
                slippage_pct=slippage_pct,
            )
            await _log_decision(session, result, wallet, trade)
            return result
    else:
        slippage_pct = None

    # Step 4: CHECK TRAP RISK
    # Derive what we can from market data + Trade table + WebSocket feed.
    from centinela.services.signal_pipeline import compute_insider_inventory_reduction
    from centinela.clients.polymarket_ws import polymarket_ws
    from centinela.clients.polymarket_clob import polymarket_clob

    spread_change = 0.0
    price_pop = 0.0
    if market and chase_result.current_price > 0 and trade.price > 0:
        price_pop = abs(chase_result.current_price - trade.price) / trade.price * 100
    if market and hasattr(market, "spread") and market.spread is not None:
        spread_change = market.spread * 100  # normalize to %

    insider_inv_red = await compute_insider_inventory_reduction(
        session, wallet.id, market.id if market else None, within_minutes=30
    )

    # reversal_3m: price moved one way, reversed within 3 min (from WS history)
    reversal_3m = 0.0
    if market:
        token_id = market.token_id_yes if trade.side == "YES" else market.token_id_no
        if token_id:
            price_now = polymarket_ws.get_price(token_id)
            price_3m_ago = polymarket_ws.get_price_history(token_id, seconds_ago=180)
            if price_now and price_3m_ago and trade.price > 0:
                pop = (price_3m_ago - trade.price) / trade.price
                revert = (price_now - price_3m_ago) / trade.price
                if pop > 0 and revert < 0:
                    reversal_3m = min(abs(revert) * 100, 100)

    # bid/ask depth change: one-shot snapshot from CLOB (no prior snapshot yet)
    # Until we have historical order book snapshots, leave as 0.
    trap_result = compute_trap_risk(
        bid_depth_change=0.0,
        ask_depth_change=0.0,
        spread_change=spread_change,
        price_pop=price_pop,
        reversal_3m=reversal_3m,
        insider_inv_red_30m=insider_inv_red,
    )
    if trap_result.action == "invalidated":
        result = DecisionResult(
            output="skip",
            step_reached="trap_risk",
            fail_reason=f"TRAP DETECTED — score {trap_result.score:.0f}, signal killed",
            chase_result=chase_result,
        )
        await record_trap_event(session, None, trade.id, market.id if market else None, trap_result)
        await _log_decision(session, result, wallet, trade)
        return result
    if trap_result.action in ("reduced", "deducted"):
        _, recommended_size = apply_trap_to_signal(trap_result, wallet.insider_score, recommended_size)
        await record_trap_event(session, None, trade.id, market.id if market else None, trap_result)
        logger.info(
            "decision.trap_adjustment",
            action=trap_result.action,
            trap_score=f"{trap_result.score:.0f}",
            adjusted_size=f"{recommended_size:,.0f}",
        )

    # Step 5: CHECK WALLET QUALITY
    quality_ok, quality_reason = _check_wallet_quality(
        wallet, signal_type, trade.is_first_entry
    )
    if not quality_ok:
        result = DecisionResult(
            output="skip",
            step_reached="wallet_quality",
            fail_reason=quality_reason,
        )
        await _log_decision(session, result, wallet, trade)
        return result

    # Step 6: CHECK PORTFOLIO LIMITS
    is_locked, lock_reason = await check_lockout(session)
    if is_locked:
        result = DecisionResult(
            output="skip",
            step_reached="portfolio",
            fail_reason=f"Lockout: {lock_reason}",
        )
        await _log_decision(session, result, wallet, trade)
        return result

    portfolio_ok, portfolio_msg = await check_portfolio_limits(
        session,
        market_id=market.id if market else None,
        category=market.category if market else None,
        position_size=recommended_size,
        signal_score=wallet.insider_score,
    )
    if not portfolio_ok:
        result = DecisionResult(
            output="skip",
            step_reached="portfolio",
            fail_reason=portfolio_msg,
        )
        await _log_decision(session, result, wallet, trade)
        return result

    # Step 7: CHECK CORRELATION (warn only, don't skip)
    warning = portfolio_msg  # portfolio_msg may contain a concentration warning

    # All checks passed -> EXECUTE
    result = DecisionResult(
        output="execute",
        step_reached="correlation",
        chase_result=chase_result,
        slippage_pct=slippage_pct,
        recommended_size=recommended_size,
        warning=warning,
        trap_risk_score=trap_result.score,
    )
    await _log_decision(session, result, wallet, trade)
    return result


def _check_wallet_quality(
    wallet: Wallet, signal_type: str, is_first_entry: bool
) -> tuple[bool, str | None]:
    """Step 4: Wallet quality check.

    Thresholds:
    (a) score >= 70 for standard insider signals
    (b) score >= 90 AND classification == sniper AND first entry
    (c) cross_platform_divergence bypasses wallet quality
    """
    score = wallet.insider_score

    if signal_type == "cross_platform":
        return True, None  # Pure math edge, no wallet needed
    if signal_type == "dumb_money_fade":
        return True, None  # Has its own scoring

    # Solo sniper first entry = lower threshold
    if (
        score >= 90
        and wallet.classification == "SNIPER"
        and is_first_entry
    ):
        return True, None

    # Standard threshold
    if score >= 70:
        return True, None

    return False, f"Signal quality too low — score {score:.0f}, need 70+"


async def _log_decision(
    session: AsyncSession,
    result: DecisionResult,
    wallet: Wallet,
    trade: Trade,
) -> None:
    """Log decision to decision_log table."""
    log = DecisionLog(
        wallet_id=wallet.id,
        market_name=trade.market_name,
        step_reached=result.step_reached,
        step_result="pass" if result.output == "execute" else "fail",
        fail_reason=result.fail_reason,
        final_output=result.output,
        recommended_size=result.recommended_size,
    )
    session.add(log)
