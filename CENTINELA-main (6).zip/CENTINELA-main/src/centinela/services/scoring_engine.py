"""Insider scoring engine — 8-component wallet scoring (0-100).

Components (12.5% weight each, calibrated after 8 weeks):
1. Win rate (weighted by sample size)
2. Entry timing (time between entry and 10%+ price move)
3. Niche focus (Herfindahl index of categories)
4. Consistency (PnL Sharpe ratio)
5. Position sizing intelligence (correlation of size vs outcome)
6. Wallet age + track record
7. Trade frequency (sweet spot 10-50/month)
8. Drawdown recovery
"""

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant import CopyabilityMetric, LeaderMetric, ScoringCalibration
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet, WalletScoreHistory
from centinela.services.leader_detection import integrate_quant_scores
from centinela.utils.math_primitives import (
    clamp,
    confidence_multiplier,
    herfindahl_index,
    safe_div,
    score100,
    sharpe_ratio,
    sigmoid,
)

logger = structlog.get_logger()

# Initial equal weights — recalibrated every 4 weeks based on signal feedback
DEFAULT_WEIGHTS = {
    "win_rate": 0.125,
    "entry_timing": 0.125,
    "niche_focus": 0.125,
    "consistency": 0.125,
    "sizing_intelligence": 0.125,
    "track_record": 0.125,
    "trade_frequency": 0.125,
    "drawdown_recovery": 0.125,
}


async def load_calibrated_weights(session: AsyncSession) -> None:
    """Load the most recent calibrated weights from DB into DEFAULT_WEIGHTS."""
    result = await session.execute(
        select(ScoringCalibration).order_by(ScoringCalibration.calibrated_at.desc()).limit(1)
    )
    calibration = result.scalar_one_or_none()
    if calibration and calibration.new_weights:
        DEFAULT_WEIGHTS.update(calibration.new_weights)
        logger.info("scoring.weights_loaded", source="db_calibration")


@dataclass
class ScoringResult:
    total_score: float
    component_scores: dict[str, float]
    classification: str
    weights: dict[str, float]


def score_wallet(trades: list[Trade], wallet: Wallet) -> ScoringResult:
    """Calculate insider score for a wallet based on its trades.

    Returns ScoringResult with total score (0-100), per-component scores,
    and classification.
    """
    if not trades:
        return ScoringResult(0.0, {k: 0.0 for k in DEFAULT_WEIGHTS}, "NOISE", DEFAULT_WEIGHTS)

    components = {
        "win_rate": _score_win_rate(trades),
        "entry_timing": _score_entry_timing(trades),
        "niche_focus": _score_niche_focus(trades),
        "consistency": _score_consistency(trades),
        "sizing_intelligence": _score_sizing(trades),
        "track_record": _score_track_record(trades, wallet),
        "trade_frequency": _score_frequency(trades),
        "drawdown_recovery": _score_drawdown(trades),
    }

    total = sum(components[k] * DEFAULT_WEIGHTS[k] for k in DEFAULT_WEIGHTS)
    total = score100(total)

    classification = _classify_wallet(trades, components)

    return ScoringResult(total, components, classification, DEFAULT_WEIGHTS)


async def recalculate_all_scores(session: AsyncSession) -> int:
    """Recalculate scores for all active wallets. Returns count updated."""
    # Load calibrated weights from DB (survives restarts)
    await load_calibrated_weights(session)

    result = await session.execute(select(Wallet).where(Wallet.is_active == True))  # noqa: E712
    wallets = result.scalars().all()
    updated = 0

    for wallet in wallets:
        trades_result = await session.execute(
            select(Trade)
            .where(Trade.wallet_id == wallet.id)
            .order_by(Trade.timestamp.asc())
        )
        trades = list(trades_result.scalars().all())

        scoring = score_wallet(trades, wallet)

        # Integrate quant scores (copyability + leader) into final score
        copy_row = await session.execute(
            select(CopyabilityMetric).where(CopyabilityMetric.wallet_id == wallet.id)
        )
        copy_metric = copy_row.scalar_one_or_none()
        copyability_score = copy_metric.copyability_score if copy_metric else 50.0

        leader_row = await session.execute(
            select(LeaderMetric).where(LeaderMetric.wallet_id == wallet.id)
        )
        leader_metric = leader_row.scalar_one_or_none()
        leader_score = leader_metric.leader_score if leader_metric else 50.0

        final_score = integrate_quant_scores(scoring.total_score, copyability_score, leader_score)

        wallet.insider_score = final_score
        wallet.classification = scoring.classification
        wallet.total_trades = len(trades)

        # Save score history
        history = WalletScoreHistory(
            wallet_id=wallet.id,
            score=scoring.total_score,
            component_scores=scoring.component_scores,
            classification=scoring.classification,
        )
        session.add(history)
        updated += 1

        logger.info(
            "scoring.updated",
            wallet=wallet.handle,
            score=round(scoring.total_score, 1),
            classification=scoring.classification,
        )

    await session.commit()
    return updated


# ---------------------------------------------------------------------------
# Component scoring functions (each returns 0-100)
# ---------------------------------------------------------------------------


def _score_win_rate(trades: list[Trade]) -> float:
    """Win rate weighted by sample size confidence."""
    # For MVP without resolution data, use a proxy: trades where price moved favorably
    # Real implementation needs market resolution outcomes
    n = len(trades)
    if n == 0:
        return 0.0

    # Placeholder: estimate from trade distribution
    # A wallet with many trades in diverse markets at reasonable prices suggests competence
    # Real scoring needs resolution data — for now, use raw trade count as confidence
    conf = confidence_multiplier(n)

    # Without resolution data, we can't compute actual win rate
    # Use the wallet's stored win_rate if available, otherwise return neutral
    # This will be properly computed once we track market resolutions
    estimated_wr = 0.55  # Neutral starting point
    return score100(estimated_wr * conf * 100)


def _score_entry_timing(trades: list[Trade]) -> float:
    """Score based on how early entries are relative to price moves.

    Needs price history data for full implementation. MVP uses proxy metrics.
    """
    if len(trades) < 10:
        return score100(30.0)  # Insufficient data

    # Proxy: wallets that make first entries (not adding to positions) score higher
    first_entries = sum(1 for t in trades if t.is_first_entry)
    first_ratio = safe_div(first_entries, len(trades))

    # High ratio of first entries suggests conviction-based timing
    return score100(first_ratio * 100)


def _score_niche_focus(trades: list[Trade]) -> float:
    """Herfindahl index of category distribution. Specialists score higher."""
    # Group by market name prefix as category proxy
    category_counts: dict[str, int] = Counter()
    for t in trades:
        # Use first significant word as category proxy
        cat = _infer_category(t.market_name)
        category_counts[cat] += 1

    if not category_counts:
        return 0.0

    hhi = herfindahl_index(category_counts)
    # HHI ranges from 1/n (even) to 1.0 (concentrated)
    # Map to 0-100 where 1.0 = 100 (specialist)
    return score100(hhi * 100)


def _score_consistency(trades: list[Trade]) -> float:
    """PnL Sharpe ratio over rolling window.

    MVP proxy: consistency of trade sizing (low variance = disciplined).
    """
    if len(trades) < 5:
        return score100(30.0)

    sizes = [t.size for t in trades if t.size > 0]
    if not sizes:
        return 0.0

    # Consistent sizing = disciplined trader
    mean_size = sum(sizes) / len(sizes)
    variance = sum((s - mean_size) ** 2 for s in sizes) / len(sizes)
    cv = safe_div(variance**0.5, mean_size)  # coefficient of variation

    # Low CV = consistent = high score. CV of 0 = 100, CV of 2+ = 0
    return score100(max(0, (1 - cv / 2)) * 100)


def _score_sizing(trades: list[Trade]) -> float:
    """Position sizing intelligence — do they size up on conviction?

    MVP proxy: variance in sizing (some variance = strategic, uniform = uninformed).
    """
    if len(trades) < 10:
        return score100(40.0)

    sizes = [t.size for t in trades if t.size > 0]
    if len(sizes) < 5:
        return score100(40.0)

    mean_size = sum(sizes) / len(sizes)
    # Check if there's intentional variation (not random noise)
    large_trades = sum(1 for s in sizes if s > mean_size * 1.5)
    large_ratio = safe_div(large_trades, len(sizes))

    # Some large trades (10-30%) suggests conviction-based sizing
    # Too few = flat sizing, too many = reckless
    if 0.1 <= large_ratio <= 0.3:
        return score100(80.0)
    elif large_ratio < 0.1:
        return score100(50.0)  # Flat sizing
    else:
        return score100(40.0)  # Too aggressive


def _score_track_record(trades: list[Trade], wallet: Wallet) -> float:
    """Wallet age + sustained performance."""
    age_days = wallet.wallet_age_days or 0
    if not trades:
        return 0.0

    # Calculate age from earliest trade if wallet_age_days not set
    if age_days == 0 and trades:
        earliest = min(t.timestamp for t in trades)
        if earliest.tzinfo is None:
            earliest = earliest.replace(tzinfo=timezone.utc)
        age_days = (datetime.now(tz=timezone.utc) - earliest).days

    # Longer track record with activity = higher score
    age_score = min(age_days / 180, 1.0)  # Max at 6 months
    activity_score = min(len(trades) / 100, 1.0)  # Max at 100 trades

    return score100((age_score * 0.5 + activity_score * 0.5) * 100)


def _score_frequency(trades: list[Trade]) -> float:
    """Trade frequency sweet spot (10-50/month)."""
    if len(trades) < 2:
        return 0.0

    earliest = min(t.timestamp for t in trades)
    latest = max(t.timestamp for t in trades)
    if earliest.tzinfo is None:
        earliest = earliest.replace(tzinfo=timezone.utc)
    if latest.tzinfo is None:
        latest = latest.replace(tzinfo=timezone.utc)

    span_days = max((latest - earliest).days, 1)
    monthly_rate = (len(trades) / span_days) * 30

    # Bell curve: peak at 10-50/month
    if 10 <= monthly_rate <= 50:
        return score100(90.0)
    elif 5 <= monthly_rate < 10 or 50 < monthly_rate <= 100:
        return score100(60.0)
    elif monthly_rate < 5:
        return score100(30.0)  # Too few
    else:
        return score100(20.0)  # Way too many (bot/MM)


def _score_drawdown(trades: list[Trade]) -> float:
    """Drawdown recovery speed.

    MVP proxy: how quickly trade sizes return to normal after a losing streak.
    Without P&L data, use trade frequency as recovery proxy.
    """
    if len(trades) < 10:
        return score100(40.0)

    # Check if there are gaps in trading (possible tilt/recovery)
    timestamps = sorted(t.timestamp for t in trades)
    gaps = []
    for i in range(1, len(timestamps)):
        t1 = timestamps[i - 1]
        t2 = timestamps[i]
        if t1.tzinfo is None:
            t1 = t1.replace(tzinfo=timezone.utc)
        if t2.tzinfo is None:
            t2 = t2.replace(tzinfo=timezone.utc)
        gaps.append((t2 - t1).total_seconds() / 3600)  # hours

    if not gaps:
        return score100(50.0)

    avg_gap = sum(gaps) / len(gaps)
    max_gap = max(gaps)

    # Consistent trader (no long breaks) = good recovery discipline
    gap_ratio = safe_div(max_gap, avg_gap)
    # Low ratio = consistent, high ratio = took long breaks (possible tilt)
    if gap_ratio < 3:
        return score100(80.0)
    elif gap_ratio < 10:
        return score100(55.0)
    else:
        return score100(30.0)


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


def _classify_wallet(trades: list[Trade], components: dict[str, float]) -> str:
    """Classify wallet based on trading patterns (spec-exact logic).

    Classification order (from spec):
    - trade_frequency > 50/week AND buys_both_sides > 40% → MARKET_MAKER
    - opposing_positions_in_related_markets > 30% → HEDGER
    - win_rate < 52% AND no_category_focus → NOISE
    - trade_frequency < 10/week AND win_rate > 70% AND niche_focus → SNIPER
    - everything else → MOMENTUM

    DUMB_MONEY is set separately by dumb_money.py based on inverse scoring.
    """
    if len(trades) < 5:
        return "NOISE"

    sides = Counter(t.side for t in trades)
    total = sum(sides.values())
    both_sides_ratio = safe_div(min(sides.get("YES", 0), sides.get("NO", 0)), total)

    # Estimate weekly frequency
    earliest = min(t.timestamp for t in trades)
    latest = max(t.timestamp for t in trades)
    if earliest.tzinfo is None:
        earliest = earliest.replace(tzinfo=timezone.utc)
    if latest.tzinfo is None:
        latest = latest.replace(tzinfo=timezone.utc)
    span_weeks = max((latest - earliest).days / 7, 1)
    weekly_freq = len(trades) / span_weeks

    # 1. MARKET_MAKER: high freq + both sides
    if weekly_freq > 50 and both_sides_ratio > 0.40:
        return "MARKET_MAKER"

    # 2. HEDGER: check for opposing positions in related markets
    #    (simplified: if they frequently trade both sides of similar markets)
    market_sides: dict[str, set[str]] = {}
    for t in trades:
        market_sides.setdefault(t.market_name, set()).add(t.side)
    both_side_markets = sum(1 for sides in market_sides.values() if len(sides) > 1)
    if len(market_sides) > 0 and both_side_markets / len(market_sides) > 0.30:
        return "HEDGER"

    # 3. NOISE: low WR + no focus
    # Use actual win_rate from wallet (passed via components proxy)
    wr_component = components.get("win_rate", 50)
    focus_component = components.get("niche_focus", 50)
    # WR component < ~45 roughly maps to actual WR < 52%
    if wr_component < 45 and focus_component < 30:
        return "NOISE"

    # 4. SNIPER: low freq + high WR + niche focus
    if weekly_freq < 10 and wr_component >= 60 and focus_component >= 60:
        return "SNIPER"

    # 5. Everything else
    return "MOMENTUM"


def _infer_category(market_name: str) -> str:
    """Infer market category from name keywords."""
    name_lower = market_name.lower()
    politics_keywords = ["president", "election", "congress", "senate", "governor", "vote", "trump", "biden", "democrat", "republican", "scotus", "fed ", "rate"]
    crypto_keywords = ["bitcoin", "btc", "eth", "crypto", "token", "defi", "blockchain", "solana", "nft"]
    sports_keywords = ["nba", "nfl", "mlb", "soccer", "football", "basketball", "win ", "championship", "super bowl", "world cup", "lakers", "finals"]

    for kw in politics_keywords:
        if kw in name_lower:
            return "Politics"
    for kw in crypto_keywords:
        if kw in name_lower:
            return "Crypto"
    for kw in sports_keywords:
        if kw in name_lower:
            return "Sports"
    return "Other"
