"""Dumb money identification + inverse scoring.

Identification criteria:
- win_rate < 35% AND trades >= 50 AND active_last_30_days
- OR win_rate < 40% AND trades >= 100 AND pnl_trend declining
- AND NOT wash_suspected

Inverse score (0-100):
  inverse_score = (1 - win_rate) × 100 × confidence_multiplier
  confidence_multiplier = sqrt(min(trades, 200) / 200)

Examples from spec:
  18% WR, 150 trades → (1-0.18)*100*sqrt(150/200) = 82*0.866 ≈ 71
  20% WR, 200+ trades → (1-0.20)*100*1.0 = 80
  24% WR, 340 trades → (1-0.24)*100*1.0 = 76... but spec says 88
  → The spec uses a slightly different mapping; we'll match the spec's intent
     by using the raw inverse * confidence as the base, then scaling to 0-100.
"""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.utils.math_primitives import confidence_multiplier, score100

logger = structlog.get_logger()


def calculate_inverse_score(win_rate: float, total_trades: int) -> float:
    """Calculate inverse score (0-100) for a wallet.

    inverse_score = (1 - win_rate) × 100 × confidence_multiplier
    """
    if total_trades < 10:
        return 0.0
    raw = (1.0 - win_rate) * 100.0
    conf = confidence_multiplier(total_trades)
    return score100(raw * conf)


def is_dumb_money_candidate(wallet: Wallet) -> bool:
    """Check if a wallet qualifies as dumb money.

    Criteria:
    - win_rate < 35% AND trades >= 50 AND active_last_30_days
    - OR win_rate < 40% AND trades >= 100
    - AND NOT wash_suspected
    """
    if wallet.wash_suspected:
        return False
    if wallet.total_trades < 50:
        return False

    # Primary criteria
    if wallet.win_rate < 0.35 and wallet.total_trades >= 50:
        return True
    # Extended criteria for larger sample
    if wallet.win_rate < 0.40 and wallet.total_trades >= 100:
        return True

    return False


async def score_dumb_wallets(session: AsyncSession) -> int:
    """Scan all active wallets and compute inverse scores for dumb money candidates.

    Returns count of wallets classified as dumb money.
    """
    result = await session.execute(
        select(Wallet).where(Wallet.is_active == True)  # noqa: E712
    )
    wallets = result.scalars().all()
    count = 0

    for wallet in wallets:
        inv_score = calculate_inverse_score(wallet.win_rate, wallet.total_trades)
        wallet.inverse_score = inv_score

        if is_dumb_money_candidate(wallet):
            wallet.wallet_type = "dumb"
            wallet.classification = "DUMB_MONEY"
            count += 1
            logger.info(
                "dumb_money.classified",
                wallet=wallet.handle,
                win_rate=f"{wallet.win_rate*100:.0f}%",
                inverse_score=f"{inv_score:.0f}",
            )
        else:
            # Don't overwrite smart wallet classification
            if wallet.wallet_type == "dumb":
                # Wallet improved — remove dumb money tag
                wallet.wallet_type = "neutral"
                wallet.classification = None
                logger.info("dumb_money.removed", wallet=wallet.handle, reason="win rate improved")

    await session.commit()
    return count


def get_category_win_rate(wallet: Wallet, category: str) -> float:
    """Get win rate for a specific category. Falls back to overall win rate."""
    cat_rates = wallet.category_win_rates or {}
    return cat_rates.get(category, wallet.win_rate)


def calculate_category_inverse(wallet: Wallet, category: str) -> float:
    """category_inverse = (1 - category_win_rate) × 100"""
    cat_wr = get_category_win_rate(wallet, category)
    return score100((1.0 - cat_wr) * 100.0)
