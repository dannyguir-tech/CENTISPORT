"""Simultaneous signal priority ranking.

When multiple signals fire within 10 minutes:
  1. Convergence (smart + dumb opposite) — highest
  2. Consensus (3+ wallets agreeing)
  3. Cross-platform divergence (pure math)
  4. Dumb money fade (inverse signal)
  5. Solo sniper first entry
  6. Highest combined score

Max simultaneous entries: 2 new positions within 10 minutes.
If more qualify → take top 2, queue rest.
"""

from dataclasses import dataclass

import structlog

logger = structlog.get_logger()

MAX_SIMULTANEOUS = 2

# Priority ranking (lower = higher priority)
PRIORITY_ORDER = {
    "convergence": 1,
    "consensus": 2,
    "cross_platform": 3,
    "dumb_money_fade": 4,
    "insider_sniper_first": 5,
    "insider": 6,
}


@dataclass
class RankedSignal:
    signal_type: str
    score: float
    priority_rank: int
    data: dict  # signal-specific data

    @property
    def sort_key(self) -> tuple[int, float]:
        """Lower rank = higher priority, then higher score."""
        return (self.priority_rank, -self.score)


def rank_signals(signals: list[dict]) -> list[dict]:
    """Rank a batch of signals by priority.

    Each signal dict should have: type, score, and any signal-specific data.
    Returns sorted list with top MAX_SIMULTANEOUS marked as "execute",
    rest as "queued".
    """
    ranked: list[RankedSignal] = []
    for s in signals:
        sig_type = s.get("type", "insider")
        score = s.get("score", 0)

        # Determine rank
        if sig_type == "insider" and s.get("is_sniper_first_entry"):
            rank = PRIORITY_ORDER["insider_sniper_first"]
        else:
            rank = PRIORITY_ORDER.get(sig_type, 6)

        ranked.append(RankedSignal(
            signal_type=sig_type,
            score=score,
            priority_rank=rank,
            data=s,
        ))

    # Sort by priority rank (ascending), then score (descending)
    ranked.sort(key=lambda r: r.sort_key)

    # Mark top N as execute, rest as queued
    results = []
    for i, r in enumerate(ranked):
        action = "execute" if i < MAX_SIMULTANEOUS else "queued"
        results.append({
            **r.data,
            "priority_rank": r.priority_rank,
            "action": action,
        })

    if len(ranked) > MAX_SIMULTANEOUS:
        logger.info(
            "signal_priority.overflow",
            total=len(ranked),
            executing=MAX_SIMULTANEOUS,
            queued=len(ranked) - MAX_SIMULTANEOUS,
        )

    return results
