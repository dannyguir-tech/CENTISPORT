"""Slippage capping — position size limited by order book depth.

Walk the book: how many shares can I buy before price moves 2%?
That number = slippage_cap.

final_size = min(kelly_size, slippage_cap, bankroll_cap)
"""

import structlog

from centinela.clients.polymarket_clob import polymarket_clob
from centinela.config import settings

logger = structlog.get_logger()


async def estimate_slippage(token_id: str, position_size_usd: float) -> float | None:
    """Estimate slippage for a given position size.

    Returns estimated slippage as a decimal (0.02 = 2%), or None if
    order book unavailable.
    """
    book = await polymarket_clob.get_order_book(token_id)
    if not book:
        return None

    asks = book.get("asks", [])
    if not asks:
        return None

    # Walk the ask side to estimate slippage
    filled = 0.0
    total_cost = 0.0
    best_ask = float(asks[0]["price"])

    for level in asks:
        price = float(level["price"])
        size = float(level.get("size", level.get("quantity", 0)))
        level_value = price * size

        remaining = position_size_usd - filled
        if remaining <= 0:
            break

        fill_at_level = min(level_value, remaining)
        total_cost += fill_at_level
        filled += fill_at_level

    if filled <= 0 or best_ask <= 0:
        return None

    avg_fill_price = total_cost / (filled / best_ask) if filled > 0 else best_ask
    slippage = (avg_fill_price - best_ask) / best_ask

    return max(0.0, slippage)


async def get_slippage_cap(token_id: str) -> float:
    """Calculate max position size where estimated slippage <= 2%.

    Walks the order book to find the USD amount that can be bought
    before price moves beyond the max slippage threshold.
    """
    book = await polymarket_clob.get_order_book(token_id)
    if not book:
        return 0.0

    asks = book.get("asks", [])
    if not asks:
        return 0.0

    best_ask = float(asks[0]["price"])
    if best_ask <= 0:
        return 0.0

    max_price = best_ask * (1 + settings.max_slippage_pct)  # 2% above best
    total_available = 0.0

    for level in asks:
        price = float(level["price"])
        if price > max_price:
            break
        size = float(level.get("size", level.get("quantity", 0)))
        total_available += price * size

    return total_available


async def check_slippage_ok(
    token_id: str | None, position_size_usd: float
) -> tuple[bool, float | None]:
    """Check if slippage is acceptable for the given position size.

    Returns (ok, estimated_slippage_pct).
    """
    if not token_id:
        return True, None  # Can't check, fail open

    slippage = await estimate_slippage(token_id, position_size_usd)
    if slippage is None:
        return True, None

    ok = slippage <= settings.max_slippage_pct
    return ok, slippage * 100  # Return as percentage
