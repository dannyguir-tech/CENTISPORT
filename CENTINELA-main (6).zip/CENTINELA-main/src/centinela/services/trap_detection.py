"""Module 5: Liquidity Trap Detection — exact spec formulas.

Catch when an insider uses YOUR copy trade as exit liquidity.

trap_risk_raw = 0.20*weak_bids + 0.15*heavy_asks + 0.20*wide_spread
              + 0.15*pop_n + 0.15*reversal_n + 0.15*insider_inv_red

Action rules:
  >= 75: INVALIDATE signal entirely
  55-74: Reduce size 50%, add warning
  40-54: Deduct 8 points from signal
  < 40:  Clean signal, no action
"""

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import TrapRiskEvent
from centinela.utils.math_primitives import clamp, score100

logger = structlog.get_logger()


class TrapResult:
    def __init__(self, score: float, action: str, components: dict):
        self.score = score
        self.action = action  # invalidated/reduced/deducted/none
        self.components = components


def compute_trap_risk(
    bid_depth_change: float,
    ask_depth_change: float,
    spread_change: float,
    price_pop: float,
    reversal_3m: float,
    insider_inv_red_30m: float,
) -> TrapResult:
    """Compute trap risk score (exact spec formula).

    All inputs are raw % values, normalized internally.
    """
    # Normalize (spec exact)
    weak_bids = clamp((-bid_depth_change) / 100, 0, 1)   # bids disappearing
    heavy_asks = clamp(ask_depth_change / 100, 0, 1)       # asks piling up
    wide_spread = clamp(spread_change / 100, 0, 1)         # spread widening
    pop_n = clamp(price_pop / 20, 0, 1)                    # initial price spike
    reversal_n = clamp(reversal_3m / 20, 0, 1)             # reversal after pop
    inv_red = clamp(insider_inv_red_30m, 0, 1)

    # Trap risk formula (spec exact)
    trap_risk_raw = (
        0.20 * weak_bids
        + 0.15 * heavy_asks
        + 0.20 * wide_spread
        + 0.15 * pop_n
        + 0.15 * reversal_n
        + 0.15 * inv_red
    )

    trap_score = score100(trap_risk_raw * 100)

    # Action rules (spec exact)
    if trap_score >= 75:
        action = "invalidated"
    elif trap_score >= 55:
        action = "reduced"
    elif trap_score >= 40:
        action = "deducted"
    else:
        action = "none"

    components = {
        "weak_bids": weak_bids,
        "heavy_asks": heavy_asks,
        "wide_spread": wide_spread,
        "price_pop": pop_n,
        "reversal_3m": reversal_n,
        "insider_inv_reduction": inv_red,
    }

    return TrapResult(score=trap_score, action=action, components=components)


def apply_trap_to_signal(trap: TrapResult, signal_score: float, position_size: float) -> tuple[float, float]:
    """Apply trap risk adjustments to signal score and position size.

    Returns (adjusted_score, adjusted_size).
    """
    if trap.action == "invalidated":
        return 0.0, 0.0  # Kill the signal
    elif trap.action == "reduced":
        return signal_score, position_size * 0.50
    elif trap.action == "deducted":
        return max(0, signal_score - 8), position_size
    else:
        return signal_score, position_size


async def record_trap_event(
    session: AsyncSession,
    alert_id: int | None,
    trade_id: int | None,
    market_id: int | None,
    result: TrapResult,
) -> TrapRiskEvent:
    """Persist trap risk event."""
    event = TrapRiskEvent(
        alert_id=alert_id,
        trade_id=trade_id,
        market_id=market_id,
        trap_risk_score=result.score,
        weak_bids=result.components["weak_bids"],
        heavy_asks=result.components["heavy_asks"],
        wide_spread=result.components["wide_spread"],
        price_pop=result.components["price_pop"],
        reversal_3m=result.components["reversal_3m"],
        insider_inv_reduction=result.components["insider_inv_reduction"],
        action_taken=result.action,
    )
    session.add(event)
    return event
