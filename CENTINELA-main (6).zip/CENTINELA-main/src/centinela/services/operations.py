"""Phase 6 operations services:
- Order book intelligence (pending orders, imbalance alerts)
- Resolution calendar (capital unlock timeline)
- Correlation risk monitor (portfolio correlation, concentration warnings)
- Entry window calculator (optimal copy delay per wallet)
"""

from collections import defaultdict
from datetime import datetime, timezone, timedelta

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.clients.polymarket_clob import polymarket_clob
from centinela.db.models.execution import Position
from centinela.db.models.market import Market
from centinela.db.models.quant import CopyabilityMetric
from centinela.db.models.wallet import Wallet

logger = structlog.get_logger()


# --- Order Book Intelligence ---

async def analyze_order_book(token_id: str) -> dict | None:
    """Analyze order book for imbalances and pending order patterns."""
    book = await polymarket_clob.get_order_book(token_id)
    if not book:
        return None

    bids = book.get("bids", [])
    asks = book.get("asks", [])

    bid_depth = sum(float(b.get("size", 0)) * float(b.get("price", 0)) for b in bids[:10])
    ask_depth = sum(float(a.get("size", 0)) * float(a.get("price", 0)) for a in asks[:10])
    total = bid_depth + ask_depth

    imbalance = (bid_depth - ask_depth) / total if total > 0 else 0
    best_bid = float(bids[0]["price"]) if bids else 0
    best_ask = float(asks[0]["price"]) if asks else 1
    spread_pct = (best_ask - best_bid) / best_ask * 100 if best_ask > 0 else 0

    # Large pending orders (top 3 levels)
    large_bids = [{"price": float(b["price"]), "size": float(b.get("size", 0))}
                  for b in bids[:3] if float(b.get("size", 0)) > 1000]
    large_asks = [{"price": float(a["price"]), "size": float(a.get("size", 0))}
                  for a in asks[:3] if float(a.get("size", 0)) > 1000]

    return {
        "bidDepth": round(bid_depth, 2),
        "askDepth": round(ask_depth, 2),
        "imbalance": round(imbalance, 4),
        "imbalanceLabel": "BID_HEAVY" if imbalance > 0.2 else ("ASK_HEAVY" if imbalance < -0.2 else "BALANCED"),
        "spreadPct": round(spread_pct, 3),
        "bestBid": best_bid,
        "bestAsk": best_ask,
        "largeBids": large_bids,
        "largeAsks": large_asks,
    }


# --- Resolution Calendar ---

async def get_resolution_calendar(session: AsyncSession) -> list[dict]:
    """Get timeline of position resolutions and capital unlocks."""
    result = await session.execute(
        select(Position)
        .where(Position.status.in_(["open", "partial"]))
        .where(Position.resolution_date != None)  # noqa: E711
        .order_by(Position.resolution_date.asc())
    )
    positions = result.scalars().all()
    now = datetime.now(tz=timezone.utc)

    calendar: list[dict] = []
    for p in positions:
        res_date = p.resolution_date
        if res_date and res_date.tzinfo is None:
            res_date = res_date.replace(tzinfo=timezone.utc)

        days_until = (res_date - now).days if res_date else None
        calendar.append({
            "positionId": p.id,
            "marketName": p.market_name,
            "side": p.side,
            "currentSize": p.current_size,
            "unrealizedPnl": p.unrealized_pnl,
            "resolutionDate": res_date.isoformat() if res_date else None,
            "daysUntil": days_until,
            "capitalUnlock": p.current_size,
        })

    return calendar


# --- Correlation Risk Monitor ---

async def analyze_portfolio_correlation(session: AsyncSession) -> dict:
    """Analyze portfolio for correlation and concentration risk."""
    result = await session.execute(
        select(Position).where(Position.status.in_(["open", "partial"]))
    )
    positions = list(result.scalars().all())

    if not positions:
        return {"categories": {}, "warnings": [], "totalDeployed": 0}

    total_deployed = sum(p.current_size for p in positions)

    # Category concentration
    cat_exposure: dict[str, float] = defaultdict(float)
    for p in positions:
        cat = p.category or "Other"
        cat_exposure[cat] += p.current_size

    categories = {}
    warnings: list[str] = []
    for cat, exposure in cat_exposure.items():
        pct = exposure / total_deployed * 100 if total_deployed > 0 else 0
        categories[cat] = {"exposure": round(exposure, 2), "pct": round(pct, 1)}
        if pct > 40:
            warnings.append(f"{cat} concentration at {pct:.0f}% — consider diversifying")
        elif pct > 30:
            warnings.append(f"{cat} approaching limit at {pct:.0f}%")

    # Utilization warning
    from centinela.services.bankroll import get_or_create_bankroll
    bankroll = await get_or_create_bankroll(session)
    utilization = total_deployed / bankroll.total_capital * 100 if bankroll.total_capital > 0 else 0
    if utilization > 70:
        warnings.append(f"Capital utilization at {utilization:.0f}% — limited room for new positions")

    return {
        "categories": categories,
        "warnings": warnings,
        "totalDeployed": round(total_deployed, 2),
        "utilization": round(utilization, 1),
        "positionCount": len(positions),
    }


# --- Entry Window Calculator ---

async def calculate_entry_window(session: AsyncSession, wallet_id: int) -> dict:
    """Calculate optimal copy delay for a wallet based on historical time-to-move."""
    result = await session.execute(
        select(CopyabilityMetric).where(CopyabilityMetric.wallet_id == wallet_id)
    )
    metric = result.scalar_one_or_none()

    w_result = await session.execute(select(Wallet).where(Wallet.id == wallet_id))
    wallet = w_result.scalar_one_or_none()

    if not metric:
        return {
            "walletId": wallet_id,
            "handle": wallet.handle if wallet else None,
            "optimalDelay": "immediate",
            "delaySeconds": 0,
            "copyabilityScore": 50,
            "note": "No time-to-move data yet",
        }

    # Optimal delay: aim to enter before the 5% move mark
    t5 = metric.t5_median or 300
    # Enter at ~30% of t5 for best edge retention
    optimal_delay = t5 * 0.3
    # But never less than 5 seconds (need time to read alert)
    optimal_delay = max(5, optimal_delay)

    if optimal_delay < 30:
        label = "FAST — enter within 30 seconds"
    elif optimal_delay < 120:
        label = f"STANDARD — enter within {optimal_delay:.0f} seconds"
    else:
        label = f"RELAXED — {optimal_delay / 60:.1f} minute window"

    return {
        "walletId": wallet_id,
        "handle": wallet.handle if wallet else None,
        "optimalDelay": label,
        "delaySeconds": round(optimal_delay),
        "t3Median": metric.t3_median,
        "t5Median": metric.t5_median,
        "t10Median": metric.t10_median,
        "copyabilityScore": metric.copyability_score,
    }
