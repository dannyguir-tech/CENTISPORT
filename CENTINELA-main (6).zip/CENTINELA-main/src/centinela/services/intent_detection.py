"""Module 1: Wallet Intent Detection — exact spec formulas.

Classifies every trade into WHY the wallet is trading:
  INFORMATIONAL    (1.25x) — real conviction, the golden signal
  POSITION_BUILDING (1.10x) — accumulating, slight boost
  MOMENTUM         (0.80x) — chasing, less edge
  HEDGING          (0.35x) — not directional, heavy penalty
  LIQUIDITY_PROVISION (0.50x) — market making
  EXIT_LIQUIDITY   (0.40x) — distributing/dumping

Without this, you copy hedging trades and lose money.
With it, hedging gets 0.35x and dies before reaching you.
"""

import math
from dataclasses import dataclass

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.db.models.quant_intelligence import TradeIntent
from centinela.utils.math_primitives import clamp

logger = structlog.get_logger()

INTENT_MULTIPLIERS = {
    "informational": 1.25,
    "position_building": 1.10,
    "momentum": 0.80,
    "hedging": 0.35,
    "liquidity_provision": 0.50,
    "exit_liquidity": 0.40,
}


@dataclass
class IntentFeatures:
    """Raw input features for intent classification."""
    z_size: float = 0.0          # clamp(log(s/s_avg), -2, 2)
    post_move: float = 0.0      # 1 - clamp(dt_move_5 / 900, 0, 1)
    spread_cross: float = 0.0   # 1 if aggressive, 0 if passive
    passive_fill: float = 0.0   # 1 if resting order
    seq_same_dir: int = 0       # same-direction trades last 6h (cap 10)
    seq_alt_dir: int = 0        # opposite-direction trades last 6h (cap 10)
    related_opp_positions: float = 0.0  # fraction holding opposite in related markets
    inventory_reduction: float = 0.0    # fraction of position reduced within 30 min
    pre_move_norm: float = 0.0  # clamp(abs_pre_move_5 / 15, 0, 1)


@dataclass
class IntentResult:
    intent_type: str
    confidence: float  # 0-1
    multiplier: float
    raw_scores: dict[str, float]
    features: dict[str, float]


def classify_intent(features: IntentFeatures) -> IntentResult:
    """Classify trade intent using exact spec formulas.

    Returns IntentResult with type, confidence, multiplier, and raw scores.
    """
    z = features.z_size
    size_norm = clamp((z + 2) / 4, 0, 1)  # Normalize z_size to 0-1

    # Six classification formulas (exact from spec)
    scores = {
        "informational": (
            0.30 * size_norm
            + 0.30 * features.post_move
            + 0.25 * features.spread_cross
            + 0.15 * (1 - features.pre_move_norm)
        ),
        "position_building": (
            0.35 * clamp(features.seq_same_dir / 5, 0, 1)
            + 0.25 * size_norm
            + 0.20 * features.passive_fill
            + 0.20 * (1 - features.inventory_reduction)
        ),
        "momentum": (
            0.45 * features.pre_move_norm
            + 0.25 * features.spread_cross
            + 0.20 * size_norm
            + 0.10 * (1 - features.post_move)
        ),
        "hedging": (
            0.50 * features.related_opp_positions
            + 0.20 * clamp(features.seq_alt_dir / 5, 0, 1)
            + 0.15 * features.passive_fill
            + 0.15 * (1 - features.post_move)
        ),
        "liquidity_provision": (
            0.45 * features.passive_fill
            + 0.20 * (1 - size_norm)
            + 0.20 * (1 - features.post_move)
            + 0.15 * clamp(features.seq_same_dir / 5, 0, 1)
        ),
        "exit_liquidity": (
            0.40 * features.inventory_reduction
            + 0.25 * features.pre_move_norm
            + 0.20 * size_norm
            + 0.15 * (1 - features.post_move)
        ),
    }

    # Classification output (spec exact)
    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    intent_type = sorted_scores[0][0]
    top1 = sorted_scores[0][1]
    top2 = sorted_scores[1][1]
    confidence = clamp(0.55 * (top1 - top2) + 0.45 * top1, 0, 1)

    multiplier = INTENT_MULTIPLIERS[intent_type]

    features_dict = {
        "z_size": features.z_size,
        "post_move": features.post_move,
        "spread_cross": features.spread_cross,
        "passive_fill": features.passive_fill,
        "seq_same_dir": features.seq_same_dir,
        "seq_alt_dir": features.seq_alt_dir,
        "related_opp_positions": features.related_opp_positions,
        "inventory_reduction": features.inventory_reduction,
        "pre_move_norm": features.pre_move_norm,
    }

    return IntentResult(
        intent_type=intent_type,
        confidence=confidence,
        multiplier=multiplier,
        raw_scores=scores,
        features=features_dict,
    )


def build_features_from_trade(
    trade_size: float,
    median_size: float,
    dt_move_5_seconds: float = 900.0,
    spread_cross: bool = False,
    passive_fill: bool = False,
    seq_same_dir: int = 0,
    seq_alt_dir: int = 0,
    related_opp_positions: float = 0.0,
    inventory_reduction: float = 0.0,
    pre_move_5_pct: float = 0.0,
) -> IntentFeatures:
    """Build IntentFeatures from raw trade data."""
    s_avg = max(median_size, 1.0)
    z_size = clamp(math.log(trade_size / s_avg) if trade_size > 0 and s_avg > 0 else 0, -2, 2)
    post_move = 1 - clamp(dt_move_5_seconds / 900, 0, 1)
    pre_move_norm = clamp(abs(pre_move_5_pct) / 15, 0, 1)

    return IntentFeatures(
        z_size=z_size,
        post_move=post_move,
        spread_cross=1.0 if spread_cross else 0.0,
        passive_fill=1.0 if passive_fill else 0.0,
        seq_same_dir=min(seq_same_dir, 10),
        seq_alt_dir=min(seq_alt_dir, 10),
        related_opp_positions=clamp(related_opp_positions, 0, 1),
        inventory_reduction=clamp(inventory_reduction, 0, 1),
        pre_move_norm=pre_move_norm,
    )


async def record_intent(
    session: AsyncSession,
    trade_id: int,
    wallet_id: int,
    market_id: int | None,
    result: IntentResult,
) -> TradeIntent:
    """Persist intent classification to database."""
    intent = TradeIntent(
        trade_id=trade_id,
        wallet_id=wallet_id,
        market_id=market_id,
        intent_type=result.intent_type,
        confidence=result.confidence,
        raw_scores=result.raw_scores,
        intent_multiplier=result.multiplier,
        features=result.features,
    )
    session.add(intent)
    return intent
