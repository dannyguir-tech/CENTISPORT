"""Telegram bot service — full integration with reply handling.

Sends all alert types and handles user replies:
  TOOK [amount] [conviction 1-5]
  SKIP [reason]

Alert types: insider trade, expired signal, take profit, stop loss,
  cross-platform divergence, lockout, strategy state change, time check.
"""

import asyncio
import re

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from centinela.config import settings
from centinela.db.models.alert import Alert
from centinela.db.models.execution import Bankroll, Position
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.db.session import async_session

logger = structlog.get_logger()

_bot = None
_app = None


async def init_bot():
    """Initialize the Telegram bot with reply handler. Call once at startup."""
    global _bot, _app
    if not settings.telegram_enabled:
        logger.info("telegram.disabled")
        return

    from telegram import Bot, Update
    from telegram.ext import Application, MessageHandler, filters

    _app = Application.builder().token(settings.telegram_bot_token).build()
    _bot = _app.bot

    # Register reply handler
    _app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, _handle_reply))

    await _app.initialize()
    await _app.start()

    # Start polling in background (non-blocking)
    asyncio.create_task(_app.updater.start_polling(drop_pending_updates=True))

    logger.info("telegram.bot_started")


async def shutdown_bot():
    """Gracefully shut down the bot."""
    global _app
    if _app:
        await _app.updater.stop()
        await _app.stop()
        await _app.shutdown()


async def _get_bot():
    """Get the bot instance."""
    global _bot
    if _bot is None and settings.telegram_enabled:
        await init_bot()
    return _bot


async def send_message(text: str) -> int | None:
    """Send a message to the configured chat. Returns message ID."""
    bot = await _get_bot()
    if bot is None:
        logger.debug("telegram.skip", msg="Bot not configured")
        return None
    try:
        msg = await bot.send_message(
            chat_id=settings.telegram_chat_id,
            text=text,
            parse_mode=None,  # Plain text — Telegram handles emojis natively
        )
        return msg.message_id
    except Exception as e:
        logger.error("telegram.send_error", error=str(e))
        return None


async def _handle_reply(update, context):
    """Handle TOOK/SKIP replies from user."""
    if not update.message or not update.message.text:
        return

    text = update.message.text.strip()
    reply_to = update.message.reply_to_message

    # Match TOOK [amount] [conviction]
    took_match = re.match(r"(?i)took\s+(\d+)\s*(\d)?", text)
    if took_match:
        amount = int(took_match.group(1))
        conviction = int(took_match.group(2)) if took_match.group(2) else 3
        await _record_took(reply_to, amount, conviction)
        await update.message.reply_text(
            f"\u2705 Recorded: TOOK ${amount:,} (conviction {conviction}/5)"
        )
        return

    # Match SKIP [reason]
    skip_match = re.match(r"(?i)skip\s*(.*)", text)
    if skip_match:
        reason = skip_match.group(1).strip() or "No reason given"
        await _record_skip(reply_to, reason)
        await update.message.reply_text(f"\u2705 Recorded: SKIP — {reason}")
        return


async def _record_took(reply_msg, amount: int, conviction: int):
    """Update the alert record with TOOK info."""
    if not reply_msg:
        return
    async with async_session() as session:
        # Find alert by telegram_message_id
        result = await session.execute(
            select(Alert).where(Alert.telegram_message_id == reply_msg.message_id)
        )
        alert = result.scalar_one_or_none()
        if alert:
            alert.was_taken = True
            alert.conviction_level = conviction
            alert.take_reason = f"${amount:,}"
            alert.recommended_size = float(amount)
            await session.commit()
            logger.info("telegram.took", alert_id=alert.id, amount=amount, conviction=conviction)


async def _record_skip(reply_msg, reason: str):
    """Update the alert record with SKIP info."""
    if not reply_msg:
        return
    async with async_session() as session:
        result = await session.execute(
            select(Alert).where(Alert.telegram_message_id == reply_msg.message_id)
        )
        alert = result.scalar_one_or_none()
        if alert:
            alert.was_taken = False
            alert.skip_reason = reason
            await session.commit()
            logger.info("telegram.skip", alert_id=alert.id, reason=reason)


# ---------------------------------------------------------------------------
# Alert senders — each creates Alert record + sends Telegram
# ---------------------------------------------------------------------------


async def send_insider_alert(
    session: AsyncSession,
    trade: Trade,
    wallet: Wallet,
    market: Market | None = None,
    sizing: dict | None = None,
    bankroll: Bankroll | None = None,
    open_positions: int = 0,
    decision_output: str = "execute",
    warning: str | None = None,
) -> Alert:
    """Full insider trade alert with sizing, bankroll, and context."""
    text = _format_insider_alert(trade, wallet, market, sizing, bankroll, open_positions, warning)
    telegram_msg_id = await send_message(text)

    alert = Alert(
        type="insider",
        priority="high" if wallet.insider_score >= 85 else "standard",
        wallet_id=wallet.id,
        market_id=market.id if market else None,
        signal_side=trade.side,
        signal_score=wallet.insider_score,
        message=text,
        telegram_message_id=telegram_msg_id,
        decision_output=decision_output,
        recommended_size=sizing["standard"] if sizing else None,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_expired_signal(
    session: AsyncSession,
    trade: Trade,
    wallet: Wallet,
    reason: str,
    price_move_pct: float,
    current_price: float,
) -> Alert:
    """Signal expired due to chase risk or timeout."""
    text = (
        f"\u23F8 CENTINELA \u2014 SIGNAL EXPIRED\n\n"
        f"\u25C8 {wallet.handle} entered {trade.side} @ ${trade.price:.2f}\n"
        f"\U0001F4CA {trade.market_name}\n"
        f"   Current price: ${current_price:.2f} ({price_move_pct:+.1f}%)\n"
        f"   \u274C {_expiry_reason_text(reason)}\n\n"
        f"Tracking phantom PnL for this signal."
    )
    telegram_msg_id = await send_message(text)

    alert = Alert(
        type="insider",
        priority="info",
        wallet_id=wallet.id,
        signal_side=trade.side,
        signal_score=wallet.insider_score,
        message=text,
        telegram_message_id=telegram_msg_id,
        chase_risk_triggered=True,
        decision_output="skip",
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_position_event(session: AsyncSession, message: str, priority: str, alert_type: str) -> Alert:
    """Send a position management alert (TP, SL, time check)."""
    telegram_msg_id = await send_message(message)
    alert = Alert(
        type=alert_type,
        priority=priority,
        message=message,
        telegram_message_id=telegram_msg_id,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_lockout_alert(session: AsyncSession, bankroll: Bankroll) -> Alert:
    """Daily/weekly lockout notification."""
    text = (
        f"\U0001F534 CENTINELA \u2014 {'DAILY' if 'Daily' in (bankroll.lockout_reason or '') else 'WEEKLY'} LOCKOUT\n\n"
        f"Loss: {bankroll.lockout_reason}\n"
        f"Signals PAUSED until lockout expires.\n\n"
        f"The watchman says: stand down."
    )
    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="lockout",
        priority="critical",
        message=text,
        telegram_message_id=telegram_msg_id,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_state_change_alert(
    session: AsyncSession, old_state: str, new_state: str, context: str = ""
) -> Alert:
    """Strategy state transition alert."""
    emoji = {"yellow": "\u26A0\uFE0F", "red": "\U0001F6D1", "green": "\u2705"}.get(new_state, "\u2753")
    text = (
        f"{emoji} CENTINELA \u2014 STATE: {old_state.upper()} \u2192 {new_state.upper()}\n\n"
        f"{context}\n\n"
    )
    if new_state == "yellow":
        text += "\U0001F527 Auto: sizes reduced 50%\nReview dashboard within 24 hours."
    elif new_state == "red":
        text += "\U0001F6D1 All new trade alerts HALTED. Review data and recalibrate."
    elif new_state == "green":
        text += "Normal trading resumed."

    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="state_change",
        priority="critical",
        message=text,
        telegram_message_id=telegram_msg_id,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_divergence_alert(
    session: AsyncSession,
    market_question: str,
    polymarket_price: float,
    kalshi_price: float,
    gap: float,
    market_id: int | None = None,
    sizing: dict | None = None,
    bankroll: Bankroll | None = None,
) -> Alert:
    """Cross-platform divergence alert with sizing."""
    direction = "UNDERPRICED" if polymarket_price < kalshi_price else "OVERPRICED"
    text = (
        f"\U0001F310 CENTINELA \u2014 CROSS-PLATFORM DIVERGENCE\n\n"
        f"\U0001F4CA {market_question}\n"
        f"   Polymarket: ${polymarket_price:.2f} ({polymarket_price * 100:.0f}%)\n"
        f"   Kalshi:     ${kalshi_price:.2f} ({kalshi_price * 100:.0f}%)\n"
        f"   Gap: {gap:.0f} points \u2014 Polymarket appears {direction}\n\n"
        f"\U0001F4A1 If insiders are also aligned \u2192 double confirmation\n"
        f"\U0001F4CC Use LIMIT ORDER on Polymarket (zero fees)"
    )
    if sizing:
        text += f"\n\n\U0001F4B0 Recommended size: ${sizing['standard']:,.0f}"
    if bankroll:
        text += f" ({sizing['standard'] / bankroll.total_capital * 100:.1f}% bankroll)" if sizing else ""

    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="cross_platform",
        priority="high" if gap >= 15 else "standard",
        market_id=market_id,
        signal_score=gap,
        message=text,
        telegram_message_id=telegram_msg_id,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_system_alert(session: AsyncSession, text: str) -> Alert:
    """System health/status message."""
    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="system",
        priority="info",
        message=text,
        telegram_message_id=telegram_msg_id,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_fade_alert(
    session: AsyncSession,
    dumb_wallet: Wallet,
    trade: Trade,
    fade_result,  # FadeScoreResult
    sizing: dict | None = None,
    bankroll: Bankroll | None = None,
) -> Alert:
    """Dumb money fade alert (spec format)."""
    cat = "Unknown"
    cat_wr = dumb_wallet.win_rate
    if dumb_wallet.category_win_rates:
        # Find worst category
        worst = min(dumb_wallet.category_win_rates.items(), key=lambda x: x[1], default=(None, cat_wr))
        if worst[0]:
            cat = worst[0]
            cat_wr = worst[1]

    text = (
        f"\U0001F53B CENTINELA \u2014 DUMB MONEY FADE\n\n"
        f"\u25C8 FADE: {dumb_wallet.handle} (Inverse: {dumb_wallet.inverse_score:.0f} | "
        f"{dumb_wallet.win_rate*100:.0f}% WR | {dumb_wallet.total_trades} trades)\n"
        f"\U0001F4CA {trade.market_name}\n"
        f"   \u2192 {dumb_wallet.handle} bought {trade.side} @ ${trade.price:.2f}\n"
        f"   \u2192 FADE: consider {fade_result.fade_side} @ ${1-trade.price:.2f}\n\n"
        f"\U0001F4C9 Lifetime: ${dumb_wallet.pnl:+,.0f} | Category: {cat} ({cat_wr*100:.0f}% WR)\n"
    )
    if fade_result.confirming_insiders:
        text += f"\U0001F50D Smart money on {fade_result.fade_side} side \u2714 CONFIRMED\n"
    else:
        text += f"\U0001F50D Smart money: no insiders in this market\n"

    text += f"\U0001F4CA Fade score: {fade_result.score:.0f}/100\n"

    if sizing:
        text += f"\n\U0001F4B0 Standard: ${sizing['standard']:,.0f}"
        if bankroll and bankroll.total_capital > 0:
            text += f" ({sizing['standard']/bankroll.total_capital*100:.1f}%)"
        text += f" | \U0001F4CC LIMIT {fade_result.fade_side} @ ${1-trade.price:.2f}\n"

    text += "\nReply: TOOK [amount] [conviction 1-5]\nReply: SKIP [reason]"

    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="dumb_money_fade",
        priority="standard",
        wallet_id=dumb_wallet.id,
        signal_side=fade_result.fade_side,
        signal_score=fade_result.score,
        message=text,
        telegram_message_id=telegram_msg_id,
        decision_output="execute",
        recommended_size=sizing["standard"] if sizing else None,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_convergence_alert(
    session: AsyncSession,
    market_name: str,
    smart_side: str,
    smart_wallets: list[tuple[str, float, float]],  # [(handle, score, size)]
    dumb_wallets: list[tuple[str, float, float]],    # [(handle, inv_score, size)]
    sizing: dict | None = None,
    cross_platform_gap: float | None = None,
) -> Alert:
    """Convergence alert — highest conviction signal."""
    dumb_side = "NO" if smart_side == "YES" else "YES"

    smart_lines = "\n".join(
        f"   \u25C8 {h} ({s:.0f}) \u2014 ${sz:,.0f} {smart_side} @ entry"
        for h, s, sz in smart_wallets
    )
    dumb_lines = "\n".join(
        f"   \u25C8 {h} (inv:{s:.0f}) \u2014 ${sz:,.0f} {dumb_side}"
        for h, s, sz in dumb_wallets
    )

    text = (
        f"\U0001F3AF CENTINELA \u2014 CONVERGENCE\n\n"
        f"\U0001F4CA {market_name} \u2192 {smart_side}\n\n"
        f"   SMART MONEY buying {smart_side}:\n{smart_lines}\n\n"
        f"   DUMB MONEY buying {dumb_side}:\n{dumb_lines}\n"
    )
    if cross_platform_gap and cross_platform_gap > 0:
        text += f"\n   \U0001F310 Kalshi: {cross_platform_gap:.0f}pt gap \u2014 confirming\n"

    if sizing:
        text += f"\n\U0001F4B0 High conviction: ${sizing['standard']:,.0f}"
        text += f"\n   \U0001F4CC LIMIT {smart_side} (zero fees)"

    text += "\n\nThis is the highest confidence signal Centinela can generate."
    text += "\n\nReply: TOOK [amount] [conviction 1-5]\nReply: SKIP [reason]"

    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="convergence",
        priority="critical",
        signal_side=smart_side,
        message=text,
        telegram_message_id=telegram_msg_id,
        decision_output="execute",
        recommended_size=sizing["standard"] if sizing else None,
    )
    session.add(alert)
    await session.flush()
    return alert


async def send_consensus_alert(
    session: AsyncSession,
    market_name: str,
    side: str,
    wallets: list[tuple[str, float, float]],  # [(handle, score, size)]
    combined_score: float,
    total_capital: float,
    sizing: dict | None = None,
    cross_platform_gap: float | None = None,
) -> Alert:
    """Consensus alert — 3+ insiders on same side."""
    wallet_lines = "\n".join(
        f"   \u25C8 {h} ({s:.0f}) \u2014 ${sz:,.0f} @ entry"
        for h, s, sz in wallets
    )

    text = (
        f"\U0001F525 CENTINELA \u2014 CONSENSUS\n\n"
        f"\U0001F4CA {market_name} \u2192 {side}\n"
        f"   {len(wallets)} insiders in last 18h:\n{wallet_lines}\n\n"
        f"   Combined: {combined_score:.0f} | Capital: ${total_capital:,.0f}\n"
    )
    if cross_platform_gap and cross_platform_gap > 0:
        text += f"   \U0001F310 Kalshi: {cross_platform_gap:.0f}pt gap\n"

    if sizing:
        text += f"\n\U0001F4B0 Standard: ${sizing['standard']:,.0f} | \U0001F4CC LIMIT @ entry (zero fees)\n"

    text += "\nReply: TOOK [amount] [conviction 1-5]\nReply: SKIP [reason]"

    telegram_msg_id = await send_message(text)
    alert = Alert(
        type="consensus",
        priority="high",
        signal_side=side,
        signal_score=combined_score,
        message=text,
        telegram_message_id=telegram_msg_id,
        decision_output="execute",
        recommended_size=sizing["standard"] if sizing else None,
    )
    session.add(alert)
    await session.flush()
    return alert


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def _format_insider_alert(
    trade: Trade,
    wallet: Wallet,
    market: Market | None,
    sizing: dict | None,
    bankroll: Bankroll | None,
    open_positions: int,
    warning: str | None,
) -> str:
    """Full insider alert matching spec format."""
    score_emoji = _score_badge(wallet.insider_score)
    classification = wallet.classification or "UNKNOWN"
    first_entry = "\U0001F539 First entry \u2014 new position" if trade.is_first_entry else "\U0001F538 Adding to position"

    lines = [
        f"{score_emoji} CENTINELA \u2014 INSIDER TRADE",
        "",
        f"\u25C8 {wallet.handle} (Score: {wallet.insider_score:.0f} | {classification})",
        f"\U0001F4CA {trade.market_name}",
        f"   \u2192 {trade.side} @ ${trade.price:.2f} | Size: ${trade.size:,.0f}",
        f"   {first_entry}",
        "",
        f"\U0001F4C8 Win Rate: {wallet.win_rate * 100:.0f}% | Trades: {wallet.total_trades}",
    ]

    # Liquidity info
    if market and market.liquidity_grade:
        lines.append(f"\U0001F4A7 Liquidity: {market.liquidity_grade} | Spread: {market.spread or 'N/A'}%")

    lines.append("")

    # Sizing block
    if sizing:
        cons_pct = sizing["conservative"] / bankroll.total_capital * 100 if bankroll and bankroll.total_capital > 0 else 0
        std_pct = sizing["standard"] / bankroll.total_capital * 100 if bankroll and bankroll.total_capital > 0 else 0
        agg_pct = sizing["aggressive"] / bankroll.total_capital * 100 if bankroll and bankroll.total_capital > 0 else 0
        lines.extend([
            f"\U0001F4B0 ENTRY:",
            f"   Conservative: ${sizing['conservative']:,.0f} ({cons_pct:.1f}%)",
            f"   Standard:     ${sizing['standard']:,.0f} ({std_pct:.1f}%)",
            f"   Aggressive:   ${sizing['aggressive']:,.0f} ({agg_pct:.1f}%)",
        ])
    lines.append(f"   \U0001F4CC LIMIT ORDER @ ${trade.price:.2f} (zero fees)")

    if sizing and sizing.get("type_multiplier", 1.0) < 1.0:
        if sizing["type_multiplier"] == 0.5:
            lines.append(f"   \U0001F528 Position build: entering 50% now, hold 50% for confirmation")

    lines.append("")

    # Bankroll status
    if bankroll:
        deployed_pct = bankroll.deployed_capital / bankroll.total_capital * 100 if bankroll.total_capital > 0 else 0
        state_emoji = {"green": "\U0001F7E2", "yellow": "\U0001F7E1", "red": "\U0001F6D1"}.get(bankroll.strategy_state, "\U0001F7E2")
        lines.extend([
            f"\U0001F4CB Bankroll: ${bankroll.total_capital:,.0f} | Deployed: {deployed_pct:.0f}% | Positions: {open_positions}/{bankroll.max_concurrent_positions}",
            f"   Daily P&L: {bankroll.daily_pnl:+,.0f} | State: {state_emoji} {bankroll.strategy_state.upper()}",
        ])

    if warning:
        lines.append(f"\u26A0\uFE0F {warning}")

    lines.extend([
        "",
        "Reply: TOOK [amount] [conviction 1-5]",
        "Reply: SKIP [reason]",
    ])

    return "\n".join(lines)


def _score_badge(score: float) -> str:
    if score >= 90:
        return "\U0001F7E2"
    if score >= 75:
        return "\U0001F7E1"
    if score >= 60:
        return "\U0001F7E0"
    return "\U0001F534"


def _expiry_reason_text(reason: str) -> str:
    return {
        "chase": "Chase risk triggered \u2014 DO NOT ENTER",
        "timeout": "Signal timed out (>15 min since insider entry)",
        "liquidity": "Market liquidity too low",
        "slippage": "Slippage too high",
    }.get(reason, f"Signal expired: {reason}")
