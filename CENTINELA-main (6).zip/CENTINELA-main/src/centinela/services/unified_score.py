"""Unified Signal Score Integration — ALL modules wired into one formula.

Exact spec formula:

  final_signal_score = base_signal_score
      × intent_multiplier                                    ← Module 1
      × (0.85 + 0.15 * safe_div(copyability_score, 100, 0)) ← Module 3
      × (0.90 + 0.10 * safe_div(leader_score, 100, 0))      ← Module 6
      × (1.00 - 0.35 * safe_div(trap_risk_score, 100, 0))   ← Module 5
      × (0.90 + 0.10 * regime_confidence)                    ← Module 7

  If pre_signal_flag was true before entry:   ← Module 4
      final_signal_score += 7

  If cluster discount applies:                ← Module 2
      final_signal_score *= consensus_cluster_adjustment

  final_signal_score = clamp(final_signal_score, 0, 100)

Execution gating:
  >= 85: HIGH CONVICTION — full size, top priority
  75-84: STANDARD VALID — normal size and priority
  65-74: WATCH — reduced size (35% cut), lower priority
  < 65:  NO ALERT — unless cross-platform >= 10 or convergence
"""

from dataclasses import dataclass

import structlog

from centinela.utils.math_primitives import clamp, safe_div

logger = structlog.get_logger()


@dataclass
class UnifiedScoreInputs:
    """All module outputs that feed into the unified formula."""
    base_signal_score: float = 70.0  # Wallet insider_score

    # Module 1: Intent
    intent_multiplier: float = 1.0
    intent_type: str = "informational"
    intent_confidence: float = 0.5

    # Module 2: Clustering
    cluster_discount: float = 1.0  # consensus_cluster_adjustment

    # Module 3: Copyability (100 = no penalty / unknown)
    copyability_score: float = 100.0

    # Module 4: Pre-signal
    pre_signal_flag: bool = False

    # Module 5: Trap risk (0 = no trap)
    trap_risk_score: float = 0.0

    # Module 6: Leader (100 = neutral, no bonus or penalty)
    leader_score: float = 100.0

    # Module 7: Regime (1.0 = full confidence / neutral)
    regime_confidence: float = 1.0
    regime_label: str = "low_vol"
    regime_min_score_adjustment: int = 0

    # Signal context (for bypass logic)
    signal_type: str = "insider"  # insider/convergence/cross_platform/dumb_money_fade
    cross_platform_gap: float = 0.0


@dataclass
class UnifiedScoreResult:
    final_score: float
    execution_gate: str  # high_conviction/standard/watch/no_alert
    size_multiplier: float  # 1.0 / 0.65 / 0.0
    priority_label: str
    breakdown: dict[str, float]


def compute_unified_score(inputs: UnifiedScoreInputs) -> UnifiedScoreResult:
    """Compute the unified signal score using ALL quant modules (spec exact).

    This is the one deterministic number. One decision.
    """
    base = inputs.base_signal_score

    # Module 1: Intent multiplier
    intent_factor = inputs.intent_multiplier

    # Module 3: Copyability factor (0.85 to 1.0)
    copy_factor = 0.85 + 0.15 * safe_div(inputs.copyability_score, 100, 0)

    # Module 6: Leader factor (0.90 to 1.0)
    leader_factor = 0.90 + 0.10 * safe_div(inputs.leader_score, 100, 0)

    # Module 5: Trap risk factor (0.65 to 1.0, lower = more trap risk)
    trap_factor = 1.00 - 0.35 * safe_div(inputs.trap_risk_score, 100, 0)

    # Module 7: Regime factor (0.90 to 1.0)
    regime_factor = 0.90 + 0.10 * inputs.regime_confidence

    # Unified formula (spec exact)
    score = base * intent_factor * copy_factor * leader_factor * trap_factor * regime_factor

    # Module 4: Pre-signal bonus
    if inputs.pre_signal_flag:
        score += 7

    # Module 2: Cluster discount
    score *= inputs.cluster_discount

    # Module 6: Leader bonus (+6 for tier-1 signals)
    if (
        inputs.leader_score >= 80
        and inputs.intent_type == "informational"
        and inputs.intent_confidence >= 0.70
    ):
        score += 6

    # Apply regime minimum score adjustment
    min_threshold = 65 + inputs.regime_min_score_adjustment

    # Final clamp
    score = clamp(score, 0, 100)

    # Execution gating (spec exact)
    if score >= 85:
        gate = "high_conviction"
        size_mult = 1.0
        priority = "critical"
    elif score >= 75:
        gate = "standard"
        size_mult = 1.0
        priority = "high"
    elif score >= min_threshold:
        gate = "watch"
        size_mult = 0.65  # 35% size cut
        priority = "standard"
    else:
        # Bypass: convergence and cross-platform >= 10 can still alert
        if inputs.signal_type == "convergence" or inputs.cross_platform_gap >= 10:
            gate = "watch"
            size_mult = 0.65
            priority = "standard"
            logger.info(
                "unified_score.bypass",
                score=f"{score:.1f}",
                signal_type=inputs.signal_type,
                xplat_gap=f"{inputs.cross_platform_gap:.1f}",
            )
        else:
            gate = "no_alert"
            size_mult = 0.0
            priority = "info"

    breakdown = {
        "base": base,
        "intent_factor": round(intent_factor, 3),
        "copy_factor": round(copy_factor, 3),
        "leader_factor": round(leader_factor, 3),
        "trap_factor": round(trap_factor, 3),
        "regime_factor": round(regime_factor, 3),
        "pre_signal_bonus": 7 if inputs.pre_signal_flag else 0,
        "cluster_discount": round(inputs.cluster_discount, 3),
        "leader_bonus": 6 if inputs.leader_score >= 80 and inputs.intent_type == "informational" and inputs.intent_confidence >= 0.70 else 0,
        "regime_min_adjustment": inputs.regime_min_score_adjustment,
        "final": round(score, 2),
    }

    logger.debug(
        "unified_score.computed",
        score=f"{score:.1f}",
        gate=gate,
        intent=inputs.intent_type,
        regime=inputs.regime_label,
    )

    return UnifiedScoreResult(
        final_score=score,
        execution_gate=gate,
        size_multiplier=size_mult,
        priority_label=priority,
        breakdown=breakdown,
    )
