"""Bankroll and position management endpoints."""

from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import select

from centinela.db.models.execution import Bankroll, Position
from centinela.dependencies import SessionDep
from centinela.services.bankroll import get_or_create_bankroll, get_open_positions

router = APIRouter(tags=["bankroll"])


class BankrollUpdate(BaseModel):
    total_capital: float | None = None
    daily_loss_limit: float | None = None
    weekly_loss_limit: float | None = None
    max_per_market_pct: float | None = None
    max_per_category_pct: float | None = None
    max_concurrent_positions: int | None = None
    kelly_fraction: float | None = None
    strategy_state: str | None = None


@router.get("/bankroll")
async def get_bankroll(session: SessionDep):
    bankroll = await get_or_create_bankroll(session)
    await session.commit()
    positions = await get_open_positions(session)
    return {
        "totalCapital": bankroll.total_capital,
        "deployedCapital": bankroll.deployed_capital,
        "availableCapital": bankroll.available_capital,
        "dailyPnl": bankroll.daily_pnl,
        "weeklyPnl": bankroll.weekly_pnl,
        "dailyLossLimit": bankroll.daily_loss_limit,
        "weeklyLossLimit": bankroll.weekly_loss_limit,
        "maxPerMarketPct": bankroll.max_per_market_pct,
        "maxPerCategoryPct": bankroll.max_per_category_pct,
        "maxConcurrentPositions": bankroll.max_concurrent_positions,
        "kellyFraction": bankroll.kelly_fraction,
        "strategyState": bankroll.strategy_state,
        "isLockedOut": bankroll.is_locked_out,
        "lockoutUntil": bankroll.lockout_until.isoformat() if bankroll.lockout_until else None,
        "lockoutReason": bankroll.lockout_reason,
        "openPositions": len(positions),
    }


@router.patch("/bankroll")
async def update_bankroll(session: SessionDep, body: BankrollUpdate):
    bankroll = await get_or_create_bankroll(session)
    if body.total_capital is not None:
        bankroll.total_capital = body.total_capital
        bankroll.available_capital = body.total_capital - bankroll.deployed_capital
    if body.daily_loss_limit is not None:
        bankroll.daily_loss_limit = body.daily_loss_limit
    if body.weekly_loss_limit is not None:
        bankroll.weekly_loss_limit = body.weekly_loss_limit
    if body.max_per_market_pct is not None:
        bankroll.max_per_market_pct = body.max_per_market_pct
    if body.max_per_category_pct is not None:
        bankroll.max_per_category_pct = body.max_per_category_pct
    if body.max_concurrent_positions is not None:
        bankroll.max_concurrent_positions = body.max_concurrent_positions
    if body.kelly_fraction is not None:
        bankroll.kelly_fraction = body.kelly_fraction
    if body.strategy_state is not None and body.strategy_state in ("green", "yellow", "red"):
        bankroll.strategy_state = body.strategy_state
    await session.commit()
    return {"status": "updated"}


@router.get("/positions")
async def list_positions(session: SessionDep, status: str | None = None):
    query = select(Position).order_by(Position.time_entered.desc())
    if status:
        query = query.where(Position.status == status)
    else:
        query = query.where(Position.status.in_(["open", "partial"]))

    result = await session.execute(query)
    positions = result.scalars().all()
    return [
        {
            "id": p.id,
            "marketName": p.market_name,
            "side": p.side,
            "size": p.size,
            "currentSize": p.current_size,
            "entryPrice": p.entry_price,
            "currentPrice": p.current_price,
            "unrealizedPnl": p.unrealized_pnl,
            "pnlPct": p.pnl_pct,
            "tp1Price": p.tp1_price,
            "tp2Price": p.tp2_price,
            "slHardPrice": p.sl_hard_price,
            "status": p.status,
            "buildPhase": p.build_phase,
            "insiderStillHolds": p.insider_still_holds,
            "signalSource": p.signal_source,
            "category": p.category,
            "timeEntered": p.time_entered.isoformat() if p.time_entered else None,
            "convictionLevel": p.conviction_level,
        }
        for p in positions
    ]


@router.get("/decisions")
async def list_decisions(session: SessionDep, limit: int = 50):
    from centinela.db.models.execution import DecisionLog

    result = await session.execute(
        select(DecisionLog).order_by(DecisionLog.timestamp.desc()).limit(limit)
    )
    logs = result.scalars().all()
    return [
        {
            "id": d.id,
            "walletId": d.wallet_id,
            "marketName": d.market_name,
            "stepReached": d.step_reached,
            "stepResult": d.step_result,
            "failReason": d.fail_reason,
            "finalOutput": d.final_output,
            "recommendedSize": d.recommended_size,
            "timestamp": d.timestamp.isoformat() if d.timestamp else None,
        }
        for d in logs
    ]
