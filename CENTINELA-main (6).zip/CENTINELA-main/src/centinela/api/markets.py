"""Market endpoints."""

from fastapi import APIRouter
from sqlalchemy import select

from centinela.db.models.market import Market
from centinela.dependencies import SessionDep

router = APIRouter(prefix="/markets", tags=["markets"])


@router.get("")
async def list_markets(
    session: SessionDep,
    category: str | None = None,
    status: str = "active",
    search: str | None = None,
    limit: int = 100,
    offset: int = 0,
):
    query = select(Market).where(Market.status == status)
    if category:
        query = query.where(Market.category == category)
    if search:
        query = query.where(Market.question.ilike(f"%{search}%"))
    query = query.order_by(Market.daily_volume.desc().nullslast()).limit(limit).offset(offset)

    result = await session.execute(query)
    markets = result.scalars().all()
    return [
        {
            "id": m.id,
            "polymarketId": m.polymarket_id,
            "question": m.question,
            "category": m.category,
            "status": m.status,
            "oddsYes": m.odds_yes,
            "oddsNo": m.odds_no,
            "dailyVolume": m.daily_volume,
            "spread": m.spread,
            "liquidityGrade": m.liquidity_grade,
        }
        for m in markets
    ]
