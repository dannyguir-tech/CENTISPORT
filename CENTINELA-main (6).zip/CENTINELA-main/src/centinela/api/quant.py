"""Phase 4 API endpoints: shadow tracking, discovery, backtest, clusters, copyability, leaders."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from centinela.db.models.quant import (
    CopyabilityMetric,
    DiscoveryCandidate,
    EdgeMonitoring,
    LeaderMetric,
    ScoringCalibration,
    WalletCluster,
)
from centinela.db.models.wallet import Wallet
from centinela.dependencies import SessionDep

router = APIRouter(tags=["quant"])


# --- Edge Monitoring ---

@router.get("/edge-state")
async def get_edge_state(session: SessionDep):
    result = await session.execute(
        select(EdgeMonitoring).order_by(EdgeMonitoring.timestamp.desc()).limit(1)
    )
    latest = result.scalar_one_or_none()
    if not latest:
        return {"state": "green", "pnl": 0, "winRate": 0}
    return {
        "state": latest.strategy_state,
        "rolling30dPnl": latest.rolling_30d_pnl,
        "pnlPeak": latest.rolling_30d_pnl_peak,
        "avgEdge": latest.avg_edge_per_trade,
        "winRate": latest.win_rate,
        "sizeMultiplier": latest.position_size_multiplier,
        "timestamp": latest.timestamp.isoformat() if latest.timestamp else None,
    }


@router.get("/edge-state/history")
async def edge_state_history(session: SessionDep, limit: int = 30):
    result = await session.execute(
        select(EdgeMonitoring).order_by(EdgeMonitoring.timestamp.desc()).limit(limit)
    )
    return [
        {
            "state": e.strategy_state,
            "pnl": e.rolling_30d_pnl,
            "winRate": e.win_rate,
            "multiplier": e.position_size_multiplier,
            "timestamp": e.timestamp.isoformat() if e.timestamp else None,
        }
        for e in result.scalars().all()
    ]


# --- Shadow Tracking ---

@router.get("/shadow-tracking")
async def shadow_summary(session: SessionDep, days: int = 30):
    from centinela.services.shadow_tracking import get_shadow_summary
    return await get_shadow_summary(session, days=days)


# --- Discovery ---

@router.get("/discovery")
async def list_candidates(session: SessionDep, status: str = "pending"):
    result = await session.execute(
        select(DiscoveryCandidate)
        .where(DiscoveryCandidate.status == status)
        .order_by(DiscoveryCandidate.auto_score.desc())
    )
    return [
        {
            "id": c.id,
            "address": c.address,
            "handle": c.handle,
            "autoScore": c.auto_score,
            "inverseScore": c.inverse_score,
            "classification": c.classification,
            "walletType": c.wallet_type_suggestion,
            "backtestPnl": c.backtest_pnl,
            "backtestFadePnl": c.backtest_fade_pnl,
            "status": c.status,
            "discoveredAt": c.discovered_at.isoformat() if c.discovered_at else None,
        }
        for c in result.scalars().all()
    ]


@router.post("/discovery/{candidate_id}/approve")
async def approve(session: SessionDep, candidate_id: int):
    from centinela.services.wallet_discovery import approve_candidate
    wallet = await approve_candidate(session, candidate_id)
    if not wallet:
        raise HTTPException(404, "Candidate not found or already processed")
    return {"status": "approved", "address": wallet.address, "handle": wallet.handle}


@router.post("/discovery/{candidate_id}/reject")
async def reject(session: SessionDep, candidate_id: int):
    result = await session.execute(
        select(DiscoveryCandidate).where(DiscoveryCandidate.id == candidate_id)
    )
    candidate = result.scalar_one_or_none()
    if not candidate:
        raise HTTPException(404, "Not found")
    candidate.status = "rejected"
    await session.commit()
    return {"status": "rejected"}


# --- Backtest ---

class BacktestRequest(BaseModel):
    address: str
    days: int = 90


@router.post("/backtest")
async def run_backtest_endpoint(session: SessionDep, body: BacktestRequest):
    from centinela.services.backtest import backtest_before_add

    result = await session.execute(select(Wallet).where(Wallet.address == body.address))
    wallet = result.scalar_one_or_none()
    if not wallet:
        raise HTTPException(404, "Wallet not found. Add it first via POST /api/wallets")
    results = await backtest_before_add(session, wallet)
    return {"address": body.address, "results": results}


# --- Clusters ---

@router.get("/clusters")
async def list_clusters(session: SessionDep):
    from collections import defaultdict

    result = await session.execute(select(WalletCluster).order_by(WalletCluster.cluster_id))
    memberships = result.scalars().all()

    clusters: dict[int, list] = defaultdict(list)
    for m in memberships:
        w_result = await session.execute(select(Wallet).where(Wallet.id == m.wallet_id))
        w = w_result.scalar_one_or_none()
        clusters[m.cluster_id].append({
            "walletId": m.wallet_id,
            "handle": w.handle if w else None,
            "confidence": m.cluster_confidence,
        })

    return [
        {"clusterId": cid, "members": members, "size": len(members)}
        for cid, members in clusters.items()
    ]


# --- Copyability ---

@router.get("/copyability")
async def list_copyability(session: SessionDep):
    result = await session.execute(
        select(CopyabilityMetric, Wallet)
        .join(Wallet, CopyabilityMetric.wallet_id == Wallet.id)
        .order_by(CopyabilityMetric.copyability_score.desc())
    )
    return [
        {
            "walletId": m.wallet_id,
            "handle": w.handle,
            "copyabilityScore": m.copyability_score,
            "t3Median": m.t3_median,
            "t5Median": m.t5_median,
            "t10Median": m.t10_median,
            "edgeRetention": m.edge_retention,
            "stability": m.stability,
            "nSignals": m.n_signals_evaluated,
        }
        for m, w in result.all()
    ]


# --- Leaders ---

@router.get("/leaders")
async def list_leaders(session: SessionDep):
    result = await session.execute(
        select(LeaderMetric, Wallet)
        .join(Wallet, LeaderMetric.wallet_id == Wallet.id)
        .order_by(LeaderMetric.leader_score.desc())
    )
    return [
        {
            "walletId": m.wallet_id,
            "handle": w.handle,
            "leaderScore": m.leader_score,
            "leaderEvents": m.leader_events,
            "followerEvents": m.follower_events,
            "avgFollowQuality": m.avg_follow_quality,
            "medianLeadTime": m.median_lead_time_min,
        }
        for m, w in result.all()
    ]


# --- Calibration History ---

@router.get("/calibrations")
async def list_calibrations(session: SessionDep, limit: int = 10):
    result = await session.execute(
        select(ScoringCalibration).order_by(ScoringCalibration.calibrated_at.desc()).limit(limit)
    )
    return [
        {
            "id": c.id,
            "oldWeights": c.old_weights,
            "newWeights": c.new_weights,
            "calibratedAt": c.calibrated_at.isoformat() if c.calibrated_at else None,
        }
        for c in result.scalars().all()
    ]
