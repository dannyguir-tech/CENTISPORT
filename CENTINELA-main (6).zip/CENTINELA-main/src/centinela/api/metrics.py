"""Dashboard metrics endpoint."""

from fastapi import APIRouter
from sqlalchemy import func, select

from centinela.db.models.wallet import Wallet
from centinela.dependencies import SessionDep
from centinela.schemas.metrics import MetricsSummary

router = APIRouter(prefix="/metrics", tags=["metrics"])


@router.get("/summary", response_model=MetricsSummary)
async def summary(session: SessionDep):
    active = select(Wallet).where(Wallet.is_active == True)  # noqa: E712

    total = await session.scalar(select(func.count()).select_from(active.subquery()))
    insiders = await session.scalar(
        select(func.count()).select_from(
            active.where(Wallet.insider_score >= 85).subquery()
        )
    )
    combined_pnl = await session.scalar(
        select(func.coalesce(func.sum(Wallet.pnl), 0.0)).select_from(
            active.subquery()
        )
    )
    avg_wr = await session.scalar(
        select(func.coalesce(func.avg(Wallet.win_rate), 0.0)).select_from(
            active.subquery()
        )
    )

    return MetricsSummary(
        totalWallets=total or 0,
        topInsidersCount=insiders or 0,
        combinedPnl=float(combined_pnl or 0),
        avgWinRate=float(avg_wr or 0),
    )
