"""Phase 5 API: intent, regimes, pre-signals, traps, polling, unified score."""

from fastapi import APIRouter, Query
from pydantic import BaseModel
from sqlalchemy import select

from centinela.db.models.quant_intelligence import (
    DetectionHealth,
    MarketRegime,
    PollPriority,
    PreSignalFlag,
    RegimeBaseline,
    TradeIntent,
    TrapRiskEvent,
)
from centinela.dependencies import SessionDep

router = APIRouter(tags=["quant-intelligence"])


# --- Intent ---

@router.get("/intents")
async def list_intents(session: SessionDep, wallet_id: int | None = None, limit: int = 50):
    query = select(TradeIntent).order_by(TradeIntent.timestamp.desc()).limit(limit)
    if wallet_id:
        query = query.where(TradeIntent.wallet_id == wallet_id)
    result = await session.execute(query)
    return [
        {
            "id": i.id,
            "tradeId": i.trade_id,
            "walletId": i.wallet_id,
            "intentType": i.intent_type,
            "confidence": i.confidence,
            "multiplier": i.intent_multiplier,
            "rawScores": i.raw_scores,
            "features": i.features,
        }
        for i in result.scalars().all()
    ]


# --- Regimes ---

@router.get("/regimes")
async def list_regimes(session: SessionDep, limit: int = 20):
    result = await session.execute(
        select(MarketRegime).order_by(MarketRegime.timestamp.desc()).limit(limit)
    )
    return [
        {
            "marketId": r.market_id,
            "regime": r.regime_label,
            "confidence": r.regime_confidence,
            "chaseMult": r.chase_multiplier,
            "positionMult": r.position_multiplier,
            "minScoreAdj": r.min_score_adjustment,
            "rawScores": r.raw_scores,
        }
        for r in result.scalars().all()
    ]


@router.get("/regime-baselines")
async def list_baselines(session: SessionDep):
    result = await session.execute(select(RegimeBaseline))
    return [
        {
            "category": b.category,
            "rv": {"mu": b.rv_mu, "sigma": b.rv_sigma},
            "spread": {"mu": b.spread_mu, "sigma": b.spread_sigma},
            "depth": {"mu": b.depth_mu, "sigma": b.depth_sigma},
            "volume": {"mu": b.vol_mu, "sigma": b.vol_sigma},
            "sampleSize": b.sample_size,
        }
        for b in result.scalars().all()
    ]


# --- Pre-Signal ---

@router.get("/pre-signals")
async def list_pre_signals(session: SessionDep, active_only: bool = False, limit: int = 30):
    query = select(PreSignalFlag).order_by(PreSignalFlag.flagged_at.desc()).limit(limit)
    if active_only:
        query = query.where(PreSignalFlag.insider_entered_after == False)  # noqa: E712
    result = await session.execute(query)
    return [
        {
            "id": f.id,
            "marketId": f.market_id,
            "marketName": f.market_name,
            "confidence": f.pre_signal_confidence,
            "insiderEnteredAfter": f.insider_entered_after,
            "delayMinutes": f.insider_entry_delay_minutes,
            "wasUseful": f.was_useful,
            "flaggedAt": f.flagged_at.isoformat() if f.flagged_at else None,
        }
        for f in result.scalars().all()
    ]


# --- Trap Risk ---

@router.get("/trap-events")
async def list_trap_events(session: SessionDep, limit: int = 30):
    result = await session.execute(
        select(TrapRiskEvent).order_by(TrapRiskEvent.timestamp.desc()).limit(limit)
    )
    return [
        {
            "id": t.id,
            "alertId": t.alert_id,
            "marketId": t.market_id,
            "trapRiskScore": t.trap_risk_score,
            "actionTaken": t.action_taken,
            "components": {
                "weakBids": t.weak_bids,
                "heavyAsks": t.heavy_asks,
                "wideSpread": t.wide_spread,
                "pricePop": t.price_pop,
                "reversal3m": t.reversal_3m,
                "insiderInvReduction": t.insider_inv_reduction,
            },
        }
        for t in result.scalars().all()
    ]


# --- Polling ---

@router.get("/poll-priorities")
async def list_poll_priorities(session: SessionDep):
    result = await session.execute(
        select(PollPriority).order_by(PollPriority.poll_priority_score.desc())
    )
    return [
        {
            "marketId": p.market_id,
            "score": p.poll_priority_score,
            "tier": p.polling_tier,
            "intervalSeconds": p.poll_interval_seconds,
        }
        for p in result.scalars().all()
    ]


@router.get("/detection-health")
async def get_detection_health(session: SessionDep):
    result = await session.execute(
        select(DetectionHealth).order_by(DetectionHealth.timestamp.desc()).limit(1)
    )
    h = result.scalar_one_or_none()
    if not h:
        return {"confidence": 0.6, "websocketAlive": False}
    return {
        "websocketAlive": h.websocket_alive,
        "pollingFreshness": h.polling_freshness,
        "sourceRedundancy": h.source_redundancy,
        "confidence": h.detection_confidence,
    }


# --- Funding Intelligence ---

@router.get("/funding-events")
async def list_funding_events(
    session: SessionDep,
    event_type: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
):
    from centinela.services.funding_intelligence import get_funding_events

    events = await get_funding_events(session, event_type=event_type, limit=limit)
    return [
        {
            "id": e.id,
            "walletId": e.wallet_id,
            "eventType": e.event_type,
            "severity": e.severity,
            "details": e.details,
            "timestamp": e.timestamp.isoformat() if e.timestamp else None,
        }
        for e in events
    ]


@router.get("/funding-events/ranked")
async def list_ranked_funding_events(
    session: SessionDep,
    limit: int = Query(default=25, ge=1, le=100),
):
    from centinela.services.funding_intelligence import get_ranked_funding_events

    return await get_ranked_funding_events(session, limit=limit)


# --- Unified Score (test endpoint) ---

class UnifiedScoreRequest(BaseModel):
    base_score: float = 75
    intent_multiplier: float = 1.0
    intent_type: str = "informational"
    intent_confidence: float = 0.7
    copyability_score: float = 60
    leader_score: float = 50
    trap_risk_score: float = 10
    regime_confidence: float = 0.6
    pre_signal_flag: bool = False
    cluster_discount: float = 1.0


@router.post("/unified-score/simulate")
async def simulate_unified_score(body: UnifiedScoreRequest):
    from centinela.services.unified_score import UnifiedScoreInputs, compute_unified_score

    inputs = UnifiedScoreInputs(
        base_signal_score=body.base_score,
        intent_multiplier=body.intent_multiplier,
        intent_type=body.intent_type,
        intent_confidence=body.intent_confidence,
        copyability_score=body.copyability_score,
        leader_score=body.leader_score,
        trap_risk_score=body.trap_risk_score,
        regime_confidence=body.regime_confidence,
        pre_signal_flag=body.pre_signal_flag,
        cluster_discount=body.cluster_discount,
    )
    result = compute_unified_score(inputs)
    return {
        "finalScore": result.final_score,
        "executionGate": result.execution_gate,
        "sizeMultiplier": result.size_multiplier,
        "priority": result.priority_label,
        "breakdown": result.breakdown,
    }
