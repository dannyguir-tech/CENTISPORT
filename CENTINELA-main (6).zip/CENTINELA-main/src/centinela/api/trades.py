"""Trade list endpoints."""

from fastapi import APIRouter
from sqlalchemy import select

from centinela.db.models.trade import Trade
from centinela.dependencies import SessionDep
from centinela.schemas.trade import TradeOut

router = APIRouter(prefix="/trades", tags=["trades"])


@router.get("/live", response_model=list[TradeOut])
async def live_trades(session: SessionDep, limit: int = 50):
    """Most recent trades across all tracked wallets."""
    result = await session.execute(
        select(Trade).order_by(Trade.timestamp.desc()).limit(limit)
    )
    return list(result.scalars().all())


@router.get("", response_model=list[TradeOut])
async def list_trades(
    session: SessionDep,
    wallet_id: int | None = None,
    limit: int = 100,
    offset: int = 0,
):
    query = select(Trade).order_by(Trade.timestamp.desc()).limit(limit).offset(offset)
    if wallet_id is not None:
        query = query.where(Trade.wallet_id == wallet_id)
    result = await session.execute(query)
    return list(result.scalars().all())
