"""Phase 3 API endpoints: dumb money, consensus, convergence, overcrowding."""

from fastapi import APIRouter
from sqlalchemy import func, select

from centinela.db.models.edge_expansion import (
    ConsensusSignal,
    ConvergenceSignal,
    DumbMoneySignal,
    OvercrowdingMetric,
)
from centinela.db.models.wallet import Wallet
from centinela.dependencies import SessionDep

router = APIRouter(tags=["edge-expansion"])


# --- Dumb Money ---

@router.get("/dumb-money/wallets")
async def list_dumb_money_wallets(session: SessionDep):
    """List all tracked dumb money wallets with inverse scores."""
    result = await session.execute(
        select(Wallet)
        .where(Wallet.wallet_type == "dumb")
        .where(Wallet.is_active == True)  # noqa: E712
        .order_by(Wallet.inverse_score.desc())
    )
    wallets = result.scalars().all()
    return [
        {
            "address": w.address,
            "handle": w.handle,
            "inverseScore": w.inverse_score,
            "winRate": w.win_rate,
            "totalTrades": w.total_trades,
            "pnl": w.pnl,
            "categoryWinRates": w.category_win_rates,
            "washSuspected": w.wash_suspected,
        }
        for w in wallets
    ]


@router.get("/dumb-money/signals")
async def list_dumb_money_signals(session: SessionDep, limit: int = 50):
    """Recent dumb money fade signals (generated and suppressed)."""
    result = await session.execute(
        select(DumbMoneySignal)
        .order_by(DumbMoneySignal.timestamp.desc())
        .limit(limit)
    )
    signals = result.scalars().all()
    return [
        {
            "id": s.id,
            "walletId": s.wallet_id,
            "marketName": s.market_name,
            "dumbSide": s.dumb_side,
            "fadeSide": s.fade_side,
            "fadeSignalScore": s.fade_signal_score,
            "components": {
                "inverseScore": s.inverse_score_component,
                "categoryInverse": s.category_inverse_component,
                "smartConfirmation": s.smart_confirmation_component,
                "crossPlatform": s.cross_platform_component,
                "dumbConsensus": s.dumb_consensus_component,
            },
            "suppressed": s.suppressed,
            "suppressReason": s.suppress_reason,
            "smartMoneyConflict": s.smart_money_conflict,
            "outcome": s.outcome,
            "timestamp": s.timestamp.isoformat() if s.timestamp else None,
        }
        for s in signals
    ]


# --- Consensus ---

@router.get("/consensus")
async def list_consensus_signals(session: SessionDep, limit: int = 20):
    result = await session.execute(
        select(ConsensusSignal)
        .order_by(ConsensusSignal.timestamp.desc())
        .limit(limit)
    )
    signals = result.scalars().all()
    return [
        {
            "id": s.id,
            "marketName": s.market_name,
            "side": s.side,
            "walletIds": s.wallet_ids,
            "walletCount": s.wallet_count,
            "combinedScore": s.combined_score,
            "totalCapital": s.total_capital,
            "outcome": s.outcome,
            "timestamp": s.timestamp.isoformat() if s.timestamp else None,
        }
        for s in signals
    ]


# --- Convergence ---

@router.get("/convergence")
async def list_convergence_signals(session: SessionDep, limit: int = 20):
    result = await session.execute(
        select(ConvergenceSignal)
        .order_by(ConvergenceSignal.timestamp.desc())
        .limit(limit)
    )
    signals = result.scalars().all()
    return [
        {
            "id": s.id,
            "marketName": s.market_name,
            "smartSide": s.smart_side,
            "smartWalletIds": s.smart_wallet_ids,
            "smartCombinedScore": s.smart_combined_score,
            "dumbSide": s.dumb_side,
            "dumbWalletIds": s.dumb_wallet_ids,
            "dumbCombinedInverseScore": s.dumb_combined_inverse_score,
            "crossPlatformGap": s.cross_platform_gap,
            "totalEdgeSources": s.total_edge_sources,
            "outcome": s.outcome,
            "timestamp": s.timestamp.isoformat() if s.timestamp else None,
        }
        for s in signals
    ]


# --- Overcrowding ---

@router.get("/overcrowding")
async def list_overcrowding(session: SessionDep):
    """Wallets with overcrowding concerns."""
    result = await session.execute(
        select(OvercrowdingMetric, Wallet)
        .join(Wallet, OvercrowdingMetric.wallet_id == Wallet.id)
        .where(OvercrowdingMetric.score_penalty > 0)
        .order_by(OvercrowdingMetric.measured_at.desc())
    )
    rows = result.all()

    seen: set[int] = set()
    out = []
    for metric, wallet in rows:
        if wallet.id in seen:
            continue
        seen.add(wallet.id)
        out.append({
            "walletId": wallet.id,
            "handle": wallet.handle,
            "reactionSeconds": metric.avg_price_reaction_seconds,
            "prevReactionSeconds": metric.prev_reaction_seconds,
            "trend": metric.trend_direction,
            "scorePenalty": metric.score_penalty,
            "measuredAt": metric.measured_at.isoformat() if metric.measured_at else None,
        })
    return out
