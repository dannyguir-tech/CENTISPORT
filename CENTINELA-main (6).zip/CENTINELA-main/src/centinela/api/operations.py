"""Phase 6 API: operations, reporting, tax, market heat map, journal, news, catalyst."""

from datetime import datetime

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import func, select

from centinela.db.models.execution import Position
from centinela.db.models.market import Market
from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.dependencies import SessionDep

router = APIRouter(tags=["operations"])


# --- Order Book Intelligence ---

@router.get("/orderbook/{token_id}")
async def get_orderbook_analysis(token_id: str):
    from centinela.services.operations import analyze_order_book
    result = await analyze_order_book(token_id)
    if not result:
        raise HTTPException(404, "Order book unavailable")
    return result


# --- Resolution Calendar ---

@router.get("/resolution-calendar")
async def resolution_calendar(session: SessionDep):
    from centinela.services.operations import get_resolution_calendar
    return await get_resolution_calendar(session)


# --- Correlation Risk ---

@router.get("/portfolio-risk")
async def portfolio_risk(session: SessionDep):
    from centinela.services.operations import analyze_portfolio_correlation
    return await analyze_portfolio_correlation(session)


# --- Entry Window Calculator ---

@router.get("/entry-window/{wallet_id}")
async def entry_window(session: SessionDep, wallet_id: int):
    from centinela.services.operations import calculate_entry_window
    return await calculate_entry_window(session, wallet_id)


# --- Market Heat Map ---

@router.get("/heat-map")
async def market_heat_map(session: SessionDep):
    """Map of insider activity density by category — color-coded."""
    # Count recent trades by category from smart wallets
    from datetime import timezone, timedelta
    cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=24)

    result = await session.execute(
        select(Trade, Wallet)
        .join(Wallet, Trade.wallet_id == Wallet.id)
        .where(Trade.timestamp >= cutoff)
        .where(Wallet.wallet_type == "smart")
        .where(Wallet.is_active == True)  # noqa: E712
    )
    rows = result.all()

    from collections import defaultdict
    cat_data: dict[str, dict] = defaultdict(lambda: {"trades": 0, "volume": 0, "wallets": set()})
    for trade, wallet in rows:
        from centinela.services.scoring_engine import _infer_category
        cat = _infer_category(trade.market_name)
        cat_data[cat]["trades"] += 1
        cat_data[cat]["volume"] += trade.size
        cat_data[cat]["wallets"].add(wallet.id)

    heat_map = []
    for cat, data in cat_data.items():
        heat_map.append({
            "category": cat,
            "trades24h": data["trades"],
            "volume24h": round(data["volume"], 2),
            "uniqueWallets": len(data["wallets"]),
            "intensity": min(data["trades"] / 10, 1.0),  # 0-1 heat scale
        })

    return sorted(heat_map, key=lambda x: x["intensity"], reverse=True)


# --- Trade Journal ---

class JournalEntry(BaseModel):
    pre_notes: str | None = None
    post_notes: str | None = None


@router.patch("/positions/{position_id}/journal")
async def update_journal(session: SessionDep, position_id: int, body: JournalEntry):
    from centinela.services.reporting import add_journal_entry
    pos = await add_journal_entry(session, position_id, body.pre_notes, body.post_notes)
    if not pos:
        raise HTTPException(404, "Position not found")
    await session.commit()
    return {"status": "updated", "positionId": position_id}


# --- Performance Reports ---

@router.get("/reports/{period}")
async def get_report(session: SessionDep, period: str):
    if period not in ("weekly", "monthly"):
        raise HTTPException(400, "Period must be 'weekly' or 'monthly'")
    from centinela.services.reporting import generate_performance_report
    return await generate_performance_report(session, period)


# --- Tax Export ---

@router.get("/tax/summary/{year}")
async def tax_summary(session: SessionDep, year: int):
    from centinela.services.tax_export import get_tax_summary
    return await get_tax_summary(session, year)


@router.get("/tax/export/{year}", response_class=PlainTextResponse)
async def tax_csv(session: SessionDep, year: int):
    from centinela.services.tax_export import export_tax_csv
    csv_content = await export_tax_csv(session, year)
    return PlainTextResponse(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=centinela_tax_{year}.csv"},
    )


# --- Catalyst Scanner ---

class CatalystRequest(BaseModel):
    market_question: str
    upcoming_event: str
    current_price: float


@router.post("/catalyst/scan")
async def scan_catalyst(body: CatalystRequest):
    from centinela.services.catalyst_scanner import scan_catalyst_impact
    result = await scan_catalyst_impact(body.market_question, body.upcoming_event, body.current_price)
    if not result:
        return {"status": "unavailable", "note": "Set ANTHROPIC_API_KEY to enable"}
    return result


# --- News / RSS ---

@router.get("/news")
async def get_news(feed: str = "reuters_top", limit: int = 10):
    from centinela.services.catalyst_scanner import fetch_rss_headlines, DEFAULT_FEEDS
    feed_url = DEFAULT_FEEDS.get(feed, feed)
    return await fetch_rss_headlines(feed_url, limit)
