from fastapi import APIRouter

from centinela.api.wallets import router as wallets_router
from centinela.api.trades import router as trades_router
from centinela.api.metrics import router as metrics_router
from centinela.api.markets import router as markets_router
from centinela.api.alerts import router as alerts_router
from centinela.api.cross_platform import router as cross_platform_router
from centinela.api.bankroll import router as bankroll_router
from centinela.api.edge_expansion import router as edge_router
from centinela.api.quant import router as quant_router
from centinela.api.quant_intelligence import router as qi_router
from centinela.api.operations import router as ops_router

api_router = APIRouter()
api_router.include_router(wallets_router)
api_router.include_router(trades_router)
api_router.include_router(metrics_router)
api_router.include_router(markets_router)
api_router.include_router(alerts_router)
api_router.include_router(cross_platform_router)
api_router.include_router(bankroll_router)
api_router.include_router(edge_router)
api_router.include_router(quant_router)
api_router.include_router(qi_router)
api_router.include_router(ops_router)


@api_router.get("/ping")
async def ping():
    return {"msg": "pong"}
