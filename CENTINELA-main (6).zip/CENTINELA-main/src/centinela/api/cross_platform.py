"""Cross-platform (Polymarket vs Kalshi) endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from centinela.db.models.cross_platform import CrossPlatformMarket, CrossPlatformPrice
from centinela.db.models.market import Market
from centinela.dependencies import SessionDep

router = APIRouter(prefix="/cross-platform", tags=["cross-platform"])


class PairCreate(BaseModel):
    polymarket_market_id: int
    kalshi_ticker: str
    kalshi_title: str = ""
    match_confidence: float = 1.0


@router.get("/pairs")
async def list_pairs(session: SessionDep):
    result = await session.execute(
        select(CrossPlatformMarket).where(CrossPlatformMarket.is_active == True)  # noqa: E712
    )
    pairs = result.scalars().all()
    out = []
    for p in pairs:
        # Get latest price snapshot
        price_result = await session.execute(
            select(CrossPlatformPrice)
            .where(CrossPlatformPrice.cross_platform_market_id == p.id)
            .order_by(CrossPlatformPrice.timestamp.desc())
            .limit(1)
        )
        latest = price_result.scalar_one_or_none()

        # Get market question
        market_result = await session.execute(
            select(Market).where(Market.id == p.polymarket_market_id)
        )
        market = market_result.scalar_one_or_none()

        out.append({
            "id": p.id,
            "polymarketMarketId": p.polymarket_market_id,
            "polymarketQuestion": market.question if market else None,
            "kalshiTicker": p.kalshi_ticker,
            "kalshiTitle": p.kalshi_title,
            "matchConfidence": p.match_confidence,
            "latestGap": latest.price_gap if latest else None,
            "polymarketPrice": latest.polymarket_price if latest else None,
            "kalshiPrice": latest.kalshi_price if latest else None,
        })
    return out


@router.post("/pairs", status_code=201)
async def create_pair(session: SessionDep, body: PairCreate):
    # Verify polymarket market exists
    market = await session.execute(
        select(Market).where(Market.id == body.polymarket_market_id)
    )
    if market.scalar_one_or_none() is None:
        raise HTTPException(404, "Polymarket market not found")

    pair = CrossPlatformMarket(
        polymarket_market_id=body.polymarket_market_id,
        kalshi_ticker=body.kalshi_ticker,
        kalshi_title=body.kalshi_title,
        match_confidence=body.match_confidence,
    )
    session.add(pair)
    await session.commit()
    return {"id": pair.id, "status": "created"}


@router.get("/divergences")
async def list_divergences(session: SessionDep, min_gap: float = 10.0):
    """Active divergences above threshold."""
    result = await session.execute(
        select(CrossPlatformMarket).where(CrossPlatformMarket.is_active == True)  # noqa: E712
    )
    pairs = result.scalars().all()

    divergences = []
    for p in pairs:
        price_result = await session.execute(
            select(CrossPlatformPrice)
            .where(CrossPlatformPrice.cross_platform_market_id == p.id)
            .order_by(CrossPlatformPrice.timestamp.desc())
            .limit(1)
        )
        latest = price_result.scalar_one_or_none()
        if latest and latest.price_gap >= min_gap:
            market_result = await session.execute(
                select(Market).where(Market.id == p.polymarket_market_id)
            )
            market = market_result.scalar_one_or_none()
            direction = "UNDERPRICED" if latest.polymarket_price < latest.kalshi_price else "OVERPRICED"
            divergences.append({
                "pairId": p.id,
                "question": market.question if market else p.kalshi_title,
                "polymarketPrice": latest.polymarket_price,
                "kalshiPrice": latest.kalshi_price,
                "gap": latest.price_gap,
                "direction": direction,
                "timestamp": latest.timestamp.isoformat(),
            })

    return sorted(divergences, key=lambda d: d["gap"], reverse=True)
