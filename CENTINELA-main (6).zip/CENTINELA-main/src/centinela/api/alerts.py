"""Alert history endpoints."""

from fastapi import APIRouter
from sqlalchemy import select

from centinela.db.models.alert import Alert
from centinela.dependencies import SessionDep

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("")
async def list_alerts(
    session: SessionDep,
    type: str | None = None,
    priority: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    query = select(Alert).order_by(Alert.sent_at.desc()).limit(limit).offset(offset)
    if type:
        query = query.where(Alert.type == type)
    if priority:
        query = query.where(Alert.priority == priority)

    result = await session.execute(query)
    alerts = result.scalars().all()
    return [
        {
            "id": a.id,
            "type": a.type,
            "priority": a.priority,
            "walletId": a.wallet_id,
            "marketId": a.market_id,
            "signalSide": a.signal_side,
            "signalScore": a.signal_score,
            "message": a.message,
            "sentAt": a.sent_at.isoformat() if a.sent_at else None,
        }
        for a in alerts
    ]
