"""Wallet CRUD endpoints."""

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from sqlalchemy import func, select

from centinela.db.models.trade import Trade
from centinela.db.models.wallet import Wallet
from centinela.dependencies import SessionDep
from centinela.schemas.wallet import WalletCreate, WalletOut, WalletUpdate, TradeOut
from centinela.services.wallet_tracker import add_wallet

router = APIRouter(prefix="/wallets", tags=["wallets"])


@router.get("", response_model=list[WalletOut])
async def list_wallets(
    session: SessionDep,
    sort_by: str = "insiderScore",
    category: str | None = None,
    min_win_rate: float = 0.0,
    search: str | None = None,
    is_active: bool = True,
):
    query = select(Wallet).where(Wallet.is_active == is_active)

    if category and category != "All":
        query = query.where(Wallet.categories.contains([category]))
    if min_win_rate > 0:
        query = query.where(Wallet.win_rate >= min_win_rate / 100.0)
    if search:
        query = query.where(
            Wallet.handle.ilike(f"%{search}%") | Wallet.address.ilike(f"%{search}%")
        )

    sort_map = {
        "insiderScore": Wallet.insider_score.desc(),
        "pnl": Wallet.pnl.desc(),
        "winRate": Wallet.win_rate.desc(),
        "trades": Wallet.total_trades.desc(),
    }
    query = query.order_by(sort_map.get(sort_by, Wallet.insider_score.desc()))

    result = await session.execute(query)
    wallets = result.scalars().all()

    out = []
    for w in wallets:
        recent = await _get_recent_trades(session, w.id)
        out.append(_to_wallet_out(w, recent))
    return out


@router.get("/{address}", response_model=WalletOut)
async def get_wallet(session: SessionDep, address: str):
    result = await session.execute(select(Wallet).where(Wallet.address == address))
    wallet = result.scalar_one_or_none()
    if not wallet:
        raise HTTPException(404, "Wallet not found")
    recent = await _get_recent_trades(session, wallet.id)
    return _to_wallet_out(wallet, recent)


@router.post("", response_model=WalletOut, status_code=201)
async def create_wallet(session: SessionDep, body: WalletCreate):
    wallet = await add_wallet(
        session,
        address=body.address,
        handle=body.handle,
        categories=body.categories,
        notes=body.notes,
    )
    recent = await _get_recent_trades(session, wallet.id)
    return _to_wallet_out(wallet, recent)


@router.patch("/{address}", response_model=WalletOut)
async def update_wallet(session: SessionDep, address: str, body: WalletUpdate):
    result = await session.execute(select(Wallet).where(Wallet.address == address))
    wallet = result.scalar_one_or_none()
    if not wallet:
        raise HTTPException(404, "Wallet not found")

    if body.handle is not None:
        wallet.handle = body.handle
    if body.categories is not None:
        wallet.categories = body.categories
    if body.notes is not None:
        wallet.notes = body.notes
    if body.is_active is not None:
        wallet.is_active = body.is_active

    await session.commit()
    recent = await _get_recent_trades(session, wallet.id)
    return _to_wallet_out(wallet, recent)


@router.delete("/{address}")
async def delete_wallet(session: SessionDep, address: str):
    result = await session.execute(select(Wallet).where(Wallet.address == address))
    wallet = result.scalar_one_or_none()
    if not wallet:
        raise HTTPException(404, "Wallet not found")
    wallet.is_active = False
    await session.commit()
    return {"status": "deactivated", "address": address}


async def _get_recent_trades(session, wallet_id: int, limit: int = 10) -> list[Trade]:
    result = await session.execute(
        select(Trade)
        .where(Trade.wallet_id == wallet_id)
        .order_by(Trade.timestamp.desc())
        .limit(limit)
    )
    return list(result.scalars().all())


def _relative_time(dt: datetime) -> str:
    now = datetime.now(tz=timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = now - dt
    hours = delta.total_seconds() / 3600
    if hours < 1:
        return f"{int(delta.total_seconds() / 60)}m ago"
    if hours < 24:
        return f"{int(hours)}h ago"
    return f"{int(hours / 24)}d ago"


def _to_wallet_out(wallet: Wallet, recent_trades: list[Trade]) -> WalletOut:
    trades_out = [
        TradeOut(
            market=t.market_name,
            side=t.side,
            size=t.size,
            time=_relative_time(t.timestamp),
            priceAtEntry=t.price,
            currentPrice=None,
        )
        for t in recent_trades
    ]
    return WalletOut(
        address=wallet.address,
        handle=wallet.handle,
        pnl=wallet.pnl,
        winRate=wallet.win_rate,
        trades=wallet.total_trades,
        avgSize=wallet.avg_size,
        age=wallet.wallet_age_days,
        categories=wallet.categories or [],
        insiderScore=wallet.insider_score,
        classification=wallet.classification,
        recentTrades=trades_out,
        isActive=wallet.is_active,
        dateAdded=wallet.date_added,
    )
