from datetime import datetime

from sqlalchemy import Index, String, func
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class Trade(Base):
    __tablename__ = "trades"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    polymarket_trade_id: Mapped[str] = mapped_column(String(100), unique=True)  # dedup key
    market_name: Mapped[str] = mapped_column(String(500))
    side: Mapped[str] = mapped_column(String(3))  # YES / NO
    size: Mapped[float] = mapped_column()  # USD value
    price: Mapped[float] = mapped_column()  # 0.0-1.0
    timestamp: Mapped[datetime] = mapped_column(index=True)
    is_first_entry: Mapped[bool] = mapped_column(default=False)
    transaction_hash: Mapped[str | None] = mapped_column(String(66))
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    __table_args__ = (Index("ix_trades_wallet_ts", "wallet_id", "timestamp"),)
