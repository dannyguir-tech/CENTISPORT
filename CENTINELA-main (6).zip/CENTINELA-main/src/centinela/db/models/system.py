"""System models — health monitoring, backfill tracking, rate limiting."""

from datetime import datetime

from sqlalchemy import String, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class SystemHealth(Base):
    """Periodic system health snapshots."""

    __tablename__ = "system_health"

    id: Mapped[int] = mapped_column(primary_key=True)
    component: Mapped[str] = mapped_column(String(50), index=True)
    status: Mapped[str] = mapped_column(String(10))  # ok/warning/error
    latency_ms: Mapped[float | None] = mapped_column()
    details: Mapped[dict] = mapped_column(JSONB, default=dict)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class BackfillLog(Base):
    """Track wallet trade history backfill progress."""

    __tablename__ = "backfill_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    trades_backfilled: Mapped[int] = mapped_column(default=0)
    oldest_trade_date: Mapped[datetime | None] = mapped_column()
    newest_trade_date: Mapped[datetime | None] = mapped_column()
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending/in_progress/complete/failed
    error_message: Mapped[str | None] = mapped_column(String(500))
    started_at: Mapped[datetime] = mapped_column(server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column()


class RateLimitLog(Base):
    """Track API rate limit events for diagnostics."""

    __tablename__ = "rate_limit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    api_source: Mapped[str] = mapped_column(String(50), index=True)  # polymarket_data/gamma/clob/kalshi
    endpoint: Mapped[str | None] = mapped_column(String(200))
    status_code: Mapped[int | None] = mapped_column()
    retry_after_seconds: Mapped[float | None] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())
