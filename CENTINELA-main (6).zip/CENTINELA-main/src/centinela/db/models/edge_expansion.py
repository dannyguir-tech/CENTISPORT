"""Phase 3: Edge Expansion models — dumb money, consensus, convergence, overcrowding."""

from datetime import datetime

from sqlalchemy import ARRAY, Index, Integer, String, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class DumbMoneyWallet(Base):
    """Dedicated dumb money wallet tracking with inverse scoring context."""

    __tablename__ = "dumb_money_wallets"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(unique=True, index=True)
    inverse_score: Mapped[float] = mapped_column(default=0.0)
    loss_rate: Mapped[float] = mapped_column(default=0.0)  # 0.0-1.0
    avg_loss_pct: Mapped[float] = mapped_column(default=0.0)
    fade_signal_count: Mapped[int] = mapped_column(default=0)
    fade_win_count: Mapped[int] = mapped_column(default=0)
    category_weaknesses: Mapped[dict] = mapped_column(JSONB, default=dict)
    last_scored_at: Mapped[datetime] = mapped_column(server_default=func.now())


class ConvergenceOpportunity(Base):
    """Pre-convergence detection: markets where convergence may form."""

    __tablename__ = "convergence_opportunities"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    market_name: Mapped[str] = mapped_column(String(500))
    smart_side: Mapped[str | None] = mapped_column(String(3))
    smart_wallet_count: Mapped[int] = mapped_column(default=0)
    dumb_side: Mapped[str | None] = mapped_column(String(3))
    dumb_wallet_count: Mapped[int] = mapped_column(default=0)
    cross_platform_gap: Mapped[float | None] = mapped_column()
    readiness_score: Mapped[float] = mapped_column(default=0.0)  # 0-100
    detected_at: Mapped[datetime] = mapped_column(server_default=func.now())


class DumbMoneySignal(Base):
    """A fade signal generated when a tracked dumb money wallet trades."""

    __tablename__ = "dumb_money_signals"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    market_name: Mapped[str] = mapped_column(String(500))
    dumb_side: Mapped[str] = mapped_column(String(3))  # what dumb money bought
    fade_side: Mapped[str] = mapped_column(String(3))  # opposite = our trade
    # 5-component fade score
    inverse_score_component: Mapped[float] = mapped_column(default=0.0)
    category_inverse_component: Mapped[float] = mapped_column(default=0.0)
    smart_confirmation_component: Mapped[float] = mapped_column(default=0.0)
    cross_platform_component: Mapped[float] = mapped_column(default=0.0)
    dumb_consensus_component: Mapped[float] = mapped_column(default=0.0)
    fade_signal_score: Mapped[float] = mapped_column(default=0.0)
    smart_money_conflict: Mapped[bool] = mapped_column(default=False)
    conflicting_wallet_ids: Mapped[list[int]] = mapped_column(ARRAY(Integer), default=list)
    suppressed: Mapped[bool] = mapped_column(default=False)
    suppress_reason: Mapped[str | None] = mapped_column(String(200))
    alert_id: Mapped[int | None] = mapped_column()
    outcome: Mapped[str | None] = mapped_column(String(10))  # win/loss/pending
    phantom_pnl: Mapped[float | None] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class ConsensusSignal(Base):
    """Consensus signal: 3+ tracked insiders on same side of a market."""

    __tablename__ = "consensus_signals"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    market_name: Mapped[str] = mapped_column(String(500))
    side: Mapped[str] = mapped_column(String(3))
    wallet_ids: Mapped[list[int]] = mapped_column(ARRAY(Integer), default=list)
    wallet_count: Mapped[int] = mapped_column()
    combined_score: Mapped[float] = mapped_column()
    total_capital: Mapped[float] = mapped_column(default=0.0)
    recommended_size: Mapped[float | None] = mapped_column()
    alert_id: Mapped[int | None] = mapped_column()
    outcome: Mapped[str | None] = mapped_column(String(10))
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())
    resolved_at: Mapped[datetime | None] = mapped_column()


class ConvergenceSignal(Base):
    """Convergence: smart money on one side AND dumb money on the other.
    Highest conviction signal in the system."""

    __tablename__ = "convergence_signals"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    market_name: Mapped[str] = mapped_column(String(500))
    smart_wallet_ids: Mapped[list[int]] = mapped_column(ARRAY(Integer), default=list)
    smart_side: Mapped[str] = mapped_column(String(3))
    smart_combined_score: Mapped[float] = mapped_column()
    dumb_wallet_ids: Mapped[list[int]] = mapped_column(ARRAY(Integer), default=list)
    dumb_side: Mapped[str] = mapped_column(String(3))
    dumb_combined_inverse_score: Mapped[float] = mapped_column()
    cross_platform_gap: Mapped[float | None] = mapped_column()
    total_edge_sources: Mapped[int] = mapped_column(default=2)  # smart+dumb, +xplat
    alert_id: Mapped[int | None] = mapped_column()
    outcome: Mapped[str | None] = mapped_column(String(10))
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class OvercrowdingMetric(Base):
    """Track how fast price reacts after a wallet trades — crowding indicator."""

    __tablename__ = "overcrowding_metrics"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    avg_price_reaction_seconds: Mapped[float] = mapped_column()  # time for 3% move after entry
    prev_reaction_seconds: Mapped[float | None] = mapped_column()  # last measurement
    trend_direction: Mapped[str | None] = mapped_column(String(15))  # improving/stable/worsening
    score_penalty: Mapped[float] = mapped_column(default=0.0)  # 0-25 point deduction
    measured_at: Mapped[datetime] = mapped_column(server_default=func.now())
