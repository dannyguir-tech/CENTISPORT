from datetime import datetime

from sqlalchemy import ARRAY, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class Wallet(Base):
    __tablename__ = "wallets"

    id: Mapped[int] = mapped_column(primary_key=True)
    address: Mapped[str] = mapped_column(String(42), unique=True, index=True)
    handle: Mapped[str | None] = mapped_column(String(100))
    insider_score: Mapped[float] = mapped_column(default=0.0)
    inverse_score: Mapped[float] = mapped_column(default=0.0)  # Phase 3: dumb money score
    classification: Mapped[str | None] = mapped_column(String(20))  # sniper/momentum/market_maker/hedger/noise/dumb_money
    wallet_type: Mapped[str] = mapped_column(String(10), default="smart")  # smart/dumb/neutral
    categories: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    category_win_rates: Mapped[dict] = mapped_column(JSONB, default=dict)  # {"Politics": 0.72, "Crypto": 0.18}
    notes: Mapped[str | None] = mapped_column()
    is_active: Mapped[bool] = mapped_column(default=True)
    wash_suspected: Mapped[bool] = mapped_column(default=False)
    crowding_score: Mapped[float] = mapped_column(default=0.0)
    edge_retention_avg: Mapped[float | None] = mapped_column()
    date_added: Mapped[datetime] = mapped_column(server_default=func.now())
    last_trade_at: Mapped[datetime | None] = mapped_column()

    # Denormalized stats (recomputed by scoring engine)
    pnl: Mapped[float] = mapped_column(default=0.0)
    win_rate: Mapped[float] = mapped_column(default=0.0)  # 0.0-1.0
    total_trades: Mapped[int] = mapped_column(default=0)
    avg_size: Mapped[float] = mapped_column(default=0.0)
    wallet_age_days: Mapped[int] = mapped_column(default=0)


class WalletScoreHistory(Base):
    __tablename__ = "wallet_scores_history"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    score: Mapped[float] = mapped_column()
    inverse_score: Mapped[float] = mapped_column(default=0.0)
    component_scores: Mapped[dict] = mapped_column(JSONB, default=dict)
    classification: Mapped[str | None] = mapped_column(String(20))
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())

    __table_args__ = (Index("ix_score_history_wallet_ts", "wallet_id", "timestamp"),)
