from datetime import datetime

from sqlalchemy import String, func
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class Market(Base):
    __tablename__ = "markets"

    id: Mapped[int] = mapped_column(primary_key=True)
    polymarket_id: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    gamma_id: Mapped[str | None] = mapped_column(String(100))
    question: Mapped[str] = mapped_column(String(1000))
    category: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20), default="active")  # active/resolved/closed
    resolution_date: Mapped[datetime | None] = mapped_column()
    resolution_outcome: Mapped[str | None] = mapped_column(String(10))
    odds_yes: Mapped[float | None] = mapped_column()
    odds_no: Mapped[float | None] = mapped_column()
    daily_volume: Mapped[float | None] = mapped_column()
    spread: Mapped[float | None] = mapped_column()
    liquidity_grade: Mapped[str | None] = mapped_column(String(1))  # A/B/C/D/F
    token_id_yes: Mapped[str | None] = mapped_column(String(100))
    token_id_no: Mapped[str | None] = mapped_column(String(100))
    last_synced_at: Mapped[datetime | None] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
