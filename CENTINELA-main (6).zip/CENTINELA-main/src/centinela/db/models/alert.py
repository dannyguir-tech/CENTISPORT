from datetime import datetime

from sqlalchemy import Boolean, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(30))  # insider/cross_platform/consensus/convergence/exit/tp/sl/lockout/state_change
    priority: Mapped[str] = mapped_column(String(10))  # critical/high/standard/info
    wallet_id: Mapped[int | None] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    signal_side: Mapped[str | None] = mapped_column(String(3))
    signal_score: Mapped[float | None] = mapped_column()
    message: Mapped[str] = mapped_column(Text)
    sent_at: Mapped[datetime] = mapped_column(server_default=func.now())
    telegram_message_id: Mapped[int | None] = mapped_column()

    # Phase 2: execution tracking
    was_taken: Mapped[bool | None] = mapped_column(Boolean, default=None)
    take_reason: Mapped[str | None] = mapped_column(String(200))
    skip_reason: Mapped[str | None] = mapped_column(String(200))
    conviction_level: Mapped[int | None] = mapped_column()  # 1-5 from user reply
    chase_risk_triggered: Mapped[bool] = mapped_column(default=False)
    decision_output: Mapped[str | None] = mapped_column(String(10))  # execute/skip/wait
    recommended_size: Mapped[float | None] = mapped_column()
    edge_retention_pct: Mapped[float | None] = mapped_column()
    phantom_pnl: Mapped[float | None] = mapped_column()
    actual_pnl: Mapped[float | None] = mapped_column()
