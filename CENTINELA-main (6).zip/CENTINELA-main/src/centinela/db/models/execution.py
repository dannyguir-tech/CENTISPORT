"""Bankroll, positions, and money management models."""

from datetime import datetime

from sqlalchemy import String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class Bankroll(Base):
    __tablename__ = "bankroll"

    id: Mapped[int] = mapped_column(primary_key=True)
    total_capital: Mapped[float] = mapped_column(default=10000.0)
    deployed_capital: Mapped[float] = mapped_column(default=0.0)
    available_capital: Mapped[float] = mapped_column(default=10000.0)
    daily_pnl: Mapped[float] = mapped_column(default=0.0)
    weekly_pnl: Mapped[float] = mapped_column(default=0.0)
    daily_loss_limit: Mapped[float] = mapped_column(default=0.05)  # 5%
    weekly_loss_limit: Mapped[float] = mapped_column(default=0.10)  # 10%
    max_per_market_pct: Mapped[float] = mapped_column(default=0.05)  # 5%
    max_per_category_pct: Mapped[float] = mapped_column(default=0.30)  # 30%
    max_concurrent_positions: Mapped[int] = mapped_column(default=12)
    is_locked_out: Mapped[bool] = mapped_column(default=False)
    lockout_until: Mapped[datetime | None] = mapped_column()
    lockout_reason: Mapped[str | None] = mapped_column(String(200))
    strategy_state: Mapped[str] = mapped_column(String(10), default="green")  # green/yellow/red
    kelly_fraction: Mapped[float] = mapped_column(default=0.25)  # quarter Kelly
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())


class Position(Base):
    __tablename__ = "positions"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int | None] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column(index=True)
    wallet_id: Mapped[int | None] = mapped_column()  # which insider we copied
    market_name: Mapped[str] = mapped_column(String(500))
    side: Mapped[str] = mapped_column(String(3))  # YES/NO
    size: Mapped[float] = mapped_column()  # initial USD size
    current_size: Mapped[float] = mapped_column()  # may be partial after TP1
    entry_price: Mapped[float] = mapped_column()
    current_price: Mapped[float | None] = mapped_column()
    unrealized_pnl: Mapped[float] = mapped_column(default=0.0)
    pnl_pct: Mapped[float] = mapped_column(default=0.0)
    resolution_date: Mapped[datetime | None] = mapped_column()
    tp1_price: Mapped[float | None] = mapped_column()  # +20% from entry
    tp2_price: Mapped[float | None] = mapped_column()  # +35% from entry
    sl_conditional_price: Mapped[float | None] = mapped_column()  # -15% if insider exited
    sl_hard_price: Mapped[float | None] = mapped_column()  # -30% hard floor
    time_entered: Mapped[datetime] = mapped_column(server_default=func.now())
    last_updated: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())
    category: Mapped[str | None] = mapped_column(String(100))
    signal_source: Mapped[str | None] = mapped_column(String(30))  # insider/consensus/cross_platform
    insider_still_holds: Mapped[bool] = mapped_column(default=True)
    build_phase: Mapped[str] = mapped_column(String(10), default="100%")  # 50%/100%
    status: Mapped[str] = mapped_column(String(10), default="open")  # open/partial/closed
    exit_price: Mapped[float | None] = mapped_column()
    realized_pnl: Mapped[float | None] = mapped_column()
    conviction_level: Mapped[int | None] = mapped_column()  # 1-5 from user reply
    journal_pre: Mapped[str | None] = mapped_column(Text)
    journal_post: Mapped[str | None] = mapped_column(Text)


class EntryQuality(Base):
    __tablename__ = "entry_quality"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int] = mapped_column(index=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column()
    insider_entry_price: Mapped[float] = mapped_column()
    alert_price: Mapped[float] = mapped_column()  # price when alert generated
    estimated_user_entry: Mapped[float | None] = mapped_column()  # price 2min after alert
    price_after_60s: Mapped[float | None] = mapped_column()
    price_after_5m: Mapped[float | None] = mapped_column()
    price_at_resolution: Mapped[float | None] = mapped_column()
    edge_retention_pct: Mapped[float | None] = mapped_column()
    slippage_actual: Mapped[float | None] = mapped_column()
    chase_risk_value: Mapped[float | None] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class SignalExpiration(Base):
    __tablename__ = "signal_expirations"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int | None] = mapped_column(index=True)
    reason: Mapped[str] = mapped_column(String(30))  # chase/liquidity/slippage/timeout/wait_expired
    insider_price: Mapped[float] = mapped_column()
    expiration_price: Mapped[float] = mapped_column()
    price_move_pct: Mapped[float] = mapped_column()
    market_name: Mapped[str | None] = mapped_column(String(500))
    wallet_handle: Mapped[str | None] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class MyTrade(Base):
    """Tracks user's actual executed trades (manual or auto)."""

    __tablename__ = "my_trades"

    id: Mapped[int] = mapped_column(primary_key=True)
    position_id: Mapped[int | None] = mapped_column(index=True)
    alert_id: Mapped[int | None] = mapped_column(index=True)
    market_name: Mapped[str] = mapped_column(String(500))
    side: Mapped[str] = mapped_column(String(3))  # YES/NO
    size: Mapped[float] = mapped_column()
    price: Mapped[float] = mapped_column()
    action: Mapped[str] = mapped_column(String(10))  # buy/sell
    conviction: Mapped[int | None] = mapped_column()  # 1-5
    notes: Mapped[str | None] = mapped_column(Text)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class DecisionLog(Base):
    __tablename__ = "decision_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int | None] = mapped_column(index=True)
    wallet_id: Mapped[int | None] = mapped_column()
    market_name: Mapped[str | None] = mapped_column(String(500))
    step_reached: Mapped[str] = mapped_column(String(20))  # status/liquidity/slippage/wallet_quality/portfolio/correlation
    step_result: Mapped[str] = mapped_column(String(10))  # pass/fail
    fail_reason: Mapped[str | None] = mapped_column(String(500))
    final_output: Mapped[str] = mapped_column(String(10))  # execute/skip/wait
    recommended_size: Mapped[float | None] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())
