"""Phase 4: Refinement + Quant Foundation models."""

from datetime import datetime

from sqlalchemy import ARRAY, Index, Integer, String, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class EdgeMonitoring(Base):
    """Rolling strategy-level metrics for GREEN/YELLOW/RED state."""

    __tablename__ = "edge_monitoring"

    id: Mapped[int] = mapped_column(primary_key=True)
    rolling_30d_pnl: Mapped[float] = mapped_column(default=0.0)
    rolling_30d_pnl_peak: Mapped[float] = mapped_column(default=0.0)
    avg_edge_per_trade: Mapped[float] = mapped_column(default=0.0)
    avg_slippage: Mapped[float] = mapped_column(default=0.0)
    win_rate: Mapped[float] = mapped_column(default=0.0)
    win_rate_by_signal_type: Mapped[dict] = mapped_column(JSONB, default=dict)
    strategy_state: Mapped[str] = mapped_column(String(10), default="green")
    prev_state: Mapped[str | None] = mapped_column(String(10))
    position_size_multiplier: Mapped[float] = mapped_column(default=1.0)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class ShadowTracking(Base):
    """Track outcome of every signal — taken or skipped — for phantom PnL."""

    __tablename__ = "shadow_tracking"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int] = mapped_column(index=True)
    signal_type: Mapped[str] = mapped_column(String(30))
    was_taken: Mapped[bool | None] = mapped_column()
    skip_reason: Mapped[str | None] = mapped_column(String(200))
    phantom_pnl: Mapped[float | None] = mapped_column()  # what would have happened
    actual_pnl: Mapped[float | None] = mapped_column()  # what actually happened
    missed_opportunity: Mapped[float | None] = mapped_column()  # positive = you missed profit
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class ScoringCalibration(Base):
    """Weight history for scoring engine recalibration."""

    __tablename__ = "scoring_calibrations"

    id: Mapped[int] = mapped_column(primary_key=True)
    old_weights: Mapped[dict] = mapped_column(JSONB)
    new_weights: Mapped[dict] = mapped_column(JSONB)
    correlation_data: Mapped[dict] = mapped_column(JSONB, default=dict)
    calibrated_at: Mapped[datetime] = mapped_column(server_default=func.now())


class DiscoveryCandidate(Base):
    """Auto-discovered wallet candidates from leaderboard scanning."""

    __tablename__ = "discovery_candidates"

    id: Mapped[int] = mapped_column(primary_key=True)
    address: Mapped[str] = mapped_column(String(42), index=True)
    handle: Mapped[str | None] = mapped_column(String(100))
    auto_score: Mapped[float] = mapped_column(default=0.0)
    inverse_score: Mapped[float] = mapped_column(default=0.0)
    classification: Mapped[str | None] = mapped_column(String(20))
    wallet_type_suggestion: Mapped[str] = mapped_column(String(10), default="smart")
    score_breakdown: Mapped[dict] = mapped_column(JSONB, default=dict)
    backtest_pnl: Mapped[float | None] = mapped_column()
    backtest_fade_pnl: Mapped[float | None] = mapped_column()
    status: Mapped[str] = mapped_column(String(10), default="pending")  # pending/approved/rejected
    discovered_at: Mapped[datetime] = mapped_column(server_default=func.now())


class WalletCluster(Base):
    """Cluster membership for wallet syndicate detection (Module 2)."""

    __tablename__ = "wallet_clusters"

    id: Mapped[int] = mapped_column(primary_key=True)
    cluster_id: Mapped[int] = mapped_column(index=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    cluster_confidence: Mapped[float] = mapped_column()
    pair_scores: Mapped[dict] = mapped_column(JSONB, default=dict)
    joined_at: Mapped[datetime] = mapped_column(server_default=func.now())


class ClusterPair(Base):
    """Pairwise link scores between wallets (Module 2)."""

    __tablename__ = "cluster_pairs"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_a_id: Mapped[int] = mapped_column(index=True)
    wallet_b_id: Mapped[int] = mapped_column(index=True)
    pair_link_score: Mapped[float] = mapped_column()
    pair_confidence: Mapped[float] = mapped_column()
    co_market_rate: Mapped[float] = mapped_column(default=0.0)
    same_side_rate: Mapped[float] = mapped_column(default=0.0)
    timing_corr: Mapped[float] = mapped_column(default=0.0)
    size_similarity: Mapped[float] = mapped_column(default=0.0)
    repeat_pair_rate: Mapped[float] = mapped_column(default=0.0)
    n_shared_events: Mapped[int] = mapped_column(default=0)
    last_calculated: Mapped[datetime] = mapped_column(server_default=func.now())

    __table_args__ = (Index("ix_cluster_pair_ab", "wallet_a_id", "wallet_b_id"),)


class CopyabilityMetric(Base):
    """Time-to-move copyability scores per wallet (Module 3)."""

    __tablename__ = "copyability_metrics"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(unique=True, index=True)
    t3_median: Mapped[float | None] = mapped_column()   # seconds to 3% move
    t5_median: Mapped[float | None] = mapped_column()   # seconds to 5% move
    t10_median: Mapped[float | None] = mapped_column()  # seconds to 10% move
    edge_retention: Mapped[float | None] = mapped_column()
    cv_t5: Mapped[float | None] = mapped_column()
    stability: Mapped[float | None] = mapped_column()
    copyability_raw: Mapped[float | None] = mapped_column()
    copyability_score: Mapped[float] = mapped_column(default=50.0)
    n_signals_evaluated: Mapped[int] = mapped_column(default=0)
    last_calculated: Mapped[datetime] = mapped_column(server_default=func.now())


class LeaderMetric(Base):
    """Leader vs follower classification per wallet (Module 6)."""

    __tablename__ = "leader_metrics"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(unique=True, index=True)
    leader_events: Mapped[int] = mapped_column(default=0)
    follower_events: Mapped[int] = mapped_column(default=0)
    avg_follow_quality: Mapped[float] = mapped_column(default=0.0)
    median_lead_time_min: Mapped[float | None] = mapped_column()
    leader_score: Mapped[float] = mapped_column(default=50.0)
    last_calculated: Mapped[datetime] = mapped_column(server_default=func.now())


class PerformanceReport(Base):
    """Weekly/monthly performance report snapshots."""

    __tablename__ = "performance_reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    report_type: Mapped[str] = mapped_column(String(10))  # weekly/monthly
    period_start: Mapped[datetime] = mapped_column()
    period_end: Mapped[datetime] = mapped_column()
    total_pnl: Mapped[float] = mapped_column(default=0.0)
    win_rate: Mapped[float] = mapped_column(default=0.0)
    total_trades: Mapped[int] = mapped_column(default=0)
    best_trade_pnl: Mapped[float | None] = mapped_column()
    worst_trade_pnl: Mapped[float | None] = mapped_column()
    avg_edge_per_trade: Mapped[float | None] = mapped_column()
    by_signal_type: Mapped[dict] = mapped_column(JSONB, default=dict)
    by_category: Mapped[dict] = mapped_column(JSONB, default=dict)
    generated_at: Mapped[datetime] = mapped_column(server_default=func.now())
