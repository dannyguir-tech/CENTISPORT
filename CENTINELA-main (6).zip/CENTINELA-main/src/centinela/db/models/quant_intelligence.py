"""Phase 5: Quant Intelligence models — intent, regime, pre-signal, trap, polling."""

from datetime import datetime

from sqlalchemy import String, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class TradeIntent(Base):
    """Module 1: Per-trade intent classification."""

    __tablename__ = "trade_intents"

    id: Mapped[int] = mapped_column(primary_key=True)
    trade_id: Mapped[int] = mapped_column(index=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    market_id: Mapped[int | None] = mapped_column()
    intent_type: Mapped[str] = mapped_column(String(25))  # informational/position_building/momentum/hedging/liquidity_provision/exit_liquidity
    confidence: Mapped[float] = mapped_column()  # 0-1
    raw_scores: Mapped[dict] = mapped_column(JSONB)  # {informational: 0.8, hedging: 0.2, ...}
    intent_multiplier: Mapped[float] = mapped_column()  # 1.25/1.10/0.80/0.35/0.50/0.40
    features: Mapped[dict] = mapped_column(JSONB, default=dict)  # {z_size, post_move, spread_cross, ...}
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class MarketRegime(Base):
    """Module 7: Per-market regime classification."""

    __tablename__ = "market_regimes"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int] = mapped_column(index=True)
    regime_label: Mapped[str] = mapped_column(String(20))  # high_vol/low_vol/trending/manipulated
    regime_confidence: Mapped[float] = mapped_column()
    raw_scores: Mapped[dict] = mapped_column(JSONB)  # {high_vol: 0.7, low_vol: 0.1, ...}
    rv: Mapped[float | None] = mapped_column()
    spread_med: Mapped[float | None] = mapped_column()
    depth_instability: Mapped[float | None] = mapped_column()
    vol_spike: Mapped[float | None] = mapped_column()
    directional_drift: Mapped[float | None] = mapped_column()
    # Regime-based adjustments
    chase_multiplier: Mapped[float] = mapped_column(default=1.0)
    position_multiplier: Mapped[float] = mapped_column(default=1.0)
    min_score_adjustment: Mapped[int] = mapped_column(default=0)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class RegimeBaseline(Base):
    """Module 7: Historical baselines per category for z-score normalization."""

    __tablename__ = "regime_baselines"

    id: Mapped[int] = mapped_column(primary_key=True)
    category: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    rv_mu: Mapped[float] = mapped_column(default=0.0)
    rv_sigma: Mapped[float] = mapped_column(default=1.0)
    spread_mu: Mapped[float] = mapped_column(default=0.0)
    spread_sigma: Mapped[float] = mapped_column(default=1.0)
    depth_mu: Mapped[float] = mapped_column(default=0.0)
    depth_sigma: Mapped[float] = mapped_column(default=1.0)
    vol_mu: Mapped[float] = mapped_column(default=1.0)
    vol_sigma: Mapped[float] = mapped_column(default=1.0)
    sample_size: Mapped[int] = mapped_column(default=0)
    last_updated: Mapped[datetime] = mapped_column(server_default=func.now())


class PreSignalFlag(Base):
    """Module 4: Pre-position detection early warning flags."""

    __tablename__ = "pre_signal_flags"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int] = mapped_column(index=True)
    market_name: Mapped[str | None] = mapped_column(String(500))
    pre_signal_confidence: Mapped[float] = mapped_column()
    liq_growth: Mapped[float | None] = mapped_column()
    spread_tightening: Mapped[float | None] = mapped_column()
    vol_growth: Mapped[float | None] = mapped_column()
    price_drift: Mapped[float | None] = mapped_column()
    related_smart_activity: Mapped[float | None] = mapped_column()
    flagged_at: Mapped[datetime] = mapped_column(server_default=func.now())
    insider_entered_after: Mapped[bool] = mapped_column(default=False)
    insider_entry_delay_minutes: Mapped[float | None] = mapped_column()
    was_useful: Mapped[bool | None] = mapped_column()


class TrapRiskEvent(Base):
    """Module 5: Liquidity trap detection events."""

    __tablename__ = "trap_risk_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int | None] = mapped_column(index=True)
    trade_id: Mapped[int | None] = mapped_column()
    market_id: Mapped[int | None] = mapped_column()
    trap_risk_score: Mapped[float] = mapped_column()
    weak_bids: Mapped[float] = mapped_column(default=0.0)
    heavy_asks: Mapped[float] = mapped_column(default=0.0)
    wide_spread: Mapped[float] = mapped_column(default=0.0)
    price_pop: Mapped[float] = mapped_column(default=0.0)
    reversal_3m: Mapped[float] = mapped_column(default=0.0)
    insider_inv_reduction: Mapped[float] = mapped_column(default=0.0)
    action_taken: Mapped[str] = mapped_column(String(15), default="none")  # invalidated/reduced/deducted/none
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class PollPriority(Base):
    """Module 8: Adaptive polling tier per market."""

    __tablename__ = "poll_priority"

    id: Mapped[int] = mapped_column(primary_key=True)
    market_id: Mapped[int] = mapped_column(unique=True, index=True)
    poll_priority_score: Mapped[float] = mapped_column(default=0.0)
    polling_tier: Mapped[int] = mapped_column(default=4)  # 1/2/3/4
    poll_interval_seconds: Mapped[int] = mapped_column(default=60)
    last_updated: Mapped[datetime] = mapped_column(server_default=func.now())


class DetectionHealth(Base):
    """Module 8: System detection confidence metric."""

    __tablename__ = "detection_health"

    id: Mapped[int] = mapped_column(primary_key=True)
    websocket_alive: Mapped[bool] = mapped_column(default=False)
    polling_freshness: Mapped[float] = mapped_column(default=1.0)
    source_redundancy: Mapped[float] = mapped_column(default=0.6)
    detection_confidence: Mapped[float] = mapped_column(default=0.6)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())


class FundingEvent(Base):
    """Funding intelligence events — new wallet bursts, coordinated market bursts."""

    __tablename__ = "funding_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    wallet_id: Mapped[int] = mapped_column(index=True)
    event_type: Mapped[str] = mapped_column(String(40), index=True)  # new_wallet_burst / coordinated_market_burst
    severity: Mapped[str] = mapped_column(String(10), default="info")  # info / warning / critical
    details: Mapped[dict] = mapped_column(JSONB, default=dict)
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())
