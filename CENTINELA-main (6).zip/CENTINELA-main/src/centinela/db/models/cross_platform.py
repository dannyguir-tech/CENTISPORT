from datetime import datetime

from sqlalchemy import Index, String, func
from sqlalchemy.orm import Mapped, mapped_column

from centinela.db.base import Base


class CrossPlatformMarket(Base):
    __tablename__ = "cross_platform_markets"

    id: Mapped[int] = mapped_column(primary_key=True)
    polymarket_market_id: Mapped[int] = mapped_column(index=True)
    kalshi_ticker: Mapped[str] = mapped_column(String(100))
    kalshi_title: Mapped[str] = mapped_column(String(500))
    match_confidence: Mapped[float] = mapped_column(default=1.0)
    is_active: Mapped[bool] = mapped_column(default=True)
    matched_at: Mapped[datetime] = mapped_column(server_default=func.now())


class CrossPlatformPrice(Base):
    __tablename__ = "cross_platform_prices"

    id: Mapped[int] = mapped_column(primary_key=True)
    cross_platform_market_id: Mapped[int] = mapped_column(index=True)
    polymarket_price: Mapped[float] = mapped_column()
    kalshi_price: Mapped[float] = mapped_column()
    price_gap: Mapped[float] = mapped_column()  # abs(poly - kalshi) * 100 as points
    timestamp: Mapped[datetime] = mapped_column(server_default=func.now())

    __table_args__ = (
        Index("ix_xplat_prices_market_ts", "cross_platform_market_id", "timestamp"),
    )
