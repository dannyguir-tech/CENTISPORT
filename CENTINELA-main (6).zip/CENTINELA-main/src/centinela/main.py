from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from centinela.api.router import api_router
from centinela.config import settings

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("centinela.starting", msg="CENTINELA is waking up...")

    # Initialize Telegram bot (if configured)
    from centinela.services.telegram_bot import init_bot, shutdown_bot

    await init_bot()

    # Start background scheduler
    from centinela.tasks.scheduler import setup_scheduler

    sched = setup_scheduler()
    sched.start()
    logger.info("centinela.scheduler_started")

    # Start WebSocket price feed (subscribes to token_ids from open positions + active markets)
    from centinela.clients.polymarket_ws import polymarket_ws
    from centinela.db.session import async_session
    from centinela.db.models.execution import Position
    from centinela.db.models.market import Market
    from sqlalchemy import select

    token_ids: list[str] = []
    async with async_session() as session:
        try:
            # Priority 1: tokens for open positions
            pos_result = await session.execute(
                select(Position).where(Position.status.in_(["open", "partial"]))
            )
            positions = list(pos_result.scalars().all())
            for pos in positions:
                if pos.market_id:
                    mkt_row = await session.execute(
                        select(Market).where(Market.id == pos.market_id)
                    )
                    mkt = mkt_row.scalar_one_or_none()
                    if mkt:
                        tid = mkt.token_id_yes if pos.side == "YES" else mkt.token_id_no
                        if tid and tid not in token_ids:
                            token_ids.append(tid)

            # Priority 2: active markets (fill remaining slots, max 10 total)
            if len(token_ids) < 10:
                mkt_result = await session.execute(
                    select(Market).where(Market.status == "active").limit(10)
                )
                for mkt in mkt_result.scalars().all():
                    for tid in (mkt.token_id_yes, mkt.token_id_no):
                        if tid and tid not in token_ids and len(token_ids) < 10:
                            token_ids.append(tid)
        except Exception as e:
            logger.warning("ws.startup_token_fetch_failed", error=str(e))

    if token_ids:
        await polymarket_ws.start_background(token_ids)
        logger.info("centinela.ws_started", tokens=len(token_ids))
    else:
        logger.info("centinela.ws_skipped", reason="no_tokens")

    # Send startup message
    if settings.telegram_enabled:
        from centinela.services.telegram_bot import send_message

        await send_message(
            "\u2705 CENTINELA ONLINE \u2014 The Watchman is awake.\n"
            "Trade polling, scoring, and position monitoring active."
        )

    yield

    await polymarket_ws.disconnect()
    sched.shutdown(wait=False)
    await shutdown_bot()
    logger.info("centinela.shutdown", msg="CENTINELA shutting down.")


app = FastAPI(
    title="CENTINELA",
    description="The Watchman Sees Everything",
    version="0.2.0",
    lifespan=lifespan,
)

# CORS: wildcard origin + credentials is rejected by browsers per spec.
# Use explicit allowed origins when credentials are needed; default to
# wildcard + no credentials for dev (no cookies / auth headers yet).
_cors_origins = [o.strip() for o in (getattr(settings, "cors_origins", "") or "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
else:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,  # spec-compliant with wildcard
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(api_router, prefix="/api")


@app.get("/health")
async def health():
    return {"status": "ok", "service": "centinela", "version": "0.2.0"}
