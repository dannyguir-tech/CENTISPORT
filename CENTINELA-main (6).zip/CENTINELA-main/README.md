# CENTINELA

### "The Watchman Sees Everything"

**Personal Polymarket insider detection and copy-trade signal system.**

Single user. Personal tool. No auth. No billing. No onboarding. Manual trading only — the system recommends, I execute.

---

## Overview

Centinela tracks Polymarket wallets, detects insider patterns, scores traders by copyability, and sends real-time Telegram alerts so I can manually copy trade. It also tracks and fades dumb-money wallets, detects cross-platform divergence against Kalshi, and runs a full quant intelligence layer on top of the core signal stack.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Python 3.12, FastAPI |
| Database | PostgreSQL (SQLAlchemy async + Alembic) |
| Cache / Queue | Redis |
| Frontend | React (dark terminal aesthetic) |
| Alerts | Telegram Bot API (primary), Discord webhook (backup) |
| Scheduler | APScheduler (19 background jobs) |
| Deployment | Docker Compose |
| SDK | `polymarket-apis` (unified wrapper for Gamma + CLOB + Data APIs) |

---

## Signal Flow (7-step waterfall)

Every trade signal passes through the decision engine. Failure at any step kills the signal.

```
Step 1  CHECK STATUS        — signal not expired, chase risk not triggered
Step 2  CHECK LIQUIDITY     — market_liquidity >= max(10_000, position_size × 10)
Step 3  CHECK SLIPPAGE      — estimated_slippage <= 2%
Step 4  CHECK TRAP RISK     — invalidate / reduce / deduct based on trap score
Step 5  CHECK WALLET QUALITY— score thresholds by signal type
Step 6  CHECK PORTFOLIO     — positions, exposure, lockout, strategy state
Step 7  CHECK CORRELATION   — warn if category concentration high

Output: EXECUTE | SKIP | WAIT
```

---

## Edge Stack

Five independent edge sources that compound together:

1. **Insider signals** — copy smart money (scored, classified, filtered)
2. **Dumb money fading** — bet against confirmed losing wallets
3. **Convergence** — smart money on one side AND dumb money on the other (highest conviction)
4. **Cross-platform divergence** — Polymarket vs Kalshi gap ≥ 10 points (pure math, no speed required)
5. **Money management** — quarter Kelly, daily/weekly loss lockout, strategy state circuit breaker

---

## Database

**38 models across 11 files**

### Core
- `wallet.py` — wallets, wallet_scores_history
- `trade.py` — trades
- `market.py` — markets, market_liquidity

### Signals & Alerts
- `alert.py` — alerts, consensus_signals, convergence_signals, signal_expirations, decision_log

### Execution Quality
*(entry_quality, signal_expirations, decision_log — all in alert.py)*

### Money Management
- `execution.py` — bankroll, positions, my_trades, entry_quality, decisions

### Dumb Money
- `edge_expansion.py` — dumb_money_wallets, dumb_money_signals, convergence_opportunities, consensus, overcrowding

### Quantitative
- `quant.py` — edge_monitoring, shadow_tracking, calibration, clusters, copyability, leader_metrics, performance_reports
- `quant_intelligence.py` — trade_intents, market_regimes, regime_baselines, pre_signal_flags, trap_risk_events, poll_priority, detection_health

### Cross-Platform
- `cross_platform.py` — cross_platform_markets, cross_platform_prices

### Tracking
- `quant.py` also contains — shadow_tracking, edge_monitoring, performance_reports

### System
- `system.py` — system_health, backfill_log, rate_limit_log

**Model files:**
```
src/centinela/db/models/
├── wallet.py
├── trade.py
├── market.py
├── alert.py
├── edge_expansion.py     (dumb money wallets/signals, convergence, consensus, overcrowding)
├── execution.py          (bankroll, positions, my_trades, entry_quality, decisions)
├── cross_platform.py     (cross-platform markets + prices)
├── quant.py              (edge monitoring, shadow, calibration, clusters, copyability, leader, reports)
├── quant_intelligence.py (trade intents, regime, baselines, pre-signal, trap, polling, detection health)
└── system.py             (system health, backfill log, rate limits)
```

---

## API Routers

**12 FastAPI routers in `src/centinela/api/`**

```
src/centinela/api/
├── alerts.py
├── bankroll.py
├── cross_platform.py
├── edge_expansion.py
├── markets.py
├── metrics.py
├── operations.py
├── quant.py
├── quant_intelligence.py
├── router.py
├── trades.py
└── wallets.py
```

---

## Scheduler

**19 scheduled background jobs:**

| Job | Interval |
|---|---|
| `trade_poll` | configurable |
| `health_check` | configurable |
| `market_sync` | configurable |
| `score_recalc` | configurable |
| `kalshi_poll` | configurable |
| `position_check` | configurable |
| `consensus_scan` | 60 s |
| `dumb_money_scoring` | 6 h |
| `wash_trade_scan` | daily |
| `edge_monitoring` | 1 h |
| `scoring_calibration` | 4 weeks |
| `wallet_discovery` | weekly |
| `cluster_detection` | daily |
| `leader_detection` | 6 h |
| `position_building` | 5 min |
| `regime_detection` | 5 min |
| `adaptive_polling` | 5 min |
| `weekly_report` | Monday 08:00 |
| `monthly_report` | 1st of month 08:00 |

---

## Project Structure

```
CENTINELA/
├── src/centinela/
│   ├── api/                         # 12 FastAPI routers (no routers/ subdirectory)
│   │   ├── alerts.py
│   │   ├── bankroll.py
│   │   ├── cross_platform.py
│   │   ├── edge_expansion.py
│   │   ├── markets.py
│   │   ├── metrics.py
│   │   ├── operations.py
│   │   ├── quant.py
│   │   ├── quant_intelligence.py
│   │   ├── router.py
│   │   ├── trades.py
│   │   └── wallets.py
│   ├── db/
│   │   └── models/                  # 11 model files, 38 models
│   ├── services/                    # business logic
│   │   ├── adaptive_polling.py
│   │   ├── backtest.py
│   │   ├── bankroll.py
│   │   ├── catalyst_scanner.py
│   │   ├── chase_risk.py
│   │   ├── cluster_detection.py
│   │   ├── consensus.py
│   │   ├── copyability.py
│   │   ├── decision_engine.py
│   │   ├── dumb_money.py
│   │   ├── edge_monitoring.py
│   │   ├── fade_scoring.py
│   │   ├── intent_detection.py
│   │   ├── kalshi_service.py
│   │   ├── leader_detection.py
│   │   ├── market_service.py
│   │   ├── operations.py
│   │   ├── overcrowding.py
│   │   ├── position_build.py
│   │   ├── position_building.py
│   │   ├── position_manager.py
│   │   ├── position_sizer.py
│   │   ├── pre_signal.py
│   │   ├── regime_detection.py
│   │   ├── reporting.py
│   │   ├── scoring_calibration.py
│   │   ├── scoring_engine.py
│   │   ├── shadow_tracking.py
│   │   ├── signal_pipeline.py
│   │   ├── signal_priority.py
│   │   ├── signal_throttle.py
│   │   ├── slippage.py
│   │   ├── tax_export.py
│   │   ├── telegram_bot.py
│   │   ├── trade_detector.py
│   │   ├── trap_detection.py
│   │   ├── unified_score.py
│   │   ├── wallet_discovery.py
│   │   ├── wallet_tracker.py
│   │   └── wash_trade_filter.py
│   ├── tasks/                       # APScheduler jobs
│   │   ├── scheduler.py
│   │   ├── edge_scan.py
│   │   ├── health_check.py
│   │   ├── kalshi_poll.py
│   │   ├── market_sync.py
│   │   ├── position_check.py
│   │   ├── quant_jobs.py
│   │   ├── reports.py
│   │   ├── score_recalc.py
│   │   └── trade_poll.py
│   ├── clients/                     # API clients (Gamma, CLOB, Data, Kalshi)
│   ├── schemas/                     # Pydantic schemas
│   ├── config.py
│   ├── dependencies.py
│   └── main.py
├── polyscan-v3.jsx                  # frontend reference (project root)
├── alembic/                         # DB migrations
├── docker-compose.yml
├── Dockerfile
└── pyproject.toml
```

---

## Key Formulas

### Wallet Score Integration
```
wallet_score_final = 0.80 * base + 0.10 * copyability + 0.10 * leader
```

### Unified Signal Score
```
final_signal_score = base_signal_score
    × intent_multiplier
    × (0.85 + 0.15 × copyability_score/100)
    × (0.90 + 0.10 × leader_score/100)
    × (1.00 − 0.35 × trap_risk_score/100)
    × (0.90 + 0.10 × regime_confidence)
    + pre_signal_bonus (+7 if flagged before entry)
    × cluster_adjustment (if consensus discount applies)
```

### Fade Signal Score
```
FADE_SIGNAL_SCORE =
    inverse_score     × 0.30   (overall reliability as loser)
  + category_inverse  × 0.25   (per-category inverse win rate)
  + smart_confirmation× 0.25   (insiders on OPPOSITE side?)
  + cross_platform    × 0.10   (Kalshi agrees with fade?)
  + dumb_consensus    × 0.10   (other dumb wallets same side?)
```

### Copyability Score
```
copyability_raw = 0.25×t3_norm + 0.30×t5_norm + 0.20×t10_norm
                + 0.15×edge_retention + 0.10×stability
copyability_adj = copyability_raw × (0.65 + 0.35×sample_conf(n, 40))
```

### Pair Link Score (cluster detection)
```
pair_link = 0.30×co_market_rate + 0.25×same_side_rate
          + 0.25×timing_corr + 0.10×size_similarity
          + 0.10×repeat_pair_rate
```

### Consensus Cluster Adjustment
```
effective_wallet_count = unique_clusters + 0.35×(total_wallets − unique_clusters)
consensus_cluster_adjustment = clamp(effective_wallet_count / total_wallets, 0.4, 1.0)
```

---

## Dashboard Pages (10 pages)

1. **Command Center** — bankroll, strategy state, live feed, positions, P&L, system health
2. **Smart Watchlist** — insider wallets, scores, classification, edge retention, copyability, leader badge
3. **Dumb Money Watchlist** — loser wallets, inverse scores, worst categories, fade P&L, live activity
4. **Wallet Detail** — full profile, per-category breakdown, score history, intent distribution
5. **My Positions** — live P&L, TP/SL proximity, build phase, insider-still-holds, time exit warnings
6. **Consensus & Convergence** — ranked by total edge alignment, cluster-adjusted counts
7. **Cross-Platform** — Polymarket vs Kalshi divergence history
8. **Performance** — P&L by signal type, shadow tracking, conviction analysis
9. **Market Intelligence** — regime classification, pre-signal flags, trap risk, polling tiers
10. **Settings** — all thresholds, bankroll config, scoring weights, strategy state overrides

Design: dark `#0a0a0e` / cream `#f5ebd2`. Fonts: Share Tech Mono + Outfit.
Reference: `polyscan-v3.jsx` (project root).

---

## Alert Functions

**11 alert functions across 3 priority levels** (in `services/telegram_bot.py`):

| Function | Priority |
|---|---|
| `send_lockout_alert` | critical |
| `send_state_change_alert` | critical |
| `send_convergence_alert` | critical |
| `send_insider_alert` | high / standard |
| `send_divergence_alert` | high / standard |
| `send_consensus_alert` | high |
| `send_fade_alert` | standard |
| `send_position_event` | configurable |
| `send_expired_signal` | info |
| `send_system_alert` | info |
| `send_message` | (raw) |

Priority levels used: **critical**, **high**, **standard**.

---

## Stats

| Metric | Value |
|---|---|
| Files | ~114 |
| Lines of code | ~11,900 |
| Database models | 38 |
| Dashboard pages | 10 |
| Scheduled background jobs | 19 |
| Alert functions | 11 across 3 priority levels |

---

## Build Phases

| Phase | Focus | Status |
|---|---|---|
| 0 | Paper trading infrastructure | complete |
| 1 | MVP signals (wallet tracking, WebSocket feed, insider scoring, Telegram, Kalshi) | complete |
| 2 | Execution protection (chase risk, slippage cap, bankroll, Kelly sizing, trade management) | complete |
| 3 | Edge expansion (dumb money, consensus, convergence, classification, overcrowding) | complete |
| 4 | Refinement + quant foundation (edge monitoring, clustering, copyability, leader detection) | complete |
| 5 | Quant intelligence (intent detection, regime, pre-signal, trap detection, adaptive polling) | complete |
| 6 | Scale + operations (order book intelligence, tax export, performance reports, catalyst scanner) | in progress |

---

## Deployment

```bash
docker compose up -d
```

Requires: `POSTGRES_URL`, `REDIS_URL`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `KALSHI_API_KEY` in environment or `.env`.

Alembic migrations:
```bash
alembic upgrade head
```

---

*CENTINELA — The Watchman Sees Everything.*
