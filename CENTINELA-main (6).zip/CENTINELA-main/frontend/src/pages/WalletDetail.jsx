/** Page 4: Wallet Detail — full wallet profile, stats, trades, intent distribution */
import { useState, useMemo } from "react";
import {
  C,
  fonts,
  getScoreColor,
  formatUsd,
  formatPct,
  relativeTime,
  getCatColor,
  pnlColor,
  pnlSign,
} from "../utils/theme";
import { usePolling, useApi } from "../hooks/useApi";
import {
  RingGauge,
  PillBadge,
  Sparkline,
  Panel,
  DataTable,
  MetricTile,
  Loading,
  ErrorCard,
} from "../components/shared";

/* ── intent colors ──────────────────────────────────────────────────── */
const INTENT_COLORS = {
  informational: C.green,
  position_building: C.cyan,
  momentum: C.amber,
  hedging: C.purple,
  lp: C.creamMuted,
  exit: C.red,
};

/* ── classification pill colors ─────────────────────────────────────── */
const CLASS_COLORS = {
  SNIPER: C.green,
  MOMENTUM: C.cyan,
  DUMB_MONEY: C.pink,
};

/* ── component ──────────────────────────────────────────────────────── */
export default function WalletDetail({ walletAddress, onBack }) {
  const {
    data: wallet,
    loading: wLoading,
    error: wError,
    refetch: wRefetch,
  } = useApi(walletAddress ? `/wallets/${walletAddress}` : null);

  const walletId = wallet?.id;

  const { data: trades } = useApi(
    walletId ? `/trades?wallet_id=${walletId}&limit=30` : null
  );

  const { data: intents } = useApi(
    walletId ? `/intents?wallet_id=${walletId}&limit=50` : null
  );

  /* ── intent distribution ───────────────────────────────────────── */
  const intentDist = useMemo(() => {
    if (!intents || !Array.isArray(intents) || intents.length === 0)
      return [];
    const counts = {};
    intents.forEach((i) => {
      const t = i.intent_type || i.intentType || "unknown";
      counts[t] = (counts[t] || 0) + 1;
    });
    const maxCount = Math.max(...Object.values(counts), 1);
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([type, count]) => ({
        type,
        count,
        pct: count / maxCount,
        color: INTENT_COLORS[type] || C.creamMuted,
      }));
  }, [intents]);

  /* ── derived wallet fields ─────────────────────────────────────── */
  const isDumb =
    wallet &&
    (wallet.wallet_type === "dumb" ||
      wallet.classification === "DUMB_MONEY");

  const score = wallet
    ? isDumb
      ? wallet.inverseScore ?? wallet.inverse_score ?? 0
      : wallet.insiderScore ?? wallet.insider_score ?? 0
    : 0;

  const classification = wallet?.classification || "UNKNOWN";
  const classColor = CLASS_COLORS[classification] || C.creamMuted;
  const handle = wallet?.handle || walletAddress?.slice(0, 10) || "\u2014";
  const addr = wallet?.address || walletAddress || "";
  const truncAddr =
    addr.length > 16 ? `${addr.slice(0, 8)}...${addr.slice(-6)}` : addr;

  /* ── loading / error states ────────────────────────────────────── */
  if (!walletAddress) {
    return (
      <div
        style={{
          padding: 40,
          textAlign: "center",
          color: C.creamMuted,
          fontFamily: fonts.mono,
        }}
      >
        No wallet selected
      </div>
    );
  }

  if (wLoading && !wallet) return <Loading />;
  if (wError && !wallet)
    return (
      <div>
        <BackButton onBack={onBack} />
        <ErrorCard message={wError} onRetry={wRefetch} />
      </div>
    );

  if (!wallet) return <Loading />;

  /* ── render ────────────────────────────────────────────────────── */
  return (
    <div>
      {/* ── Back button ────────────────────────────────────────── */}
      <BackButton onBack={onBack} />

      {/* ── Header ─────────────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 18,
          marginBottom: 24,
          padding: "18px 20px",
          background: C.card,
          border: `1px solid ${C.border}`,
          borderRadius: 10,
        }}
      >
        <RingGauge
          value={score}
          size={64}
          color={isDumb ? C.pink : getScoreColor(score)}
          label={String(Math.round(score))}
        />
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span
              style={{
                fontFamily: fonts.sans,
                fontSize: 22,
                fontWeight: 700,
                color: C.cream,
              }}
            >
              {handle}
            </span>
            <PillBadge text={classification} color={classColor} />
            {isDumb && <PillBadge text="DUMB MONEY" color={C.pink} />}
          </div>
          <div
            style={{
              fontFamily: fonts.mono,
              fontSize: 11,
              color: C.creamMuted,
              marginTop: 4,
              letterSpacing: 0.5,
            }}
          >
            {truncAddr}
          </div>
          {wallet.categories && wallet.categories.length > 0 && (
            <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
              {wallet.categories.map((cat) => (
                <PillBadge
                  key={cat}
                  text={cat}
                  color={getCatColor(cat)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Stats grid (8 MetricTiles) ─────────────────────────── */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 10,
          marginBottom: 20,
        }}
      >
        <MetricTile
          label="PnL"
          value={pnlSign(wallet.pnl)}
          color={pnlColor(wallet.pnl)}
        />
        <MetricTile
          label="Win Rate"
          value={formatPct(wallet.winRate ?? wallet.win_rate)}
          color={
            (wallet.winRate ?? wallet.win_rate ?? 0) >= 0.5
              ? C.green
              : C.red
          }
        />
        <MetricTile
          label="Trades"
          value={wallet.trades ?? wallet.totalTrades ?? 0}
        />
        <MetricTile
          label="Avg Size"
          value={formatUsd(wallet.avgSize ?? wallet.avg_size)}
        />
        <MetricTile
          label={isDumb ? "Inverse Score" : "Score"}
          value={Math.round(score)}
          color={isDumb ? C.pink : getScoreColor(score)}
        />
        <MetricTile
          label="Copyability"
          value={Math.round(wallet.copyability ?? 0)}
          color={
            (wallet.copyability ?? 0) >= 80 ? C.green : C.creamSoft
          }
        />
        <MetricTile
          label="Leader"
          value={Math.round(
            wallet.leaderScore ?? wallet.leader_score ?? 0
          )}
          color={getScoreColor(
            wallet.leaderScore ?? wallet.leader_score ?? 0
          )}
        />
        <MetricTile
          label="Crowding"
          value={
            wallet.crowding != null || wallet.crowdingPct != null
              ? `${(wallet.crowding ?? wallet.crowdingPct ?? 0).toFixed(1)}%`
              : "\u2014"
          }
          color={
            (wallet.crowding ?? wallet.crowdingPct ?? 0) > 25
              ? C.red
              : C.creamSoft
          }
        />
      </div>

      {/* ── Dumb wallet: inverse score + category weaknesses ───── */}
      {isDumb && (
        <Panel
          title="Dumb Money Profile"
          style={{ marginBottom: 20 }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 20,
              marginBottom: 12,
            }}
          >
            <div style={{ textAlign: "center" }}>
              <div
                style={{
                  fontFamily: fonts.mono,
                  fontSize: 36,
                  fontWeight: 700,
                  color: C.pink,
                }}
              >
                {Math.round(
                  wallet.inverseScore ?? wallet.inverse_score ?? 0
                )}
              </div>
              <div
                style={{
                  fontFamily: fonts.mono,
                  fontSize: 10,
                  color: C.creamMuted,
                  textTransform: "uppercase",
                  letterSpacing: 1,
                }}
              >
                Inverse Score
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  fontFamily: fonts.mono,
                  fontSize: 11,
                  color: C.creamMuted,
                  marginBottom: 8,
                }}
              >
                Category Weaknesses
              </div>
              {(wallet.categoryWinRates ||
                wallet.category_win_rates) && (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 6,
                  }}
                >
                  {Object.entries(
                    wallet.categoryWinRates ||
                      wallet.category_win_rates ||
                      {}
                  ).map(([cat, wr]) => {
                    const catColor = getCatColor(cat);
                    const wrNum = Number(wr) || 0;
                    return (
                      <div
                        key={cat}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          fontFamily: fonts.mono,
                          fontSize: 11,
                        }}
                      >
                        <span
                          style={{
                            color: catColor,
                            minWidth: 70,
                          }}
                        >
                          {cat}
                        </span>
                        <div
                          style={{
                            flex: 1,
                            height: 6,
                            background: C.creamGhost,
                            borderRadius: 3,
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              width: `${Math.max(wrNum * 100, 2)}%`,
                              height: "100%",
                              background: C.red,
                              borderRadius: 3,
                            }}
                          />
                        </div>
                        <span style={{ color: C.red, minWidth: 40 }}>
                          {formatPct(wr)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </Panel>
      )}

      {/* ── Recent Trades ──────────────────────────────────────── */}
      <Panel title="Recent Trades" style={{ marginBottom: 20 }}>
        {!trades && (
          <div
            style={{
              textAlign: "center",
              padding: 20,
              color: C.creamMuted,
              fontFamily: fonts.mono,
              fontSize: 11,
            }}
          >
            Loading trades...
          </div>
        )}
        {trades && trades.length === 0 && (
          <div
            style={{
              textAlign: "center",
              padding: 20,
              color: C.creamMuted,
              fontFamily: fonts.mono,
              fontSize: 11,
            }}
          >
            No recent trades
          </div>
        )}
        {trades && trades.length > 0 && (
          <div style={{ overflowX: "auto" }}>
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
                fontFamily: fonts.mono,
                fontSize: 11,
              }}
            >
              <thead>
                <tr>
                  {["Market", "Side", "Size", "Price", "Time"].map(
                    (h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: h === "Market" ? "left" : "right",
                          padding: "6px 10px",
                          borderBottom: `1px solid ${C.border}`,
                          color: C.creamMuted,
                          fontWeight: 500,
                          fontSize: 9,
                          textTransform: "uppercase",
                          letterSpacing: 1,
                        }}
                      >
                        {h}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {trades.map((t, i) => {
                  const side =
                    t.side || t.trade_side || "\u2014";
                  const sideColor =
                    side === "YES" || side === "BUY"
                      ? C.green
                      : side === "NO" || side === "SELL"
                      ? C.red
                      : C.creamMuted;
                  const market =
                    t.market_name || t.marketName || "\u2014";
                  const size = t.size ?? t.trade_size ?? null;
                  const price = t.price ?? t.trade_price ?? null;
                  const ts =
                    t.timestamp ||
                    t.created_at ||
                    t.createdAt ||
                    null;

                  return (
                    <tr
                      key={t.id || i}
                      style={{
                        borderBottom: `1px solid ${C.border}`,
                      }}
                    >
                      <td
                        style={{
                          padding: "6px 10px",
                          color: C.cream,
                          maxWidth: 200,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {market}
                      </td>
                      <td
                        style={{
                          padding: "6px 10px",
                          textAlign: "right",
                        }}
                      >
                        <span
                          style={{
                            display: "inline-block",
                            padding: "1px 6px",
                            borderRadius: 3,
                            fontSize: 9,
                            fontWeight: 700,
                            background: `${sideColor}18`,
                            color: sideColor,
                          }}
                        >
                          {side}
                        </span>
                      </td>
                      <td
                        style={{
                          padding: "6px 10px",
                          textAlign: "right",
                          color: C.creamSoft,
                        }}
                      >
                        {formatUsd(size)}
                      </td>
                      <td
                        style={{
                          padding: "6px 10px",
                          textAlign: "right",
                          color: C.creamSoft,
                        }}
                      >
                        {price != null
                          ? `$${Number(price).toFixed(2)}`
                          : "\u2014"}
                      </td>
                      <td
                        style={{
                          padding: "6px 10px",
                          textAlign: "right",
                          color: C.creamMuted,
                          fontSize: 10,
                        }}
                      >
                        {relativeTime(ts)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {/* ── Intent Distribution (smart wallets only) ───────────── */}
      {!isDumb && intentDist.length > 0 && (
        <Panel title="Intent Distribution">
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 8,
            }}
          >
            {intentDist.map(({ type, count, pct, color }) => (
              <div
                key={type}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                }}
              >
                <span
                  style={{
                    fontFamily: fonts.mono,
                    fontSize: 10,
                    color: color,
                    minWidth: 110,
                    textTransform: "uppercase",
                    letterSpacing: 0.5,
                  }}
                >
                  {type.replace(/_/g, " ")}
                </span>
                <div
                  style={{
                    flex: 1,
                    height: 10,
                    background: C.creamGhost,
                    borderRadius: 5,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      width: `${Math.max(pct * 100, 2)}%`,
                      height: "100%",
                      background: color,
                      borderRadius: 5,
                      transition: "width 0.3s ease",
                    }}
                  />
                </div>
                <span
                  style={{
                    fontFamily: fonts.mono,
                    fontSize: 11,
                    color: C.creamSoft,
                    minWidth: 30,
                    textAlign: "right",
                  }}
                >
                  {count}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {/* ── Intent info for smart wallets without data ─────────── */}
      {!isDumb && intentDist.length === 0 && intents && (
        <Panel title="Intent Distribution">
          <div
            style={{
              textAlign: "center",
              padding: 20,
              color: C.creamMuted,
              fontFamily: fonts.mono,
              fontSize: 11,
            }}
          >
            No intent data available
          </div>
        </Panel>
      )}
    </div>
  );
}

/* ── Back button sub-component ──────────────────────────────────────── */
function BackButton({ onBack }) {
  if (!onBack) return null;
  return (
    <button
      onClick={onBack}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        background: "transparent",
        border: `1px solid ${C.border}`,
        borderRadius: 6,
        padding: "6px 14px",
        color: C.creamSoft,
        fontFamily: fonts.mono,
        fontSize: 11,
        cursor: "pointer",
        marginBottom: 16,
        transition: "border-color 0.15s ease",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = C.cream;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = C.border;
      }}
    >
      <span style={{ fontSize: 14 }}>{"\u2190"}</span>
      Back
    </button>
  );
}
