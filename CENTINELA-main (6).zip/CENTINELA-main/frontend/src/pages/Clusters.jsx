/** Page 16: Clusters — wallet cluster visualization, copyability scores, leader board */
import { useState } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct } from '../utils/theme';
import { useApi, usePolling, apiPatch, apiPost } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, Loading, ErrorCard } from '../components/shared';

/* ── table header cell style ───────────────────────────────── */
const th = {
  textAlign: 'left',
  padding: '8px 10px',
  borderBottom: `1px solid ${C.border}`,
  color: C.creamMuted,
  fontFamily: fonts.sans,
  fontWeight: 500,
  fontSize: 10,
  textTransform: 'uppercase',
  letterSpacing: 1,
};
const td = {
  padding: '8px 10px',
  fontFamily: fonts.mono,
  fontSize: 12,
  color: C.creamSoft,
  borderBottom: `1px solid ${C.border}`,
};

export default function Clusters() {
  const { data: clusters, loading: cLoad, error: cErr } = usePolling('/clusters', 30000);
  const { data: copyability, loading: cpLoad, error: cpErr } = useApi('/copyability');
  const { data: leaders, loading: lLoad, error: lErr } = useApi('/leaders');

  if (cLoad && !clusters) return <Loading />;
  if (cErr && !clusters) return <ErrorCard message={cErr} />;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* ── WALLET CLUSTERS ─────────────────────────────────── */}
      <Panel title="Wallet Clusters" right={
        clusters && (
          <PillBadge
            text={`${clusters.length} cluster${clusters.length !== 1 ? 's' : ''}`}
            color={C.purple}
          />
        )
      }>
        {(!clusters || clusters.length === 0) ? (
          <div style={{ color: C.creamMuted, fontFamily: fonts.mono, fontSize: 12, padding: 12, textAlign: 'center' }}>
            No clusters detected
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {clusters.map((cl) => {
              /* find shared markets among members */
              const marketSets = (cl.members || [])
                .filter((m) => m.markets && m.markets.length > 0)
                .map((m) => m.markets);
              let sharedMarkets = [];
              if (marketSets.length >= 2) {
                const first = new Set(marketSets[0]);
                sharedMarkets = [...first].filter((mkt) =>
                  marketSets.every((ms) => ms.includes(mkt))
                );
              }

              return (
                <div
                  key={cl.clusterId ?? cl.cluster_id}
                  style={{
                    background: C.card,
                    border: `1px solid ${C.purple}33`,
                    borderRadius: 8,
                    padding: 16,
                  }}
                >
                  {/* header row */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                    <span style={{
                      fontFamily: fonts.mono, fontSize: 13, fontWeight: 700,
                      color: C.purple, letterSpacing: 0.5,
                    }}>
                      Cluster #{cl.clusterId ?? cl.cluster_id}
                    </span>
                    <PillBadge
                      text={`${cl.members?.length ?? cl.size ?? 0} members`}
                      color={C.cyan}
                    />
                  </div>

                  {/* member list */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {(cl.members || []).map((m) => (
                      <div
                        key={m.walletId ?? m.wallet_id}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 6,
                          padding: '5px 10px',
                          background: `${C.purple}12`,
                          border: `1px solid ${C.purple}30`,
                          borderRadius: 6,
                        }}
                      >
                        <span style={{
                          fontFamily: fonts.mono, fontSize: 11, color: C.cream, fontWeight: 600,
                        }}>
                          {m.handle || `#${m.walletId ?? m.wallet_id}`}
                        </span>
                        <span style={{
                          fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted,
                        }}>
                          W{m.walletId ?? m.wallet_id}
                        </span>
                        <span style={{
                          fontFamily: fonts.mono, fontSize: 10,
                          color: (m.confidence ?? m.cluster_confidence ?? 0) >= 0.8 ? C.green
                            : (m.confidence ?? m.cluster_confidence ?? 0) >= 0.5 ? C.amber
                            : C.red,
                          fontWeight: 600,
                        }}>
                          {((m.confidence ?? m.cluster_confidence ?? 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* shared markets note */}
                  {sharedMarkets.length > 0 && (
                    <div style={{
                      marginTop: 8, fontFamily: fonts.mono, fontSize: 10,
                      color: C.amber, padding: '4px 8px',
                      background: `${C.amber}10`, borderRadius: 4,
                    }}>
                      Shared markets: {sharedMarkets.join(', ')}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* summary note */}
        {clusters && clusters.length > 0 && (
          <div style={{
            marginTop: 14, fontFamily: fonts.mono, fontSize: 11,
            color: C.creamMuted, padding: '8px 12px',
            background: C.card, borderRadius: 6,
            border: `1px solid ${C.border}`,
          }}>
            Cluster C1 affects consensus signals — {clusters[0]?.members?.length ?? '?'} wallets
            {' -> '}{((clusters[0]?.members?.length ?? 4) / 1.5).toFixed(1)} effective (cluster discount)
          </div>
        )}
      </Panel>

      {/* ── COPYABILITY SCORES ──────────────────────────────── */}
      <Panel title="Copyability Scores">
        {cpLoad && !copyability ? (
          <Loading />
        ) : cpErr && !copyability ? (
          <ErrorCard message={cpErr} />
        ) : !copyability || copyability.length === 0 ? (
          <div style={{ color: C.creamMuted, fontFamily: fonts.mono, fontSize: 12, textAlign: 'center', padding: 12 }}>
            No copyability data
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Wallet</th>
                  <th style={{ ...th, textAlign: 'center' }}>Score</th>
                  <th style={th}>T5 Median</th>
                  <th style={th}>Edge Retention</th>
                  <th style={th}>Stability</th>
                  <th style={th}>Signals Eval</th>
                </tr>
              </thead>
              <tbody>
                {copyability.map((m) => {
                  const score = m.copyabilityScore ?? m.copyability_score ?? 0;
                  const scoreColor = getScoreColor(score);
                  return (
                    <tr key={m.walletId ?? m.wallet_id}>
                      <td style={{ ...td, color: C.cream, fontWeight: 600 }}>
                        {m.handle || `#${m.walletId ?? m.wallet_id}`}
                      </td>
                      <td style={{ ...td, textAlign: 'center' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                          <RingGauge
                            value={score}
                            max={100}
                            size={36}
                            color={scoreColor}
                            label={Math.round(score).toString()}
                          />
                        </div>
                      </td>
                      <td style={td}>
                        {(m.t5Median ?? m.t5_median) != null
                          ? `${Number(m.t5Median ?? m.t5_median).toFixed(0)}s`
                          : '\u2014'}
                      </td>
                      <td style={td}>
                        {(m.edgeRetention ?? m.edge_retention) != null
                          ? `${(Number(m.edgeRetention ?? m.edge_retention) * 100).toFixed(1)}%`
                          : '\u2014'}
                      </td>
                      <td style={td}>
                        <span style={{
                          color: (m.stability ?? 0) >= 0.8 ? C.green
                            : (m.stability ?? 0) >= 0.5 ? C.amber : C.red,
                        }}>
                          {m.stability != null ? Number(m.stability).toFixed(2) : '\u2014'}
                        </span>
                      </td>
                      <td style={td}>
                        {m.signalsEvaluated ?? m.signals_evaluated ?? '\u2014'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {/* ── LEADER BOARD ────────────────────────────────────── */}
      <Panel title="Leader Board">
        {lLoad && !leaders ? (
          <Loading />
        ) : lErr && !leaders ? (
          <ErrorCard message={lErr} />
        ) : !leaders || leaders.length === 0 ? (
          <div style={{ color: C.creamMuted, fontFamily: fonts.mono, fontSize: 12, textAlign: 'center', padding: 12 }}>
            No leader data
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Wallet</th>
                  <th style={{ ...th, textAlign: 'center' }}>Leader Score</th>
                  <th style={th}>Leader Events</th>
                  <th style={th}>Follower Events</th>
                  <th style={th}>Avg Follow Quality</th>
                  <th style={th}>Median Lead Time</th>
                </tr>
              </thead>
              <tbody>
                {leaders.map((m) => {
                  const score = m.leaderScore ?? m.leader_score ?? 0;
                  const scoreColor = getScoreColor(score);
                  return (
                    <tr key={m.walletId ?? m.wallet_id}>
                      <td style={{ ...td, color: C.cream, fontWeight: 600 }}>
                        {m.handle || `#${m.walletId ?? m.wallet_id}`}
                      </td>
                      <td style={{ ...td, textAlign: 'center' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                          <RingGauge
                            value={score}
                            max={100}
                            size={36}
                            color={scoreColor}
                            label={Math.round(score).toString()}
                          />
                        </div>
                      </td>
                      <td style={td}>
                        {m.leaderEvents ?? m.leader_events ?? '\u2014'}
                      </td>
                      <td style={td}>
                        {m.followerEvents ?? m.follower_events ?? '\u2014'}
                      </td>
                      <td style={td}>
                        {(m.avgFollowQuality ?? m.avg_follow_quality) != null
                          ? Number(m.avgFollowQuality ?? m.avg_follow_quality).toFixed(2)
                          : '\u2014'}
                      </td>
                      <td style={td}>
                        {(m.medianLeadTime ?? m.median_lead_time) != null
                          ? `${Number(m.medianLeadTime ?? m.median_lead_time).toFixed(0)}s`
                          : '\u2014'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
