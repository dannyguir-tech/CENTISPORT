/** Page 17: Settings — full settings page with read/write, collapsible sections, sliders */
import { useState, useCallback, useEffect, useRef } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct } from '../utils/theme';
import { useApi, usePolling, apiPatch, apiPost } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, Loading, ErrorCard } from '../components/shared';

/* ── helpers ────────────────────────────────────────────────── */

/** Convert camelCase to snake_case for API field names */
function toSnake(str) {
  return str.replace(/([A-Z])/g, '_$1').toLowerCase();
}

/** Collapsible section wrapper using Panel */
function Section({ title, expanded, onToggle, children }) {
  return (
    <Panel
      title={null}
      style={{ marginBottom: 16, background: C.panel }}
    >
      <button
        onClick={onToggle}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          padding: 0, marginBottom: expanded ? 16 : 0,
        }}
      >
        <span style={{
          fontFamily: fonts.mono, fontSize: 12, fontWeight: 700,
          letterSpacing: 1.8, color: C.green, textTransform: 'uppercase',
        }}>
          {title}
        </span>
        <span style={{
          fontFamily: fonts.mono, fontSize: 14, color: C.creamMuted,
          transform: expanded ? 'rotate(180deg)' : 'rotate(0)',
          transition: 'transform 0.2s ease',
          display: 'inline-block',
        }}>
          {'\u25BC'}
        </span>
      </button>
      {expanded && children}
    </Panel>
  );
}

/* ── slider styles (CSS-in-JS for range inputs) ────────────── */
const sliderTrack = {
  WebkitAppearance: 'none',
  appearance: 'none',
  width: '100%',
  height: 6,
  borderRadius: 3,
  background: `linear-gradient(to right, ${C.green}44, ${C.green})`,
  outline: 'none',
  cursor: 'pointer',
};

/** Styled range slider component */
function Slider({ label, value, min, max, step, onChange, onBlur, unit = '' }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        marginBottom: 6,
      }}>
        <span style={{
          fontFamily: fonts.sans, fontSize: 12, color: C.creamSoft, fontWeight: 500,
        }}>
          {label}
        </span>
        <span style={{
          fontFamily: fonts.mono, fontSize: 13, color: C.cream, fontWeight: 700,
        }}>
          {value}{unit}
        </span>
      </div>
      <div style={{ position: 'relative' }}>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={onChange}
          onMouseUp={onBlur}
          onTouchEnd={onBlur}
          style={{
            ...sliderTrack,
            background: `linear-gradient(to right, ${C.green} 0%, ${C.green} ${pct}%, ${C.creamGhost} ${pct}%, ${C.creamGhost} 100%)`,
          }}
        />
      </div>
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, marginTop: 2,
      }}>
        <span>{min}{unit}</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
}

/** Visual save-flash indicator */
function useSaveFlash() {
  const [flashFields, setFlashFields] = useState({});
  const timers = useRef({});

  const flash = useCallback((field) => {
    setFlashFields((prev) => ({ ...prev, [field]: true }));
    if (timers.current[field]) clearTimeout(timers.current[field]);
    timers.current[field] = setTimeout(() => {
      setFlashFields((prev) => ({ ...prev, [field]: false }));
    }, 1200);
  }, []);

  useEffect(() => {
    return () => Object.values(timers.current).forEach(clearTimeout);
  }, []);

  return { flashFields, flash };
}

/* ── main component ─────────────────────────────────────────── */

export default function Settings() {
  const { data: bankroll, loading: bLoad, error: bErr, refetch } = useApi('/bankroll');
  const { data: calibrations } = useApi('/calibrations?limit=5');
  const { data: ping } = useApi('/ping');

  /* collapsible section state */
  const [expanded, setExpanded] = useState({
    bankroll: true,
    lossLimits: true,
    execution: true,
    strategyState: true,
    calibration: false,
    systemHealth: false,
  });

  const toggle = (key) =>
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));

  /* local form state — initialized from bankroll */
  const [form, setForm] = useState(null);
  const { flashFields, flash } = useSaveFlash();

  useEffect(() => {
    if (bankroll && !form) {
      setForm({
        totalCapital: bankroll.totalCapital ?? bankroll.total_capital ?? 0,
        maxPerMarketPct: Number(
          ((bankroll.maxPerMarketPct ?? bankroll.max_per_market_pct ?? 0.05) * 100).toFixed(1)
        ),
        maxPerCategoryPct: Number(
          ((bankroll.maxPerCategoryPct ?? bankroll.max_per_category_pct ?? 0.25) * 100).toFixed(0)
        ),
        maxConcurrentPositions:
          bankroll.maxConcurrentPositions ?? bankroll.max_concurrent_positions ?? 10,
        dailyLossLimit: Number(
          ((bankroll.dailyLossLimit ?? bankroll.daily_loss_limit ?? 0.05) * 100).toFixed(1)
        ),
        weeklyLossLimit: Number(
          ((bankroll.weeklyLossLimit ?? bankroll.weekly_loss_limit ?? 0.10) * 100).toFixed(0)
        ),
        kellyFraction:
          bankroll.kellyFraction ?? bankroll.kelly_fraction ?? 0.25,
      });
    }
  }, [bankroll]); // eslint-disable-line react-hooks/exhaustive-deps

  /* save a single field */
  const saveField = useCallback(async (camelField, rawValue, divisor = 1) => {
    const snakeField = toSnake(camelField);
    const apiValue = divisor !== 1 ? rawValue / divisor : rawValue;
    const result = await apiPatch('/bankroll', { [snakeField]: apiValue });
    if (result !== null) {
      flash(camelField);
      refetch();
    }
  }, [flash, refetch]);

  /* strategy state override */
  const [overriding, setOverriding] = useState(false);
  const setStrategyState = useCallback(async (state) => {
    setOverriding(true);
    await apiPatch('/bankroll', { strategy_state: state });
    refetch();
    setOverriding(false);
  }, [refetch]);

  /* ping / health */
  const [telegramStatus, setTelegramStatus] = useState(null);
  const testTelegram = useCallback(async () => {
    setTelegramStatus('testing');
    const result = await apiPost('/ping', {});
    setTelegramStatus(result !== null ? 'ok' : 'fail');
    setTimeout(() => setTelegramStatus(null), 3000);
  }, []);

  /* loading gate */
  if (bLoad && !bankroll) return <Loading />;
  if (bErr && !bankroll) return <ErrorCard message={bErr} />;
  if (!form) return <Loading />;

  const currentState = bankroll?.strategyState ?? bankroll?.strategy_state ?? 'green';

  /* field-level flash style helper */
  const fieldStyle = (field) => ({
    transition: 'box-shadow 0.3s ease',
    boxShadow: flashFields[field] ? `0 0 0 2px ${C.green}66` : 'none',
    borderRadius: 6,
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>

      {/* ── 1. BANKROLL ──────────────────────────────────────── */}
      <Section title="Bankroll" expanded={expanded.bankroll} onToggle={() => toggle('bankroll')}>
        {/* Total Capital — number input */}
        <div style={{ marginBottom: 18, ...fieldStyle('totalCapital') }}>
          <label style={{
            fontFamily: fonts.sans, fontSize: 12, color: C.creamSoft,
            display: 'block', marginBottom: 6, fontWeight: 500,
          }}>
            Total Capital
          </label>
          <div style={{ position: 'relative' }}>
            <span style={{
              position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
              fontFamily: fonts.mono, fontSize: 14, color: C.creamMuted,
            }}>$</span>
            <input
              type="number"
              value={form.totalCapital}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                if (!isNaN(v)) setForm((f) => ({ ...f, totalCapital: v }));
              }}
              onBlur={() => saveField('totalCapital', form.totalCapital)}
              style={{
                width: '100%', padding: '10px 12px 10px 28px',
                background: C.bg, border: `1px solid ${C.border}`, borderRadius: 6,
                color: C.cream, fontFamily: fonts.mono, fontSize: 16, fontWeight: 700,
                outline: 'none',
              }}
            />
          </div>
        </div>

        {/* Max per market % */}
        <div style={fieldStyle('maxPerMarketPct')}>
          <Slider
            label="Max Per Market"
            value={form.maxPerMarketPct}
            min={1} max={10} step={0.5} unit="%"
            onChange={(e) => setForm((f) => ({ ...f, maxPerMarketPct: parseFloat(e.target.value) }))}
            onBlur={() => saveField('maxPerMarketPct', form.maxPerMarketPct, 100)}
          />
        </div>

        {/* Max per category % */}
        <div style={fieldStyle('maxPerCategoryPct')}>
          <Slider
            label="Max Per Category"
            value={form.maxPerCategoryPct}
            min={10} max={50} step={5} unit="%"
            onChange={(e) => setForm((f) => ({ ...f, maxPerCategoryPct: parseFloat(e.target.value) }))}
            onBlur={() => saveField('maxPerCategoryPct', form.maxPerCategoryPct, 100)}
          />
        </div>

        {/* Max concurrent positions */}
        <div style={fieldStyle('maxConcurrentPositions')}>
          <Slider
            label="Max Concurrent Positions"
            value={form.maxConcurrentPositions}
            min={5} max={20} step={1} unit=""
            onChange={(e) => setForm((f) => ({ ...f, maxConcurrentPositions: parseInt(e.target.value) }))}
            onBlur={() => saveField('maxConcurrentPositions', form.maxConcurrentPositions)}
          />
        </div>
      </Section>

      {/* ── 2. LOSS LIMITS ───────────────────────────────────── */}
      <Section title="Loss Limits" expanded={expanded.lossLimits} onToggle={() => toggle('lossLimits')}>
        <div style={fieldStyle('dailyLossLimit')}>
          <Slider
            label="Daily Loss Limit"
            value={form.dailyLossLimit}
            min={1} max={10} step={0.5} unit="%"
            onChange={(e) => setForm((f) => ({ ...f, dailyLossLimit: parseFloat(e.target.value) }))}
            onBlur={() => saveField('dailyLossLimit', form.dailyLossLimit, 100)}
          />
        </div>

        <div style={fieldStyle('weeklyLossLimit')}>
          <Slider
            label="Weekly Loss Limit"
            value={form.weeklyLossLimit}
            min={5} max={20} step={1} unit="%"
            onChange={(e) => setForm((f) => ({ ...f, weeklyLossLimit: parseFloat(e.target.value) }))}
            onBlur={() => saveField('weeklyLossLimit', form.weeklyLossLimit, 100)}
          />
        </div>
      </Section>

      {/* ── 3. EXECUTION ─────────────────────────────────────── */}
      <Section title="Execution" expanded={expanded.execution} onToggle={() => toggle('execution')}>
        <div style={fieldStyle('kellyFraction')}>
          <Slider
            label="Kelly Fraction"
            value={form.kellyFraction}
            min={0.1} max={0.5} step={0.05} unit=""
            onChange={(e) => setForm((f) => ({ ...f, kellyFraction: parseFloat(e.target.value) }))}
            onBlur={() => saveField('kellyFraction', form.kellyFraction)}
          />
        </div>
      </Section>

      {/* ── 4. STRATEGY STATE ────────────────────────────────── */}
      <Section title="Strategy State" expanded={expanded.strategyState} onToggle={() => toggle('strategyState')}>
        {/* current state display */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16,
        }}>
          <span style={{ fontFamily: fonts.sans, fontSize: 12, color: C.creamSoft }}>
            Current State:
          </span>
          <PillBadge
            text={currentState.toUpperCase()}
            color={
              currentState === 'green' ? C.green
                : currentState === 'yellow' ? C.amber
                : C.red
            }
          />
        </div>

        {/* override buttons */}
        <div style={{ display: 'flex', gap: 10 }}>
          {[
            { state: 'green', color: C.green, label: 'GREEN' },
            { state: 'yellow', color: C.amber, label: 'YELLOW' },
            { state: 'red', color: C.red, label: 'RED' },
          ].map(({ state, color, label }) => {
            const isActive = currentState === state;
            return (
              <button
                key={state}
                onClick={() => setStrategyState(state)}
                disabled={overriding}
                style={{
                  flex: 1, padding: '12px 8px',
                  background: isActive ? `${color}22` : 'transparent',
                  border: `2px solid ${isActive ? color : C.border}`,
                  borderRadius: 8,
                  color: isActive ? color : C.creamMuted,
                  fontFamily: fonts.mono, fontSize: 13, fontWeight: 700,
                  cursor: overriding ? 'wait' : 'pointer',
                  letterSpacing: 1,
                  transition: 'all 0.2s ease',
                  boxShadow: isActive ? `0 0 12px ${color}33` : 'none',
                }}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* lockout info */}
        {(bankroll?.isLockedOut ?? bankroll?.is_locked_out) && (
          <div style={{
            marginTop: 12, padding: '10px 14px',
            background: `${C.red}12`, border: `1px solid ${C.red}44`,
            borderRadius: 6,
          }}>
            <span style={{
              fontFamily: fonts.mono, fontSize: 11, color: C.red, fontWeight: 600,
            }}>
              LOCKED OUT
            </span>
            <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft, marginLeft: 8 }}>
              {bankroll?.lockoutReason ?? bankroll?.lockout_reason ?? 'Loss limit breached'}
            </span>
            {(bankroll?.lockoutUntil ?? bankroll?.lockout_until) && (
              <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 4 }}>
                Until: {new Date(bankroll.lockoutUntil ?? bankroll.lockout_until).toLocaleString()}
              </div>
            )}
          </div>
        )}
      </Section>

      {/* ── 5. CALIBRATION HISTORY ───────────────────────────── */}
      <Section title="Calibration History" expanded={expanded.calibration} onToggle={() => toggle('calibration')}>
        {!calibrations || calibrations.length === 0 ? (
          <div style={{
            color: C.creamMuted, fontFamily: fonts.mono, fontSize: 12,
            textAlign: 'center', padding: 12,
          }}>
            No calibration history
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {calibrations.map((cal) => {
              const oldW = cal.oldWeights ?? cal.old_weights ?? {};
              const newW = cal.newWeights ?? cal.new_weights ?? {};
              const allKeys = [...new Set([...Object.keys(oldW), ...Object.keys(newW)])];

              return (
                <div
                  key={cal.id}
                  style={{
                    background: C.card, border: `1px solid ${C.border}`,
                    borderRadius: 6, padding: 12,
                  }}
                >
                  <div style={{
                    fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, marginBottom: 8,
                  }}>
                    {(cal.calibratedAt ?? cal.calibrated_at ?? '').split('T')[0] || 'Unknown date'}
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {allKeys.map((k) => {
                      const oldVal = oldW[k];
                      const newVal = newW[k];
                      const diff = oldVal != null && newVal != null
                        ? ((newVal - oldVal) * 100).toFixed(1)
                        : null;
                      const diffColor = diff > 0 ? C.green : diff < 0 ? C.red : C.creamMuted;
                      return (
                        <div
                          key={k}
                          style={{
                            padding: '4px 8px', background: `${C.creamGhost}`,
                            borderRadius: 4, fontFamily: fonts.mono, fontSize: 10,
                          }}
                        >
                          <span style={{ color: C.creamMuted }}>{k}: </span>
                          {oldVal != null && (
                            <span style={{ color: C.creamSoft }}>
                              {(oldVal * 100).toFixed(1)}%
                            </span>
                          )}
                          {diff != null && (
                            <span style={{ color: diffColor, fontWeight: 600 }}>
                              {' -> '}{(newVal * 100).toFixed(1)}%
                              {' ('}{diff > 0 ? '+' : ''}{diff}{'%)'}
                            </span>
                          )}
                          {oldVal == null && newVal != null && (
                            <span style={{ color: C.green }}>
                              {(newVal * 100).toFixed(1)}% (new)
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Section>

      {/* ── 6. SYSTEM HEALTH ─────────────────────────────────── */}
      <Section title="System Health" expanded={expanded.systemHealth} onToggle={() => toggle('systemHealth')}>
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12,
        }}>
          {/* API Endpoint */}
          <div style={{
            background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: 14,
          }}>
            <div style={{
              fontFamily: fonts.sans, fontSize: 10, color: C.creamMuted,
              textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
            }}>
              API Endpoint
            </div>
            <div style={{ fontFamily: fonts.mono, fontSize: 12, color: C.cream }}>
              GET /api/ping
            </div>
            <div style={{
              fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft, marginTop: 4,
            }}>
              {ping ? JSON.stringify(ping).slice(0, 60) : '\u2014'}
            </div>
          </div>

          {/* Backend Status */}
          <div style={{
            background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: 14,
          }}>
            <div style={{
              fontFamily: fonts.sans, fontSize: 10, color: C.creamMuted,
              textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
            }}>
              Backend Status
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 10, height: 10, borderRadius: '50%',
                background: ping ? C.green : C.red,
                boxShadow: `0 0 8px ${ping ? C.green : C.red}66`,
              }} />
              <span style={{
                fontFamily: fonts.mono, fontSize: 13, fontWeight: 600,
                color: ping ? C.green : C.red,
              }}>
                {ping ? 'ONLINE' : 'OFFLINE'}
              </span>
            </div>
          </div>

          {/* Telegram Test */}
          <div style={{
            background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: 14,
          }}>
            <div style={{
              fontFamily: fonts.sans, fontSize: 10, color: C.creamMuted,
              textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
            }}>
              Telegram Connectivity
            </div>
            <button
              onClick={testTelegram}
              disabled={telegramStatus === 'testing'}
              style={{
                padding: '8px 16px',
                background: telegramStatus === 'ok' ? `${C.green}22`
                  : telegramStatus === 'fail' ? `${C.red}22`
                  : 'transparent',
                border: `1px solid ${
                  telegramStatus === 'ok' ? C.green
                    : telegramStatus === 'fail' ? C.red
                    : C.border
                }`,
                borderRadius: 6, cursor: 'pointer',
                fontFamily: fonts.mono, fontSize: 11, fontWeight: 600,
                color: telegramStatus === 'ok' ? C.green
                  : telegramStatus === 'fail' ? C.red
                  : C.creamSoft,
                transition: 'all 0.2s ease',
              }}
            >
              {telegramStatus === 'testing' ? 'Testing...'
                : telegramStatus === 'ok' ? 'Connected'
                : telegramStatus === 'fail' ? 'Failed'
                : 'Test Connection'}
            </button>
          </div>

          {/* Data Freshness */}
          <div style={{
            background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: 14,
          }}>
            <div style={{
              fontFamily: fonts.sans, fontSize: 10, color: C.creamMuted,
              textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
            }}>
              Data Freshness
            </div>
            <div style={{
              fontFamily: fonts.mono, fontSize: 12, color: C.cream,
            }}>
              {bankroll?.updatedAt ?? bankroll?.updated_at
                ? new Date(bankroll.updatedAt ?? bankroll.updated_at).toLocaleString()
                : 'Unknown'}
            </div>
            <div style={{
              fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 4,
            }}>
              Last bankroll sync
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}
