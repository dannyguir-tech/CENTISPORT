/** Page 9: Cross-Platform — Polymarket vs Kalshi divergence tracking */
import { C, fonts, getScoreColor, formatUsd, formatPct, formatPctRaw, relativeTime, getCatColor, pnlColor, pnlSign } from '../utils/theme';
import { usePolling, useApi } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, ProgressBar, DataTable, Loading, ErrorCard } from '../components/shared';

function gapPill(gap) {
  if (gap == null) return <PillBadge text="\u2014" color={C.creamMuted} />;
  const g = Number(gap);
  if (g >= 10) return <PillBadge text="ACTIONABLE" color={C.green} />;
  if (g >= 5) return <PillBadge text="WATCHING" color={C.amber} />;
  return <PillBadge text="LOW" color={C.creamMuted} />;
}

export default function CrossPlatform() {
  const { data: divergences, loading: divLoading, error: divError } = usePolling('/cross-platform/divergences?min_gap=5', 60000);
  const { data: pairs, loading: pairsLoading, error: pairsError } = usePolling('/cross-platform/pairs', 60000);

  const isLoading = divLoading && pairsLoading && !divergences && !pairs;
  if (isLoading) return <Loading />;

  const divList = Array.isArray(divergences) ? divergences : [];
  const pairList = Array.isArray(pairs) ? pairs : [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Header */}
      <div style={{ marginBottom: 4 }}>
        <h2 style={{ fontFamily: fonts.mono, fontSize: 16, fontWeight: 700, letterSpacing: 2, margin: 0, color: C.green, textTransform: 'uppercase' }}>
          CROSS-PLATFORM DIVERGENCE
        </h2>
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 4 }}>
          Polymarket vs Kalshi price divergence tracking
        </div>
      </div>

      {/* Active Divergences */}
      <Panel title="Active Divergences" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {divList.length} active
        </span>
      }>
        {divError && <ErrorCard message="Failed to load divergences" />}
        {divList.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {divList.map((d, i) => {
              const gap = d.gap != null ? Number(d.gap) : null;
              const isActionable = gap != null && gap >= 10;
              return (
                <div
                  key={d.id || d.marketId || i}
                  style={{
                    background: C.card,
                    border: `1px solid ${isActionable ? `${C.green}44` : C.border}`,
                    borderRadius: 8,
                    padding: '12px 16px',
                    display: 'grid',
                    gridTemplateColumns: '1fr auto auto auto auto auto',
                    alignItems: 'center',
                    gap: 16,
                  }}
                >
                  {/* Market name */}
                  <div style={{ minWidth: 0 }}>
                    <div style={{
                      fontFamily: fonts.mono, fontSize: 12, fontWeight: 600, color: C.cream,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                    }}>
                      {d.question || d.marketName || d.market || '\u2014'}
                    </div>
                  </div>

                  {/* Polymarket price */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Poly</div>
                    <div style={{ fontFamily: fonts.mono, fontSize: 14, fontWeight: 700, color: C.cream }}>
                      {d.polymarketPrice != null ? `${Number(d.polymarketPrice).toFixed(1)}\u00A2` : '\u2014'}
                    </div>
                  </div>

                  {/* Kalshi price */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Kalshi</div>
                    <div style={{ fontFamily: fonts.mono, fontSize: 14, fontWeight: 700, color: C.cream }}>
                      {d.kalshiPrice != null ? `${Number(d.kalshiPrice).toFixed(1)}\u00A2` : '\u2014'}
                    </div>
                  </div>

                  {/* Gap */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Gap</div>
                    <div style={{
                      fontFamily: fonts.mono, fontSize: 14, fontWeight: 700,
                      color: gap != null && gap >= 10 ? C.green : gap != null && gap >= 5 ? C.amber : C.creamSoft,
                    }}>
                      {gap != null ? `${gap.toFixed(1)}pt` : '\u2014'}
                    </div>
                  </div>

                  {/* Direction */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Dir</div>
                    <div style={{
                      fontFamily: fonts.mono, fontSize: 11, fontWeight: 600,
                      color: d.direction === 'UNDERPRICED' ? C.green : d.direction === 'OVERPRICED' ? C.red : C.creamSoft,
                    }}>
                      {d.direction || '\u2014'}
                    </div>
                  </div>

                  {/* Status pill */}
                  <div>{gapPill(gap)}</div>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            borderRadius: 8,
            padding: '32px 24px',
            textAlign: 'center',
          }}>
            <div style={{ fontFamily: fonts.mono, fontSize: 13, color: C.creamSoft, marginBottom: 6 }}>
              No active divergences
            </div>
            <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
              Gaps typically appear 2-3 times per day.
            </div>
          </div>
        )}
      </Panel>

      {/* Matched Pairs */}
      <Panel title="Matched Pairs" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {pairList.length} pairs
        </span>
      }>
        {pairsError && <ErrorCard message="Failed to load pairs" />}
        {pairList.length > 0 ? (
          <DataTable
            columns={[
              {
                key: 'polymarketQuestion',
                label: 'Polymarket Question',
                render: (r) => (
                  <span style={{
                    fontFamily: fonts.mono, fontSize: 11, color: C.cream,
                    display: 'block', maxWidth: 280, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                  }}>
                    {r.polymarketQuestion || r.question || '\u2014'}
                  </span>
                ),
              },
              {
                key: 'kalshiTitle',
                label: 'Kalshi Title',
                render: (r) => (
                  <span style={{
                    fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft,
                    display: 'block', maxWidth: 260, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                  }}>
                    {r.kalshiTitle || r.kalshiTicker || '\u2014'}
                  </span>
                ),
              },
              {
                key: 'matchConfidence',
                label: 'Match Conf.',
                render: (r) => {
                  const conf = r.matchConfidence != null ? Number(r.matchConfidence) : null;
                  if (conf == null) return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  const display = conf <= 1 ? (conf * 100).toFixed(0) : conf.toFixed(0);
                  return (
                    <span style={{
                      fontFamily: fonts.mono, fontSize: 11, fontWeight: 600,
                      color: Number(display) >= 80 ? C.green : Number(display) >= 60 ? C.amber : C.creamMuted,
                    }}>
                      {display}%
                    </span>
                  );
                },
              },
              {
                key: 'latestGap',
                label: 'Latest Gap',
                render: (r) => {
                  const gap = r.latestGap != null ? Number(r.latestGap) : null;
                  if (gap == null) return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  return (
                    <span style={{
                      fontFamily: fonts.mono, fontSize: 11, fontWeight: 600,
                      color: gap >= 10 ? C.green : gap >= 5 ? C.amber : C.creamSoft,
                    }}>
                      {gap.toFixed(1)}pt
                    </span>
                  );
                },
              },
            ]}
            rows={pairList}
          />
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No matched pairs found
          </div>
        )}
      </Panel>
    </div>
  );
}
