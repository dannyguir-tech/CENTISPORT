/** Page 10: Performance — P&L, signal quality, shadow tracking, category analysis */
import { C, fonts, getScoreColor, formatUsd, formatPct, formatPctRaw, relativeTime, getCatColor, pnlColor, pnlSign } from '../utils/theme';
import { usePolling, useApi } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, ProgressBar, DataTable, Loading, ErrorCard } from '../components/shared';

const SIGNAL_TYPES = ['insider', 'dumb_money_fade', 'convergence', 'cross_platform', 'consensus'];

function signalLabel(key) {
  const labels = {
    insider: 'Insider',
    dumb_money_fade: 'Dumb Money Fade',
    convergence: 'Convergence',
    cross_platform: 'Cross-Platform',
    consensus: 'Consensus',
  };
  return labels[key] || key?.replace(/_/g, ' ')?.toUpperCase() || '\u2014';
}

function signalBorderColor(key) {
  const colors = {
    insider: C.amber,
    dumb_money_fade: C.pink,
    convergence: C.cyan,
    cross_platform: C.purple,
    consensus: C.green,
  };
  return colors[key] || C.border;
}

export default function Performance() {
  const { data: weekly, loading: wLoading, error: wError } = useApi('/reports/weekly');
  const { data: monthly, loading: mLoading } = useApi('/reports/monthly');
  const { data: shadow, loading: sLoading } = useApi('/shadow-tracking?days=30');

  if (wLoading && !weekly) return <Loading />;
  if (wError && !weekly) return <ErrorCard message="Failed to load performance data" />;

  const w = weekly || {};
  const pnlBySource = w.pnlBySource || {};
  const countBySource = w.countBySource || {};
  const winRateBySource = w.winRateBySource || {};
  const pnlByCategory = w.pnlByCategory || {};

  // Compute category max for proportional bars
  const catEntries = Object.entries(pnlByCategory);
  const catAbsMax = catEntries.length > 0 ? Math.max(...catEntries.map(([, v]) => Math.abs(Number(v) || 0)), 1) : 1;

  // Shadow savings/cost calculation
  const shadowSavings = shadow ? (shadow.actual_pnl != null && shadow.all_signals_pnl != null
    ? Number(shadow.actual_pnl) - Number(shadow.all_signals_pnl)
    : null) : null;
  const netMissed = shadow?.missed_opportunity != null ? Number(shadow.missed_opportunity) : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Header */}
      <div style={{ marginBottom: 4 }}>
        <h2 style={{ fontFamily: fonts.mono, fontSize: 16, fontWeight: 700, letterSpacing: 2, margin: 0, color: C.green, textTransform: 'uppercase' }}>
          PERFORMANCE
        </h2>
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 4 }}>
          Comprehensive P&L and signal quality analysis
        </div>
      </div>

      {/* Top 4 Metric Tiles */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        <MetricTile
          label="Total P&L"
          value={pnlSign(w.totalPnl)}
          color={pnlColor(w.totalPnl)}
        />
        <MetricTile
          label="Trades"
          value={w.tradesTotal != null ? String(w.tradesTotal) : '\u2014'}
          sub={w.wins != null && w.losses != null ? `${w.wins}W - ${w.losses}L` : undefined}
        />
        <MetricTile
          label="Win Rate"
          value={w.winRate != null ? `${(Number(w.winRate) * 100).toFixed(1)}%` : '\u2014'}
          color={w.winRate != null && Number(w.winRate) >= 0.55 ? C.green : w.winRate != null && Number(w.winRate) >= 0.45 ? C.amber : w.winRate != null ? C.red : undefined}
        />
        <MetricTile
          label="Avg Per Trade"
          value={pnlSign(w.avgPnlPerTrade)}
          color={pnlColor(w.avgPnlPerTrade)}
        />
      </div>

      {/* By Signal Type */}
      <Panel title="By Signal Type">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 10 }}>
          {SIGNAL_TYPES.map((key) => {
            const pnl = pnlBySource[key];
            const count = countBySource[key];
            const winRate = winRateBySource[key];
            const hasSomeData = pnl != null || count != null;
            return (
              <div
                key={key}
                style={{
                  background: C.card,
                  border: `1px solid ${hasSomeData ? `${signalBorderColor(key)}33` : C.border}`,
                  borderRadius: 8,
                  padding: '14px 16px',
                  borderLeft: `3px solid ${signalBorderColor(key)}`,
                }}
              >
                <div style={{
                  fontFamily: fonts.mono, fontSize: 10, fontWeight: 600, color: signalBorderColor(key),
                  textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8,
                }}>
                  {signalLabel(key)}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>TRADES</span>
                    <span style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 700, color: C.cream }}>
                      {count != null ? count : '\u2014'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>P&L</span>
                    <span style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 700, color: pnlColor(pnl) }}>
                      {pnl != null ? pnlSign(pnl) : '\u2014'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>WIN RATE</span>
                    <span style={{
                      fontFamily: fonts.mono, fontSize: 13, fontWeight: 700,
                      color: winRate != null && Number(winRate) >= 0.55 ? C.green : winRate != null && Number(winRate) >= 0.45 ? C.amber : winRate != null ? C.red : C.creamMuted,
                    }}>
                      {winRate != null ? `${(Number(winRate) * 100).toFixed(0)}%` : '\u2014'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      {/* Shadow Tracking */}
      <Panel title="Shadow Tracking" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>30 days</span>
      }>
        {sLoading && !shadow ? (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 12 }}>Loading shadow data...</div>
        ) : shadow ? (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 14 }}>
              <MetricTile
                label="Execution Rate"
                value={shadow.execution_rate != null ? `${(Number(shadow.execution_rate) * 100).toFixed(0)}%` : '\u2014'}
                sub={shadow.taken != null && shadow.total_signals != null ? `${shadow.taken}/${shadow.total_signals} signals` : undefined}
              />
              <MetricTile
                label="Actual P&L"
                value={shadow.actual_pnl != null ? pnlSign(shadow.actual_pnl) : '\u2014'}
                color={pnlColor(shadow.actual_pnl)}
              />
              <MetricTile
                label="All-Signals P&L"
                value={shadow.all_signals_pnl != null ? pnlSign(shadow.all_signals_pnl) : '\u2014'}
                color={pnlColor(shadow.all_signals_pnl)}
              />
              <MetricTile
                label="Missed Opportunity"
                value={netMissed != null ? pnlSign(netMissed) : '\u2014'}
                color={C.amber}
              />
              <MetricTile
                label="Net Missed"
                value={shadow.net_missed != null ? pnlSign(shadow.net_missed) : (netMissed != null ? pnlSign(netMissed) : '\u2014')}
                color={shadow.net_missed != null ? pnlColor(shadow.net_missed) : (netMissed != null ? pnlColor(netMissed) : undefined)}
              />
            </div>
            {/* Savings/cost banner */}
            {shadowSavings != null && (
              <div style={{
                background: shadowSavings >= 0 ? C.greenDim : C.redDim,
                border: `1px solid ${shadowSavings >= 0 ? `${C.green}33` : `${C.red}33`}`,
                borderRadius: 8,
                padding: '10px 16px',
                fontFamily: fonts.mono,
                fontSize: 12,
                color: shadowSavings >= 0 ? C.green : C.red,
                fontWeight: 600,
              }}>
                {shadowSavings >= 0
                  ? `Your filtering is saving you ${formatUsd(Math.abs(shadowSavings))}`
                  : `Your filtering is costing you ${formatUsd(Math.abs(shadowSavings))}`}
              </div>
            )}
          </>
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 12, textAlign: 'center' }}>
            No shadow tracking data available
          </div>
        )}
      </Panel>

      {/* By Category */}
      {catEntries.length > 0 && (
        <Panel title="By Category">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {catEntries.sort((a, b) => Math.abs(Number(b[1]) || 0) - Math.abs(Number(a[1]) || 0)).map(([cat, val]) => {
              const n = Number(val) || 0;
              const isPositive = n >= 0;
              const barWidthPct = Math.max((Math.abs(n) / catAbsMax) * 100, 4);
              const catColor = getCatColor(cat);
              return (
                <div key={cat} style={{
                  background: C.card,
                  border: `1px solid ${C.border}`,
                  borderRadius: 6,
                  padding: '10px 14px',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: catColor }}>
                      {cat}
                    </span>
                    <span style={{ fontFamily: fonts.mono, fontSize: 12, fontWeight: 700, color: pnlColor(n) }}>
                      {pnlSign(n)}
                    </span>
                  </div>
                  <div style={{ width: '100%', height: 6, background: C.creamGhost, borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{
                      width: `${barWidthPct}%`,
                      height: '100%',
                      background: isPositive ? C.green : C.red,
                      borderRadius: 3,
                      transition: 'width 0.3s ease',
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
          {/* Summary sentence */}
          {catEntries.length >= 2 && (() => {
            const sorted = catEntries.sort((a, b) => Number(b[1] || 0) - Number(a[1] || 0));
            const best = sorted[0];
            const worst = sorted[sorted.length - 1];
            if (best && worst && Number(best[1]) > 0 && Number(worst[1]) < 0) {
              return (
                <div style={{
                  fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft, marginTop: 10,
                  padding: '8px 12px', background: C.card, borderRadius: 6, border: `1px solid ${C.border}`,
                }}>
                  You make money in {best[0]} ({pnlSign(best[1])}) but lose in {worst[0]} ({pnlSign(worst[1])})
                </div>
              );
            }
            return null;
          })()}
        </Panel>
      )}

      {/* Monthly Data */}
      {monthly && !mLoading && (
        <Panel title="Monthly Overview">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            <MetricTile
              label="Monthly P&L"
              value={monthly.totalPnl != null ? pnlSign(monthly.totalPnl) : '\u2014'}
              color={pnlColor(monthly.totalPnl)}
            />
            <MetricTile
              label="Monthly Trades"
              value={monthly.tradesTotal != null ? String(monthly.tradesTotal) : '\u2014'}
              sub={monthly.wins != null && monthly.losses != null ? `${monthly.wins}W - ${monthly.losses}L` : undefined}
            />
            <MetricTile
              label="Monthly Win Rate"
              value={monthly.winRate != null ? `${(Number(monthly.winRate) * 100).toFixed(1)}%` : '\u2014'}
              color={monthly.winRate != null && Number(monthly.winRate) >= 0.55 ? C.green : monthly.winRate != null ? C.amber : undefined}
            />
            <MetricTile
              label="Monthly Avg/Trade"
              value={monthly.avgPnlPerTrade != null ? pnlSign(monthly.avgPnlPerTrade) : '\u2014'}
              color={pnlColor(monthly.avgPnlPerTrade)}
            />
          </div>
          {/* Monthly signal breakdown if available */}
          {monthly.pnlBySource && Object.keys(monthly.pnlBySource).length > 0 && (
            <div style={{ marginTop: 12 }}>
              <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 8 }}>
                Monthly by signal
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {Object.entries(monthly.pnlBySource).map(([src, pnl]) => (
                  <div key={src} style={{
                    background: C.card, border: `1px solid ${C.border}`, borderRadius: 6,
                    padding: '6px 12px', display: 'flex', gap: 8, alignItems: 'center',
                  }}>
                    <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase' }}>{src.replace(/_/g, ' ')}</span>
                    <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 700, color: pnlColor(pnl) }}>{pnlSign(pnl)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Panel>
      )}
    </div>
  );
}
