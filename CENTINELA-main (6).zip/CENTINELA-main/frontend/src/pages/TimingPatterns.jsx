/** Page 14: Insider Timing Patterns — 24-hour clock visualization per wallet */
import { useState, useMemo } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, getCatColor, pnlColor } from '../utils/theme';
import { useApi, usePolling } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, SidePill, Loading, ErrorCard } from '../components/shared';

/* ── helpers ───────────────────────────────────────────────────────── */

function formatHour(h) {
  if (h === 0) return '12am';
  if (h < 12) return `${h}am`;
  if (h === 12) return '12pm';
  return `${h - 12}pm`;
}

function formatHourRange(start, end) {
  return `${formatHour(start)}-${formatHour(end % 24)}`;
}

function safeNum(v) {
  if (v == null) return 0;
  const n = Number(v);
  return isNaN(n) ? 0 : n;
}

/* ── dropdown style ────────────────────────────────────────────────── */

const selectStyle = {
  background: C.card,
  border: `1px solid ${C.border}`,
  borderRadius: 6,
  padding: '8px 12px',
  color: C.cream,
  fontFamily: fonts.mono,
  fontSize: 12,
  outline: 'none',
  minWidth: 260,
  cursor: 'pointer',
};

/* ── component ─────────────────────────────────────────────────────── */

export default function TimingPatterns() {
  const [walletId, setWalletId] = useState('');

  /* fetch smart wallets for selector */
  const { data: wallets, loading: walletsLoading, error: walletsError } = useApi('/wallets');

  /* filter to smart wallets only */
  const smartWallets = useMemo(() => {
    if (!wallets || !Array.isArray(wallets)) return [];
    return wallets.filter(w => {
      const wt = (w.wallet_type || '').toLowerCase();
      const cls = (w.classification || '').toUpperCase();
      return wt === 'smart' || cls === 'SNIPER' || cls === 'MOMENTUM' || (safeNum(w.insiderScore ?? w.insider_score) >= 60 && cls !== 'DUMB_MONEY');
    });
  }, [wallets]);

  /* selected wallet info */
  const selectedWallet = useMemo(() => {
    if (!walletId || !smartWallets.length) return null;
    return smartWallets.find(w => {
      const addr = w.address || w.wallet_address || w.id;
      return String(addr) === String(walletId);
    });
  }, [walletId, smartWallets]);

  /* fetch trades for selected wallet */
  const tradesPath = walletId ? `/trades?wallet_id=${walletId}&limit=200` : null;
  const { data: trades, loading: tradesLoading, error: tradesError } = useApi(tradesPath || '/trades?limit=0', [walletId]);

  /* ── hourly analysis ────────────────────────────────────────────── */
  const hourlyData = useMemo(() => {
    if (!walletId || !trades || !Array.isArray(trades) || trades.length === 0) return null;

    /* init 24-hour buckets */
    const buckets = Array.from({ length: 24 }, (_, i) => ({
      hour: i,
      count: 0,
      totalSize: 0,
      wins: 0,
      total: 0,
    }));

    for (const t of trades) {
      const ts = t.timestamp || t.created_at;
      if (!ts) continue;
      const d = new Date(ts);
      if (isNaN(d.getTime())) continue;
      const hour = d.getUTCHours();
      buckets[hour].count += 1;
      buckets[hour].totalSize += safeNum(t.size ?? t.amount ?? t.trade_size);
      buckets[hour].total += 1;
      const outcome = t.outcome || t.result || '';
      const pnl = safeNum(t.pnl ?? t.profit);
      if (outcome === 'win' || outcome === 'won' || pnl > 0) {
        buckets[hour].wins += 1;
      }
    }

    /* compute per-bucket stats */
    const maxCount = Math.max(...buckets.map(b => b.count), 1);
    const processed = buckets.map(b => ({
      ...b,
      avgSize: b.count > 0 ? b.totalSize / b.count : 0,
      winRate: b.total > 0 ? b.wins / b.total : 0,
      intensity: b.count / maxCount,
    }));

    /* find peak hours */
    const sorted = [...processed].sort((a, b) => b.count - a.count);
    const peakHour = sorted[0].hour;
    /* find contiguous peak block */
    let peakStart = peakHour;
    let peakEnd = (peakHour + 1) % 24;
    /* expand while adjacent hours have significant activity */
    const threshold = maxCount * 0.5;
    let back = (peakHour - 1 + 24) % 24;
    while (processed[back].count >= threshold && back !== peakEnd) {
      peakStart = back;
      back = (back - 1 + 24) % 24;
    }
    let fwd = (peakHour + 1) % 24;
    while (processed[fwd].count >= threshold && fwd !== peakStart) {
      peakEnd = (fwd + 1) % 24;
      fwd = (fwd + 1) % 24;
    }

    return {
      buckets: processed,
      maxCount,
      peakStart,
      peakEnd,
      totalTrades: trades.length,
    };
  }, [trades, walletId]);

  /* ── grouped hour ranges for table ─────────────────────────────── */
  const hourRanges = useMemo(() => {
    if (!hourlyData) return [];
    const ranges = [];
    for (let i = 0; i < 24; i += 3) {
      const slice = hourlyData.buckets.slice(i, i + 3);
      const count = slice.reduce((s, b) => s + b.count, 0);
      const totalSize = slice.reduce((s, b) => s + b.totalSize, 0);
      const wins = slice.reduce((s, b) => s + b.wins, 0);
      const total = slice.reduce((s, b) => s + b.total, 0);
      ranges.push({
        label: formatHourRange(i, i + 3),
        count,
        avgSize: count > 0 ? totalSize / count : 0,
        winRate: total > 0 ? wins / total : 0,
      });
    }
    return ranges;
  }, [hourlyData]);

  /* ── loading / error ────────────────────────────────────────────── */
  if (walletsLoading && !wallets) return <Loading />;
  if (walletsError && !wallets) return <ErrorCard message={walletsError} />;

  /* ── render ─────────────────────────────────────────────────────── */
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* ── Wallet selector ──────────────────────────────────────── */}
      <Panel title="INSIDER TIMING PATTERNS">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <label style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Smart Wallet
          </label>
          <select
            value={walletId}
            onChange={e => setWalletId(e.target.value)}
            style={selectStyle}
          >
            <option value="" style={{ background: C.card, color: C.creamMuted }}>-- Select a smart wallet --</option>
            {smartWallets.map(w => {
              const addr = w.address || w.wallet_address || w.id;
              const name = w.handle || (addr ? String(addr).slice(0, 14) : '?');
              const score = Math.round(safeNum(w.insiderScore ?? w.insider_score));
              return (
                <option key={addr} value={addr} style={{ background: C.card, color: C.cream }}>
                  {name} ({score})
                </option>
              );
            })}
          </select>
          {selectedWallet && (
            <RingGauge
              value={safeNum(selectedWallet.insiderScore ?? selectedWallet.insider_score)}
              size={36}
              color={getScoreColor(safeNum(selectedWallet.insiderScore ?? selectedWallet.insider_score))}
              label={String(Math.round(safeNum(selectedWallet.insiderScore ?? selectedWallet.insider_score)))}
            />
          )}
        </div>
      </Panel>

      {/* ── Empty state ──────────────────────────────────────────── */}
      {!walletId && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '50px 20px',
            fontFamily: fonts.mono,
            fontSize: 13,
            color: C.creamMuted,
            letterSpacing: 0.5,
          }}>
            Select a wallet to see timing patterns
          </div>
        </Panel>
      )}

      {/* ── Loading trades ───────────────────────────────────────── */}
      {walletId && tradesLoading && !trades && <Loading />}
      {walletId && tradesError && !trades && <ErrorCard message={tradesError} />}

      {/* ── 24-Hour bar chart ────────────────────────────────────── */}
      {walletId && hourlyData && (
        <>
          <Panel title="24-HOUR ACTIVITY (UTC)">
            {/* Bar chart */}
            <div style={{
              display: 'flex',
              alignItems: 'flex-end',
              gap: 2,
              height: 140,
              padding: '0 4px',
              marginBottom: 8,
            }}>
              {hourlyData.buckets.map((b, i) => {
                const barHeight = Math.max(b.intensity * 120, b.count > 0 ? 6 : 2);
                const isPeak = b.count === hourlyData.maxCount;
                const opacity = Math.max(0.15, b.intensity);

                return (
                  <div
                    key={i}
                    style={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: 4,
                    }}
                    title={`${formatHour(i)}: ${b.count} trades, WR ${(b.winRate * 100).toFixed(0)}%`}
                  >
                    {/* trade count label */}
                    {b.count > 0 && (
                      <span style={{
                        fontFamily: fonts.mono,
                        fontSize: 8,
                        color: isPeak ? C.green : C.creamMuted,
                        fontWeight: isPeak ? 700 : 400,
                      }}>
                        {b.count}
                      </span>
                    )}
                    {/* bar */}
                    <div style={{
                      width: '100%',
                      height: barHeight,
                      borderRadius: 2,
                      background: isPeak
                        ? C.green
                        : b.count > 0
                          ? `rgba(0,255,170,${opacity})`
                          : C.creamGhost,
                      transition: 'height 0.3s ease',
                    }} />
                  </div>
                );
              })}
            </div>

            {/* Hour labels */}
            <div style={{
              display: 'flex',
              gap: 2,
              padding: '0 4px',
            }}>
              {hourlyData.buckets.map((b, i) => (
                <div key={i} style={{
                  flex: 1,
                  textAlign: 'center',
                  fontFamily: fonts.mono,
                  fontSize: 7,
                  color: C.creamMuted,
                }}>
                  {i % 3 === 0 ? formatHour(i) : ''}
                </div>
              ))}
            </div>

            {/* Peak label */}
            <div style={{
              marginTop: 12,
              fontFamily: fonts.mono,
              fontSize: 11,
              color: C.creamSoft,
              textAlign: 'center',
              padding: '8px 12px',
              background: C.greenDim,
              borderRadius: 6,
              border: `1px solid ${C.green}33`,
            }}>
              Most active:{' '}
              <span style={{ color: C.green, fontWeight: 700 }}>
                {formatHourRange(hourlyData.peakStart, hourlyData.peakEnd)} UTC
              </span>
            </div>
          </Panel>

          {/* ── Distribution table ───────────────────────────────── */}
          <Panel title="TRADE DISTRIBUTION">
            <div style={{ overflowX: 'auto' }}>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontFamily: fonts.mono,
                fontSize: 12,
              }}>
                <thead>
                  <tr>
                    {['Hour Range', 'Trades', 'Avg Size', 'Win Rate'].map(h => (
                      <th key={h} style={{
                        textAlign: h === 'Hour Range' ? 'left' : 'right',
                        padding: '8px 10px',
                        borderBottom: `1px solid ${C.border}`,
                        color: C.creamMuted,
                        fontWeight: 500,
                        fontSize: 10,
                        textTransform: 'uppercase',
                        letterSpacing: 1,
                      }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {hourRanges.map((r, i) => {
                    const isHot = r.count >= hourlyData.totalTrades * 0.15;
                    return (
                      <tr key={i} style={{
                        borderBottom: `1px solid ${C.border}`,
                        background: isHot ? C.greenDim : 'transparent',
                      }}>
                        <td style={{ padding: '8px 10px', color: C.creamSoft, fontWeight: isHot ? 700 : 400 }}>
                          {r.label}
                        </td>
                        <td style={{ padding: '8px 10px', textAlign: 'right', color: isHot ? C.green : C.creamSoft, fontWeight: isHot ? 700 : 400 }}>
                          {r.count}
                        </td>
                        <td style={{ padding: '8px 10px', textAlign: 'right', color: C.creamSoft }}>
                          {formatUsd(r.avgSize)}
                        </td>
                        <td style={{
                          padding: '8px 10px',
                          textAlign: 'right',
                          color: r.winRate >= 0.6 ? C.green : r.winRate >= 0.4 ? C.amber : r.count > 0 ? C.red : C.creamMuted,
                          fontWeight: 600,
                        }}>
                          {r.count > 0 ? `${(r.winRate * 100).toFixed(0)}%` : '\u2014'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>

          {/* ── Summary ──────────────────────────────────────────── */}
          <Panel title="SUMMARY">
            <div style={{
              fontFamily: fonts.mono,
              fontSize: 12,
              color: C.creamSoft,
              padding: '10px 14px',
              background: C.card,
              border: `1px solid ${C.border}`,
              borderRadius: 6,
              lineHeight: 1.8,
            }}>
              <span style={{ color: C.cream, fontWeight: 700 }}>
                {selectedWallet ? (selectedWallet.handle || String(walletId).slice(0, 12)) : walletId}
              </span>
              {' '}trades most between{' '}
              <span style={{ color: C.green, fontWeight: 700 }}>
                {formatHourRange(hourlyData.peakStart, hourlyData.peakEnd)} UTC
              </span>.
              <br />
              Total trades analyzed:{' '}
              <span style={{ color: C.cream, fontWeight: 600 }}>{hourlyData.totalTrades}</span>.
              {' '}Peak hour:{' '}
              <span style={{ color: C.green, fontWeight: 600 }}>
                {formatHour(hourlyData.buckets.reduce((best, b) => b.count > (hourlyData.buckets[best]?.count || 0) ? b.hour : best, 0))} UTC
              </span>
              {' '}with{' '}
              <span style={{ color: C.green, fontWeight: 600 }}>{hourlyData.maxCount}</span> trades.
            </div>
          </Panel>
        </>
      )}

      {/* ── No trades ────────────────────────────────────────────── */}
      {walletId && !tradesLoading && !hourlyData && trades && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '30px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
          }}>
            No trades found for this wallet
          </div>
        </Panel>
      )}
    </div>
  );
}
