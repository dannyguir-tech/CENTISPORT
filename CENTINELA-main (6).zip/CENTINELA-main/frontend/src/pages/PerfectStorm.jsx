/** Page 8: Perfect Storm Detector — only signals where 3+ edges align simultaneously */
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, pnlColor, pnlSign } from '../utils/theme';
import { usePolling } from '../hooks/useApi';
import { RingGauge, PillBadge, Panel, MetricTile, ProgressBar, SidePill, Loading, ErrorCard } from '../components/shared';

/* ---------- helpers ---------- */

function recommendAction(score) {
  if (score >= 90) return { text: 'STRONG ENTRY \u2014 Full size', color: C.green };
  if (score >= 75) return { text: 'ENTRY \u2014 Standard size', color: C.cyan };
  if (score >= 60) return { text: 'CAUTIOUS ENTRY \u2014 Half size', color: C.amber };
  return { text: 'MONITOR \u2014 Wait for confirmation', color: C.creamMuted };
}

function getEdgeChecks(item) {
  const smartWallets = item.smartWalletIds ?? item.smart_wallet_ids ?? [];
  const smartNames = item.smartWalletNames ?? item.smart_wallet_names ?? [];
  const dumbWallets = item.dumbWalletIds ?? item.dumb_wallet_ids ?? [];
  const smartSide = item.smartSide ?? item.smart_side ?? 'YES';
  const dumbSide = item.dumbSide ?? item.dumb_side ?? (smartSide === 'YES' ? 'NO' : 'YES');
  const gap = item.crossPlatformGap ?? item.cross_platform_gap ?? null;

  const edges = [];

  // Edge 1: Smart money
  const hasSmartMoney = smartWallets.length > 0;
  const smartLabel = smartNames.length > 0
    ? smartNames.join(', ')
    : `${smartWallets.length} wallet${smartWallets.length !== 1 ? 's' : ''}`;
  edges.push({
    confirmed: hasSmartMoney,
    label: `Smart money: ${hasSmartMoney ? smartLabel : 'none detected'}`,
    detail: hasSmartMoney ? `on ${smartSide}` : null,
  });

  // Edge 2: Dumb money on opposite side
  const hasDumbMoney = dumbWallets.length > 0;
  edges.push({
    confirmed: hasDumbMoney,
    label: `Dumb money: ${hasDumbMoney ? `${dumbWallets.length} wallet${dumbWallets.length !== 1 ? 's' : ''}` : 'none detected'}`,
    detail: hasDumbMoney ? `on opposite side (${dumbSide})` : null,
  });

  // Edge 3: Cross-platform gap
  const hasGap = gap != null && Math.abs(Number(gap)) > 0;
  edges.push({
    confirmed: hasGap,
    label: `Cross-platform: ${hasGap ? `+${Math.abs(Number(gap)).toFixed(0)}pt gap confirming` : 'no gap detected'}`,
    detail: null,
  });

  return edges;
}

/* ---------- Perfect Storm Card ---------- */

function PerfectStormCard({ item }) {
  const marketName = item.marketName ?? item.market_name ?? 'Unknown';
  const smartSide = item.smartSide ?? item.smart_side ?? 'YES';
  const totalEdges = item.totalEdgeSources ?? item.total_edge_sources ?? 0;
  const combinedScore = item.smartCombinedScore ?? item.smart_combined_score ?? item.combinedScore ?? item.combined_score ?? 0;
  const ts = item.timestamp ?? item.created_at ?? item.createdAt ?? null;
  const edges = getEdgeChecks(item);
  const action = recommendAction(combinedScore);
  const scoreColor = getScoreColor(combinedScore);

  return (
    <div style={{
      background: C.card,
      border: `1px solid ${C.green}50`,
      borderRadius: 12,
      padding: 22,
      marginBottom: 14,
      boxShadow: `0 0 20px ${C.green}12, inset 0 1px 0 ${C.green}15`,
    }}>
      {/* Row 1: Market name (large) + side */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <span style={{
          fontFamily: fonts.mono,
          fontWeight: 700,
          fontSize: 18,
          color: C.cream,
          letterSpacing: 0.5,
        }}>
          {marketName}
        </span>
        <SidePill side={smartSide} />
        <PillBadge text={`${totalEdges} EDGES`} color={C.green} />
      </div>

      {/* Row 2: Edge alignment display + gauge */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr auto',
        gap: 20,
        alignItems: 'start',
        marginBottom: 14,
      }}>
        {/* Edge checklist */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {edges.map((edge, i) => (
            <div key={i} style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: 8,
              fontFamily: fonts.mono,
              fontSize: 11,
            }}>
              <span style={{
                color: edge.confirmed ? C.green : C.creamMuted,
                fontSize: 13,
                lineHeight: '16px',
                flexShrink: 0,
              }}>
                {edge.confirmed ? '\u2705' : '\u25CB'}
              </span>
              <span style={{ color: edge.confirmed ? C.creamSoft : C.creamMuted }}>
                {edge.label}
                {edge.detail && (
                  <span style={{ color: edge.confirmed ? C.green : C.creamMuted, marginLeft: 4 }}>
                    {edge.detail}
                  </span>
                )}
              </span>
            </div>
          ))}
        </div>

        {/* Large conviction gauge */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
          <RingGauge
            value={combinedScore}
            max={100}
            size={72}
            color={scoreColor}
            label={String(Math.round(combinedScore))}
          />
          <span style={{
            fontFamily: fonts.mono,
            fontSize: 8,
            color: C.creamMuted,
            textTransform: 'uppercase',
            letterSpacing: 1,
          }}>
            CONVICTION
          </span>
        </div>
      </div>

      {/* Row 3: Recommended action */}
      <div style={{
        background: `${action.color}10`,
        border: `1px solid ${action.color}25`,
        borderRadius: 6,
        padding: '8px 12px',
        fontFamily: fonts.mono,
        fontSize: 11,
        fontWeight: 600,
        color: action.color,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <span>{action.text}</span>
        {ts && (
          <span style={{ fontSize: 9, fontWeight: 400, color: C.creamMuted }}>
            {relativeTime(ts)}
          </span>
        )}
      </div>
    </div>
  );
}

/* ---------- Alert item ---------- */

function AlertItem({ alert }) {
  const marketName = alert.marketName ?? alert.market_name ?? alert.details?.marketName ?? 'Unknown';
  const ts = alert.timestamp ?? alert.created_at ?? alert.createdAt ?? null;
  const msg = alert.message ?? alert.description ?? '';

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 0',
      borderBottom: `1px solid ${C.border}`,
      fontFamily: fonts.mono,
      fontSize: 11,
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: C.green,
        boxShadow: `0 0 6px ${C.green}`,
        flexShrink: 0,
      }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <span style={{ color: C.cream, fontWeight: 600 }}>{marketName}</span>
        {msg && <span style={{ color: C.creamMuted, marginLeft: 6 }}>{msg}</span>}
      </div>
      {ts && (
        <span style={{ color: C.creamMuted, fontSize: 9, flexShrink: 0 }}>
          {relativeTime(ts)}
        </span>
      )}
    </div>
  );
}

/* ---------- Main page ---------- */

export default function PerfectStorm() {
  const { data: convergence, loading: convLoad, error: convErr } = usePolling('/convergence?limit=20', 30000);
  const { data: alerts, loading: alertLoad, error: alertErr } = usePolling('/alerts?type=convergence&limit=20', 30000);

  if (convLoad && !convergence) return <Loading />;

  const allConv = Array.isArray(convergence) ? convergence : [];
  const perfectStorms = allConv.filter((item) => {
    const edges = item.totalEdgeSources ?? item.total_edge_sources ?? 0;
    return edges >= 3;
  });
  const alertArr = Array.isArray(alerts) ? alerts : [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Header with glowing green border */}
      <div style={{
        background: `linear-gradient(135deg, ${C.green}08 0%, ${C.panel} 50%, ${C.green}05 100%)`,
        border: `1px solid ${C.green}40`,
        borderRadius: 12,
        padding: '20px 24px',
        boxShadow: `0 0 30px ${C.green}10`,
      }}>
        <h1 style={{
          fontFamily: fonts.mono,
          fontSize: 20,
          fontWeight: 700,
          color: C.green,
          margin: 0,
          letterSpacing: 2,
          textTransform: 'uppercase',
          textShadow: `0 0 20px ${C.green}40`,
        }}>
          PERFECT STORM DETECTOR
        </h1>
        <p style={{
          fontFamily: fonts.mono,
          fontSize: 12,
          color: C.creamSoft,
          margin: '8px 0 0 0',
          letterSpacing: 0.3,
        }}>
          Trades where 3+ independent edges align simultaneously
        </p>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          marginTop: 12,
        }}>
          <MetricTile
            label="ACTIVE STORMS"
            value={perfectStorms.length}
            color={perfectStorms.length > 0 ? C.green : C.creamMuted}
          />
        </div>
      </div>

      {/* Error state */}
      {convErr && <ErrorCard message={convErr} />}

      {/* Perfect storm cards */}
      {perfectStorms.length > 0 ? (
        <div>
          {perfectStorms.map((item, i) => (
            <PerfectStormCard key={item.id ?? i} item={item} />
          ))}
        </div>
      ) : (
        <Panel style={{
          border: `1px solid ${C.border}`,
          textAlign: 'center',
        }}>
          <div style={{
            padding: '40px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
            lineHeight: 1.8,
          }}>
            <div style={{ fontSize: 28, marginBottom: 12, opacity: 0.3 }}>{'\u26A1'}</div>
            <div style={{ marginBottom: 6 }}>No perfect storms detected.</div>
            <div style={{ fontSize: 11 }}>
              These are rare \u2014 typically 1\u20132 per week when all edges align.
            </div>
          </div>
        </Panel>
      )}

      {/* Recent perfect storm alerts */}
      {alertArr.length > 0 && (
        <Panel title="RECENT PERFECT STORM ALERTS">
          {alertArr.map((alert, i) => (
            <AlertItem key={alert.id ?? i} alert={alert} />
          ))}
        </Panel>
      )}
    </div>
  );
}
