/** Page 5: My Positions — live P&L, TP/SL proximity, build phase, insider holds, journal */
import { useState, useCallback } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, pnlColor, pnlSign } from '../utils/theme';
import { usePolling } from '../hooks/useApi';
import { apiPatch } from '../hooks/useApi';
import { RingGauge, PillBadge, Panel, MetricTile, ProgressBar, SidePill, Loading, ErrorCard } from '../components/shared';

/* ---------- helpers ---------- */

function tp1Progress(entry, current, tp1) {
  if (entry == null || current == null || tp1 == null) return 0;
  const range = tp1 - entry;
  if (range === 0) return 0;
  return Math.min(Math.max(((current - entry) / range) * 100, 0), 100);
}

function slDistance(current, sl) {
  if (current == null || sl == null) return null;
  return Math.abs(current - sl);
}

function buildPhaseLabel(phase) {
  if (phase === '100%' || phase === 1 || phase === '1') return { label: '100%', color: C.green };
  return { label: '50%', color: C.amber };
}

function insiderHoldsDisplay(pos) {
  if (pos.signalSource === 'dumb_money_fade' || pos.category === 'FADE') {
    return { dot: C.pink, text: 'N/A (FADE)' };
  }
  if (pos.insiderStillHolds === true) return { dot: C.green, text: 'HOLDS' };
  if (pos.insiderStillHolds === false) return { dot: C.creamMuted, text: 'EXITED' };
  return { dot: C.creamMuted, text: 'UNKNOWN' };
}

function convictionStars(level) {
  if (level == null) return null;
  const n = Math.min(Math.max(Number(level), 0), 5);
  if (isNaN(n)) return String(level);
  return '\u2605'.repeat(Math.round(n)) + '\u2606'.repeat(5 - Math.round(n));
}

/* ---------- Position card ---------- */

function PositionCard({ pos }) {
  const [journal, setJournal] = useState(pos.journal || '');
  const [saving, setSaving] = useState(false);

  const handleBlur = useCallback(async () => {
    if (journal === (pos.journal || '')) return;
    setSaving(true);
    await apiPatch(`/positions/${pos.id}/journal`, { journal });
    setSaving(false);
  }, [journal, pos.id, pos.journal]);

  const pnlVal = pos.unrealizedPnl ?? pos.pnl ?? null;
  const pnlPctVal = pos.pnlPct ?? null;
  const entryP = pos.entryPrice ?? pos.entry_price ?? null;
  const currentP = pos.currentPrice ?? pos.current_price ?? null;
  const tp1P = pos.tp1Price ?? pos.tp1_price ?? null;
  const slP = pos.slHardPrice ?? pos.sl_hard ?? pos.sl_hard_price ?? null;
  const slDist = slDistance(currentP, slP);
  const tp1Pct = tp1Progress(entryP, currentP, tp1P);
  const bp = buildPhaseLabel(pos.buildPhase ?? pos.build_phase);
  const ins = insiderHoldsDisplay(pos);
  const isResPlay = pos.is_resolution_play || pos.isResolutionPlay;

  return (
    <div style={{
      background: C.card,
      border: `1px solid ${C.border}`,
      borderRadius: 10,
      padding: 18,
      marginBottom: 10,
    }}>
      {/* row 1: name + badges */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span style={{ fontFamily: fonts.mono, fontWeight: 700, fontSize: 15, color: C.cream }}>{pos.marketName || pos.market_name || 'Unknown'}</span>
        <SidePill side={pos.side} />
        <PillBadge text={pos.signalSource || pos.signal_source || 'manual'} color={C.purple} />
        {isResPlay && <PillBadge text="RESOLUTION PLAY" color={C.cyan} />}
        <PillBadge text={bp.label} color={bp.color} />
      </div>

      {/* row 2: stats mini grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))',
        gap: 10,
        marginBottom: 12,
      }}>
        <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
          <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Entry</div>
          <span style={{ color: C.creamSoft }}>{entryP != null ? `$${Number(entryP).toFixed(2)}` : '\u2014'}</span>
        </div>
        <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
          <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Current</div>
          <span style={{ color: C.cream }}>{currentP != null ? `$${Number(currentP).toFixed(2)}` : '\u2014'}</span>
        </div>
        <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
          <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>Size</div>
          <span style={{ color: C.creamSoft }}>{formatUsd(pos.currentSize ?? pos.current_size ?? pos.size)}</span>
        </div>
        <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
          <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>P&L $</div>
          <span style={{ color: pnlColor(pnlVal), fontWeight: 700 }}>{pnlSign(pnlVal)}</span>
        </div>
        <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted }}>
          <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>P&L %</div>
          <span style={{ color: pnlColor(pnlPctVal), fontWeight: 700 }}>{pnlPctVal != null ? `${(Number(pnlPctVal) * 100).toFixed(1)}%` : '\u2014'}</span>
        </div>
      </div>

      {/* row 3: TP1 progress */}
      <div style={{ marginBottom: 10 }}>
        <ProgressBar
          value={tp1Pct}
          max={100}
          color={C.green}
          height={5}
          label={`TP1 Progress \u2014 ${tp1Pct.toFixed(0)}%${tp1P != null ? ` (target $${Number(tp1P).toFixed(2)})` : ''}`}
        />
      </div>

      {/* row 4: SL distance + insider + conviction */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 16, marginBottom: 10 }}>
        {/* SL distance */}
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          <span style={{ color: C.red }}>SL</span>{' '}
          {slP != null ? `$${Number(slP).toFixed(2)}` : '\u2014'}
          {slDist != null && (
            <span style={{ color: C.creamMuted, marginLeft: 4 }}>
              ({slDist.toFixed(2)} away)
            </span>
          )}
        </div>

        {/* Insider holds */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: fonts.mono, fontSize: 10 }}>
          <div style={{
            width: 7, height: 7, borderRadius: '50%',
            background: ins.dot,
            boxShadow: ins.dot !== C.creamMuted ? `0 0 5px ${ins.dot}` : 'none',
          }} />
          <span style={{ color: ins.dot }}>{ins.text}</span>
        </div>

        {/* Conviction */}
        {(pos.convictionLevel != null || pos.conviction_level != null) && (
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.amber }}>
            Conviction: {convictionStars(pos.convictionLevel ?? pos.conviction_level)}
          </div>
        )}
      </div>

      {/* row 5: journal */}
      <div style={{ position: 'relative' }}>
        <textarea
          value={journal}
          onChange={(e) => setJournal(e.target.value)}
          onBlur={handleBlur}
          placeholder="Quick journal note..."
          rows={2}
          style={{
            width: '100%',
            boxSizing: 'border-box',
            background: C.bg,
            border: `1px solid ${C.border}`,
            borderRadius: 6,
            padding: '8px 10px',
            fontFamily: fonts.mono,
            fontSize: 11,
            color: C.creamSoft,
            resize: 'vertical',
            outline: 'none',
          }}
        />
        {saving && (
          <span style={{
            position: 'absolute', top: 6, right: 10,
            fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted,
          }}>
            saving...
          </span>
        )}
      </div>
    </div>
  );
}

/* ---------- Main page ---------- */

export default function Positions() {
  const { data: positions, loading: posLoad, error: posErr } = usePolling('/positions', 10000);
  const { data: bankroll, loading: brLoad } = usePolling('/bankroll', 30000);

  if (posLoad && !positions) return <Loading />;
  if (posErr && !positions) return <ErrorCard message={posErr} />;

  const posArr = Array.isArray(positions) ? positions : [];
  const totalPnl = posArr.reduce((sum, p) => sum + (p.unrealizedPnl ?? p.pnl ?? 0), 0);
  const totalDeployed = posArr.reduce((sum, p) => sum + (p.currentSize ?? p.current_size ?? p.size ?? 0), 0);
  const maxPositions = bankroll?.maxPositions ?? bankroll?.max_positions ?? '\u2014';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Header metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        <MetricTile
          label="POSITIONS"
          value={`${posArr.length} / ${maxPositions}`}
        />
        <MetricTile
          label="UNREALIZED P&L"
          value={pnlSign(totalPnl)}
          color={pnlColor(totalPnl)}
        />
        <MetricTile
          label="TOTAL DEPLOYED"
          value={formatUsd(totalDeployed)}
        />
      </div>

      {/* Position cards */}
      {posArr.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {posArr.map((p) => (
            <PositionCard key={p.id ?? p.market_id ?? Math.random()} pos={p} />
          ))}
        </div>
      ) : (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '40px 20px',
            fontFamily: fonts.mono,
            fontSize: 13,
            color: C.creamMuted,
            letterSpacing: 0.5,
          }}>
            No open positions
          </div>
        </Panel>
      )}
    </div>
  );
}
