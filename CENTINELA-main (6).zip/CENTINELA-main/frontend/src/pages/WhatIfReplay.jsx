/** Page 15: What-If Replay — select a resolved market, replay what happened */
import { useState, useMemo } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, getCatColor, pnlColor } from '../utils/theme';
import { useApi, usePolling } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, SidePill, Loading, ErrorCard } from '../components/shared';

/* ── helpers ───────────────────────────────────────────────────────── */

function classifyWallet(trade) {
  const wt = (trade.wallet_type || trade.walletType || '').toLowerCase();
  const cls = (trade.classification || '').toUpperCase();
  if (wt === 'smart' || cls === 'SNIPER' || cls === 'MOMENTUM') return 'smart';
  if (wt === 'dumb' || cls === 'DUMB_MONEY') return 'dumb';
  return 'unknown';
}

function dotColor(type) {
  if (type === 'smart') return C.green;
  if (type === 'dumb') return C.pink;
  return C.creamMuted;
}

function formatTs(ts) {
  if (!ts) return '\u2014';
  const d = new Date(ts);
  if (isNaN(d.getTime())) return '\u2014';
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const mo = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${mo}/${dd} ${hh}:${mm}`;
}

function safeNum(v) {
  if (v == null) return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}

function formatHours(ms) {
  if (ms == null || isNaN(ms)) return '\u2014';
  const hours = ms / (1000 * 60 * 60);
  if (hours < 1) return `${Math.round(hours * 60)}m`;
  if (hours < 24) return `${hours.toFixed(1)}h`;
  return `${(hours / 24).toFixed(1)}d`;
}

/* ── dropdown style ────────────────────────────────────────────────── */

const selectStyle = {
  background: C.card,
  border: `1px solid ${C.border}`,
  borderRadius: 6,
  padding: '8px 12px',
  color: C.cream,
  fontFamily: fonts.mono,
  fontSize: 12,
  outline: 'none',
  minWidth: 260,
  cursor: 'pointer',
};

/* ── component ─────────────────────────────────────────────────────── */

export default function WhatIfReplay() {
  const [marketId, setMarketId] = useState('');

  /* fetch markets (prefer resolved, but accept all) */
  const { data: markets, loading: mktsLoading, error: mktsError } = useApi('/markets');

  /* filtered to resolved markets for display, but show all in dropdown */
  const resolvedMarkets = useMemo(() => {
    if (!markets || !Array.isArray(markets)) return [];
    return markets.filter(m => {
      const status = (m.status || m.state || '').toLowerCase();
      return status === 'resolved' || status === 'closed' || status === 'settled';
    });
  }, [markets]);

  /* all markets for fallback */
  const allMarkets = useMemo(() => {
    if (!markets || !Array.isArray(markets)) return [];
    return markets;
  }, [markets]);

  const displayMarkets = resolvedMarkets.length > 0 ? resolvedMarkets : allMarkets;

  /* fetch trades when market is selected */
  const tradesPath = marketId ? `/trades?market_id=${marketId}&limit=100` : null;
  const { data: trades, loading: tradesLoading, error: tradesError } = useApi(tradesPath || '/trades?limit=0', [marketId]);

  /* selected market object */
  const selectedMarket = useMemo(() => {
    if (!marketId || !allMarkets.length) return null;
    return allMarkets.find(m => String(m.id ?? m.market_id) === String(marketId));
  }, [marketId, allMarkets]);

  /* ── timeline + analysis ────────────────────────────────────────── */
  const timeline = useMemo(() => {
    if (!marketId || !trades || !Array.isArray(trades)) return [];
    return [...trades].sort((a, b) => {
      const ta = new Date(a.timestamp || a.created_at || 0).getTime();
      const tb = new Date(b.timestamp || b.created_at || 0).getTime();
      return ta - tb;
    });
  }, [trades, marketId]);

  const replay = useMemo(() => {
    if (!timeline.length) return null;

    /* find first smart money signal entry */
    let firstSignalIdx = -1;
    let firstSignalPrice = null;
    let firstSignalTs = null;
    let firstSignalSide = null;

    for (let i = 0; i < timeline.length; i++) {
      const t = timeline[i];
      if (classifyWallet(t) === 'smart') {
        firstSignalIdx = i;
        firstSignalPrice = safeNum(t.price ?? t.avg_price);
        firstSignalTs = new Date(t.timestamp || t.created_at || 0).getTime();
        firstSignalSide = (t.side || '').toUpperCase();
        break;
      }
    }

    /* find last trade for resolution proxy */
    const lastTrade = timeline[timeline.length - 1];
    const lastPrice = safeNum(lastTrade.price ?? lastTrade.avg_price);
    const lastTs = new Date(lastTrade.timestamp || lastTrade.created_at || 0).getTime();

    /* resolution price — from market data or last trade */
    const resolutionPrice = safeNum(
      selectedMarket?.resolution_price ??
      selectedMarket?.resolutionPrice ??
      selectedMarket?.final_price ??
      lastPrice
    );

    /* resolution outcome from market */
    const resolutionOutcome = selectedMarket?.resolution ??
      selectedMarket?.outcome ??
      selectedMarket?.resolution_outcome ??
      selectedMarket?.resolutionOutcome ??
      null;

    /* compute theoretical P&L */
    let theoreticalPnl = null;
    if (firstSignalPrice != null && firstSignalPrice > 0 && resolutionPrice != null) {
      if (firstSignalSide === 'YES') {
        theoreticalPnl = (resolutionPrice - firstSignalPrice) / firstSignalPrice;
      } else if (firstSignalSide === 'NO') {
        theoreticalPnl = (firstSignalPrice - resolutionPrice) / firstSignalPrice;
      } else {
        theoreticalPnl = (resolutionPrice - firstSignalPrice) / firstSignalPrice;
      }
    }

    /* hold time from signal to resolution */
    let holdTime = null;
    if (firstSignalTs && lastTs && lastTs > firstSignalTs) {
      holdTime = lastTs - firstSignalTs;
    }

    /* smart / dumb counts */
    const smartCount = timeline.filter(t => classifyWallet(t) === 'smart').length;
    const dumbCount = timeline.filter(t => classifyWallet(t) === 'dumb').length;

    return {
      firstSignalIdx,
      firstSignalPrice,
      firstSignalTs,
      firstSignalSide,
      resolutionPrice,
      resolutionOutcome,
      theoreticalPnl,
      holdTime,
      smartCount,
      dumbCount,
      totalTrades: timeline.length,
    };
  }, [timeline, selectedMarket]);

  /* ── loading / error ────────────────────────────────────────────── */
  if (mktsLoading && !markets) return <Loading />;
  if (mktsError && !markets) return <ErrorCard message={mktsError} />;

  /* ── render ─────────────────────────────────────────────────────── */
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* ── Market selector ──────────────────────────────────────── */}
      <Panel title="WHAT-IF REPLAY">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <label style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Resolved Market
          </label>
          <select
            value={marketId}
            onChange={e => setMarketId(e.target.value)}
            style={selectStyle}
          >
            <option value="" style={{ background: C.card, color: C.creamMuted }}>-- Select a resolved market --</option>
            {displayMarkets.map(m => {
              const id = m.id ?? m.market_id;
              const name = m.name ?? m.question ?? m.title ?? `Market #${id}`;
              const status = (m.status || m.state || '').toUpperCase();
              return (
                <option key={id} value={id} style={{ background: C.card, color: C.cream }}>
                  {name} [{status}]
                </option>
              );
            })}
          </select>
          {selectedMarket && (
            <div style={{ display: 'flex', gap: 6 }}>
              <PillBadge
                text={(selectedMarket.status || selectedMarket.state || 'UNKNOWN').toUpperCase()}
                color={C.cyan}
              />
              {(selectedMarket.category || selectedMarket.market_category) && (
                <PillBadge
                  text={selectedMarket.category || selectedMarket.market_category}
                  color={getCatColor(selectedMarket.category || selectedMarket.market_category)}
                />
              )}
            </div>
          )}
        </div>
      </Panel>

      {/* ── Empty state ──────────────────────────────────────────── */}
      {!marketId && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '50px 20px',
            fontFamily: fonts.mono,
            fontSize: 13,
            color: C.creamMuted,
            letterSpacing: 0.5,
          }}>
            Select a resolved market to replay
          </div>
        </Panel>
      )}

      {/* ── Loading trades ───────────────────────────────────────── */}
      {marketId && tradesLoading && !trades && <Loading />}
      {marketId && tradesError && !trades && <ErrorCard message={tradesError} />}

      {/* ── Outcome display ──────────────────────────────────────── */}
      {marketId && replay && (
        <Panel title="OUTCOME">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 14 }}>
            {replay.resolutionOutcome != null && (
              <MetricTile
                label="RESOLUTION"
                value={String(replay.resolutionOutcome).toUpperCase()}
                color={C.cyan}
              />
            )}
            {replay.firstSignalPrice != null && (
              <MetricTile
                label="FIRST SIGNAL PRICE"
                value={`$${replay.firstSignalPrice.toFixed(2)}`}
                color={C.green}
                sub={replay.firstSignalSide ? `Side: ${replay.firstSignalSide}` : undefined}
              />
            )}
            {replay.resolutionPrice != null && (
              <MetricTile
                label="RESOLUTION PRICE"
                value={`$${replay.resolutionPrice.toFixed(2)}`}
                color={C.cream}
              />
            )}
            {replay.holdTime != null && (
              <MetricTile
                label="HOLD TIME"
                value={formatHours(replay.holdTime)}
                color={C.creamSoft}
                sub="signal to resolution"
              />
            )}
            {replay.theoreticalPnl != null && (
              <MetricTile
                label="THEORETICAL P&L"
                value={`${replay.theoreticalPnl >= 0 ? '+' : ''}${(replay.theoreticalPnl * 100).toFixed(1)}%`}
                color={pnlColor(replay.theoreticalPnl)}
                sub="if entered at first signal"
              />
            )}
          </div>

          {/* What-if narrative */}
          {replay.firstSignalPrice != null && replay.resolutionPrice != null && (
            <div style={{
              fontFamily: fonts.mono,
              fontSize: 12,
              color: C.creamSoft,
              padding: '12px 14px',
              background: C.card,
              border: `1px solid ${C.border}`,
              borderRadius: 6,
              lineHeight: 1.8,
            }}>
              If you entered at{' '}
              <span style={{ color: C.green, fontWeight: 700 }}>
                ${replay.firstSignalPrice.toFixed(2)}
              </span>
              {' '}when the first signal fired
              {replay.firstSignalSide && (
                <span> ({replay.firstSignalSide})</span>
              )}
              , you would have{' '}
              <span style={{
                color: replay.theoreticalPnl != null && replay.theoreticalPnl >= 0 ? C.green : C.red,
                fontWeight: 700,
              }}>
                {replay.theoreticalPnl != null
                  ? `${replay.theoreticalPnl >= 0 ? 'made' : 'lost'} ${Math.abs(replay.theoreticalPnl * 100).toFixed(1)}%`
                  : 'seen an unknown return'}
              </span>
              {replay.holdTime != null && (
                <>
                  {' '}over{' '}
                  <span style={{ color: C.cream, fontWeight: 600 }}>
                    {formatHours(replay.holdTime)}
                  </span>
                </>
              )}.
            </div>
          )}
        </Panel>
      )}

      {/* ── Event timeline ───────────────────────────────────────── */}
      {marketId && timeline.length > 0 && (
        <Panel title="EVENT REPLAY">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {timeline.map((t, i) => {
              const type = classifyWallet(t);
              const ts = t.timestamp || t.created_at;
              const handle = t.handle || t.wallet_handle || (t.wallet_address ? t.wallet_address.slice(0, 10) : '\u2014');
              const side = (t.side || '').toUpperCase();
              const size = t.size ?? t.amount ?? t.trade_size ?? null;
              const price = t.price ?? t.avg_price ?? null;
              const isSmart = type === 'smart';
              const isDumb = type === 'dumb';
              const isFirstSignal = replay && replay.firstSignalIdx === i;

              return (
                <div
                  key={t.id ?? t.trade_id ?? i}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '90px 14px 1fr auto',
                    gap: 12,
                    alignItems: 'center',
                    padding: '10px 14px',
                    borderBottom: `1px solid ${C.border}`,
                    background: isFirstSignal
                      ? C.greenDim
                      : isSmart
                        ? `${C.green}08`
                        : isDumb
                          ? `${C.pink}08`
                          : 'transparent',
                    borderLeft: isFirstSignal
                      ? `3px solid ${C.green}`
                      : isSmart
                        ? `3px solid ${C.green}44`
                        : isDumb
                          ? `3px solid ${C.pink}44`
                          : '3px solid transparent',
                  }}
                >
                  {/* timestamp */}
                  <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, whiteSpace: 'nowrap' }}>
                    {formatTs(ts)}
                  </span>

                  {/* dot */}
                  <div style={{
                    width: 10,
                    height: 10,
                    borderRadius: '50%',
                    background: dotColor(type),
                    boxShadow: `0 0 6px ${dotColor(type)}`,
                    flexShrink: 0,
                  }} />

                  {/* trade info */}
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span style={{
                        fontFamily: fonts.mono,
                        fontSize: 12,
                        fontWeight: 600,
                        color: isSmart ? C.green : isDumb ? C.pink : C.cream,
                      }}>
                        {handle}
                      </span>
                      <SidePill side={side} />
                      {size != null && (
                        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamSoft }}>
                          {formatUsd(size)}
                        </span>
                      )}
                      <PillBadge
                        text={type === 'smart' ? 'SMART' : type === 'dumb' ? 'DUMB' : 'UNK'}
                        color={dotColor(type)}
                      />
                    </div>
                    {isFirstSignal && (
                      <div style={{
                        fontFamily: fonts.mono,
                        fontSize: 10,
                        fontWeight: 700,
                        color: C.green,
                        marginTop: 4,
                        letterSpacing: 1,
                        textTransform: 'uppercase',
                      }}>
                        FIRST SIGNAL
                      </div>
                    )}
                  </div>

                  {/* price */}
                  <span style={{
                    fontFamily: fonts.mono,
                    fontSize: 11,
                    color: C.creamSoft,
                    whiteSpace: 'nowrap',
                  }}>
                    {price != null ? `$${Number(price).toFixed(2)}` : '\u2014'}
                  </span>
                </div>
              );
            })}
          </div>
        </Panel>
      )}

      {/* ── Summary stats ────────────────────────────────────────── */}
      {marketId && replay && (
        <Panel title="REPLAY SUMMARY">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12 }}>
            <MetricTile
              label="TOTAL TRADES"
              value={replay.totalTrades}
            />
            <MetricTile
              label="SMART ENTRIES"
              value={replay.smartCount}
              color={C.green}
            />
            <MetricTile
              label="DUMB ENTRIES"
              value={replay.dumbCount}
              color={C.pink}
            />
            {replay.firstSignalPrice != null && (
              <MetricTile
                label="SIGNAL PRICE"
                value={`$${replay.firstSignalPrice.toFixed(2)}`}
                color={C.green}
              />
            )}
            {replay.resolutionPrice != null && (
              <MetricTile
                label="RESOLUTION PRICE"
                value={`$${replay.resolutionPrice.toFixed(2)}`}
                color={C.cyan}
              />
            )}
            {replay.holdTime != null && (
              <MetricTile
                label="TOTAL DURATION"
                value={formatHours(replay.holdTime)}
              />
            )}
            {replay.theoreticalPnl != null && (
              <MetricTile
                label="THEORETICAL RETURN"
                value={`${replay.theoreticalPnl >= 0 ? '+' : ''}${(replay.theoreticalPnl * 100).toFixed(1)}%`}
                color={pnlColor(replay.theoreticalPnl)}
              />
            )}
          </div>
        </Panel>
      )}

      {/* ── No trades ────────────────────────────────────────────── */}
      {marketId && !tradesLoading && timeline.length === 0 && trades && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '30px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
          }}>
            No trades found for this market
          </div>
        </Panel>
      )}
    </div>
  );
}
