/** Page 11: Market Intelligence — regimes, pre-signals, traps, polling tiers, detection health, heat map */
import { C, fonts, getScoreColor, formatUsd, formatPct, formatPctRaw, relativeTime, getCatColor, pnlColor, pnlSign } from '../utils/theme';
import { usePolling, useApi } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, ProgressBar, DataTable, Loading, ErrorCard } from '../components/shared';

const regimeColors = {
  HIGH_VOL: C.red, high_vol: C.red,
  LOW_VOL: C.green, low_vol: C.green,
  TRENDING: C.cyan, trending: C.cyan,
  MANIPULATED: C.purple, manipulated: C.purple,
};

function regimePill(regime) {
  const key = regime?.toUpperCase() || 'UNKNOWN';
  const color = regimeColors[regime] || regimeColors[key] || C.creamMuted;
  return <PillBadge text={key} color={color} />;
}

const actionColors = {
  invalidated: C.red,
  reduced: C.amber,
  deducted: C.amber,
  none: C.creamMuted,
};

function actionPill(action) {
  const key = action?.toLowerCase() || 'none';
  const color = actionColors[key] || C.creamMuted;
  return <PillBadge text={key.toUpperCase()} color={color} />;
}

function tierPill(tier) {
  const tierStr = typeof tier === 'number' ? `T${tier}` : (tier || '').toString().toUpperCase();
  const colors = { T1: C.green, T2: C.cyan, T3: C.amber, T4: C.creamMuted };
  const color = colors[tierStr] || C.creamMuted;
  return <PillBadge text={tierStr} color={color} />;
}

export default function Intelligence() {
  const { data: regimes, loading: rLoading } = usePolling('/regimes?limit=20', 30000);
  const { data: preSignals, loading: pLoading } = usePolling('/pre-signals?active_only=true&limit=15', 30000);
  const { data: traps, loading: tLoading } = usePolling('/trap-events?limit=15', 30000);
  const { data: polling } = useApi('/poll-priorities');
  const { data: health } = useApi('/detection-health');
  const { data: heatMap } = useApi('/heat-map');

  const isLoading = rLoading && !regimes;
  if (isLoading) return <Loading />;

  const regimeList = Array.isArray(regimes) ? regimes : [];
  const preSignalList = Array.isArray(preSignals) ? preSignals : [];
  const trapList = Array.isArray(traps) ? traps : [];
  const pollingList = Array.isArray(polling) ? polling : [];
  const heatMapList = Array.isArray(heatMap) ? heatMap : [];

  // Heat map intensity max
  const heatMaxVolume = heatMapList.length > 0 ? Math.max(...heatMapList.map((h) => Number(h.volume) || 0), 1) : 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Header */}
      <div style={{ marginBottom: 4 }}>
        <h2 style={{ fontFamily: fonts.mono, fontSize: 16, fontWeight: 700, letterSpacing: 2, margin: 0, color: C.green, textTransform: 'uppercase' }}>
          MARKET INTELLIGENCE
        </h2>
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 4 }}>
          Market microstructure and quant module output
        </div>
      </div>

      {/* 1. Market Regimes */}
      <Panel title="Market Regimes" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {regimeList.length} markets
        </span>
      }>
        {regimeList.length > 0 ? (
          <DataTable
            columns={[
              {
                key: 'marketId',
                label: 'Market ID',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.cream, maxWidth: 200, display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.marketId || '\u2014'}
                  </span>
                ),
              },
              {
                key: 'regime',
                label: 'Regime',
                render: (r) => regimePill(r.regime),
              },
              {
                key: 'confidence',
                label: 'Confidence',
                render: (r) => {
                  const conf = r.confidence != null ? Number(r.confidence) : null;
                  if (conf == null) return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  const pct = conf <= 1 ? (conf * 100).toFixed(0) : conf.toFixed(0);
                  return (
                    <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: Number(pct) >= 70 ? C.green : Number(pct) >= 50 ? C.amber : C.red }}>
                      {pct}%
                    </span>
                  );
                },
              },
              {
                key: 'chaseMult',
                label: 'Chase x',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft }}>
                    {r.chaseMult != null ? Number(r.chaseMult).toFixed(2) : '\u2014'}
                  </span>
                ),
              },
              {
                key: 'positionMult',
                label: 'Position x',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft }}>
                    {r.positionMult != null ? Number(r.positionMult).toFixed(2) : '\u2014'}
                  </span>
                ),
              },
              {
                key: 'minScoreAdj',
                label: 'Min Score Adj',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: r.minScoreAdj != null && Number(r.minScoreAdj) > 0 ? C.amber : C.creamSoft }}>
                    {r.minScoreAdj != null ? (Number(r.minScoreAdj) >= 0 ? '+' : '') + Number(r.minScoreAdj).toFixed(0) : '\u2014'}
                  </span>
                ),
              },
            ]}
            rows={regimeList}
          />
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No regime data available
          </div>
        )}
      </Panel>

      {/* 2. Pre-Signal Flags */}
      <Panel title="Pre-Signal Flags" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {preSignalList.length} active
        </span>
      }>
        {preSignalList.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 10 }}>
            {preSignalList.map((f, i) => {
              const conf = f.confidence != null ? Number(f.confidence) : null;
              const confPct = conf != null ? (conf <= 1 ? conf * 100 : conf) : 0;
              const isActive = f.active !== false;
              return (
                <div
                  key={f.id || i}
                  style={{
                    background: C.card,
                    border: `1px solid ${isActive ? `${C.cyan}44` : C.border}`,
                    borderRadius: 8,
                    padding: '14px 16px',
                  }}
                >
                  {/* Market name */}
                  <div style={{
                    fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: C.cream,
                    marginBottom: 10, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                  }}>
                    {f.marketName || f.market || '\u2014'}
                  </div>

                  {/* Confidence gauge + details */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <RingGauge
                      value={confPct}
                      max={100}
                      size={48}
                      color={confPct >= 70 ? C.green : confPct >= 50 ? C.amber : C.red}
                      label={`${Math.round(confPct)}`}
                    />
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>INSIDER ENTERED</span>
                        <span style={{
                          fontFamily: fonts.mono, fontSize: 10, fontWeight: 600,
                          color: f.insiderEnteredAfter ? C.green : C.creamMuted,
                        }}>
                          {f.insiderEnteredAfter ? 'YES' : 'NO'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>WAS USEFUL</span>
                        <span style={{
                          fontFamily: fonts.mono, fontSize: 10, fontWeight: 600,
                          color: f.wasUseful ? C.green : C.creamMuted,
                        }}>
                          {f.wasUseful ? 'YES' : 'NO'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>FLAGGED</span>
                        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamSoft }}>
                          {f.flaggedAt ? relativeTime(f.flaggedAt) : '\u2014'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No active pre-signal flags
          </div>
        )}
      </Panel>

      {/* 3. Trap Risk Events */}
      <Panel title="Trap Risk Events" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {trapList.length} events
        </span>
      }>
        {trapList.length > 0 ? (
          <DataTable
            columns={[
              {
                key: 'marketId',
                label: 'Market ID',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.cream, maxWidth: 180, display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.marketId || '\u2014'}
                  </span>
                ),
              },
              {
                key: 'trapRiskScore',
                label: 'Trap Score',
                render: (r) => {
                  const score = r.trapRiskScore != null ? Number(r.trapRiskScore) : null;
                  if (score == null) return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  return (
                    <span style={{
                      fontFamily: fonts.mono, fontSize: 12, fontWeight: 700,
                      color: score >= 75 ? C.red : score >= 55 ? C.amber : C.creamSoft,
                    }}>
                      {score.toFixed(0)}
                    </span>
                  );
                },
              },
              {
                key: 'actionTaken',
                label: 'Action Taken',
                render: (r) => actionPill(r.actionTaken),
              },
              {
                key: 'components',
                label: 'Components',
                render: (r) => {
                  const comps = r.components;
                  if (!comps || typeof comps !== 'object') return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  const entries = Object.entries(comps);
                  if (entries.length === 0) return <span style={{ color: C.creamMuted }}>\u2014</span>;
                  return (
                    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                      {entries.map(([key, val]) => (
                        <span key={key} style={{
                          fontFamily: fonts.mono, fontSize: 9, color: C.creamSoft,
                          background: C.creamGhost, padding: '1px 5px', borderRadius: 3,
                        }}>
                          {key}: {typeof val === 'number' ? val.toFixed(1) : String(val)}
                        </span>
                      ))}
                    </div>
                  );
                },
              },
            ]}
            rows={trapList}
          />
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No trap risk events recorded
          </div>
        )}
      </Panel>

      {/* 4. Polling Tiers */}
      <Panel title="Polling Tiers" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>
          {pollingList.length} markets
        </span>
      }>
        {pollingList.length > 0 ? (
          <DataTable
            columns={[
              {
                key: 'marketId',
                label: 'Market ID',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.cream, maxWidth: 200, display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.marketId || '\u2014'}
                  </span>
                ),
              },
              {
                key: 'score',
                label: 'Priority Score',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: C.cream }}>
                    {r.score != null ? Number(r.score).toFixed(0) : '\u2014'}
                  </span>
                ),
              },
              {
                key: 'tier',
                label: 'Tier',
                render: (r) => tierPill(r.tier),
              },
              {
                key: 'intervalSeconds',
                label: 'Interval',
                render: (r) => (
                  <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft }}>
                    {r.intervalSeconds != null ? `${r.intervalSeconds}s` : '\u2014'}
                  </span>
                ),
              },
            ]}
            rows={pollingList}
          />
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No polling tier data
          </div>
        )}
      </Panel>

      {/* 5. Detection Health */}
      <Panel title="Detection Health">
        {health ? (
          <div style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            borderRadius: 8,
            padding: '16px 20px',
            display: 'flex',
            alignItems: 'center',
            gap: 24,
            flexWrap: 'wrap',
          }}>
            {/* Confidence */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <RingGauge
                value={health.confidence != null ? (Number(health.confidence) <= 1 ? Number(health.confidence) * 100 : Number(health.confidence)) : 0}
                max={100}
                size={56}
                color={health.confidence != null && ((Number(health.confidence) <= 1 ? Number(health.confidence) : Number(health.confidence) / 100) >= 0.6) ? C.green : C.red}
                label={`${health.confidence != null ? Math.round(Number(health.confidence) <= 1 ? Number(health.confidence) * 100 : Number(health.confidence)) : 0}%`}
              />
              <div>
                <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>Confidence</div>
                <div style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 700, color: C.cream }}>
                  {health.confidence != null ? `${(Number(health.confidence) <= 1 ? Number(health.confidence) * 100 : Number(health.confidence)).toFixed(1)}%` : '\u2014'}
                </div>
              </div>
            </div>

            {/* WebSocket alive */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 12, height: 12, borderRadius: '50%',
                background: health.websocketAlive ? C.green : C.red,
                boxShadow: `0 0 8px ${health.websocketAlive ? C.green : C.red}`,
              }} />
              <div>
                <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>WebSocket</div>
                <div style={{ fontFamily: fonts.mono, fontSize: 12, fontWeight: 600, color: health.websocketAlive ? C.green : C.red }}>
                  {health.websocketAlive ? 'ALIVE' : 'DOWN'}
                </div>
              </div>
            </div>

            {/* Polling freshness */}
            <div>
              <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>Polling Freshness</div>
              <div style={{ fontFamily: fonts.mono, fontSize: 12, fontWeight: 600, color: C.cream }}>
                {health.pollingFreshness != null ? relativeTime(health.pollingFreshness) : (health.lastPoll != null ? relativeTime(health.lastPoll) : '\u2014')}
              </div>
            </div>
          </div>
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            Detection health data unavailable
          </div>
        )}
      </Panel>

      {/* 6. Category Heat Map */}
      <Panel title="Category Heat Map" right={
        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted }}>24h activity</span>
      }>
        {heatMapList.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 10 }}>
            {heatMapList.map((cat, i) => {
              const catColor = getCatColor(cat.category || cat.name);
              const volume = Number(cat.volume) || 0;
              const intensityPct = Math.max((volume / heatMaxVolume) * 100, 5);
              return (
                <div
                  key={cat.category || cat.name || i}
                  style={{
                    background: C.card,
                    border: `1px solid ${C.border}`,
                    borderRadius: 8,
                    padding: '14px 16px',
                    borderTop: `3px solid ${catColor}`,
                  }}
                >
                  {/* Category name */}
                  <div style={{
                    fontFamily: fonts.mono, fontSize: 12, fontWeight: 700, color: catColor,
                    marginBottom: 10, textTransform: 'uppercase', letterSpacing: 1,
                  }}>
                    {cat.category || cat.name || '\u2014'}
                  </div>

                  {/* Stats */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>24H TRADES</span>
                      <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: C.cream }}>
                        {cat.trades != null ? cat.trades : (cat.tradeCount != null ? cat.tradeCount : '\u2014')}
                      </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>VOLUME</span>
                      <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: C.cream }}>
                        {volume > 0 ? formatUsd(volume) : '\u2014'}
                      </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>WALLETS</span>
                      <span style={{ fontFamily: fonts.mono, fontSize: 11, fontWeight: 600, color: C.cream }}>
                        {cat.uniqueWallets != null ? cat.uniqueWallets : (cat.wallets != null ? cat.wallets : '\u2014')}
                      </span>
                    </div>
                  </div>

                  {/* Intensity bar */}
                  <div style={{ width: '100%', height: 5, background: C.creamGhost, borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{
                      width: `${intensityPct}%`,
                      height: '100%',
                      background: catColor,
                      borderRadius: 3,
                      transition: 'width 0.3s ease',
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, padding: 16, textAlign: 'center' }}>
            No category heat map data available
          </div>
        )}
      </Panel>
    </div>
  );
}
