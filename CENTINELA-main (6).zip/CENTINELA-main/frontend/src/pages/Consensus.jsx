/** Page 7: Consensus & Convergence — ranked by edge alignment, cluster-adjusted */
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, pnlColor, pnlSign } from '../utils/theme';
import { usePolling } from '../hooks/useApi';
import { RingGauge, PillBadge, Panel, MetricTile, ProgressBar, SidePill, Loading, ErrorCard } from '../components/shared';

/* ---------- Convergence card ---------- */

function ConvergenceCard({ item }) {
  const smartWallets = item.smartWalletIds ?? item.smart_wallet_ids ?? [];
  const dumbWallets = item.dumbWalletIds ?? item.dumb_wallet_ids ?? [];
  const smartScore = item.smartCombinedScore ?? item.smart_combined_score ?? 0;
  const dumbScore = item.dumbCombinedInverseScore ?? item.dumb_combined_inverse_score ?? 0;
  const smartSide = item.smartSide ?? item.smart_side ?? 'YES';
  const dumbSide = item.dumbSide ?? item.dumb_side ?? (smartSide === 'YES' ? 'NO' : 'YES');
  const gap = item.crossPlatformGap ?? item.cross_platform_gap ?? null;
  const totalEdges = item.totalEdgeSources ?? item.total_edge_sources ?? 0;
  const ts = item.timestamp ?? item.created_at ?? item.createdAt ?? null;
  const marketName = item.marketName ?? item.market_name ?? 'Unknown';

  const edgeMax = 3;
  const edgeLabel = `${totalEdges}/${edgeMax} edges aligned`;
  const edgeColor = totalEdges >= 3 ? C.green : totalEdges >= 2 ? C.amber : C.creamMuted;

  return (
    <div style={{
      background: C.card,
      border: `1px solid ${C.green}33`,
      borderRadius: 10,
      padding: 16,
      marginBottom: 10,
    }}>
      {/* Row 1: Market + sides */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <span style={{ fontFamily: fonts.mono, fontWeight: 700, fontSize: 14, color: C.cream }}>
          {marketName}
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, marginRight: 2 }}>SMART</span>
          <SidePill side={smartSide} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, marginRight: 2 }}>DUMB</span>
          <SidePill side={dumbSide} />
        </div>
      </div>

      {/* Row 2: Wallet details grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 10,
        marginBottom: 10,
      }}>
        {/* Smart wallets */}
        <div style={{
          background: `${C.green}08`,
          border: `1px solid ${C.green}15`,
          borderRadius: 6,
          padding: '8px 10px',
        }}>
          <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>
            Smart Wallets
          </div>
          <div style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 700, color: C.green }}>
            {smartWallets.length} <span style={{ fontSize: 10, fontWeight: 400, color: C.creamSoft }}>wallets</span>
          </div>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamSoft, marginTop: 2 }}>
            Combined score: {Number(smartScore).toFixed(0)}
          </div>
        </div>

        {/* Dumb wallets */}
        <div style={{
          background: `${C.red}08`,
          border: `1px solid ${C.red}15`,
          borderRadius: 6,
          padding: '8px 10px',
        }}>
          <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>
            Dumb Wallets
          </div>
          <div style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 700, color: C.red }}>
            {dumbWallets.length} <span style={{ fontSize: 10, fontWeight: 400, color: C.creamSoft }}>wallets</span>
          </div>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamSoft, marginTop: 2 }}>
            Inverse score: {Number(dumbScore).toFixed(0)}
          </div>
        </div>
      </div>

      {/* Row 3: Gap + edge badge + timestamp */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 10 }}>
        {gap != null && Number(gap) !== 0 && (
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.cyan }}>
            Cross-platform gap: +{Math.abs(Number(gap)).toFixed(0)}pt
          </div>
        )}

        <PillBadge text={edgeLabel} color={edgeColor} />

        {ts && (
          <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, marginLeft: 'auto' }}>
            {relativeTime(ts)}
          </span>
        )}
      </div>
    </div>
  );
}

/* ---------- Consensus card ---------- */

function ConsensusCard({ item }) {
  const marketName = item.marketName ?? item.market_name ?? 'Unknown';
  const side = item.side ?? item.direction ?? 'YES';
  const walletCount = item.walletCount ?? item.wallet_count ?? 0;
  const adjustedCount = item.adjustedWalletCount ?? item.adjusted_wallet_count ?? walletCount;
  const combinedScore = item.combinedScore ?? item.combined_score ?? 0;
  const totalCapital = item.totalCapital ?? item.total_capital ?? 0;
  const ts = item.timestamp ?? item.created_at ?? item.createdAt ?? null;
  const hasClustering = walletCount > adjustedCount;

  return (
    <div style={{
      background: C.card,
      border: `1px solid ${C.border}`,
      borderRadius: 10,
      padding: 16,
      marginBottom: 10,
    }}>
      {/* Row 1: Market name + direction */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <span style={{ fontFamily: fonts.mono, fontWeight: 700, fontSize: 14, color: C.cream }}>
          {marketName}
        </span>
        <SidePill side={side} />
      </div>

      {/* Row 2: Stats */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        gap: 16,
        fontFamily: fonts.mono,
        fontSize: 11,
        color: C.creamSoft,
        marginBottom: 6,
      }}>
        <div>
          <span style={{ color: C.creamMuted, fontSize: 9, textTransform: 'uppercase', letterSpacing: 1 }}>Wallets </span>
          <span style={{ fontWeight: 700, color: C.cream }}>{walletCount}</span>
        </div>
        <div>
          <span style={{ color: C.creamMuted, fontSize: 9, textTransform: 'uppercase', letterSpacing: 1 }}>Score </span>
          <span style={{ fontWeight: 700, color: getScoreColor(combinedScore) }}>{Number(combinedScore).toFixed(0)}</span>
        </div>
        <div>
          <span style={{ color: C.creamMuted, fontSize: 9, textTransform: 'uppercase', letterSpacing: 1 }}>Capital </span>
          <span style={{ fontWeight: 600 }}>{formatUsd(totalCapital)}</span>
        </div>
      </div>

      {/* Row 3: Cluster note + timestamp */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 10 }}>
        {hasClustering && (
          <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.amber }}>
            Cluster adjusted: {walletCount} wallets \u2192 {adjustedCount} effective
          </span>
        )}
        {ts && (
          <span style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, marginLeft: 'auto' }}>
            {relativeTime(ts)}
          </span>
        )}
      </div>
    </div>
  );
}

/* ---------- Main page ---------- */

export default function Consensus() {
  const { data: convergence, loading: convLoad, error: convErr } = usePolling('/convergence?limit=20', 30000);
  const { data: consensus, loading: consLoad, error: consErr } = usePolling('/consensus?limit=20', 30000);

  if ((convLoad && !convergence) && (consLoad && !consensus)) return <Loading />;

  const convArr = Array.isArray(convergence) ? convergence : [];
  const consArr = Array.isArray(consensus) ? consensus : [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* ---- CONVERGENCE section (top, highlighted) ---- */}
      <Panel
        title="CONVERGENCE \u2014 HIGHEST CONVICTION"
        style={{
          border: `1px solid ${C.green}30`,
          background: `linear-gradient(180deg, ${C.green}06 0%, ${C.panel} 100%)`,
        }}
      >
        {convErr && <ErrorCard message={convErr} />}
        {convArr.length > 0 ? (
          convArr.map((item, i) => (
            <ConvergenceCard key={item.id ?? i} item={item} />
          ))
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '30px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
          }}>
            No convergence signals
          </div>
        )}
      </Panel>

      {/* ---- CONSENSUS section ---- */}
      <Panel title="CONSENSUS \u2014 3+ INSIDERS ALIGNED">
        {consErr && <ErrorCard message={consErr} />}
        {consArr.length > 0 ? (
          consArr.map((item, i) => (
            <ConsensusCard key={item.id ?? i} item={item} />
          ))
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '30px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
          }}>
            No consensus signals
          </div>
        )}
      </Panel>
    </div>
  );
}
