/** Page 1: Command Center — bankroll, strategy state, live signal feed, positions */
import { useRef, useEffect } from "react";
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, stateColor, signalTypeIcon, pnlColor, pnlSign } from "../utils/theme";
import { usePolling } from "../hooks/useApi";
import { RingGauge, MetricTile, Panel, SignalCard, ProgressBar, Loading, ErrorCard, StateBanner, SidePill, PillBadge } from "../components/shared";

const EDGE_ROWS = [
  { key: "smart_money", label: "Smart Money", color: C.green },
  { key: "dumb_money", label: "Dumb Money", color: C.red },
  { key: "convergence", label: "Convergence", color: C.cyan },
  { key: "cross_platform", label: "Cross-Platform", color: C.purple },
  { key: "risk_management", label: "Risk Management", color: C.amber },
];

export default function CommandCenter() {
  const { data: bankroll, loading: bLoading, error: bError } = usePolling("/bankroll", 10000);
  const { data: alerts, loading: aLoading, error: aError } = usePolling("/alerts?limit=20", 10000);
  const { data: positions, loading: pLoading, error: pError } = usePolling("/positions?status=open", 10000);
  const { data: edgeState, loading: eLoading } = usePolling("/edge-state", 10000);

  const feedRef = useRef(null);
  const prevAlertLen = useRef(0);

  // auto-scroll feed to top on new data
  useEffect(() => {
    const list = Array.isArray(alerts) ? alerts : [];
    if (list.length !== prevAlertLen.current && feedRef.current) {
      feedRef.current.scrollTop = 0;
    }
    prevAlertLen.current = list.length;
  }, [alerts]);

  if (bLoading && !bankroll) return <Loading />;
  if (bError && !bankroll) return <ErrorCard message={bError} />;

  const b = bankroll || {};
  const state = edgeState?.state || b.strategyState || "green";
  const totalCapital = b.totalCapital ?? 0;
  const deployed = b.deployedCapital ?? 0;
  const available = totalCapital - deployed;
  const deployedPct = totalCapital > 0 ? deployed / totalCapital : 0;
  const dailyPnl = b.dailyPnl ?? 0;
  const openPos = b.openPositions ?? 0;
  const maxPos = b.maxConcurrentPositions ?? 12;
  const dailyLossLimit = b.dailyLossLimit ?? 0.05;
  const dailyLossMax = dailyLossLimit * totalCapital;
  const dailyLossUsage = dailyLossMax > 0 ? Math.abs(Math.min(dailyPnl, 0)) / dailyLossMax : 0;
  const dailyLossWarn = dailyLossUsage > 0.8;

  const alertList = Array.isArray(alerts) ? alerts : [];
  const posList = Array.isArray(positions) ? positions : [];

  return (
    <div>
      {/* ---- Top Metric Tiles ---- */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 12, marginBottom: 16 }}>
        <MetricTile label="Bankroll" value={formatUsd(totalCapital)} />
        <MetricTile label="Deployed" value={formatPct(deployedPct)} sub={formatUsd(deployed)} />
        <MetricTile label="Available" value={formatUsd(available)} />
        <MetricTile
          label="Today P&L"
          value={pnlSign(dailyPnl)}
          color={pnlColor(dailyPnl)}
        />
        <MetricTile label="Positions" value={`${openPos} / ${maxPos}`} />
        <MetricTile label="Daily Loss Usage">
          <div style={{ marginTop: 6 }}>
            <ProgressBar
              value={Math.abs(Math.min(dailyPnl, 0))}
              max={dailyLossMax || 1}
              color={C.amber}
              warn={dailyLossWarn}
              height={8}
            />
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: dailyLossWarn ? C.red : C.creamMuted, marginTop: 4 }}>
              {(dailyLossUsage * 100).toFixed(0)}% of {formatUsd(dailyLossMax)} limit
            </div>
          </div>
        </MetricTile>
      </div>

      {/* ---- Strategy State Banner ---- */}
      <StateBanner state={state} />

      {/* ---- Two-Column: Edge Stack + Live Signal Feed ---- */}
      <div style={{ display: "flex", gap: 14, marginBottom: 16, flexWrap: "wrap" }}>
        {/* LEFT: Edge Stack */}
        <Panel title="Edge Stack" style={{ width: 260, minWidth: 240, flexShrink: 0 }}>
          {EDGE_ROWS.map((edge) => (
            <div key={edge.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: edge.color, boxShadow: `0 0 6px ${edge.color}55` }} />
                <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamSoft }}>{edge.label}</span>
              </div>
              <PillBadge text="ACTIVE" color={edge.color} />
            </div>
          ))}
        </Panel>

        {/* RIGHT: Live Signal Feed */}
        <Panel title="Live Signal Feed" style={{ flex: 1, minWidth: 280 }}>
          {aLoading && !alerts ? (
            <Loading />
          ) : aError && !alerts ? (
            <ErrorCard message={aError} />
          ) : alertList.length === 0 ? (
            <div style={{ fontFamily: fonts.mono, fontSize: 12, color: C.creamMuted, padding: 20, textAlign: "center" }}>
              No recent signals
            </div>
          ) : (
            <div ref={feedRef} style={{ maxHeight: 340, overflowY: "auto" }}>
              {alertList.map((a, i) => {
                const type = a.signal_type || a.type || "system";
                const icon = signalTypeIcon(type);
                const title = a.market_name || a.marketName || a.message || "Signal";
                const subtitle = [
                  a.side ? `${a.side}` : null,
                  a.wallet_count ? `${a.wallet_count} wallets` : null,
                  a.combined_score ? `score ${a.combined_score}` : null,
                  a.description || null,
                ].filter(Boolean).join(" \u00B7 ");
                const borderColor = type === "convergence" ? `${C.cyan}44`
                  : type === "consensus" ? `${C.green}44`
                  : type === "dumb_money_fade" ? `${C.red}44`
                  : type === "cross_platform" ? `${C.purple}44`
                  : C.border;
                return (
                  <SignalCard
                    key={a.id ?? i}
                    icon={icon}
                    title={title}
                    subtitle={subtitle || "\u2014"}
                    meta={relativeTime(a.created_at || a.timestamp)}
                    borderColor={borderColor}
                  />
                );
              })}
            </div>
          )}
        </Panel>
      </div>

      {/* ---- Active Positions ---- */}
      <Panel title="Active Positions">
        {pLoading && !positions ? (
          <Loading />
        ) : pError && !positions ? (
          <ErrorCard message={pError} />
        ) : posList.length === 0 ? (
          <div style={{ fontFamily: fonts.mono, fontSize: 12, color: C.creamMuted, padding: 20, textAlign: "center" }}>
            No open positions
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: fonts.mono, fontSize: 11 }}>
              <thead>
                <tr>
                  {["Market", "Side", "P&L", "Source", "Phase"].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: "6px 10px", borderBottom: `1px solid ${C.border}`, color: C.creamMuted, fontWeight: 500, fontSize: 9, textTransform: "uppercase", letterSpacing: 1 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {posList.map((p, i) => {
                  const pnl = p.pnlPct ?? p.unrealizedPnl ?? 0;
                  const pnlVal = typeof p.pnlPct === "number" ? `${(pnl * 100).toFixed(1)}%` : formatUsd(pnl);
                  const sourceColor = p.signalSource === "convergence" ? C.cyan
                    : p.signalSource === "consensus" ? C.green
                    : p.signalSource === "dumb_money_fade" ? C.red
                    : p.signalSource === "cross_platform" ? C.purple
                    : C.creamMuted;
                  return (
                    <tr key={p.id ?? i} style={{ borderBottom: `1px solid ${C.border}` }}>
                      <td style={{ padding: "8px 10px", color: C.creamSoft, maxWidth: 260, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {p.marketName || p.market_name || "\u2014"}
                      </td>
                      <td style={{ padding: "8px 10px" }}>
                        <SidePill side={p.side} />
                      </td>
                      <td style={{ padding: "8px 10px", color: pnlColor(pnl), fontWeight: 600 }}>
                        {pnlVal}
                      </td>
                      <td style={{ padding: "8px 10px" }}>
                        <PillBadge text={p.signalSource || p.signal_source || "\u2014"} color={sourceColor} />
                      </td>
                      <td style={{ padding: "8px 10px" }}>
                        <PillBadge text={p.buildPhase || p.build_phase || "\u2014"} color={C.creamMuted} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
