/** Page 6: Agreement Board — watch consensus forming before alerts fire */
import { useMemo } from "react";
import { C, fonts, formatUsd } from "../utils/theme";
import { usePolling } from "../hooks/useApi";
import { Panel, Loading, ErrorCard, PillBadge } from "../components/shared";

const CONSENSUS_THRESHOLD = 3;

export default function AgreementBoard() {
  const { data: markets, loading: mLoading, error: mError } = usePolling("/markets?status=active", 10000);
  const { data: trades, loading: tLoading, error: tError } = usePolling("/trades/live?limit=200", 10000);

  // Cross-reference: group trades by market, count unique smart wallet_ids per side
  const cards = useMemo(() => {
    if (!trades || !markets) return [];

    const marketList = Array.isArray(markets) ? markets : [];
    const tradeList = Array.isArray(trades) ? trades : [];

    // Build a lookup for market data
    const marketMap = {};
    for (const m of marketList) {
      const key = m.market_id || m.id || m.marketId;
      if (key) marketMap[key] = m;
    }

    // Group trades by market
    const grouped = {};
    for (const t of tradeList) {
      const mKey = t.market_id || t.marketId;
      if (!mKey) continue;
      if (!grouped[mKey]) {
        grouped[mKey] = { yes: {}, no: {} };
      }
      const side = (t.side || "").toUpperCase() === "NO" ? "no" : "yes";
      const wId = t.wallet_id || t.walletId || t.address;
      if (!wId) continue;
      if (!grouped[mKey][side][wId]) {
        grouped[mKey][side][wId] = 0;
      }
      grouped[mKey][side][wId] += Number(t.size || t.amount || 0);
    }

    // Build card data, filter to 2+ wallets on any side
    const result = [];
    for (const [mKey, sides] of Object.entries(grouped)) {
      const yesWallets = Object.keys(sides.yes);
      const noWallets = Object.keys(sides.no);
      const maxSide = Math.max(yesWallets.length, noWallets.length);
      if (maxSide < 2) continue;

      const mData = marketMap[mKey] || {};
      const yesCapital = Object.values(sides.yes).reduce((s, v) => s + v, 0);
      const noCapital = Object.values(sides.no).reduce((s, v) => s + v, 0);
      const totalWallets = yesWallets.length + noWallets.length;
      const totalCapital = yesCapital + noCapital;
      // Alignment strength: how skewed the wallet count is toward one side
      const alignment = totalWallets > 0 ? Math.abs(yesWallets.length - noWallets.length) / totalWallets : 0;

      result.push({
        marketId: mKey,
        marketName: mData.market_name || mData.name || mData.title || mKey,
        currentOdds: mData.current_odds ?? mData.currentOdds ?? mData.yes_price ?? null,
        yesCount: yesWallets.length,
        noCount: noWallets.length,
        yesCapital,
        noCapital,
        totalCapital,
        alignment,
        maxSide,
      });
    }

    // Sort by alignment strength desc (strongest agreement first)
    result.sort((a, b) => b.alignment - a.alignment || b.maxSide - a.maxSide);
    return result;
  }, [markets, trades]);

  const isLoading = (mLoading && !markets) || (tLoading && !trades);
  const hasError = (mError && !markets) || (tError && !trades);

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontFamily: fonts.mono, fontSize: 16, fontWeight: 700, letterSpacing: 2, margin: 0, color: C.green }}>
          AGREEMENT BOARD
        </h2>
        <p style={{ fontFamily: fonts.mono, fontSize: 11, color: C.creamMuted, margin: "6px 0 0 0" }}>
          Watch consensus forming before alerts fire
        </p>
      </div>

      {isLoading ? (
        <Loading />
      ) : hasError ? (
        <ErrorCard message={mError || tError || "Failed to load data"} />
      ) : cards.length === 0 ? (
        <div style={{
          fontFamily: fonts.mono, fontSize: 13, color: C.creamMuted,
          padding: 40, textAlign: "center",
          background: C.card, border: `1px solid ${C.border}`, borderRadius: 10,
        }}>
          No active agreement forming
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {cards.map((card) => {
            const isConsensus = card.maxSide >= CONSENSUS_THRESHOLD;
            const totalWallets = card.yesCount + card.noCount;
            const yesPct = totalWallets > 0 ? (card.yesCount / totalWallets) * 100 : 50;
            const noPct = 100 - yesPct;
            const yesCapPct = card.totalCapital > 0 ? (card.yesCapital / card.totalCapital) * 100 : 50;

            return (
              <div
                key={card.marketId}
                style={{
                  background: C.card,
                  border: `1px solid ${isConsensus ? `${C.green}44` : C.border}`,
                  borderRadius: 10,
                  padding: 18,
                }}
              >
                {/* Row 1: Market name + odds + status pill */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: fonts.sans, fontSize: 14, fontWeight: 600, color: C.cream, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {card.marketName}
                    </div>
                    {card.currentOdds != null && (
                      <div style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, marginTop: 2 }}>
                        Odds: {typeof card.currentOdds === "number" ? `${(card.currentOdds * 100).toFixed(0)}%` : card.currentOdds}
                      </div>
                    )}
                  </div>
                  <PillBadge
                    text={isConsensus
                      ? `CONSENSUS \u2713`
                      : `PRE-CONSENSUS (${card.maxSide}/${CONSENSUS_THRESHOLD})`}
                    color={isConsensus ? C.green : C.amber}
                  />
                </div>

                {/* Row 2: YES vs NO side stats */}
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, fontFamily: fonts.mono, fontSize: 11 }}>
                  <div>
                    <span style={{ color: C.green, fontWeight: 600 }}>YES</span>
                    <span style={{ color: C.creamMuted, marginLeft: 8 }}>
                      {card.yesCount} wallet{card.yesCount !== 1 ? "s" : ""}
                    </span>
                    <span style={{ color: C.creamSoft, marginLeft: 8 }}>
                      ~{formatUsd(card.yesCapital)}
                    </span>
                  </div>
                  <div>
                    <span style={{ color: C.creamSoft, marginRight: 8 }}>
                      ~{formatUsd(card.noCapital)}
                    </span>
                    <span style={{ color: C.creamMuted, marginRight: 8 }}>
                      {card.noCount} wallet{card.noCount !== 1 ? "s" : ""}
                    </span>
                    <span style={{ color: C.red, fontWeight: 600 }}>NO</span>
                  </div>
                </div>

                {/* Row 3: Alignment bar */}
                <div style={{ display: "flex", height: 8, borderRadius: 4, overflow: "hidden", background: C.creamGhost }}>
                  <div style={{
                    width: `${yesCapPct}%`,
                    background: C.green,
                    borderRadius: yesCapPct >= 100 ? 4 : "4px 0 0 4px",
                    transition: "width 0.3s ease",
                    minWidth: card.yesCapital > 0 ? 4 : 0,
                  }} />
                  <div style={{
                    width: `${100 - yesCapPct}%`,
                    background: C.red,
                    borderRadius: yesCapPct <= 0 ? 4 : "0 4px 4px 0",
                    transition: "width 0.3s ease",
                    minWidth: card.noCapital > 0 ? 4 : 0,
                  }} />
                </div>

                {/* Row 4: Capital percentages label */}
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted }}>
                  <span>{yesCapPct.toFixed(0)}% capital</span>
                  <span>{(100 - yesCapPct).toFixed(0)}% capital</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
