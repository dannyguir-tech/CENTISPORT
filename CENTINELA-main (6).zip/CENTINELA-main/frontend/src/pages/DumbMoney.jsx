/** Page 3: Dumb Money by Niche — card layout, inverse scores, live signal feed */
import { useState, useMemo } from "react";
import {
  C,
  fonts,
  getScoreColor,
  formatUsd,
  formatPct,
  relativeTime,
  getCatColor,
  pnlColor,
  pnlSign,
} from "../utils/theme";
import { usePolling, useApi } from "../hooks/useApi";
import {
  RingGauge,
  PillBadge,
  Sparkline,
  Panel,
  DataTable,
  MetricTile,
  Loading,
  ErrorCard,
} from "../components/shared";

/* ── category config ────────────────────────────────────────────────── */
const CATEGORIES = [
  { key: "All", color: C.cream },
  { key: "Politics", color: C.purple },
  { key: "Crypto", color: C.amber },
  { key: "Sports", color: C.cyan },
];

/* ── signal status styling ──────────────────────────────────────────── */
function signalStatusStyle(signal) {
  if (signal.suppressed) return { label: "SUPPRESSED", color: C.red, bg: C.redDim };
  const score = signal.fadeSignalScore ?? signal.fade_signal_score ?? 0;
  if (score >= 70) return { label: "ALERT SENT", color: C.green, bg: C.greenDim };
  return { label: "BELOW FLOOR", color: C.creamMuted, bg: C.creamGhost };
}

/* ── component ──────────────────────────────────────────────────────── */
export default function DumbMoney() {
  const [activeCategory, setActiveCategory] = useState("All");

  const {
    data: allWallets,
    loading: wLoading,
    error: wError,
    refetch: wRefetch,
  } = usePolling("/dumb-money/wallets", 30000);

  const {
    data: signals,
    loading: sLoading,
    error: sError,
    refetch: sRefetch,
  } = usePolling("/dumb-money/signals?limit=20", 30000);

  /* ── filter by category ────────────────────────────────────────── */
  const wallets = useMemo(() => {
    if (!allWallets) return [];
    if (activeCategory === "All") return allWallets;
    return allWallets.filter((w) => {
      const cats = w.categories || w.category ? [w.category] : [];
      const allCats = Array.isArray(w.categories) ? w.categories : cats;
      return allCats.some(
        (c) => (c || "").toLowerCase() === activeCategory.toLowerCase()
      );
    });
  }, [allWallets, activeCategory]);

  /* ── loading / error states ────────────────────────────────────── */
  if (wLoading && !allWallets) return <Loading />;
  if (wError && !allWallets)
    return <ErrorCard message={wError} onRetry={wRefetch} />;

  /* ── render ────────────────────────────────────────────────────── */
  return (
    <div>
      {/* ── Category tabs ──────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          gap: 0,
          marginBottom: 20,
          borderBottom: `1px solid ${C.border}`,
        }}
      >
        {CATEGORIES.map((cat) => {
          const active = activeCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              style={{
                background: active ? `${cat.color}0c` : "transparent",
                border: "none",
                borderBottom: active
                  ? `2px solid ${cat.color}`
                  : "2px solid transparent",
                color: active ? cat.color : C.creamMuted,
                padding: "10px 20px",
                fontSize: 12,
                fontFamily: fonts.mono,
                fontWeight: active ? 700 : 500,
                cursor: "pointer",
                letterSpacing: 1,
                textTransform: "uppercase",
                transition: "all 0.15s ease",
              }}
            >
              {cat.key}
            </button>
          );
        })}
      </div>

      {/* ── Wallet cards (2 per row) ───────────────────────────── */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 12,
          marginBottom: 24,
        }}
      >
        {wallets.map((w) => {
          const inverseScore = w.inverseScore ?? w.inverse_score ?? 0;
          const winRate = w.winRate ?? w.win_rate ?? 0;
          const pnl = w.pnl ?? 0;
          const handle = w.handle || "Unknown";
          const addr = w.address || "";
          const truncAddr =
            addr.length > 12
              ? `${addr.slice(0, 6)}...${addr.slice(-4)}`
              : addr;
          const catWinRates = w.categoryWinRates || w.category_win_rates || {};

          return (
            <div
              key={w.address || w.id}
              style={{
                background: C.card,
                border: `1px solid ${C.border}`,
                borderRadius: 10,
                padding: 16,
                display: "flex",
                gap: 14,
                alignItems: "flex-start",
              }}
            >
              {/* Ring gauge */}
              <RingGauge
                value={inverseScore}
                size={52}
                color={C.pink}
                label={String(Math.round(inverseScore))}
              />

              {/* Details */}
              <div style={{ flex: 1, minWidth: 0 }}>
                {/* Handle + address */}
                <div
                  style={{
                    fontWeight: 700,
                    fontSize: 14,
                    color: C.pink,
                    marginBottom: 2,
                  }}
                >
                  {handle}
                </div>
                <div
                  style={{
                    fontFamily: fonts.mono,
                    fontSize: 10,
                    color: C.creamMuted,
                    marginBottom: 8,
                  }}
                >
                  {truncAddr}
                </div>

                {/* Win rate (low = bad) */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    marginBottom: 6,
                    fontFamily: fonts.mono,
                    fontSize: 11,
                  }}
                >
                  <span style={{ color: C.red }}>
                    WR: {formatPct(winRate)}
                  </span>
                  <span style={{ color: pnlColor(pnl), fontWeight: 600 }}>
                    PnL: {pnlSign(pnl)}
                  </span>
                </div>

                {/* Category win rates */}
                {Object.keys(catWinRates).length > 0 && (
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 6,
                      marginTop: 4,
                    }}
                  >
                    {Object.entries(catWinRates).map(([cat, wr]) => (
                      <span
                        key={cat}
                        style={{
                          fontFamily: fonts.mono,
                          fontSize: 9,
                          padding: "2px 6px",
                          borderRadius: 3,
                          background: `${getCatColor(cat)}12`,
                          color: getCatColor(cat),
                        }}
                      >
                        {cat}: {formatPct(wr)}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {wallets.length === 0 && (
          <div
            style={{
              gridColumn: "1 / -1",
              textAlign: "center",
              padding: 30,
              color: C.creamMuted,
              fontFamily: fonts.mono,
              fontSize: 12,
            }}
          >
            No dumb money wallets in this category
          </div>
        )}
      </div>

      {/* ── Live Activity Feed ─────────────────────────────────── */}
      <Panel title="Live Activity Feed">
        {sError && !signals && (
          <ErrorCard message={sError} onRetry={sRefetch} />
        )}

        {(!signals || signals.length === 0) && !sError && (
          <div
            style={{
              textAlign: "center",
              padding: 20,
              color: C.creamMuted,
              fontFamily: fonts.mono,
              fontSize: 11,
            }}
          >
            No recent signals
          </div>
        )}

        {signals &&
          signals.map((s) => {
            const status = signalStatusStyle(s);
            const fadeScore =
              s.fadeSignalScore ?? s.fade_signal_score ?? 0;
            const market =
              s.marketName ?? s.market_name ?? s.market ?? "\u2014";
            const handle =
              s.walletHandle ?? s.wallet_handle ?? s.handle ?? "\u2014";
            const fadeSide = s.fadeSide ?? s.fade_side ?? "\u2014";
            const dumbSide = s.dumbSide ?? s.dumb_side ?? "\u2014";
            const suppressReason =
              s.suppressReason ?? s.suppress_reason ?? "";
            const hasConflict =
              s.smartMoneyConflict ?? s.smart_money_conflict ?? false;

            return (
              <div
                key={s.id || s.signal_id || Math.random()}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "8px 12px",
                  marginBottom: 4,
                  background: status.bg,
                  border: `1px solid ${status.color}22`,
                  borderRadius: 6,
                  fontFamily: fonts.mono,
                  fontSize: 11,
                }}
              >
                {/* Status pill */}
                <PillBadge text={status.label} color={status.color} />

                {/* Wallet handle */}
                <span style={{ color: C.pink, fontWeight: 600, minWidth: 70 }}>
                  {handle}
                </span>

                {/* Market */}
                <span
                  style={{
                    color: C.cream,
                    flex: 1,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {market}
                </span>

                {/* Fade info */}
                <span style={{ color: C.creamSoft }}>
                  {dumbSide}{" "}
                  <span style={{ color: C.creamMuted }}>{"\u2192"}</span>{" "}
                  <span style={{ color: C.green, fontWeight: 600 }}>
                    FADE {fadeSide}
                  </span>
                </span>

                {/* Fade score */}
                <span
                  style={{
                    color: fadeScore >= 70 ? C.green : C.creamMuted,
                    fontWeight: 600,
                    minWidth: 30,
                    textAlign: "right",
                  }}
                >
                  {Math.round(fadeScore)}
                </span>

                {/* Conflict flag */}
                {hasConflict && (
                  <PillBadge text="CONFLICT" color={C.red} />
                )}

                {/* Suppress reason */}
                {s.suppressed && suppressReason && (
                  <span
                    style={{
                      color: C.red,
                      fontSize: 9,
                      maxWidth: 120,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                    title={suppressReason}
                  >
                    {suppressReason}
                  </span>
                )}
              </div>
            );
          })}
      </Panel>
    </div>
  );
}
