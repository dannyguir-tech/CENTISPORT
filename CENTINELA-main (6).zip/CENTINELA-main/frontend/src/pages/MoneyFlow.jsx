/** Page 12: Money Flow Timeline — select a market, see capital flow over time */
import { useState, useMemo } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, getCatColor, pnlColor } from '../utils/theme';
import { useApi, usePolling } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, SidePill, Loading, ErrorCard } from '../components/shared';

/* ── helpers ───────────────────────────────────────────────────────── */

function classifyWallet(trade) {
  const wt = (trade.wallet_type || trade.walletType || '').toLowerCase();
  const cls = (trade.classification || '').toUpperCase();
  if (wt === 'smart' || cls === 'SNIPER' || cls === 'MOMENTUM') return 'smart';
  if (wt === 'dumb' || cls === 'DUMB_MONEY') return 'dumb';
  return 'unknown';
}

function dotColor(type) {
  if (type === 'smart') return C.green;
  if (type === 'dumb') return C.pink;
  return C.creamMuted;
}

function formatTs(ts) {
  if (!ts) return '\u2014';
  const d = new Date(ts);
  if (isNaN(d.getTime())) return '\u2014';
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const mo = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${mo}/${dd} ${hh}:${mm}`;
}

/* ── dropdown style ────────────────────────────────────────────────── */

const selectStyle = {
  background: C.card,
  border: `1px solid ${C.border}`,
  borderRadius: 6,
  padding: '8px 12px',
  color: C.cream,
  fontFamily: fonts.mono,
  fontSize: 12,
  outline: 'none',
  minWidth: 260,
  cursor: 'pointer',
};

/* ── component ─────────────────────────────────────────────────────── */

export default function MoneyFlow() {
  const [marketId, setMarketId] = useState('');

  /* fetch active markets for dropdown */
  const { data: markets, loading: mktsLoading, error: mktsError } = useApi('/markets?status=active');

  /* fetch trades when a market is selected */
  const tradesPath = marketId ? `/trades?market_id=${marketId}&limit=100` : null;
  const { data: trades, loading: tradesLoading, error: tradesError } = useApi(tradesPath || '/trades?limit=0', [marketId]);

  /* ── derived timeline data ──────────────────────────────────────── */
  const timeline = useMemo(() => {
    if (!marketId || !trades || !Array.isArray(trades)) return [];
    const sorted = [...trades].sort((a, b) => {
      const ta = new Date(a.timestamp || a.created_at || 0).getTime();
      const tb = new Date(b.timestamp || b.created_at || 0).getTime();
      return ta - tb;
    });
    return sorted;
  }, [trades, marketId]);

  const analysis = useMemo(() => {
    if (!timeline.length) return null;

    let firstSmartIdx = -1;
    let firstDumbOppositeIdx = -1;
    let firstSmartSide = null;

    for (let i = 0; i < timeline.length; i++) {
      const t = timeline[i];
      const type = classifyWallet(t);
      if (type === 'smart' && firstSmartIdx === -1) {
        firstSmartIdx = i;
        firstSmartSide = (t.side || '').toUpperCase();
      }
      if (type === 'dumb' && firstSmartSide) {
        const dumbSide = (t.side || '').toUpperCase();
        if (dumbSide && dumbSide !== firstSmartSide && firstDumbOppositeIdx === -1) {
          firstDumbOppositeIdx = i;
        }
      }
    }

    /* compute time gap between first smart and first dumb entry */
    let hourGap = null;
    let priceMove = null;
    if (firstSmartIdx >= 0) {
      const smartTs = new Date(timeline[firstSmartIdx].timestamp || timeline[firstSmartIdx].created_at || 0).getTime();
      const firstDumbIdx = timeline.findIndex((t, i) => i > firstSmartIdx && classifyWallet(t) === 'dumb');
      if (firstDumbIdx >= 0) {
        const dumbTs = new Date(timeline[firstDumbIdx].timestamp || timeline[firstDumbIdx].created_at || 0).getTime();
        hourGap = Math.max(0, (dumbTs - smartTs) / (1000 * 60 * 60));
        const smartPrice = Number(timeline[firstSmartIdx].price ?? timeline[firstSmartIdx].avg_price ?? 0);
        const dumbPrice = Number(timeline[firstDumbIdx].price ?? timeline[firstDumbIdx].avg_price ?? 0);
        if (smartPrice > 0) {
          priceMove = (dumbPrice - smartPrice) / smartPrice;
        }
      }
    }

    return { firstSmartIdx, firstDumbOppositeIdx, hourGap, priceMove };
  }, [timeline]);

  /* ── selected market name ───────────────────────────────────────── */
  const selectedMarket = useMemo(() => {
    if (!markets || !marketId) return null;
    const arr = Array.isArray(markets) ? markets : [];
    return arr.find(m => String(m.id ?? m.market_id) === String(marketId));
  }, [markets, marketId]);

  /* ── loading / error ────────────────────────────────────────────── */
  if (mktsLoading && !markets) return <Loading />;
  if (mktsError && !markets) return <ErrorCard message={mktsError} />;

  const marketArr = Array.isArray(markets) ? markets : [];

  /* ── render ─────────────────────────────────────────────────────── */
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* ── Market selector ──────────────────────────────────────── */}
      <Panel title="MONEY FLOW TIMELINE">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <label style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1 }}>
            Market
          </label>
          <select
            value={marketId}
            onChange={e => setMarketId(e.target.value)}
            style={selectStyle}
          >
            <option value="" style={{ background: C.card, color: C.creamMuted }}>-- Select a market --</option>
            {marketArr.map(m => {
              const id = m.id ?? m.market_id;
              const name = m.name ?? m.question ?? m.title ?? `Market #${id}`;
              return (
                <option key={id} value={id} style={{ background: C.card, color: C.cream }}>
                  {name}
                </option>
              );
            })}
          </select>
          {selectedMarket && (
            <PillBadge
              text={selectedMarket.category || selectedMarket.market_category || 'GENERAL'}
              color={getCatColor(selectedMarket.category || selectedMarket.market_category)}
            />
          )}
        </div>
      </Panel>

      {/* ── Empty state ──────────────────────────────────────────── */}
      {!marketId && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '50px 20px',
            fontFamily: fonts.mono,
            fontSize: 13,
            color: C.creamMuted,
            letterSpacing: 0.5,
          }}>
            Select a market to see money flow timeline
          </div>
        </Panel>
      )}

      {/* ── Loading trades ───────────────────────────────────────── */}
      {marketId && tradesLoading && !trades && <Loading />}
      {marketId && tradesError && !trades && <ErrorCard message={tradesError} />}

      {/* ── Timeline ─────────────────────────────────────────────── */}
      {marketId && timeline.length > 0 && (
        <Panel title="TIMELINE">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {timeline.map((t, i) => {
              const type = classifyWallet(t);
              const ts = t.timestamp || t.created_at;
              const handle = t.handle || t.wallet_handle || (t.wallet_address ? t.wallet_address.slice(0, 10) : '\u2014');
              const side = (t.side || '').toUpperCase();
              const size = t.size ?? t.amount ?? t.trade_size ?? null;
              const price = t.price ?? t.avg_price ?? null;

              const isFirstSmart = analysis && analysis.firstSmartIdx === i;
              const isFadeSignal = analysis && analysis.firstDumbOppositeIdx === i;

              return (
                <div
                  key={t.id ?? t.trade_id ?? i}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '90px 14px 1fr auto',
                    gap: 12,
                    alignItems: 'center',
                    padding: '10px 14px',
                    borderBottom: `1px solid ${C.border}`,
                    background: isFirstSmart
                      ? C.greenDim
                      : isFadeSignal
                        ? C.pinkDim
                        : 'transparent',
                  }}
                >
                  {/* timestamp */}
                  <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamMuted, whiteSpace: 'nowrap' }}>
                    {formatTs(ts)}
                  </span>

                  {/* dot */}
                  <div style={{
                    width: 10,
                    height: 10,
                    borderRadius: '50%',
                    background: dotColor(type),
                    boxShadow: `0 0 6px ${dotColor(type)}`,
                    flexShrink: 0,
                  }} />

                  {/* wallet info */}
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span style={{ fontFamily: fonts.mono, fontSize: 12, fontWeight: 600, color: C.cream }}>
                        {handle}
                      </span>
                      <SidePill side={side} />
                      {size != null && (
                        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.creamSoft }}>
                          {formatUsd(size)}
                        </span>
                      )}
                      <PillBadge
                        text={type === 'smart' ? 'SMART' : type === 'dumb' ? 'DUMB' : 'UNK'}
                        color={dotColor(type)}
                      />
                    </div>
                    {/* labels */}
                    {isFirstSmart && (
                      <div style={{
                        fontFamily: fonts.mono,
                        fontSize: 10,
                        fontWeight: 700,
                        color: C.green,
                        marginTop: 4,
                        letterSpacing: 1,
                        textTransform: 'uppercase',
                      }}>
                        FIRST INSIDER ENTRY
                      </div>
                    )}
                    {isFadeSignal && (
                      <div style={{
                        fontFamily: fonts.mono,
                        fontSize: 10,
                        fontWeight: 700,
                        color: C.pink,
                        marginTop: 4,
                        letterSpacing: 1,
                        textTransform: 'uppercase',
                      }}>
                        FADE SIGNAL
                      </div>
                    )}
                  </div>

                  {/* price */}
                  <span style={{
                    fontFamily: fonts.mono,
                    fontSize: 11,
                    color: C.creamSoft,
                    whiteSpace: 'nowrap',
                  }}>
                    {price != null ? `$${Number(price).toFixed(2)}` : '\u2014'}
                  </span>
                </div>
              );
            })}
          </div>
        </Panel>
      )}

      {/* ── No trades ────────────────────────────────────────────── */}
      {marketId && !tradesLoading && timeline.length === 0 && trades && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '30px 20px',
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamMuted,
          }}>
            No trades found for this market
          </div>
        </Panel>
      )}

      {/* ── Summary ──────────────────────────────────────────────── */}
      {marketId && analysis && analysis.hourGap != null && (
        <Panel title="FLOW SUMMARY">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 14 }}>
            <MetricTile
              label="SMART LEAD TIME"
              value={analysis.hourGap < 1
                ? `${Math.round(analysis.hourGap * 60)}m`
                : `${analysis.hourGap.toFixed(1)}h`}
              color={C.green}
              sub="before dumb money"
            />
            {analysis.priceMove != null && (
              <MetricTile
                label="PRICE MOVE"
                value={formatPct(analysis.priceMove)}
                color={pnlColor(analysis.priceMove)}
                sub="in that window"
              />
            )}
            <MetricTile
              label="TOTAL TRADES"
              value={timeline.length}
              sub={`${timeline.filter(t => classifyWallet(t) === 'smart').length} smart / ${timeline.filter(t => classifyWallet(t) === 'dumb').length} dumb`}
            />
          </div>
          <div style={{
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.creamSoft,
            padding: '10px 14px',
            background: C.card,
            border: `1px solid ${C.border}`,
            borderRadius: 6,
          }}>
            Smart money entered{' '}
            <span style={{ color: C.green, fontWeight: 700 }}>
              {analysis.hourGap < 1
                ? `${Math.round(analysis.hourGap * 60)} minutes`
                : `${analysis.hourGap.toFixed(1)} hours`}
            </span>
            {' '}before dumb money.
            {analysis.priceMove != null && (
              <>
                {' '}Price moved{' '}
                <span style={{ color: pnlColor(analysis.priceMove), fontWeight: 700 }}>
                  {formatPct(analysis.priceMove)}
                </span>
                {' '}in that window.
              </>
            )}
          </div>
        </Panel>
      )}
    </div>
  );
}
