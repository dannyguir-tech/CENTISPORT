/** Page 2: Smart Money by Niche — category tabs, wallet table with scores, filtering */
import { useState, useMemo } from "react";
import {
  C,
  fonts,
  getScoreColor,
  formatUsd,
  formatPct,
  relativeTime,
  getCatColor,
  pnlColor,
  pnlSign,
} from "../utils/theme";
import { usePolling, useApi } from "../hooks/useApi";
import {
  RingGauge,
  PillBadge,
  Sparkline,
  Panel,
  DataTable,
  MetricTile,
  Loading,
  ErrorCard,
} from "../components/shared";

/* ── category config ────────────────────────────────────────────────── */
const CATEGORIES = [
  { key: "All", color: C.cream },
  { key: "Politics", color: C.purple },
  { key: "Crypto", color: C.amber },
  { key: "Sports", color: C.cyan },
];

const CLASSIFICATION_COLORS = {
  SNIPER: C.green,
  MOMENTUM: C.cyan,
};

/* ── component ──────────────────────────────────────────────────────── */
export default function SmartWatchlist({ onSelectWallet }) {
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [minScore, setMinScore] = useState(0);

  const {
    data: wallets,
    loading,
    error,
    refetch,
  } = usePolling(
    `/wallets?sort_by=insiderScore&category=${activeCategory}`,
    30000
  );

  /* ── derived data ──────────────────────────────────────────────── */
  const smartWallets = useMemo(() => {
    if (!wallets) return [];
    return wallets
      .filter((w) => w.wallet_type !== "dumb" && w.classification !== "DUMB_MONEY")
      .filter((w) => {
        if (search) {
          const q = search.toLowerCase();
          const handle = (w.handle || "").toLowerCase();
          if (!handle.includes(q)) return false;
        }
        const score = w.insiderScore ?? w.insider_score ?? 0;
        return score >= minScore;
      });
  }, [wallets, search, minScore]);

  const categoryStats = useMemo(() => {
    if (!smartWallets.length) return { total: 0, avgWinRate: 0 };
    const total = smartWallets.length;
    const sum = smartWallets.reduce(
      (acc, w) => acc + (w.winRate ?? w.win_rate ?? 0),
      0
    );
    return { total, avgWinRate: total ? sum / total : 0 };
  }, [smartWallets]);

  /* ── loading / error states ────────────────────────────────────── */
  if (loading && !wallets) return <Loading />;
  if (error && !wallets) return <ErrorCard message={error} onRetry={refetch} />;

  /* ── render ────────────────────────────────────────────────────── */
  return (
    <div>
      {/* ── Category tabs ──────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          gap: 0,
          marginBottom: 20,
          borderBottom: `1px solid ${C.border}`,
        }}
      >
        {CATEGORIES.map((cat) => {
          const active = activeCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              style={{
                background: active ? `${cat.color}0c` : "transparent",
                border: "none",
                borderBottom: active
                  ? `2px solid ${cat.color}`
                  : "2px solid transparent",
                color: active ? cat.color : C.creamMuted,
                padding: "10px 20px",
                fontSize: 12,
                fontFamily: fonts.mono,
                fontWeight: active ? 700 : 500,
                cursor: "pointer",
                letterSpacing: 1,
                textTransform: "uppercase",
                transition: "all 0.15s ease",
              }}
            >
              {cat.key}
            </button>
          );
        })}
      </div>

      {/* ── Category header ────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 24,
          marginBottom: 16,
          fontFamily: fonts.mono,
          fontSize: 12,
          color: C.creamSoft,
        }}
      >
        <span>
          <span style={{ color: C.cream, fontWeight: 700, fontSize: 16 }}>
            {categoryStats.total}
          </span>{" "}
          wallets
        </span>
        <span>
          Combined WR:{" "}
          <span
            style={{
              color:
                categoryStats.avgWinRate >= 0.6
                  ? C.green
                  : categoryStats.avgWinRate >= 0.4
                  ? C.amber
                  : C.red,
              fontWeight: 600,
            }}
          >
            {formatPct(categoryStats.avgWinRate)}
          </span>
        </span>
      </div>

      {/* ── Filter bar ─────────────────────────────────────────── */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 16,
          marginBottom: 16,
          padding: "10px 14px",
          background: C.panel,
          border: `1px solid ${C.border}`,
          borderRadius: 8,
        }}
      >
        <input
          type="text"
          placeholder="Search handle..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            borderRadius: 4,
            padding: "6px 10px",
            color: C.cream,
            fontFamily: fonts.mono,
            fontSize: 11,
            width: 180,
            outline: "none",
          }}
        />
        <label
          style={{
            fontFamily: fonts.mono,
            fontSize: 10,
            color: C.creamMuted,
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          Min Score: {minScore}
          <input
            type="range"
            min={0}
            max={100}
            value={minScore}
            onChange={(e) => setMinScore(Number(e.target.value))}
            style={{ width: 120, accentColor: C.green }}
          />
        </label>
      </div>

      {/* ── Wallet table ───────────────────────────────────────── */}
      <Panel>
        <div style={{ overflowX: "auto" }}>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              fontFamily: fonts.mono,
              fontSize: 12,
            }}
          >
            <thead>
              <tr>
                {[
                  "Score",
                  "Handle",
                  "Class",
                  "Win Rate",
                  "Trades",
                  "PnL",
                  "Copyability",
                  "Leader",
                  "Crowding %",
                ].map((h) => (
                  <th
                    key={h}
                    style={{
                      textAlign: h === "Handle" ? "left" : "right",
                      padding: "8px 10px",
                      borderBottom: `1px solid ${C.border}`,
                      color: C.creamMuted,
                      fontWeight: 500,
                      fontSize: 10,
                      textTransform: "uppercase",
                      letterSpacing: 1,
                      whiteSpace: "nowrap",
                    }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {smartWallets.map((w) => {
                const score = w.insiderScore ?? w.insider_score ?? 0;
                const winRate = w.winRate ?? w.win_rate ?? 0;
                const trades = w.trades ?? w.totalTrades ?? 0;
                const pnl = w.pnl ?? 0;
                const copyability = w.copyability ?? 0;
                const leader = w.leaderScore ?? w.leader_score ?? 0;
                const crowding = w.crowding ?? w.crowdingPct ?? 0;
                const classification = w.classification || "UNKNOWN";
                const classColor =
                  CLASSIFICATION_COLORS[classification] || C.creamMuted;

                const isHighCopy = copyability >= 80;
                const isHighCrowd = crowding > 25;

                let rowBg = "transparent";
                if (isHighCopy) rowBg = C.greenDim;
                if (isHighCrowd) rowBg = C.redDim;

                return (
                  <tr
                    key={w.address || w.id}
                    onClick={() =>
                      onSelectWallet && onSelectWallet(w.address)
                    }
                    style={{
                      borderBottom: `1px solid ${C.border}`,
                      background: rowBg,
                      cursor: onSelectWallet ? "pointer" : "default",
                      transition: "background 0.1s ease",
                    }}
                    onMouseEnter={(e) => {
                      if (!isHighCopy && !isHighCrowd)
                        e.currentTarget.style.background = C.creamGhost;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = rowBg;
                    }}
                  >
                    <td style={{ padding: "8px 10px", textAlign: "right" }}>
                      <RingGauge
                        value={score}
                        size={32}
                        color={getScoreColor(score)}
                        label={String(Math.round(score))}
                      />
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        color: C.cream,
                        fontWeight: 600,
                      }}
                    >
                      {w.handle || w.address?.slice(0, 10) || "\u2014"}
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "right" }}>
                      <PillBadge text={classification} color={classColor} />
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color:
                          winRate >= 0.6
                            ? C.green
                            : winRate >= 0.4
                            ? C.amber
                            : C.red,
                      }}
                    >
                      {formatPct(winRate)}
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color: C.creamSoft,
                      }}
                    >
                      {trades}
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color: pnlColor(pnl),
                        fontWeight: 600,
                      }}
                    >
                      {pnlSign(pnl)}
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color: copyability >= 80 ? C.green : C.creamSoft,
                      }}
                    >
                      {Math.round(copyability)}
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color: getScoreColor(leader),
                      }}
                    >
                      {Math.round(leader)}
                    </td>
                    <td
                      style={{
                        padding: "8px 10px",
                        textAlign: "right",
                        color: crowding > 25 ? C.red : C.creamSoft,
                        fontWeight: crowding > 25 ? 700 : 400,
                      }}
                    >
                      {typeof crowding === "number"
                        ? `${crowding.toFixed(1)}%`
                        : "\u2014"}
                    </td>
                  </tr>
                );
              })}
              {smartWallets.length === 0 && (
                <tr>
                  <td
                    colSpan={9}
                    style={{
                      padding: 30,
                      textAlign: "center",
                      color: C.creamMuted,
                      fontFamily: fonts.mono,
                      fontSize: 12,
                    }}
                  >
                    No wallets match current filters
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
