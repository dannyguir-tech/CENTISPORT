/** Page 13: Wallet Comparison — compare any 2 wallets side by side */
import { useState, useMemo } from 'react';
import { C, fonts, getScoreColor, formatUsd, formatPct, relativeTime, getCatColor, pnlColor } from '../utils/theme';
import { useApi, usePolling } from '../hooks/useApi';
import { Panel, MetricTile, PillBadge, RingGauge, SidePill, Loading, ErrorCard } from '../components/shared';

/* ── helpers ───────────────────────────────────────────────────────── */

function safeNum(v) {
  if (v == null) return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}

function winnerColor(a, b, higherWins = true) {
  if (a == null || b == null) return { aColor: C.creamSoft, bColor: C.creamSoft };
  if (a === b) return { aColor: C.creamSoft, bColor: C.creamSoft };
  const aWins = higherWins ? a > b : a < b;
  return {
    aColor: aWins ? C.green : C.creamSoft,
    bColor: aWins ? C.creamSoft : C.green,
  };
}

function getMarketId(trade) {
  return trade.market_id ?? trade.marketId ?? null;
}

function getSide(trade) {
  return (trade.side || '').toUpperCase();
}

/* ── dropdown style ────────────────────────────────────────────────── */

const selectStyle = {
  background: C.card,
  border: `1px solid ${C.border}`,
  borderRadius: 6,
  padding: '8px 12px',
  color: C.cream,
  fontFamily: fonts.mono,
  fontSize: 12,
  outline: 'none',
  minWidth: 220,
  cursor: 'pointer',
  flex: 1,
};

/* ── stat row ──────────────────────────────────────────────────────── */

function StatRow({ label, aVal, bVal, format, higherWins = true }) {
  const aNum = safeNum(aVal);
  const bNum = safeNum(bVal);
  const { aColor, bColor } = winnerColor(aNum, bNum, higherWins);
  const fmt = format || (v => (v != null ? String(v) : '\u2014'));

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '1fr auto 1fr',
      gap: 12,
      alignItems: 'center',
      padding: '8px 14px',
      borderBottom: `1px solid ${C.border}`,
    }}>
      <div style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 600, color: aColor, textAlign: 'right' }}>
        {fmt(aVal)}
      </div>
      <div style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1.5, textAlign: 'center', minWidth: 80 }}>
        {label}
      </div>
      <div style={{ fontFamily: fonts.mono, fontSize: 13, fontWeight: 600, color: bColor, textAlign: 'left' }}>
        {fmt(bVal)}
      </div>
    </div>
  );
}

/* ── component ─────────────────────────────────────────────────────── */

export default function WalletComparison() {
  const [addrA, setAddrA] = useState('');
  const [addrB, setAddrB] = useState('');

  /* all wallets for selector */
  const { data: wallets, loading: walletsLoading, error: walletsError } = useApi('/wallets');

  /* individual wallet details */
  const { data: walletA, loading: loadA } = useApi(addrA ? `/wallets/${addrA}` : '/wallets?limit=0', [addrA]);
  const { data: walletB, loading: loadB } = useApi(addrB ? `/wallets/${addrB}` : '/wallets?limit=0', [addrB]);

  /* trades for agreement analysis */
  const { data: tradesA } = useApi(addrA ? `/trades?wallet_id=${addrA}&limit=50` : '/trades?limit=0', [addrA]);
  const { data: tradesB } = useApi(addrB ? `/trades?wallet_id=${addrB}&limit=50` : '/trades?limit=0', [addrB]);

  /* ── agreement analysis ─────────────────────────────────────────── */
  const agreement = useMemo(() => {
    if (!addrA || !addrB) return null;
    if (!Array.isArray(tradesA) || !Array.isArray(tradesB)) return null;
    if (tradesA.length === 0 || tradesB.length === 0) return null;

    /* build market -> side maps */
    const mapA = {};
    for (const t of tradesA) {
      const mid = getMarketId(t);
      if (mid != null) mapA[mid] = { side: getSide(t), name: t.market_name || t.marketName || `#${mid}` };
    }
    const mapB = {};
    for (const t of tradesB) {
      const mid = getMarketId(t);
      if (mid != null) mapB[mid] = { side: getSide(t), name: t.market_name || t.marketName || `#${mid}` };
    }

    const shared = [];
    for (const mid of Object.keys(mapA)) {
      if (mapB[mid]) {
        const agree = mapA[mid].side === mapB[mid].side;
        shared.push({
          marketId: mid,
          name: mapA[mid].name || mapB[mid].name,
          sideA: mapA[mid].side,
          sideB: mapB[mid].side,
          agree,
        });
      }
    }

    const agrees = shared.filter(s => s.agree).length;
    const disagrees = shared.filter(s => !s.agree).length;

    return { shared, agrees, disagrees };
  }, [tradesA, tradesB, addrA, addrB]);

  /* ── wallet field extractors ────────────────────────────────────── */
  function extractFields(w) {
    if (!w) return null;
    /* handle single-object or array responses */
    const obj = Array.isArray(w) ? w[0] : w;
    if (!obj) return null;
    return {
      handle: obj.handle || obj.wallet_handle || (obj.address ? obj.address.slice(0, 12) : '\u2014'),
      address: obj.address || obj.wallet_address || '',
      score: safeNum(obj.insiderScore ?? obj.insider_score ?? obj.score) ?? 0,
      winRate: safeNum(obj.winRate ?? obj.win_rate) ?? 0,
      trades: safeNum(obj.trades ?? obj.totalTrades ?? obj.total_trades) ?? 0,
      pnl: safeNum(obj.pnl ?? obj.total_pnl) ?? 0,
      copyability: safeNum(obj.copyability ?? obj.copyabilityScore ?? obj.copyability_score) ?? 0,
      leaderScore: safeNum(obj.leaderScore ?? obj.leader_score) ?? 0,
      classification: obj.classification || obj.wallet_type || 'UNKNOWN',
      category: obj.category || '',
    };
  }

  const a = extractFields(walletA);
  const b = extractFields(walletB);

  /* ── loading / error ────────────────────────────────────────────── */
  if (walletsLoading && !wallets) return <Loading />;
  if (walletsError && !wallets) return <ErrorCard message={walletsError} />;

  const walletArr = Array.isArray(wallets) ? wallets : [];
  const bothSelected = addrA && addrB;

  /* ── render ─────────────────────────────────────────────────────── */
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* ── Selectors ────────────────────────────────────────────── */}
      <Panel title="WALLET COMPARISON">
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 200 }}>
            <label style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4, display: 'block' }}>
              Wallet A
            </label>
            <select value={addrA} onChange={e => setAddrA(e.target.value)} style={selectStyle}>
              <option value="" style={{ background: C.card, color: C.creamMuted }}>-- Select wallet A --</option>
              {walletArr.map(w => {
                const addr = w.address || w.wallet_address || w.id;
                const name = w.handle || (addr ? addr.slice(0, 14) : '?');
                return (
                  <option key={`a-${addr}`} value={addr} style={{ background: C.card, color: C.cream }}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>

          <div style={{
            fontFamily: fonts.mono,
            fontSize: 16,
            fontWeight: 700,
            color: C.creamMuted,
            alignSelf: 'flex-end',
            paddingBottom: 8,
          }}>
            VS
          </div>

          <div style={{ flex: 1, minWidth: 200 }}>
            <label style={{ fontFamily: fonts.mono, fontSize: 9, color: C.creamMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4, display: 'block' }}>
              Wallet B
            </label>
            <select value={addrB} onChange={e => setAddrB(e.target.value)} style={selectStyle}>
              <option value="" style={{ background: C.card, color: C.creamMuted }}>-- Select wallet B --</option>
              {walletArr.map(w => {
                const addr = w.address || w.wallet_address || w.id;
                const name = w.handle || (addr ? addr.slice(0, 14) : '?');
                return (
                  <option key={`b-${addr}`} value={addr} style={{ background: C.card, color: C.cream }}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
      </Panel>

      {/* ── Empty state ──────────────────────────────────────────── */}
      {!bothSelected && (
        <Panel>
          <div style={{
            textAlign: 'center',
            padding: '50px 20px',
            fontFamily: fonts.mono,
            fontSize: 13,
            color: C.creamMuted,
            letterSpacing: 0.5,
          }}>
            Select two wallets to compare
          </div>
        </Panel>
      )}

      {/* ── Loading detail ───────────────────────────────────────── */}
      {bothSelected && (loadA || loadB) && !a && !b && <Loading />}

      {/* ── Side-by-side cards ───────────────────────────────────── */}
      {bothSelected && a && b && (
        <>
          {/* Header cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[a, b].map((w, idx) => (
              <Panel key={idx}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 10 }}>
                  <RingGauge value={w.score} size={56} color={getScoreColor(w.score)} label={String(Math.round(w.score))} />
                  <div>
                    <div style={{ fontFamily: fonts.mono, fontSize: 15, fontWeight: 700, color: C.cream }}>
                      {w.handle}
                    </div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                      <PillBadge text={w.classification} color={w.classification === 'SNIPER' ? C.green : w.classification === 'MOMENTUM' ? C.cyan : C.creamMuted} />
                      {w.category && <PillBadge text={w.category} color={getCatColor(w.category)} />}
                    </div>
                  </div>
                </div>
              </Panel>
            ))}
          </div>

          {/* Stats comparison */}
          <Panel title="HEAD TO HEAD">
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              padding: '6px 14px',
              marginBottom: 4,
            }}>
              <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.green, fontWeight: 700, letterSpacing: 1 }}>
                {a.handle}
              </span>
              <span style={{ fontFamily: fonts.mono, fontSize: 10, color: C.green, fontWeight: 700, letterSpacing: 1 }}>
                {b.handle}
              </span>
            </div>

            <StatRow
              label="SCORE"
              aVal={a.score}
              bVal={b.score}
              format={v => v != null ? Math.round(v) : '\u2014'}
            />
            <StatRow
              label="WIN RATE"
              aVal={a.winRate}
              bVal={b.winRate}
              format={v => v != null ? formatPct(v) : '\u2014'}
            />
            <StatRow
              label="TRADES"
              aVal={a.trades}
              bVal={b.trades}
              format={v => v != null ? String(Math.round(v)) : '\u2014'}
            />
            <StatRow
              label="P&L"
              aVal={a.pnl}
              bVal={b.pnl}
              format={v => v != null ? formatUsd(v) : '\u2014'}
            />
            <StatRow
              label="COPYABILITY"
              aVal={a.copyability}
              bVal={b.copyability}
              format={v => v != null ? Math.round(v) : '\u2014'}
            />
            <StatRow
              label="LEADER SCORE"
              aVal={a.leaderScore}
              bVal={b.leaderScore}
              format={v => v != null ? Math.round(v) : '\u2014'}
            />
          </Panel>

          {/* ── Agreement analysis ───────────────────────────────── */}
          <Panel title="AGREEMENT ANALYSIS">
            {agreement && agreement.shared.length > 0 ? (
              <>
                <div style={{
                  display: 'flex',
                  gap: 16,
                  marginBottom: 14,
                  fontFamily: fonts.mono,
                  fontSize: 12,
                  color: C.creamSoft,
                }}>
                  <span>
                    These wallets{' '}
                    <span style={{ color: C.green, fontWeight: 700 }}>agree on {agreement.agrees} market{agreement.agrees !== 1 ? 's' : ''}</span>,{' '}
                    <span style={{ color: C.red, fontWeight: 700 }}>disagree on {agreement.disagrees}</span>
                  </span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {agreement.shared.map((s, i) => (
                    <div
                      key={s.marketId}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr auto 80px 80px',
                        gap: 10,
                        alignItems: 'center',
                        padding: '8px 14px',
                        borderBottom: `1px solid ${C.border}`,
                        background: s.agree ? C.greenDim : C.redDim,
                      }}
                    >
                      <span style={{ fontFamily: fonts.mono, fontSize: 11, color: C.cream, fontWeight: 600 }}>
                        {s.name}
                      </span>
                      <PillBadge
                        text={s.agree ? 'AGREE' : 'DISAGREE'}
                        color={s.agree ? C.green : C.red}
                      />
                      <div style={{ textAlign: 'center' }}>
                        <SidePill side={s.sideA} />
                      </div>
                      <div style={{ textAlign: 'center' }}>
                        <SidePill side={s.sideB} />
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div style={{
                textAlign: 'center',
                padding: '30px 20px',
                fontFamily: fonts.mono,
                fontSize: 12,
                color: C.creamMuted,
              }}>
                {!agreement
                  ? 'Loading trade data...'
                  : 'No shared markets found between these wallets'}
              </div>
            )}
          </Panel>
        </>
      )}
    </div>
  );
}
