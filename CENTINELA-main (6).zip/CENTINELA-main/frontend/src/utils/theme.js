/* CENTINELA Design System — exact spec colors, fonts, utilities */

export const C = {
  bg: '#060609',
  panel: '#0b0b10',
  card: '#0e0e15',
  border: 'rgba(245,235,210,0.06)',
  borderHi: 'rgba(245,235,210,0.12)',
  cream: '#f5ebd2',
  creamSoft: 'rgba(245,235,210,0.65)',
  creamMuted: 'rgba(245,235,210,0.35)',
  creamFaint: 'rgba(245,235,210,0.15)',
  creamGhost: 'rgba(245,235,210,0.07)',
  green: '#00ffaa',
  red: '#ff4466',
  cyan: '#00e5ff',
  amber: '#ffb84d',
  purple: '#b48eff',
  pink: '#ff6b9d',
  greenDim: 'rgba(0,255,170,0.10)',
  redDim: 'rgba(255,68,102,0.10)',
  cyanDim: 'rgba(0,229,255,0.10)',
  amberDim: 'rgba(255,184,77,0.10)',
  purpleDim: 'rgba(180,142,255,0.10)',
  pinkDim: 'rgba(255,107,157,0.10)',
};

export const fonts = {
  mono: "'DM Mono', monospace",
  sans: "'Instrument Sans', sans-serif",
};

export function getScoreColor(score) {
  if (score >= 90) return C.green;
  if (score >= 75) return C.cyan;
  if (score >= 60) return C.amber;
  if (score >= 40) return C.red;
  return '#662233';
}

export function getScoreLabel(score) {
  if (score >= 90) return 'ELITE';
  if (score >= 75) return 'HIGH';
  if (score >= 60) return 'MID';
  if (score >= 40) return 'LOW';
  return 'NOISE';
}

export const categoryColor = {
  Politics: C.purple,
  Crypto: C.amber,
  Sports: C.cyan,
};

export function getCatColor(cat) {
  return categoryColor[cat] || C.creamMuted;
}

export function formatUsd(val) {
  if (val == null) return '\u2014';
  const n = Number(val);
  if (isNaN(n)) return '\u2014';
  if (Math.abs(n) >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (Math.abs(n) >= 1_000) return `$${(n / 1_000).toFixed(1)}K`;
  return `$${n.toFixed(0)}`;
}

export function formatPct(val, decimals = 1) {
  if (val == null) return '\u2014';
  return `${(Number(val) * 100).toFixed(decimals)}%`;
}

export function formatPctRaw(val, decimals = 1) {
  if (val == null) return '\u2014';
  return `${Number(val).toFixed(decimals)}%`;
}

export function relativeTime(ts) {
  if (!ts) return '\u2014';
  const d = new Date(ts);
  const now = Date.now();
  const diff = Math.floor((now - d.getTime()) / 1000);
  if (diff < 0) return 'just now';
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export function stateColor(state) {
  if (state === 'green') return C.green;
  if (state === 'yellow') return C.amber;
  if (state === 'red') return C.red;
  return C.creamMuted;
}

export function severityColor(sev) {
  if (sev === 'critical') return C.red;
  if (sev === 'high') return C.amber;
  if (sev === 'warning') return C.amber;
  return C.creamMuted;
}

export function signalTypeIcon(type) {
  const map = {
    convergence: '\uD83C\uDFAF', insider: '\uD83D\uDFE1', dumb_money_fade: '\uD83D\uDD3B',
    cross_platform: '\uD83C\uDF10', consensus: '\uD83D\uDD25', lockout: '\uD83D\uDD12',
    state_change: '\u26A1', tp: '\uD83D\uDCB0', sl: '\uD83D\uDED1', system: '\u2699\uFE0F',
  };
  return map[type] || '\uD83D\uDCCA';
}

export function pnlColor(val) {
  if (val == null) return C.creamMuted;
  return Number(val) >= 0 ? C.green : C.red;
}

export function pnlSign(val) {
  if (val == null) return '\u2014';
  const n = Number(val);
  return n >= 0 ? `+${formatUsd(n)}` : `-${formatUsd(Math.abs(n))}`;
}
