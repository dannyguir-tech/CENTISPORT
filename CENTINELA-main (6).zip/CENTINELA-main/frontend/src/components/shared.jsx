import React, { useState } from "react";
import { C, fonts, getScoreColor, formatUsd, relativeTime, getCatColor, pnlColor } from "../utils/theme";
import { signalTypeIcon, stateColor } from "../utils/theme";

/* ================================================================== */
/*  1. RingGauge                                                      */
/* ================================================================== */

export function RingGauge({ value, size = 48, strokeWidth = 3, label }) {
  const safeVal =
    value == null || isNaN(Number(value))
      ? 0
      : Math.max(0, Math.min(100, Number(value)));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (safeVal / 100) * circumference;
  const color = getScoreColor(safeVal);
  const cx = size / 2;
  const cy = size / 2;
  const filterId = `rg-${size}-${Math.round(safeVal)}`;

  return (
    <svg
      width={size}
      height={size + (label ? 14 : 0)}
      style={{ overflow: "visible", display: "block" }}
    >
      <defs>
        <filter id={filterId}>
          <feDropShadow
            dx="0"
            dy="0"
            stdDeviation="2"
            floodColor={color}
            floodOpacity="0.5"
          />
        </filter>
      </defs>

      {/* background track */}
      <circle
        cx={cx}
        cy={cy}
        r={radius}
        fill="none"
        stroke={C.creamGhost}
        strokeWidth={strokeWidth}
      />

      {/* progress arc */}
      <circle
        cx={cx}
        cy={cy}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${cx} ${cy})`}
        style={{
          transition: "stroke-dashoffset 0.6s cubic-bezier(0.4,0,0.2,1)",
          filter: `url(#${filterId})`,
        }}
      />

      {/* center value */}
      <text
        x={cx}
        y={label ? cy - 2 : cy}
        textAnchor="middle"
        dominantBaseline="central"
        style={{
          fontFamily: fonts.mono,
          fontSize: size * 0.3,
          fontWeight: 700,
          fill: color,
        }}
      >
        {value == null ? "\u2014" : Math.round(safeVal)}
      </text>

      {/* optional label below */}
      {label && (
        <text
          x={cx}
          y={size + 10}
          textAnchor="middle"
          dominantBaseline="central"
          style={{
            fontFamily: fonts.sans,
            fontSize: 8,
            fill: C.creamMuted,
            textTransform: "uppercase",
            letterSpacing: "0.5px",
          }}
        >
          {label}
        </text>
      )}
    </svg>
  );
}

/* ================================================================== */
/*  2. Sparkline                                                      */
/* ================================================================== */

export function Sparkline({
  data = [],
  width = 120,
  height = 32,
  color = C.green,
}) {
  if (!data || data.length < 2) {
    return (
      <svg width={width} height={height}>
        <line
          x1={0}
          y1={height / 2}
          x2={width}
          y2={height / 2}
          stroke={C.creamGhost}
          strokeWidth={1}
        />
      </svg>
    );
  }

  const pad = 2;
  const w = width - pad * 2;
  const h = height - pad * 2;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const gradId = `sp-g-${width}-${height}`;
  const glowId = `sp-gl-${width}-${height}`;

  const coords = data.map((v, i) => ({
    x: pad + (i / (data.length - 1)) * w,
    y: pad + h - ((v - min) / range) * h,
  }));

  const polylinePoints = coords.map((p) => `${p.x},${p.y}`).join(" ");

  // Closed polygon for gradient fill underneath
  const firstX = coords[0].x;
  const lastX = coords[coords.length - 1].x;
  const fillPoints = `${polylinePoints} ${lastX},${height} ${firstX},${height}`;

  const end = coords[coords.length - 1];

  return (
    <svg width={width} height={height} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <filter id={glowId}>
          <feDropShadow
            dx="0"
            dy="0"
            stdDeviation="2"
            floodColor={color}
            floodOpacity="0.6"
          />
        </filter>
      </defs>
      <polygon points={fillPoints} fill={`url(#${gradId})`} />
      <polyline
        points={polylinePoints}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinejoin="round"
      />
      <circle
        cx={end.x}
        cy={end.y}
        r={2.5}
        fill={color}
        style={{ filter: `url(#${glowId})` }}
      />
    </svg>
  );
}

/* ================================================================== */
/*  3. PillBadge                                                      */
/* ================================================================== */

export function PillBadge({ label, text, color = C.creamMuted, bg }) {
  const display = label || text;
  if (!display) return null;

  const bgColor = bg || `${color}1a`;
  const borderColor = `${color}33`;

  return (
    <span
      style={{
        display: "inline-block",
        fontFamily: fonts.mono,
        fontSize: 9,
        textTransform: "uppercase",
        letterSpacing: "1.5px",
        color: color,
        background: bgColor,
        border: `1px solid ${borderColor}`,
        borderRadius: 999,
        padding: "2px 8px",
        lineHeight: "14px",
        whiteSpace: "nowrap",
        transition: "opacity 0.15s ease",
      }}
    >
      {display}
    </span>
  );
}

/* ================================================================== */
/*  4. MetricTile                                                     */
/* ================================================================== */

export function MetricTile({ label, value, color, sub, children }) {
  const [hov, setHov] = useState(false);

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: C.card,
        border: `1px solid ${hov ? C.borderHi : C.border}`,
        borderRadius: 8,
        padding: "14px 18px",
        minWidth: 0,
        transition: "border-color 0.15s ease",
      }}
    >
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 10,
          color: C.creamMuted,
          textTransform: "uppercase",
          letterSpacing: 1.5,
          marginBottom: 6,
        }}
      >
        {label || "\u2014"}
      </div>
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 22,
          fontWeight: 700,
          color: color || C.cream,
          lineHeight: 1.1,
        }}
      >
        {value != null ? value : "\u2014"}
      </div>
      {sub != null && (
        <div
          style={{
            fontSize: 11,
            color: C.creamMuted,
            marginTop: 4,
            fontFamily: fonts.sans,
          }}
        >
          {sub}
        </div>
      )}
      {children}
    </div>
  );
}

/* ================================================================== */
/*  5. Panel                                                          */
/* ================================================================== */

export function Panel({ title, children, rightContent, right, noPad, style: extra }) {
  const rc = rightContent || right;

  return (
    <div
      style={{
        background: C.panel,
        border: `1px solid ${C.border}`,
        borderRadius: 8,
        overflow: "hidden",
        ...extra,
      }}
    >
      {(title || rc) && (
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "10px 16px",
            borderBottom: `1px solid ${C.border}`,
          }}
        >
          {title && (
            <span
              style={{
                fontFamily: fonts.sans,
                fontSize: 11,
                color: C.creamMuted,
                textTransform: "uppercase",
                letterSpacing: 1.5,
                fontWeight: 600,
              }}
            >
              {title}
            </span>
          )}
          {rc && <div>{rc}</div>}
        </div>
      )}
      <div style={noPad ? undefined : { padding: 16 }}>{children}</div>
    </div>
  );
}

/* ================================================================== */
/*  6. SignalCard                                                     */
/* ================================================================== */

const SIGNAL_BORDER_COLORS = {
  convergence: C.green,
  insider: C.amber,
  dumb_money_fade: C.red,
  cross_platform: C.cyan,
  consensus: C.purple,
  lockout: C.pink,
  state_change: C.amber,
  tp: C.green,
  sl: C.red,
  system: C.creamMuted,
};

const BADGE_MAP = {
  outsized: { label: "outsized", color: C.amber },
  spike: { label: "spike", color: C.red },
  resolution: { label: "resolution", color: C.cyan },
  leader: { label: "leader", color: C.green },
  intent: { label: "intent", color: C.purple },
  trap: { label: "trap", color: C.pink },
};

export function SignalCard({
  alert,
  onClick,
  /* legacy props for backward compat */
  icon: legacyIcon,
  title: legacyTitle,
  subtitle: legacySubtitle,
  meta: legacyMeta,
  borderColor: legacyBorderColor,
}) {
  const [hov, setHov] = useState(false);

  /* ------- legacy mode (icon/title/subtitle/meta) ------- */
  if (!alert && (legacyTitle || legacyIcon)) {
    return (
      <div
        style={{
          background: C.card,
          border: `1px solid ${legacyBorderColor || C.border}`,
          borderRadius: 6,
          padding: "10px 14px",
          marginBottom: 6,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          {legacyIcon && <span style={{ fontSize: 14 }}>{legacyIcon}</span>}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div
              style={{
                fontFamily: fonts.mono,
                fontSize: 12,
                fontWeight: 600,
                color: C.cream,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {legacyTitle}
            </div>
            {legacySubtitle && (
              <div
                style={{
                  fontFamily: fonts.mono,
                  fontSize: 10,
                  color: C.creamSoft,
                  marginTop: 2,
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {legacySubtitle}
              </div>
            )}
          </div>
          {legacyMeta && (
            <span
              style={{
                fontFamily: fonts.mono,
                fontSize: 10,
                color: C.creamMuted,
                whiteSpace: "nowrap",
              }}
            >
              {legacyMeta}
            </span>
          )}
        </div>
      </div>
    );
  }

  /* ------- new alert-based mode ------- */
  if (!alert) return null;

  const {
    type,
    priority,
    signalScore,
    message,
    sentAt,
    walletId,
    marketId,
  } = alert;

  const bColor = SIGNAL_BORDER_COLORS[type] || C.creamMuted;
  const icon = signalTypeIcon(type);
  const firstLine = message ? String(message).split("\n")[0] : "\u2014";

  const msgLower = message ? String(message).toLowerCase() : "";
  const activeBadges = Object.keys(BADGE_MAP).filter((k) =>
    msgLower.includes(k)
  );

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: "flex",
        alignItems: "flex-start",
        gap: 12,
        padding: "12px 14px",
        borderLeft: `3px solid ${bColor}`,
        background: hov ? C.card : "transparent",
        cursor: onClick ? "pointer" : "default",
        transition: "background 0.15s ease",
        animation: "centinelaFadeIn 0.3s ease",
        borderBottom: `1px solid ${C.border}`,
      }}
    >
      {/* type icon */}
      <span
        style={{
          fontSize: 18,
          lineHeight: 1,
          flexShrink: 0,
          marginTop: 2,
        }}
      >
        {icon}
      </span>

      {/* ring gauge */}
      <div style={{ flexShrink: 0 }}>
        <RingGauge value={signalScore} size={32} strokeWidth={2.5} />
      </div>

      {/* text content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.cream,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            marginBottom: 4,
          }}
        >
          {firstLine}
        </div>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 4,
            alignItems: "center",
          }}
        >
          {type && (
            <PillBadge label={type.replace(/_/g, " ")} color={bColor} />
          )}
          {activeBadges.map((k) => (
            <PillBadge
              key={k}
              label={BADGE_MAP[k].label}
              color={BADGE_MAP[k].color}
            />
          ))}
        </div>

        {(walletId || marketId) && (
          <div
            style={{
              fontFamily: fonts.mono,
              fontSize: 9,
              color: C.creamMuted,
              marginTop: 4,
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {marketId && <span>MKT: {marketId}</span>}
            {marketId && walletId && <span> &middot; </span>}
            {walletId && <span>W: {walletId}</span>}
          </div>
        )}
      </div>

      {/* timestamp */}
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 9,
          color: C.creamMuted,
          whiteSpace: "nowrap",
          flexShrink: 0,
          marginTop: 2,
        }}
      >
        {relativeTime(sentAt)}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  7. DataTable                                                      */
/* ================================================================== */

export function DataTable({ columns, rows, onRowClick, emptyText }) {
  const [hovRow, setHovRow] = useState(null);

  const safeCols = columns || [];
  const safeRows = rows || [];

  if (safeRows.length === 0) {
    return (
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 12,
          color: C.creamMuted,
          padding: "32px 16px",
          textAlign: "center",
        }}
      >
        {emptyText || "No data"}
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontFamily: fonts.sans,
          fontSize: 12,
        }}
      >
        <thead>
          <tr>
            {safeCols.map((col) => (
              <th
                key={col.key}
                style={{
                  textAlign: col.align || "left",
                  padding: "8px 10px",
                  borderBottom: `1px solid ${C.border}`,
                  color: C.creamMuted,
                  fontFamily: fonts.sans,
                  fontWeight: 500,
                  fontSize: 10,
                  textTransform: "uppercase",
                  letterSpacing: 1,
                  width: col.width || "auto",
                  whiteSpace: "nowrap",
                }}
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {safeRows.map((row, i) => (
            <tr
              key={i}
              onClick={onRowClick ? () => onRowClick(row, i) : undefined}
              onMouseEnter={() => setHovRow(i)}
              onMouseLeave={() => setHovRow(null)}
              style={{
                borderBottom: `1px solid ${C.border}`,
                background: hovRow === i ? C.creamGhost : "transparent",
                cursor: onRowClick ? "pointer" : "default",
                transition: "background 0.15s ease",
              }}
            >
              {safeCols.map((col) => {
                const raw = row[col.key];
                const isNum =
                  col.align === "right" ||
                  (raw != null && typeof raw === "number");
                return (
                  <td
                    key={col.key}
                    style={{
                      padding: "8px 10px",
                      color: C.creamSoft,
                      fontFamily: isNum ? fonts.mono : fonts.sans,
                      textAlign: col.align || "left",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {col.render
                      ? col.render(row)
                      : raw != null
                      ? raw
                      : "\u2014"}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ================================================================== */
/*  8. ProgressBar                                                    */
/* ================================================================== */

export function ProgressBar({
  value,
  max = 100,
  color = C.green,
  height = 4,
  warn,
  label,
}) {
  const safeMax = Number(max) || 100;
  const safeVal = value == null ? 0 : Math.max(0, Math.min(Number(value), safeMax));
  const pct = safeMax > 0 ? (safeVal / safeMax) * 100 : 0;
  const barColor = warn ? C.red : color;

  return (
    <div>
      {label && (
        <div
          style={{
            fontFamily: fonts.mono,
            fontSize: 10,
            color: C.creamMuted,
            marginBottom: 3,
          }}
        >
          {label}
        </div>
      )}
      <div
        style={{
          width: "100%",
          height,
          background: C.creamGhost,
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${pct}%`,
            height: "100%",
            background: barColor,
            borderRadius: 2,
            transition: "width 0.3s ease",
          }}
        />
      </div>
    </div>
  );
}

/* ================================================================== */
/*  9. Loading                                                        */
/* ================================================================== */

const pulseKeyframes = `
@keyframes centinelaPulse {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 1; }
}
`;

export function Loading() {
  return (
    <>
      <style>{pulseKeyframes}</style>
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 13,
          color: C.creamMuted,
          padding: 40,
          textAlign: "center",
          animation: "centinelaPulse 1.5s ease-in-out infinite",
        }}
      >
        Loading...
      </div>
    </>
  );
}

/* ================================================================== */
/* 10. ErrorCard                                                      */
/* ================================================================== */

export function ErrorCard({ message, onRetry }) {
  const [hov, setHov] = useState(false);

  return (
    <div
      style={{
        background: C.redDim,
        border: "1px solid rgba(255,68,102,0.20)",
        borderRadius: 8,
        padding: "16px 20px",
        display: "flex",
        alignItems: "center",
        gap: 12,
      }}
    >
      <span style={{ fontSize: 20, lineHeight: 1, flexShrink: 0 }}>
        {"\u26A0\uFE0F"}
      </span>
      <div style={{ flex: 1 }}>
        <div
          style={{
            fontFamily: fonts.mono,
            fontSize: 12,
            color: C.red,
            marginBottom: onRetry ? 8 : 0,
          }}
        >
          {message || "Something went wrong"}
        </div>
        {onRetry && (
          <button
            onClick={onRetry}
            onMouseEnter={() => setHov(true)}
            onMouseLeave={() => setHov(false)}
            style={{
              fontFamily: fonts.mono,
              fontSize: 10,
              textTransform: "uppercase",
              letterSpacing: 1.5,
              color: C.cream,
              background: hov
                ? "rgba(255,68,102,0.25)"
                : "rgba(255,68,102,0.15)",
              border: "1px solid rgba(255,68,102,0.30)",
              borderRadius: 4,
              padding: "5px 14px",
              cursor: "pointer",
              transition: "background 0.15s ease",
            }}
          >
            Retry
          </button>
        )}
      </div>
    </div>
  );
}

/* ================================================================== */
/* 11. GridBG                                                         */
/* ================================================================== */

export function GridBG() {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        pointerEvents: "none",
        zIndex: 0,
        overflow: "hidden",
      }}
    >
      {/* grid pattern */}
      <svg
        width="100%"
        height="100%"
        style={{ position: "absolute", top: 0, left: 0 }}
      >
        <defs>
          <pattern
            id="centinela-grid"
            width="50"
            height="50"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 50 0 L 0 0 0 50"
              fill="none"
              stroke={C.border}
              strokeWidth="0.5"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#centinela-grid)" />
      </svg>

      {/* green orb — top-left */}
      <div
        style={{
          position: "absolute",
          top: "-10%",
          left: "-10%",
          width: "50%",
          height: "50%",
          borderRadius: "50%",
          background: `radial-gradient(circle, ${C.green} 0%, transparent 70%)`,
          opacity: 0.025,
        }}
      />
      {/* cyan orb — bottom-right */}
      <div
        style={{
          position: "absolute",
          bottom: "-10%",
          right: "-10%",
          width: "50%",
          height: "50%",
          borderRadius: "50%",
          background: `radial-gradient(circle, ${C.cyan} 0%, transparent 70%)`,
          opacity: 0.02,
        }}
      />
      {/* purple orb — center-left */}
      <div
        style={{
          position: "absolute",
          top: "30%",
          left: "-5%",
          width: "40%",
          height: "40%",
          borderRadius: "50%",
          background: `radial-gradient(circle, ${C.purple} 0%, transparent 70%)`,
          opacity: 0.03,
        }}
      />
    </div>
  );
}

/* ================================================================== */
/* 12. ScanLine                                                       */
/* ================================================================== */

const scanKeyframes = `
@keyframes centinelaScanLine {
  0%   { top: -2px; }
  100% { top: 100vh; }
}
`;

const fadeInKeyframes = `
@keyframes centinelaFadeIn {
  from { opacity: 0; transform: translateY(4px); }
  to   { opacity: 1; transform: translateY(0); }
}
`;

export function ScanLine() {
  return (
    <>
      <style>{scanKeyframes}{fadeInKeyframes}</style>
      <div
        style={{
          position: "fixed",
          left: 0,
          width: "100vw",
          height: "2px",
          background: `linear-gradient(90deg, transparent, ${C.green}, transparent)`,
          opacity: 0.03,
          pointerEvents: "none",
          zIndex: 1,
          animation: "centinelaScanLine 4s linear infinite",
          top: "-2px",
        }}
      />
    </>
  );
}

/* ================================================================== */
/* 13. StateBanner                                                    */
/* ================================================================== */

const STATE_CONFIG = {
  GREEN: {
    bg: C.greenDim,
    border: "rgba(0,255,170,0.15)",
    color: C.green,
    text: "System nominal",
  },
  YELLOW: {
    bg: C.amberDim,
    border: "rgba(255,184,77,0.15)",
    color: C.amber,
    text: "Edge declining \u2014 sizes reduced 50%",
  },
  RED: {
    bg: C.redDim,
    border: "rgba(255,68,102,0.15)",
    color: C.red,
    text: "Strategy unprofitable \u2014 signals halted",
  },
};

export function StateBanner({ state, label }) {
  const key = state ? String(state).toUpperCase() : null;
  const cfg = key && STATE_CONFIG[key];
  if (!cfg) return null;

  return (
    <div
      style={{
        width: "100%",
        padding: "8px 16px",
        background: cfg.bg,
        borderBottom: `1px solid ${cfg.border}`,
        fontFamily: fonts.mono,
        fontSize: 11,
        fontWeight: 600,
        color: cfg.color,
        textTransform: "uppercase",
        letterSpacing: 1.5,
        textAlign: "center",
      }}
    >
      {label || cfg.text}
    </div>
  );
}

/* ================================================================== */
/* 14. SidePill                                                       */
/* ================================================================== */

export function SidePill({ side }) {
  if (!side) return null;
  const upper = String(side).toUpperCase();
  const isYes = upper === "YES";
  const color = isYes ? C.green : C.red;
  const bg = isYes ? C.greenDim : C.redDim;

  return (
    <span
      style={{
        display: "inline-block",
        fontFamily: fonts.mono,
        fontSize: 9,
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: 1,
        color: color,
        background: bg,
        border: `1px solid ${color}33`,
        borderRadius: 999,
        padding: "1px 7px",
        lineHeight: "14px",
        whiteSpace: "nowrap",
      }}
    >
      {upper}
    </span>
  );
}

/* ================================================================== */
/*  LEGACY COMPAT — kept for existing page imports                    */
/* ================================================================== */

/** Stat card used across dashboard pages */
export function StatCard({ label, value, sub, color }) {
  return (
    <div
      style={{
        background: C.card,
        border: `1px solid ${C.border}`,
        borderRadius: 8,
        padding: "14px 18px",
      }}
    >
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 11,
          color: C.creamMuted,
          textTransform: "uppercase",
          letterSpacing: 1.5,
        }}
      >
        {label}
      </div>
      <div
        style={{
          fontFamily: fonts.mono,
          fontSize: 22,
          fontWeight: 700,
          color: color || C.cream,
          marginTop: 4,
        }}
      >
        {value}
      </div>
      {sub && (
        <div style={{ fontSize: 11, color: C.creamMuted, marginTop: 2 }}>
          {sub}
        </div>
      )}
    </div>
  );
}

/** Grid layout for stat cards */
export function StatGrid({ children, cols = 4 }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: `repeat(${cols}, 1fr)`,
        gap: 12,
        marginBottom: 20,
      }}
    >
      {children}
    </div>
  );
}

/** Score badge ring (legacy) */
export function ScoreBadge({ score, size = 42 }) {
  const color = getScoreColor(score);
  const pct = (score || 0) / 100;
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        border: `2px solid ${color}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: fonts.mono,
        fontSize: size * 0.33,
        fontWeight: 700,
        color,
        background: `${color}11`,
        position: "relative",
      }}
    >
      {score != null ? Math.round(score) : "\u2014"}
      <svg
        style={{ position: "absolute", top: -2, left: -2 }}
        width={size + 4}
        height={size + 4}
      >
        <circle
          cx={(size + 4) / 2}
          cy={(size + 4) / 2}
          r={size / 2}
          fill="none"
          stroke={color}
          strokeWidth={2}
          strokeDasharray={`${pct * Math.PI * size} ${Math.PI * size}`}
          strokeLinecap="round"
          transform={`rotate(-90 ${(size + 4) / 2} ${(size + 4) / 2})`}
          opacity={0.6}
        />
      </svg>
    </div>
  );
}

/** Section header */
export function SectionHeader({ title, right }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 16,
      }}
    >
      <h2
        style={{
          fontFamily: fonts.mono,
          fontSize: 16,
          fontWeight: 700,
          letterSpacing: 2,
          margin: 0,
          color: C.green,
        }}
      >
        {title}
      </h2>
      {right}
    </div>
  );
}
