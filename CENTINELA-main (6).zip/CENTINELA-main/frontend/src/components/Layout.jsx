import { useState, useEffect } from 'react';
import { C, fonts } from '../utils/theme';

const NAV_ITEMS = [
  // OVERVIEW
  { id: 'command-center', label: 'Command Center', icon: '◈', section: 'OVERVIEW' },
  { id: 'agreement-board', label: 'Agreement Board', icon: '◫', section: 'OVERVIEW' },
  // WALLETS
  { id: 'smart-money', label: 'Smart Money', icon: '◆', section: 'WALLETS' },
  { id: 'dumb-money', label: 'Dumb Money', icon: '◇', section: 'WALLETS' },
  { id: 'wallet-detail', label: 'Wallet Detail', icon: '◎', section: 'WALLETS', isNew: true },
  { id: 'wallet-comparison', label: 'Wallet Comparison', icon: '⊞', section: 'WALLETS', isNew: true },
  { id: 'timing-patterns', label: 'Timing Patterns', icon: '◴', section: 'WALLETS', isNew: true },
  // POSITIONS
  { id: 'my-positions', label: 'My Positions', icon: '▣', section: 'POSITIONS' },
  { id: 'consensus', label: 'Consensus', icon: '◉', section: 'POSITIONS' },
  { id: 'perfect-storm', label: 'Perfect Storm', icon: '⬡', section: 'POSITIONS' },
  // MARKETS
  { id: 'cross-platform', label: 'Cross-Platform', icon: '⊕', section: 'MARKETS' },
  { id: 'market-intelligence', label: 'Market Intelligence', icon: '◬', section: 'MARKETS' },
  { id: 'money-flow', label: 'Money Flow', icon: '⇄', section: 'MARKETS', isNew: true },
  // ANALYSIS
  { id: 'performance', label: 'Performance', icon: '▧', section: 'ANALYSIS' },
  { id: 'what-if-replay', label: 'What-If Replay', icon: '↻', section: 'ANALYSIS', isNew: true },
  { id: 'clusters', label: 'Clusters', icon: '⬢', section: 'ANALYSIS' },
  // SYSTEM
  { id: 'settings', label: 'Settings', icon: '⚙', section: 'SYSTEM' },
];

const SECTIONS = ['OVERVIEW', 'WALLETS', 'POSITIONS', 'MARKETS', 'ANALYSIS', 'SYSTEM'];

function getStaleSeconds(lastUpdated) {
  if (!lastUpdated) return null;
  return Math.floor((Date.now() - new Date(lastUpdated).getTime()) / 1000);
}

export default function Layout({ children, activePage, onNavigate, lastUpdated }) {
  const [hoveredItem, setHoveredItem] = useState(null);
  const [staleSeconds, setStaleSeconds] = useState(() => getStaleSeconds(lastUpdated));

  // Update stale timer every second
  useEffect(() => {
    setStaleSeconds(getStaleSeconds(lastUpdated));
    const interval = setInterval(() => {
      setStaleSeconds(getStaleSeconds(lastUpdated));
    }, 1000);
    return () => clearInterval(interval);
  }, [lastUpdated]);

  const isStale = staleSeconds !== null && staleSeconds > 30;

  // Group nav items by section
  const grouped = {};
  for (const section of SECTIONS) {
    grouped[section] = NAV_ITEMS.filter((item) => item.section === section);
  }

  return (
    <div
      style={{
        display: 'flex',
        minHeight: '100vh',
        fontFamily: fonts.sans,
        background: C.bg,
        color: C.cream,
      }}
    >
      {/* LEFT SIDEBAR */}
      <aside
        style={{
          width: 220,
          flexShrink: 0,
          background: C.panel,
          borderRight: `1px solid ${C.border}`,
          display: 'flex',
          flexDirection: 'column',
          overflowY: 'auto',
        }}
      >
        {/* Logo / Title */}
        <div
          style={{
            padding: '20px 16px 6px',
            borderBottom: `1px solid ${C.border}`,
            paddingBottom: 14,
          }}
        >
          <div
            style={{
              fontFamily: fonts.mono,
              fontSize: 14,
              fontWeight: 700,
              letterSpacing: 3,
              color: C.green,
              textShadow: `0 0 12px rgba(0,255,170,0.4), 0 0 24px rgba(0,255,170,0.15)`,
              textAlign: 'center',
            }}
          >
            CENTINELA
          </div>
          <div
            style={{
              fontFamily: fonts.sans,
              fontSize: 8,
              color: C.creamMuted,
              fontStyle: 'italic',
              textAlign: 'center',
              marginTop: 4,
              letterSpacing: 0.5,
            }}
          >
            The Watchman Sees Everything
          </div>
        </div>

        {/* Navigation */}
        <nav style={{ flex: 1, padding: '8px 0', overflowY: 'auto' }}>
          {SECTIONS.map((section) => (
            <div key={section} style={{ marginBottom: 4 }}>
              {/* Section header */}
              <div
                style={{
                  fontSize: 8,
                  fontFamily: fonts.mono,
                  fontWeight: 600,
                  color: C.creamFaint,
                  textTransform: 'uppercase',
                  letterSpacing: 1.5,
                  padding: '10px 16px 4px',
                  userSelect: 'none',
                }}
              >
                {section}
              </div>

              {/* Nav items */}
              {grouped[section].map((item) => {
                const isActive = activePage === item.id;
                const isHovered = hoveredItem === item.id;

                return (
                  <div
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    onMouseEnter={() => setHoveredItem(item.id)}
                    onMouseLeave={() => setHoveredItem(null)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '7px 12px 7px 14px',
                      marginLeft: 0,
                      fontSize: 12,
                      fontWeight: 500,
                      color: isActive ? C.green : isHovered ? C.cream : C.creamSoft,
                      cursor: 'pointer',
                      userSelect: 'none',
                      transition: 'all 0.15s ease',
                      background: isActive
                        ? C.greenDim
                        : isHovered
                          ? C.creamGhost
                          : 'transparent',
                      borderLeft: isActive
                        ? `2px solid ${C.green}`
                        : '2px solid transparent',
                    }}
                  >
                    <span
                      style={{
                        fontSize: 13,
                        width: 18,
                        textAlign: 'center',
                        flexShrink: 0,
                        opacity: isActive ? 1 : 0.6,
                      }}
                    >
                      {item.icon}
                    </span>
                    <span style={{ flex: 1 }}>{item.label}</span>
                    {item.isNew && (
                      <span
                        style={{
                          fontSize: 7,
                          fontFamily: fonts.mono,
                          fontWeight: 700,
                          color: C.cyan,
                          background: C.cyanDim,
                          padding: '1px 4px',
                          borderRadius: 3,
                          letterSpacing: 0.5,
                          flexShrink: 0,
                        }}
                      >
                        NEW
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Last Updated Footer */}
        <div
          style={{
            padding: '12px 16px',
            borderTop: `1px solid ${C.border}`,
            fontSize: 9,
            fontFamily: fonts.mono,
            color: isStale ? C.red : C.creamMuted,
            textAlign: 'center',
            flexShrink: 0,
          }}
        >
          {staleSeconds !== null ? (
            <>
              <span>Last updated: {staleSeconds}s ago</span>
              {isStale && (
                <div
                  style={{
                    marginTop: 4,
                    fontSize: 8,
                    color: C.red,
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    letterSpacing: 1,
                    textShadow: `0 0 8px rgba(255,68,102,0.4)`,
                  }}
                >
                  DATA STALE
                </div>
              )}
            </>
          ) : (
            <span>No data loaded</span>
          )}
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main
        style={{
          flex: 1,
          padding: 24,
          overflowY: 'auto',
          maxHeight: '100vh',
          background: C.bg,
          scrollbarWidth: 'thin',
          scrollbarColor: `${C.creamGhost} transparent`,
        }}
      >
        {children}
      </main>

      {/* Scrollbar styling via injected CSS */}
      <style>{`
        main::-webkit-scrollbar {
          width: 6px;
        }
        main::-webkit-scrollbar-track {
          background: transparent;
        }
        main::-webkit-scrollbar-thumb {
          background: ${C.creamGhost};
          border-radius: 3px;
        }
        main::-webkit-scrollbar-thumb:hover {
          background: ${C.creamFaint};
        }
        aside::-webkit-scrollbar {
          width: 4px;
        }
        aside::-webkit-scrollbar-track {
          background: transparent;
        }
        aside::-webkit-scrollbar-thumb {
          background: ${C.creamGhost};
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
}
