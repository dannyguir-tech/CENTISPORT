import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import CommandCenter from './pages/CommandCenter';
import AgreementBoard from './pages/AgreementBoard';
import SmartWatchlist from './pages/SmartWatchlist';
import DumbMoney from './pages/DumbMoney';
import WalletDetail from './pages/WalletDetail';
import WalletComparison from './pages/WalletComparison';
import TimingPatterns from './pages/TimingPatterns';
import Positions from './pages/Positions';
import Consensus from './pages/Consensus';
import PerfectStorm from './pages/PerfectStorm';
import CrossPlatform from './pages/CrossPlatform';
import Intelligence from './pages/Intelligence';
import MoneyFlow from './pages/MoneyFlow';
import Performance from './pages/Performance';
import WhatIfReplay from './pages/WhatIfReplay';
import Clusters from './pages/Clusters';
import Settings from './pages/Settings';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* OVERVIEW */}
        <Route index element={<CommandCenter />} />
        <Route path="agreement-board" element={<AgreementBoard />} />
        {/* WALLETS */}
        <Route path="smart" element={<SmartWatchlist />} />
        <Route path="dumb" element={<DumbMoney />} />
        <Route path="wallet/:address" element={<WalletDetail />} />
        <Route path="wallet-compare" element={<WalletComparison />} />
        <Route path="timing-patterns" element={<TimingPatterns />} />
        {/* POSITIONS */}
        <Route path="positions" element={<Positions />} />
        <Route path="consensus" element={<Consensus />} />
        <Route path="perfect-storm" element={<PerfectStorm />} />
        {/* MARKETS */}
        <Route path="cross-platform" element={<CrossPlatform />} />
        <Route path="intelligence" element={<Intelligence />} />
        <Route path="money-flow" element={<MoneyFlow />} />
        {/* ANALYSIS */}
        <Route path="performance" element={<Performance />} />
        <Route path="what-if" element={<WhatIfReplay />} />
        <Route path="clusters" element={<Clusters />} />
        {/* SYSTEM */}
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  );
}
