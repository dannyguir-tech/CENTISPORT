import { useState, useEffect, useCallback, useRef } from 'react';

const API_BASE = import.meta.env.VITE_API_URL || '/api';

async function apiFetch(path, options = {}, retries = 1) {
  const url = `${API_BASE}${path}`;
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
      const ct = res.headers.get('content-type') || '';
      if (ct.includes('json')) return await res.json();
      return await res.text();
    } catch (err) {
      if (i < retries) {
        await new Promise(r => setTimeout(r, 2000));
        continue;
      }
      console.warn(`API error: ${path}`, err.message);
      return null;
    }
  }
  return null;
}

export function useApi(path, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await apiFetch(path);
    if (result === null) {
      setError('Failed to fetch');
    } else {
      setData(result);
    }
    setLoading(false);
  }, [path]);

  useEffect(() => { refetch(); }, [refetch, ...deps]); // eslint-disable-line react-hooks/exhaustive-deps

  return { data, loading, error, refetch };
}

export function usePolling(path, intervalMs = 10000) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const intervalRef = useRef(null);

  const fetchData = useCallback(async () => {
    const result = await apiFetch(path);
    if (result === null) {
      setError('Failed to fetch');
    } else {
      setData(result);
      setError(null);
      setLastUpdated(Date.now());
    }
    setLoading(false);
  }, [path]);

  useEffect(() => {
    fetchData();
    intervalRef.current = setInterval(fetchData, intervalMs);
    return () => clearInterval(intervalRef.current);
  }, [fetchData, intervalMs]);

  return { data, loading, error, lastUpdated, refetch: fetchData };
}

export async function apiPost(path, body) {
  return apiFetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

export async function apiPatch(path, body) {
  return apiFetch(path, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

export { API_BASE };
