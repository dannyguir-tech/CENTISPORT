import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      manifest: {
        name: "CENTINELA",
        short_name: "Centinela",
        description: "The Watchman Sees Everything",
        theme_color: "#0a0a0e",
        background_color: "#0a0a0e",
        display: "standalone",
        icons: [{ src: "/icon-192.png", sizes: "192x192", type: "image/png" }],
      },
    }),
  ],
  server: {
    proxy: { "/api": "http://localhost:8000" },
  },
});
