# CENTINELA — Final Execution Brief
## "The Watchman Sees Everything"
### Personal Polymarket Insider Detection & Copy Trade Signal System

---

## PHILOSOPHY

**One rule governs every decision in this system:**
> If a feature does not improve signal quality, execution quality, or risk control — do not build it yet.

This is a lean execution engine, not a feature showcase. Build only what generates profit. Measure everything. Scale what works. Cut what doesn't.

---

## OVERVIEW

Centinela tracks Polymarket wallets, detects insider patterns, scores traders by copyability, and sends real-time Telegram alerts so I can manually copy trade. I make every trade decision — the system recommends, I execute.

Single user. Personal tool. No auth, no billing, no onboarding.

---

## TECH STACK

- **Backend:** Python (FastAPI)
- **Database:** PostgreSQL (upgrade path: TimescaleDB if time-series queries become bottleneck)
- **Cache/Queue:** Redis (real-time trade streaming, rate limiting, priority queue)
- **Frontend:** React dashboard (dark terminal aesthetic — cream text on black)
- **Alerts:** Telegram Bot API (primary), Discord webhook (backup)
- **Scheduler:** APScheduler or Celery (periodic scans, score recalculation)
- **Deployment:** Docker Compose (PostgreSQL + Redis + API + Worker + Frontend)
- **Python SDK:** `pip install polymarket-apis` (unified wrapper for all 3 APIs with Pydantic validation)

---

## API ARCHITECTURE

There are 3 separate Polymarket APIs. Using the wrong one for the wrong job will break things.

### 1. Gamma API (gamma-api.polymarket.com) — Market Discovery
- Market metadata: titles, descriptions, outcomes, token IDs, resolution criteria
- Event grouping (related markets under one event)
- Filtering by: slug, market_id, token_id, tag_id, active/closed/archived, liquidity, volume, dates
- **Use for:** market discovery, quality filtering, category tagging, resolution tracking
- **Cache:** 5-minute TTL (market metadata doesn't change often)

### 2. CLOB API (clob.polymarket.com) — Order Book & Pricing
- Midpoints, prices, spreads, tick sizes for any token
- Full order book depth (bids + asks)
- Recent filled trades
- Fee rates per market (maker_base_fee, taker_base_fee)
- Order placement (limit GTC, market FOK) — requires API keys
- Rate limits: ~10 orders/sec, 60 req/min public. Cloudflare throttling (delays, not rejects).
- **Use for:** order book analysis, liquidity checks, slippage estimation, price data
- Read-only mode works WITHOUT API keys

### 3. Data API — Wallet Tracking & Leaderboard
- User positions and P&L for any wallet
- Trade history / activity for any wallet
- Leaderboard rankings by profit/volume
- **Use for:** ALL wallet tracking, position monitoring, leaderboard scanning
- **This is the PRIMARY wallet data source — NOT the CLOB API**
- Public data, no auth required

### 4. WebSocket (wss://ws-subscriptions-clob.polymarket.com)
- **Market channel** (`/ws/market`) — real-time order book updates, price changes, trade fills
  - Subscribe to specific token IDs
  - Set `custom_feature_enabled: true` for additional event types
  - Up to 10 instruments per connection (open multiple connections if needed)
- **User channel** (`/ws/user`) — order status updates (requires auth)
- **Use for:** real-time trade detection, order book monitoring, pending order alerts
- This is the speed layer — WebSocket, not polling

### 5. External APIs
- **Kalshi API** — prices for cross-platform divergence detection (CRITICAL — Phase 1)
- **Polygon RPC** — on-chain backup data source (DELAYED — enable after system stability)

### Fee Strategy
- **ALWAYS use limit orders (GTC) for zero fees.** Never market orders (FOK).
- Maker orders = zero fees on most markets
- Taker fees exist on some markets — check `maker_base_fee` and `taker_base_fee` before recommending entry
- Build "Use LIMIT ORDER at $X.XX (zero fees)" into every alert

---

## BUILD PHASES

### Phase 0: Paper Trading Infrastructure (Week 1)
Build everything in simulation mode first. No real money until criteria are met.

```
Paper Trading Graduation Criteria:
- Minimum 50 signals tracked
- Edge retention ≥ 40% (you're capturing 40%+ of the insider's edge after delay)
- Win rate ≥ 55% on signals you "took" (paper)
- Rolling 30-day phantom PnL is positive
- Minimum 4 weeks of data
→ Do NOT trade real money until ALL criteria are met
```

### Phase 1: MVP Signals (Week 1-3)
5 features. Nothing else until these work.

1. **Wallet tracker** — add/remove wallets, store metadata, category tags
2. **Real-time trade feed** — WebSocket connection to market channel, detect trades from tracked wallets, store everything
3. **Basic insider scoring** — score wallets 0-100 (details in Scoring Engine section below)
4. **Telegram alerts** — formatted signal messages with context (details in Alert Format section below)
5. **Cross-platform price comparison** — Kalshi API integration, detect divergence ≥ 10 points

### Phase 2: Execution Protection (Week 3-5)
This is what separates "cool tool" from "profitable system."

6. **Chase risk filter** — if price moved too far after insider entry, expire the signal
7. **Slippage capping** — position size capped by order book depth, not just bankroll
8. **Entry quality tracking** — measure edge retention on every signal
9. **Bankroll manager** — capital limits, daily/weekly loss lockout
10. **Position size calculator** — fractional Kelly, capped by slippage
11. **Wash trade filter** — detect and exclude fake wallets
12. **Signal throttling** — max alerts per hour/day, quality floor

### Phase 3: Edge Refinement (Week 5-8)
Only build these after Phase 1-2 are running and producing data.

13. **Consensus signals** — 3+ wallets on same side = high conviction
14. **Wallet classification** — categorize as sniper/momentum/market maker/hedger/noise
15. **First entry detection** — early/mid/late position build phase
16. **Overcrowding detection** — detect when too many people are copying a wallet
17. **Exit rules engine** — TP/SL/time/insider-exit alerts
18. **Edge decay monitoring** — GREEN/YELLOW/RED strategy state with auto-response
19. **Scoring weight calibration** — data-driven weight adjustment after 4-8 weeks
20. **Shadow tracking** — phantom PnL on skipped signals

### Phase 4: Scale Intelligence (Week 8-12)
Layer on only after the core edge is proven.

21. **Wallet discovery** — auto-scan leaderboard for new candidates
22. **Cluster detection** — identify related wallets controlled by same person
23. **Backtest engine** — historical simulation before adding wallets
24. **Order book intelligence** — pending order detection, imbalance alerts
25. **Resolution calendar** — capital unlock timeline, utilization forecasting
26. **Market heat map** — where smart money is concentrated
27. **Entry window calculator** — optimal copy delay per wallet
28. **Correlation risk monitor** — portfolio-level risk alerts

### Phase 5: Operations (Week 12+)
Build when everything else is profitable and stable.

29. **Trade journal** — pre/post notes, pattern analysis, Telegram quick-entry
30. **Performance reports** — weekly/monthly automated analysis
31. **Tax export** — cost basis, realized gains, CSV for filing
32. **Dashboard polish** — animations, mobile PWA, notification sounds
33. **AI catalyst scanner** — Claude API for probability impact estimation
34. **News integration** — Twitter/RSS for catalyst timestamping

---

## EXECUTION PROTECTION SYSTEM (the money-saving layer)

### Chase Risk Filter
The #1 way copy traders lose money: chasing a price that already moved.

```
Logic:
1. Insider enters at price P
2. Alert fires at time T (target: within 30 seconds)
3. At time T, check current price P_now
4. Calculate move: (P_now - P) / P
5. Calculate dynamic threshold: max(3%, 1.5 × avg_1min_volatility_for_this_market)
6. If move > threshold → EXPIRE signal
7. Alert becomes: "⏸ Signal expired — price moved too fast. Insider entered at $0.28, now $0.33 (+17.8%). Do not chase."

If expired: do NOT send normal trade alert. Send expiration notice instead.
No override. No exceptions.
```

### Slippage Capping
Position size is limited by TWO factors, not just one:

```
kelly_size = fractional Kelly calculation based on bankroll and edge
slippage_cap = max position where estimated slippage ≤ 2%
final_size = min(kelly_size, slippage_cap)

Slippage estimation:
- Fetch current order book depth
- Walk the book: how many shares can I buy before price moves 2%?
- That number = slippage_cap
- Recalculate on every alert (order books change)
```

### Entry Quality Tracking
Measure how much of the insider's edge you actually capture:

```
For every signal, record:
- insider_entry_price: what the insider paid
- alert_price: price when alert was generated
- estimated_user_entry: price 2 minutes after alert (realistic entry for manual trading)
- price_after_60s: price 60 seconds after insider entry
- price_after_5m: price 5 minutes after insider entry
- price_at_resolution: final outcome price ($1 or $0)

Derived metric — Edge Retention %:
- insider_edge = abs(resolution_price - insider_entry_price)
- user_edge = abs(resolution_price - estimated_user_entry)
- edge_retention = user_edge / insider_edge × 100

If a wallet consistently shows edge_retention < 30%:
→ The insider's trades move price too fast to copy
→ Downgrade wallet score or remove from watchlist
→ Alert: "Wallet X has poor copyability — you only capture 22% of their edge"
```

### Signal Expiration
Signals are NOT evergreen. They expire when:

```
- Chase risk filter triggers (price moved too fast)
- Market liquidity drops below minimum (can't enter without massive slippage)
- Slippage estimate exceeds 5% for recommended position size
- Market enters "accepting_orders: false" state
- More than 15 minutes have passed since insider entry (configurable)

Expired signals are logged but NOT sent as trade alerts.
They ARE tracked for phantom PnL (what would have happened if you chased).
```

---

## INSIDER SCORING ENGINE

### Wallet Classification
Before scoring, classify each wallet:

```
SNIPER — Low trade frequency, high win rate, early entries, niche focus
  → Best for copying. Highest signal quality.

MOMENTUM — Medium frequency, rides trends, enters after initial move
  → Copyable but edge retention may be lower.

MARKET_MAKER — Very high frequency, both sides, profits from spread
  → DO NOT COPY. Their strategy doesn't work for directional copying.
  → Auto-exclude from alerts.

HEDGER — Trades opposing positions across related markets
  → DO NOT COPY individual trades. Their edge is portfolio-level.
  → Auto-exclude from alerts.

NOISE — Low win rate, random sizing, no clear pattern
  → Auto-exclude.

Classification logic:
- trade_frequency > 50/week AND buys_both_sides > 40% → MARKET_MAKER
- opposing_positions_in_related_markets > 30% → HEDGER
- win_rate < 52% AND no_category_focus → NOISE
- trade_frequency < 10/week AND win_rate > 70% AND niche_focus → SNIPER
- everything else → MOMENTUM
```

### Scoring Components (0-100)

```
Initial weights (equal at 12.5% each — adjust after calibration):

1. WIN RATE (weighted by sample size)
   - Raw win rate × confidence multiplier
   - Confidence: sqrt(min(trades, 200) / 200)
   - 89% win rate with 15 trades scores lower than 78% with 200 trades

2. ENTRY TIMING
   - Measure: time between wallet entry and subsequent 10%+ price move
   - Consistently entering 24-72h before moves = high score
   - Entering after moves = low score
   - Need minimum 10 data points to score

3. NICHE FOCUS
   - Herfindahl index of category distribution
   - 90% of trades in one category = specialist = high score
   - Even spread across 4+ categories = generalist = lower score

4. CONSISTENCY (PnL Sharpe ratio)
   - Rolling 30-day PnL series
   - Sharpe = mean(daily_pnl) / std(daily_pnl)
   - Steady winners score higher than volatile lucky streaks

5. POSITION SIZING INTELLIGENCE
   - Do they size up on high-conviction plays?
   - Correlation between position size and trade outcome
   - Kelly-like behavior = high score
   - Random/equal sizing = neutral

6. WALLET AGE + TRACK RECORD
   - Age alone isn't enough — sustained performance over time
   - Score = age_months × avg_monthly_return (normalized)
   - 6-month wallet with consistent returns > 2-year wallet with recent decline

7. TRADE FREQUENCY (sweet spot)
   - Too few (< 5/month) = insufficient data = low score
   - Sweet spot (10-50/month) = enough data, not a bot = high score
   - Too many (> 200/month) = likely bot/market maker = low score (also caught by classification)

8. DRAWDOWN RECOVERY
   - After a losing streak, how fast do they return to peak PnL?
   - Fast recovery = emotional discipline = high score
   - Slow/no recovery = possible strategy decay = low score

Calibration Process (runs every 4 weeks after initial 8-week period):
1. For each scoring component, correlate with actual copy PnL from signal feedback data
2. Components that predict profitable signals get higher weight
3. Components that don't predict outcomes get lower weight
4. Store weight history so I can see how the scoring model evolves
5. Alert: "Scoring weights updated. Win rate weight increased from 12.5% to 18.2%. Niche focus decreased to 8.1%."
```

### Wash Trade Filter
Detect fake/inflated wallets before they enter the watchlist:

```
Flag wallet if ANY of:
- > 20% of trades have an immediate opposing trade within 5 minutes (buy YES then sell YES)
- Net exposure across all positions is consistently near zero
- High-frequency trading (> 100 trades/day) with near-zero net PnL
- Funding trail leads to same source as another tracked wallet (cluster overlap)

Action: exclude from watchlist, mark as "wash_suspected" in database
Do not score. Do not alert.
```

### First Entry Detection
Determine where the insider is in their position-building process:

```
For each new trade from a tracked wallet:
1. Check: do they already have a position in this market?
2. If no → this is FIRST ENTRY → priority: HIGH
3. If yes → they're ADDING to position:
   - Current size < 33% of their avg position size in this category → EARLY build
   - Current size 33-66% of avg → MID build
   - Current size > 66% of avg → LATE build

Signal priority:
- FIRST ENTRY → highest priority, send immediately
- EARLY build → high priority
- MID build → standard priority
- LATE build → low priority (most of the edge is already captured)

Include in alert: "🔹 First entry — new position" or "🔸 Adding to position (mid-build, 45% of typical size)"
```

---

## BANKROLL MANAGEMENT

```
Configuration:
- total_capital: [set by me]
- max_per_market: 5% of bankroll
- max_per_category: 30% of bankroll
- max_concurrent_positions: 12
- daily_loss_limit: 5% of bankroll
- weekly_loss_limit: 10% of bankroll

Position Sizing:
- Method: Fractional Kelly Criterion
- Default fraction: 0.25 (quarter Kelly — conservative)
- Kelly % = (win_rate × avg_win/avg_loss - (1 - win_rate)) / (avg_win/avg_loss)
- Apply fraction: kelly_size = kelly_pct × available_capital × fraction
- Apply slippage cap: final_size = min(kelly_size, slippage_capped_size)
- Apply bankroll cap: final_size = min(final_size, max_per_market_amount)
- If max_concurrent_positions reached: only accept signals with combined_score > 85

Lockout Rules:
- Daily P&L hits -5% → LOCKOUT. No new trade alerts until next day.
  → Telegram: "🔴 CENTINELA LOCKOUT — Daily loss limit reached (-$X). Stand down until tomorrow."
- Weekly P&L hits -10% → LOCKOUT until next Monday.
  → Telegram: "🔴 CENTINELA LOCKOUT — Weekly loss limit reached. No new trades until Monday."
- No override. No exceptions. The watchman protects you from yourself.

Show in every alert:
- Current bankroll | Deployed % | Available $ | Daily P&L | Positions open (X/12)
```

---

## EDGE MONITORING (strategy-level circuit breaker)

```
Strategy State System:

GREEN — Edge is healthy
  Conditions: rolling 30-day PnL positive AND avg edge per trade > 0 AND win rate > 52%
  Action: normal trading, normal position sizes

YELLOW — Edge is declining
  Conditions: rolling 30-day PnL declining 20%+ from peak OR avg slippage trending up OR win rate dropped below 52%
  Action: reduce ALL position sizes by 50%, alert me daily with trend data
  → Telegram: "⚠️ CENTINELA YELLOW — Edge declining. Reducing sizes 50%. Rolling 30d PnL: -12% from peak. Review required."

RED — Edge is gone
  Conditions: rolling 30-day PnL negative OR avg edge per trade < 0 for 2+ weeks
  Action: HALT all new trade alerts. Only send monitoring data.
  → Telegram: "🛑 CENTINELA RED — Strategy unprofitable. All new signals halted. Review data and recalibrate."

State transitions logged. Dashboard shows state history over time.
Manual override to return to GREEN requires reviewing performance data and acknowledging the state change.
```

---

## CROSS-PLATFORM DIVERGENCE (your most reliable edge)

```
Priority: CRITICAL — build in Phase 1 alongside insider signals

How it works:
1. For each active Polymarket market, search Kalshi for matching event
2. Match by: keyword similarity in market question, resolution criteria overlap
3. Store matched pairs in cross_platform_markets table
4. Poll Kalshi prices every 60 seconds for matched markets
5. Calculate gap: abs(polymarket_price - kalshi_price)
6. If gap ≥ 10 points → send alert

Alert format:
"🌐 CENTINELA — CROSS-PLATFORM DIVERGENCE

📊 Will Fed Cut Rates in June 2026?
   Polymarket: YES @ $0.34 (34%)
   Kalshi:     YES @ $0.47 (47%)
   Gap: 13 points — Polymarket appears UNDERPRICED

💡 If insiders are also buying YES → double confirmation
📌 Use LIMIT ORDER on Polymarket at $0.34 (zero fees)

💰 Recommended size: $600 (1.5% bankroll)"

Why this edge is reliable:
- Doesn't depend on insider data
- Doesn't require fast execution (gaps persist for hours/days)
- Pure probability arbitrage — one platform is wrong
- Combine with insider signals for highest conviction trades
- Track: which platform is typically "right" over time
```

---

## OVERCROWDING DETECTION

```
Problem: if 50 people copy the same wallet, the price moves instantly after the insider trades.
This destroys edge retention for everyone.

Detection signals:
1. Price moves > 5% within 60 seconds of wallet's trade (and it didn't used to)
2. Reaction speed to this wallet's trades is increasing over time
   - Measure: time for price to move 3% after their entry
   - If this is shrinking week over week → wallet is getting crowded
3. Multiple copy trading tools now publicly recommend this wallet

Action:
- If crowding score > threshold → downgrade insider score by 15-25 points
- Alert: "📉 Wallet X is getting crowded — price now moves within 15 seconds of their trades (was 4 minutes 30 days ago). Edge retention dropping. Consider removing."
- Do NOT auto-remove. Let me decide. But make the data obvious.
```

---

## SIGNAL THROTTLING

```
Problem: too many alerts = alert fatigue = missed real signals in the noise

Limits:
- max_alerts_per_hour: 5
- max_alerts_per_day: 20
- quality_floor: only send signals with combined_score ≥ 70

Priority override: CRITICAL alerts (kill switch, system offline, loss lockout) bypass all throttles

When throttled:
- Queue lower-priority signals
- Send batch summary every 2 hours: "3 signals were throttled in the last 2 hours. Highest score: 72. Details on dashboard."
- Never drop a signal — always log it, track phantom PnL, just don't send Telegram for low-priority ones

Quiet hours (configurable):
- Default: 11pm - 7am local time
- During quiet hours: only CRITICAL and HIGH priority alerts
- Standard/Info alerts batched for morning summary
- Override: if a consensus signal fires during quiet hours, send it anyway
```

---

## SHADOW TRACKING (measuring YOUR execution, not just the system's)

```
For every signal that fires:
1. Log: was it taken? (yes/no/partial)
2. If taken: actual entry price, actual size, conviction level (1-5)
3. If skipped: reason (didn't see it, didn't like it, too busy, scared, etc.)
4. Track outcome regardless of whether taken

Derived metrics:
- signals_taken_count / signals_total → your execution rate
- taken_pnl → actual money made/lost
- skipped_pnl → money you WOULD have made/lost if you took every signal
- missed_opportunity_cost → skipped_pnl (only wins) — how much you left on the table
- regret_cost → signals taken that lost — how much your overrides cost you

Monthly insight:
"You took 34 of 67 signals (51%). Your actual PnL: +$2,400. If you took all signals: +$4,100.
Biggest miss: Skipped consensus signal on Fed Rate market that would have netted +$1,200.
Biggest save: Skipped 3 signals that all lost, saving you $890.
Net missed opportunity: $1,700. Your signal filtering is costing more than it's saving."

This is how you learn when to trust the system vs when your gut is right.
```


---

## TRADE DECISION ENGINE (the brain between alert and execution)

Every signal passes through this waterfall. If it fails ANY step, it's killed.

### Decision Waterfall

```
Step 1: CHECK STATUS
  Condition: signal.status == VALID
  Fail → SKIP (signal expired, chase risk triggered, or market closed)

Step 2: CHECK LIQUIDITY
  Condition: market_liquidity >= max(10000, position_size × 10)
  Fail → SKIP ("Low liquidity — market has $X, need $Y minimum for your size")
  Note: scales with your position size — as bankroll grows, floor grows with it

Step 3: CHECK SLIPPAGE
  Condition: estimated_slippage <= 2%
  Fail → SKIP ("Slippage too high — estimated X% on $Y entry")

Step 4: CHECK WALLET QUALITY
  Condition: EITHER of:
    (a) avg_wallet_score >= 70 AND consensus_wallets >= 3
    (b) single_wallet_score >= 90 AND classification == "sniper" AND is_first_entry == true
    (c) signal_type == "dumb_money_fade" AND inverse_score >= 85
    (d) signal_type == "cross_platform_divergence" AND price_gap >= 10
  Fail → SKIP ("Signal quality too low — score X, need Y")
  Note: solo top snipers, dumb money fades, and cross-platform divergence bypass consensus requirement

Step 5: CHECK PORTFOLIO LIMITS
  Condition: current_open_positions < max_concurrent_positions (12)
  Fail → only accept if combined_score > 85
  Sub-checks:
    - Market exposure < 5% of bankroll
    - Category exposure < 30% of bankroll
    - Not locked out (daily/weekly loss limit)
    - Strategy state != RED

Step 6: CHECK CORRELATION
  Condition: new position doesn't push portfolio correlation above threshold
  Fail → WARN (don't skip, but flag in alert: "⚠️ This increases your Politics concentration to 34%")

Output: EXECUTE | SKIP | WAIT

EXECUTE → signal passes all checks, recommend entry now
SKIP → signal fails a check, log reason, track phantom PnL
WAIT → passes quality checks but entry price is suboptimal
  → Place limit order at insider_entry_price + max(0.01, tick_size)
  → If not filled in 15 minutes → expire
  → Alert: "⏳ WAIT — placing limit at $0.29. Will expire in 15 min if not filled."
```

### Simultaneous Signal Priority
When multiple signals fire within 10 minutes:

```
Ranking:
1. Convergence signals (smart + dumb aligned opposite sides)
2. Consensus signals (3+ wallets agreeing)
3. Cross-platform divergence (pure math edge)
4. Dumb money fade (inverse signal from confirmed losers)
5. Solo sniper first entry (single top wallet)
6. Highest combined score

Max simultaneous entries: 2 new positions within 10 minutes
If more than 2 qualify → take top 2, queue the rest for review
```

### Position Building
Don't go all-in on first signal. Build positions like the insiders do:

```
If signal is FIRST_ENTRY from a sniper:
  → Enter 50% of recommended size
  → If insider ADDS to position within 48 hours → add remaining 50%
  → If insider doesn't add → hold at 50%, reassess

If signal is CONSENSUS (3+ wallets):
  → Enter full recommended size (multiple insiders = higher conviction)

If signal is CONVERGENCE (smart + dumb opposite sides):
  → Enter full recommended size (highest conviction signal in system)

If signal is CROSS_PLATFORM_DIVERGENCE:
  → Enter full recommended size (mathematical edge, no timing dependency)

If signal is DUMB_MONEY_FADE:
  → Enter 60% of recommended size (contrarian plays deserve slight caution)
```

---

## TRADE MANAGEMENT (when to get out)

### Entry Rules
```
entry_type: LIMIT ORDER ONLY (GTC)
  → NEVER market orders. Zero maker fees.
  → Limit price: insider_entry_price + max(0.01, tick_size)
  → If not filled in 60 seconds at that price, widen by 1 tick
  → Max widening: 3 ticks from insider price
  → If still not filled → signal expires

entry_timing:
  → max_delay: 90 seconds from insider's first entry
  → If time_since_first_entry > 90 seconds → SKIP
  → Exception: cross-platform divergence (no time pressure, gaps persist hours)
  → Exception: dumb money fade (no time pressure, inverse signal)
```

### Take Profit Rules (laddered exit)
```
Level 1: price_increase >= 20%
  → Action: exit 50% of position (lock in half the gains)
  → Alert: "💰 TP1 hit on [market] — selling 50% at +22%. Holding rest."

Level 2: price_increase >= 35%
  → Action: exit remaining position (full profit)
  → Alert: "💰 TP2 hit on [market] — fully exited at +37%. Total P&L: +$X"

If market resolves before TP:
  → Auto-calculate P&L at resolution price ($1 or $0)
```

### Stop Loss Rules (conditional — NOT just price-based)
```
Prediction markets are NOT stocks. A -15% move might be noise, not signal.
Stop losses must consider whether the INSIDER still holds.

Level 1 (conditional stop):
  Condition: price_drop >= 15% AND insider_has_exited == true
  Action: exit full position
  Alert: "🔴 SL triggered — price -17% AND insider exited. Closing position."
  Rationale: if the person you copied got out, the thesis is dead

Level 2 (hard floor):
  Condition: price_drop >= 30%
  Action: exit full position REGARDLESS of insider status
  Alert: "🔴 HARD STOP — price -32%. Exiting regardless. Protecting capital."
  Rationale: -30% is too much to recover. Cut the loss.

What NOT to do:
  → Do NOT stop out at -15% if the insider is still holding
  → Their conviction is information. Respect it.
  → A -20% swing that resolves at +100% is a normal prediction market trade
```

### Time-Based Exit (relative to resolution, not absolute)
```
Logic:
  time_held_ratio = time_held / (resolution_date - entry_date)

  If time_held_ratio > 0.5 AND unrealized_pnl < 5%:
    → Alert: "⏰ Time check — holding [market] for 14 of 28 days with only +3%. Capital might work harder elsewhere."
    → Decision is MINE. System alerts, I decide.

  If time_held_ratio > 0.75 AND unrealized_pnl < 0%:
    → Alert: "⏰ URGENT — 75% of time elapsed, position is negative. Strongly consider exiting."

  Exception: if consensus wallets are ADDING during this period, suppress time exit alert
```

### Insider Exit Tracking
```
If a wallet I copied exits their position:
  → Immediate HIGH priority alert
  → "🚨 Len9311238 EXITED 'SCOTUS Ruling' — sold full YES position at $0.41"
  → Include: their P&L on the trade, time held, whether other consensus wallets still hold
  → Decision is mine, but this is the strongest exit signal available
```

---

## DUMB MONEY TRACKING (inverse signals — the hidden edge)

### The Concept
If 87% of Polymarket users lose money, there are wallets that CONSISTENTLY lose. A wallet with a 20% win rate is just as valuable as an 80% winner — you just bet the opposite direction. This is called "fading" dumb money.

### How It Works

```
Identification:
1. Scan leaderboard and Data API for wallets with:
   - Win rate < 35% over 50+ trades
   - Negative P&L over 3+ months
   - Consistent losing (not just one bad streak — sustained poor performance)
   - Active trading (still placing trades, not abandoned)
   - Reasonable size (> $500 avg position — not just dust trades)

2. Classify as DUMB MONEY if:
   - win_rate < 35% AND trades >= 50 AND active_last_30_days == true
   - OR win_rate < 40% AND trades >= 100 AND pnl_trend == declining
   - AND NOT wash_suspected (wash traders fake losses too)

3. Score inversely (0-100):
   - inverse_score = (1 - win_rate) × 100 × confidence_multiplier
   - confidence_multiplier = sqrt(min(trades, 200) / 200)
   - A wallet with 18% win rate over 150 trades scores ~90 (very reliable loser)
   - A wallet with 30% win rate over 30 trades scores ~55 (not enough data yet)
```

### Dumb Money Signal Generation

```
When a tracked DUMB_MONEY wallet enters a position:

1. They buy YES at $0.40 → Centinela generates FADE signal: consider NO at $0.60
2. Calculate FADE_SIGNAL_SCORE using composite formula (see below)
3. If score ≥ 70 → signal is VALID, run through decision engine waterfall
4. If score < 70 → log for phantom PnL tracking but do NOT alert
```

### Fade Signal Scoring Formula

The fade signal score is NOT just the inverse score of the wallet. It's a composite that cross-references smart money, category performance, platform pricing, and dumb consensus:

```
FADE_SIGNAL_SCORE = (
    inverse_score        × 0.30    ← how reliably this wallet loses overall
  + category_inverse     × 0.25    ← how bad they are in THIS market's category
  + smart_confirmation   × 0.25    ← are insiders on the OPPOSITE side?
  + cross_platform_conf  × 0.10    ← does Kalshi agree with the fade?
  + dumb_consensus       × 0.10    ← are OTHER dumb wallets also on the losing side?
)
```

**Component calculations:**

```
1. INVERSE SCORE (0-100) — already calculated in wallet scoring
   inverse_score = (1 - win_rate) × 100 × confidence_multiplier
   confidence_multiplier = sqrt(min(trades, 200) / 200)
   Example: 20% win rate, 150 trades → (1 - 0.20) × 100 × sqrt(150/200) = 80 × 0.866 = ~69
   Example: 20% win rate, 200+ trades → (1 - 0.20) × 100 × 1.0 = 80
   Example: 18% win rate, 150 trades → ~71

2. CATEGORY INVERSE (0-100) — per-category win rate for THIS market
   category_inverse = (1 - category_win_rate) × 100
   Example: DegenKing in Crypto market, his Crypto WR is 18% → (1 - 0.18) × 100 = 82
   Example: DegenKing in Politics market, his Politics WR is 41% → (1 - 0.41) × 100 = 59
   → This ensures you only fade where they're WORST

3. SMART MONEY CONFIRMATION (0-100) — cross-reference with insider watchlist
   
   Check all tracked insiders for positions in THIS market:
   
   IF insider(s) on OPPOSITE side of dumb money:
     → smart_confirmation = avg(insider_scores of those wallets)
     → e.g. Len9311238 (97) buying YES while dumb money bought NO
     → smart_confirmation = 97
     → This is the GOLDEN signal — smart and dumb disagreeing
   
   IF no insiders have positions in this market:
     → smart_confirmation = 50 (neutral)
     → Fade can proceed but weaker signal
   
   IF insider(s) on SAME side as dumb money:
     → smart_confirmation = 0
     → AND SUPPRESS THE ENTIRE SIGNAL — do not alert
     → Even losers get lucky. Smart money on their side = abort.
     → Log as "suppressed — smart money conflict" for tracking

4. CROSS-PLATFORM CONFIRMATION (0-100) — does Kalshi pricing agree?
   
   Check: does Kalshi price support the fade direction?
   
   IF fading dumb money YES (betting NO):
     → Check Kalshi NO price vs Polymarket NO price
     → If Kalshi NO is higher → Kalshi agrees dumb money is wrong
     → cross_platform_conf = min(price_gap_points × 10, 100)
     → 10pt gap = 100, 5pt gap = 50, 2pt gap = 20
   
   IF Kalshi agrees WITH the dumb money:
     → cross_platform_conf = 0
     → Warning flag in alert: "⚠️ Kalshi pricing doesn't support this fade"
   
   IF no matching Kalshi market exists:
     → cross_platform_conf = 40 (slight discount — can't confirm)

5. DUMB CONSENSUS (0-100) — other dumb wallets on the same losing side
   
   dumb_wallets_same_side = count of OTHER tracked dumb money wallets on same side
   dumb_consensus = min(dumb_wallets_same_side × 33, 100)
   → 0 other dumb wallets = 0
   → 1 other dumb wallet = 33
   → 2 = 66
   → 3+ = 100
   → Multiple losers agreeing = stronger fade signal
```

### Worked Examples

```
EXAMPLE 1: STRONG FADE (score 76 — alert fires)

Market: "Bitcoin $200K by December"
DegenKing buys YES @ $0.15

inverse_score: 88 (24% WR, 340 trades, high confidence)
category_inverse: 82 (18% Crypto WR — his worst category)
smart_confirmation: 93 (GhostTrader score 93 holds NO — confirms fade)
cross_platform: 30 (Kalshi NO $0.88 vs Poly NO $0.85 — 3pt gap)
dumb_consensus: 33 (BagHolder99 also bought YES)

SCORE = (88×0.30) + (82×0.25) + (93×0.25) + (30×0.10) + (33×0.10)
      = 26.4 + 20.5 + 23.25 + 3.0 + 3.3
      = 76.45 → PASS (≥70)

→ Alert fires: "FADE DegenKing — consider NO @ $0.85"
→ GhostTrader confirmation noted in alert
→ Sizing: 60% of normal (dumb money caution)
```

```
EXAMPLE 2: WEAK FADE — NO INSIDER CONFIRMATION (score 66 — no alert)

Same market, same DegenKing trade
But NO insiders have positions in this market

inverse_score: 88
category_inverse: 82
smart_confirmation: 50 (neutral — no insiders present)
cross_platform: 30
dumb_consensus: 33

SCORE = (88×0.30) + (82×0.25) + (50×0.25) + (30×0.10) + (33×0.10)
      = 26.4 + 20.5 + 12.5 + 3.0 + 3.3
      = 65.7 → FAIL (<70)

→ No alert. Logged for phantom PnL tracking.
→ This shows why cross-referencing insiders matters — without confirmation, the signal isn't strong enough.
```

```
EXAMPLE 3: SUPPRESSED — SMART MONEY CONFLICT

Market: "Senate Passes Infrastructure Bill"
BagHolder99 buys YES @ $0.45
BUT Len9311238 (score 97) ALSO holds YES

smart_confirmation = 0 (insider on SAME side as dumb money)
→ SIGNAL SUPPRESSED — do not calculate, do not alert
→ Log: "suppressed — smart money conflict with Len9311238"
→ Even consistent losers accidentally land on the right side sometimes
```

```
EXAMPLE 4: CONVERGENCE — MAXIMUM SIGNAL (triggered separately)

Market: "Senate Infrastructure Bill"
Smart money: Len9311238 (97) YES + NicheSniper (95) YES
Dumb money: DegenKing (inv:88) NO + BagHolder99 (inv:82) NO
Kalshi: YES @ $0.52 vs Poly YES @ $0.43 (9pt gap)

This triggers the CONVERGENCE detection system:
→ Smart wallets on YES, dumb wallets on NO = opposite sides ✓
→ Cross-platform confirms YES direction ✓
→ Total edge sources aligned: 3 (smart + dumb inverse + cross-platform)
→ 🎯 CONVERGENCE ALERT fires — highest conviction signal
→ Full sizing (not 60% dumb money discount — convergence overrides)
```

### Dumb Money Activity Feed (dashboard view)

The Dumb Money Watchlist page should show a real-time activity log:

```
DUMB MONEY LIVE ACTIVITY

🔻 DegenKing (inv:88) bought YES $3K on "Bitcoin $200K" — 12 min ago
   Smart check: GhostTrader holds NO ✓ CONFIRMED
   Category: Crypto (18% WR — worst)
   Kalshi: 3pt gap supporting fade
   Fade score: 76 → ✅ ALERT SENT
   
🚫 BagHolder99 (inv:82) bought YES $2.2K on "Senate Infrastructure" — 34 min ago
   Smart check: Len9311238 holds YES ✗ CONFLICT
   → SUPPRESSED (smart money on same side)
   
⬜ LiquidityKing (inv:31) bought NO $800 on "Fed Rate Cut" — 1h ago
   Inverse score too low (31 < 70) → NO SIGNAL
   
⬜ DegenKing (inv:88) bought NO $1.5K on "UK Election" — 2h ago
   Smart check: no insiders present → neutral (50)
   Category: Politics (41% WR — not worst)
   Fade score: 58 → ❌ BELOW FLOOR (need 70)
   
🎯 CONVERGENCE DETECTED on "Senate Infrastructure" — 3h ago
   Smart: Len9311238 (97) + NicheSniper (95) → YES
   Dumb: DegenKing (88) + BagHolder99 (82) → NO
   → CONVERGENCE ALERT SENT (highest conviction)
```

Each row shows: what happened, why it did or didn't generate an alert, and the cross-reference result. You can scan this in 10 seconds and understand exactly where the dumb money is flowing and whether the smart money confirms the fade.

### Dumb Money Dashboard Metrics

```
Top of Dumb Money Watchlist page:

DUMB MONEY OVERVIEW
├── Tracked: 8 wallets
├── Active today: 5
├── Signals generated (30d): 34
├── Signals that passed (30d): 18 (53% pass rate)  
├── Signals suppressed (30d): 11 (smart money conflict)
├── Fade win rate (30d): 64%
├── Convergence signals (30d): 4
├── Convergence win rate: 75%
└── Total fade P&L (30d): +$2,840

WORST PERFORMERS (your best fade targets):
1. DegenKing — inv:88, 18% Crypto, 24% Sports — fade P&L: +$1,200
2. BagHolder99 — inv:82, 22% Politics — fade P&L: +$890  
3. BlindBet — inv:79, 28% Crypto, 31% Sports — fade P&L: +$440

SMART MONEY OVERLAP (convergence potential):
├── Markets where dumb + smart are on opposite sides: 3
├── Markets where dumb + smart agree (suppressed): 2
└── Markets with dumb money only (no insider data): 7
```

### Dumb Money Safeguards

```
CRITICAL: dumb money fading has unique risks

1. SIZE SMALLER than insider copies
   → Default: 60% of normal recommended size for fades
   → Rationale: contrarian trades are inherently riskier than following smart money

2. NEVER fade dumb money when smart money is on the SAME side
   → If an insider is buying YES and dumb money is also buying YES
   → The dumb money signal is WRONG in this case (even losers get lucky)
   → Suppress the fade signal completely

3. CATEGORY FILTERING
   → Some dumb money wallets lose in ALL categories
   → Others only lose in specific categories (bad at sports, decent at politics)
   → Track per-category win rates and only fade in their WORST categories
   → "DegenKing: 18% win rate Crypto, 24% Sports, 41% Politics → only fade Crypto and Sports"

4. AVOID OBVIOUS MARKETS
   → Dumb money buying "Will aliens contact Earth in 2026?" at YES $0.03 is not a signal
   → Filter: skip markets where one side is > 90% or < 10%
   → The dumb money edge exists in CONTESTED markets (30-70% range)

5. TIME DECAY
   → Old dumb money data matters less than recent data
   → Weight last 90 days 2x vs older trades
   → A wallet that lost consistently for a year but started winning last month → remove
```

### Dumb Money Discovery

```
Run weekly scan:
1. Pull bottom 100 wallets from leaderboard by P&L
2. Filter for: still active, sufficient trade count, not wash trading
3. Score inversely
4. Surface candidates with inverse_score >= 70
5. Backtest: "If I faded every trade from this wallet over 90 days, what's my P&L?"
6. Add to dumb money watchlist if backtest is profitable

Auto-refresh:
- Rescore dumb money wallets every 72 hours
- If a dumb money wallet starts WINNING (win rate climbs above 45%), remove them
  → Alert: "DegenKing is improving — win rate now 42%. Removing from dumb money watchlist."
- If a new wallet enters sustained losing streak, flag as candidate
```

---

## EDGE STACK (the complete picture)

Centinela now has 5 independent edge sources. They work alone but compound together:

```
1. INSIDER SIGNALS (copy smart money)
   → Follow wallets with proven track records
   → Filtered by classification, edge retention, crowding
   → Boosted by consensus (3+ wallets agreeing)

2. DUMB MONEY FADING (inverse signals)
   → Bet against wallets with proven losing track records
   → Filtered by category, smart money conflict check
   → Boosted by dumb money consensus (2+ losers on same side)

3. CONVERGENCE (smart + dumb aligned on opposite sides)
   → Highest conviction signal in the system
   → Smart money on one side AND dumb money on the other
   → Extremely rare but extremely high win rate

4. CROSS-PLATFORM DIVERGENCE (mathematical arbitrage)
   → Polymarket vs Kalshi price gap ≥ 10 points
   → No speed required, gaps persist for hours
   → Independent of all wallet analysis

5. MONEY MANAGEMENT (survival edge)
   → Quarter Kelly sizing
   → Daily/weekly loss lockout
   → Strategy state circuit breaker
   → Correlation monitoring
   → Position building (scale in, not all at once)
   → This isn't a signal — it's what keeps you alive long enough for signals 1-4 to compound

The magic: when 2+ edges align on the same trade, win rate goes up dramatically.
   → Insider buying YES + Kalshi price higher = strong
   → Insider buying YES + dumb money buying NO + Kalshi higher = near-certain
```

---

## QUANTITATIVE MODULES (the institutional-grade layer)

These modules transform Centinela from a signal tool into a quantitative trading system. They layer on TOP of the existing architecture — they do not replace it. Build in Phase 4+ only after the core system is profitable.

### General Math Primitives (used across all modules)

```python
import math

def clamp(x, a, b):
    return min(max(x, a), b)

def safe_div(x, y, default=0):
    return x / y if abs(y) > 1e-9 else default

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def decay(dt, tau):
    return math.exp(-dt / tau)

def z_clamped(x, mu, sigma, zmax=3):
    return clamp(safe_div(x - mu, sigma, 0), -zmax, zmax)

def score100(x):
    return round(100 * clamp(x, 0, 1), 2)

def sample_conf(n, n_ref):
    return math.sqrt(clamp(n / n_ref, 0, 1))
```

All confidence values bounded 0-1. All scores bounded 0-100. No unbounded outputs anywhere.

---

### Module 1: Wallet Intent Detection

**Purpose:** Classify every trade into WHY the wallet is trading — not just WHAT they traded. A hedge trade from an insider is not a signal. An informational trade is.

**Per-trade input features:**
```
s           = trade size in dollars
s_avg       = wallet median trade size (last 30 trades, same category)
z_size      = clamp(log(safe_div(s, s_avg, 1)), -2, 2)

dt_move_5   = seconds until market moves 5% in trade direction (cap 900s)
post_move   = 1 - clamp(dt_move_5 / 900, 0, 1)
              → 1.0 = immediate move after trade, 0.0 = no move

spread_cross = 1 if trade crosses spread aggressively, else 0
passive_fill = 1 if resting/passive order, else 0

seq_same_dir = same-direction trades in this market, last 6h (cap 10)
seq_alt_dir  = opposite-direction trades in this market, last 6h (cap 10)

related_opp_positions = fraction of related markets where wallet holds opposite side (0-1)
inventory_reduction   = fraction of position reduced within 30 min after trade (0-1)

pre_move_5   = abs % move in same direction in 15 min BEFORE trade (cap 15%)
pre_move_norm = clamp(pre_move_5 / 15, 0, 1)
```

**Classification formulas:**

```
INFORMATIONAL (real conviction — the signal you want):
  = 0.30 * clamp((z_size + 2) / 4, 0, 1)    ← big trade
  + 0.30 * post_move                          ← market moved after
  + 0.25 * spread_cross                       ← aggressive execution
  + 0.15 * (1 - pre_move_norm)                ← entered BEFORE the move

POSITION_BUILDING (accumulating over time):
  = 0.35 * clamp(seq_same_dir / 5, 0, 1)     ← repeated same-side entries
  + 0.25 * clamp((z_size + 2) / 4, 0, 1)     ← meaningful size
  + 0.20 * passive_fill                        ← patient, not desperate
  + 0.20 * (1 - inventory_reduction)           ← still holding

MOMENTUM (chasing a move already underway):
  = 0.45 * pre_move_norm                       ← entered AFTER move started
  + 0.25 * spread_cross                        ← aggressive (FOMO)
  + 0.20 * clamp((z_size + 2) / 4, 0, 1)     ← decent size
  + 0.10 * (1 - post_move)                     ← market didn't move much MORE

HEDGING (portfolio protection, not directional):
  = 0.50 * related_opp_positions               ← holds opposite side elsewhere
  + 0.20 * clamp(seq_alt_dir / 5, 0, 1)       ← trading both sides
  + 0.15 * passive_fill                        ← not urgent
  + 0.15 * (1 - post_move)                     ← no market reaction

LIQUIDITY_PROVISION (market making behavior):
  = 0.45 * passive_fill                        ← resting orders
  + 0.20 * (1 - clamp((z_size + 2) / 4, 0, 1)) ← smaller size
  + 0.20 * (1 - post_move)                     ← no information content
  + 0.15 * clamp(seq_same_dir / 5, 0, 1)      ← repeated but passive

EXIT_LIQUIDITY (distributing/dumping into strength):
  = 0.40 * inventory_reduction                  ← selling off position
  + 0.25 * pre_move_norm                        ← move happened, now exiting
  + 0.20 * clamp((z_size + 2) / 4, 0, 1)      ← decent size
  + 0.15 * (1 - post_move)                     ← market stops after their exit
```

**Classification output:**
```
intent_type = argmax of the six raw scores
top1 = highest raw score
top2 = second highest raw score
confidence = clamp(0.55 * (top1 - top2) + 0.45 * top1, 0, 1)
```

**Intent multipliers applied to ALL downstream signal scores:**
```
INFORMATIONAL    = 1.25  ← boost (this is the golden signal)
POSITION_BUILDING = 1.10  ← slight boost (accumulation = conviction)
MOMENTUM         = 0.80  ← penalty (chasing, less edge)
HEDGING          = 0.35  ← heavy penalty (not directional)
LIQUIDITY_PROVISION = 0.50 ← penalty (market making, not signal)
EXIT_LIQUIDITY   = 0.40  ← heavy penalty (they're getting OUT)
```

**Why this matters:** Without intent detection, you copy a trade where the insider is actually hedging their real position in a related market. That's not a signal — it's noise. With intent detection, hedging trades get 0.35x multiplier and effectively die before reaching you. Only informational and position-building trades survive.

---

### Module 2: Wallet Clustering / Hidden Syndicates

**Purpose:** Detect when multiple wallets are controlled by the same person or coordinated group. Prevents fake consensus signals.

**Pairwise link scoring (for wallets i and j over rolling 30 days):**

```
co_market_rate   = shared markets traded / union of all markets traded
same_side_rate   = fraction of shared-market trades with matching direction
timing_corr      = fraction of shared-market entries within 120 seconds
size_similarity  = 1 - clamp(abs(log(safe_div(median_size_i, median_size_j, 1))) / log(3), 0, 1)
repeat_pair_rate = repeated same-market same-side co-occurrences / max(total_shared_events, 1)

pair_link_score = 0.30 * co_market_rate
               + 0.25 * same_side_rate
               + 0.25 * timing_corr
               + 0.10 * size_similarity
               + 0.10 * repeat_pair_rate

n_shared = total shared market events
pair_confidence = pair_link_score * sample_conf(n_shared, 25)
```

**Graph construction:**
```
Create edge between wallets if pair_confidence >= 0.68
Run connected components or Louvain community detection → cluster_id per wallet
cluster_confidence = mean(pair_confidence to other wallets in same cluster)
```

**Consensus discount (CRITICAL for preventing fake consensus):**
```
When k wallets trigger a consensus signal and some belong to same cluster:

effective_wallet_count = unique_clusters + 0.35 * (total_wallets - unique_clusters)

Example: 4 wallets trigger consensus, but 3 are in same cluster
  → unique_clusters = 2 (cluster A has 3 wallets, wallet D is independent)
  → effective = 2 + 0.35 * (4 - 2) = 2.70
  → Instead of counting "4 wallets agree" you count "2.70 effective wallets"

consensus_cluster_adjustment = clamp(effective_wallet_count / total_wallets, 0.4, 1.0)
adjusted_combined_score = raw_combined_score * consensus_cluster_adjustment
```

---

### Module 3: Copyability Score (Time-to-Move Model)

**Purpose:** Measure how practically copyable a wallet is. A 95-score wallet that moves price in 5 seconds is useless if your alerts take 30 seconds.

**Per-wallet historical metrics:**
```
t3  = median seconds to 3% move in trade direction
t5  = median seconds to 5% move
t10 = median seconds to 10% move
er  = average edge retention (already in system, 0-1)

cv_t5 = std(t5_samples) / mean(t5_samples)
stability = 1 - clamp(cv_t5 / 1.5, 0, 1)
  → High variation in timing = low stability = unreliable to copy

Normalize against copy thresholds:
t3_norm  = clamp(t3 / 180, 0, 1)    ← 3 minutes = fully copyable at 3%
t5_norm  = clamp(t5 / 300, 0, 1)    ← 5 minutes = fully copyable at 5%
t10_norm = clamp(t10 / 600, 0, 1)   ← 10 minutes = fully copyable at 10%
```

**Copyability formula:**
```
copyability_raw = 0.25 * t3_norm
                + 0.30 * t5_norm
                + 0.20 * t10_norm
                + 0.15 * er
                + 0.10 * stability

n_signals = historical entries evaluated
copyability_adj = copyability_raw * (0.65 + 0.35 * sample_conf(n_signals, 40))
copyability_score = score100(copyability_adj)
```

**Interpretation and action:**
```
80-100 = highly copyable  → boost alert priority one level
60-79  = workable         → normal processing
40-59  = difficult        → reduce recommended size by 35%
below 40 = avoid          → suppress signal unless cross-platform divergence ≥ 12 points
```

**Integration into wallet score:**
```
wallet_score_final = 0.85 * wallet_score_base + 0.15 * copyability_score
```

---

### Module 4: Pre-Position Detection (Early Warning)

**Purpose:** Detect markets where smart money is ABOUT to enter — before the actual trade signal fires.

**Market-level features (rolling 30 min):**
```
liq_growth         = % growth in top-of-book depth (cap 100%)
spread_tightening  = % reduction in spread (cap 100%)
vol_growth         = % growth in traded volume (cap 200%)
price_drift        = absolute mid-price change (cap 10%)
related_smart_activity = fraction of tracked smart wallets active in correlated markets (last 6h)

Normalize:
liq_n        = clamp(liq_growth / 100, 0, 1)
spread_n     = clamp(spread_tightening / 100, 0, 1)
vol_n        = clamp(vol_growth / 200, 0, 1)
quiet_price_n = 1 - clamp(price_drift / 10, 0, 1)  ← price HASN'T moved yet
```

**Pre-signal formula:**
```
pre_signal_raw = 0.30 * liq_n
               + 0.20 * spread_n
               + 0.25 * vol_n
               + 0.15 * quiet_price_n
               + 0.10 * related_smart_activity

pre_signal_confidence = clamp(pre_signal_raw, 0, 1)
pre_signal_flag = 1 if pre_signal_confidence >= 0.68 else 0
```

**Usage:**
```
If flag = 1:
  → Raise market to Tier 1 polling (every 2 sec)
  → Soft alert: "👁 CENTINELA WATCHING — [market] showing pre-position activity"
  → NOT an execution alert — just awareness

If insider later enters a pre-flagged market:
  → Add +7 points to signal quality score
  → Alert notes: "📡 Pre-positioned market — flagged 45 min before entry"
```

---

### Module 5: Liquidity Trap Detection

**Purpose:** Catch when an insider is using YOUR copy trade as their exit liquidity. They enter, price pops, you follow, then they dump on you.

**Measured within 5 minutes after insider entry:**
```
bid_depth_change   = % change in bid depth near best bid (clip -100 to 100)
ask_depth_change   = % change in ask depth near best ask (clip -100 to 100)
spread_change      = % change in spread (clip -100 to 100)
price_pop          = % move in trade direction after entry (clip 0 to 20)
reversal_3m        = % reversal against direction within 3 min (clip 0 to 20)
insider_inv_red_30m = fraction of position reduced by insider within 30 min (0-1)

Normalize:
weak_bids    = clamp((-bid_depth_change) / 100, 0, 1)   ← bids disappearing
heavy_asks   = clamp(ask_depth_change / 100, 0, 1)       ← asks piling up
wide_spread  = clamp(spread_change / 100, 0, 1)          ← spread widening
pop_n        = clamp(price_pop / 20, 0, 1)               ← initial price spike
reversal_n   = clamp(reversal_3m / 20, 0, 1)             ← reversal after pop
```

**Trap risk formula:**
```
trap_risk_raw = 0.20 * weak_bids
              + 0.15 * heavy_asks
              + 0.20 * wide_spread
              + 0.15 * pop_n
              + 0.15 * reversal_n
              + 0.15 * insider_inv_red_30m

trap_risk_score = score100(trap_risk_raw)
```

**Action rules:**
```
≥ 75  → INVALIDATE signal entirely. Alert: "🪤 TRAP DETECTED — signal killed"
55-74 → Reduce position size 50%, add warning to alert
40-54 → Deduct 8 points from signal score
< 40  → No action (clean signal)
```

---

### Module 6: Smart Money Leader Detection

**Purpose:** Identify which wallets consistently enter BEFORE other top wallets follow. These are the alpha generators — the ones moving first.

**Per-wallet metrics:**
```
leader_events   = count of markets where wallet i entered FIRST and another top wallet followed same side within 6 hours
follower_events = count of markets where wallet i FOLLOWED another top wallet
avg_follow_quality = average normalized score of wallets that followed i (0-1)
median_lead_time = median minutes between i's entry and follower entry (cap 360)

lead_time_n = 1 - clamp(median_lead_time / 360, 0, 1)
```

**Leader score formula:**
```
leader_raw = 0.45 * safe_div(leader_events, leader_events + follower_events, 0.5)
           + 0.30 * avg_follow_quality
           + 0.25 * lead_time_n

leader_adj = leader_raw * (0.60 + 0.40 * sample_conf(leader_events + follower_events, 30))
leader_score = score100(leader_adj)
```

**Integration:**
```
wallet_score_final = 0.80 * wallet_score_existing
                   + 0.10 * copyability_score
                   + 0.10 * leader_score

If leader_score >= 80 AND intent_type == INFORMATIONAL AND intent_confidence >= 0.70:
  → Add +6 bonus points to signal quality
  → This is your tier-1 signal: a confirmed leader making an informational trade
```

---

### Module 7: Market Regime Detection

**Purpose:** Markets behave differently in different states. The same signal in a calm market vs a manipulated market should be treated completely differently.

**Features (rolling 60 min window):**
```
rv                = realized volatility of mid-price returns
spread_med        = median spread %
depth_instability = coefficient of variation of top-book depth
vol_spike         = current 15-min volume / trailing 4h avg 15-min volume
directional_drift = abs net price move / realized volatility proxy

Normalize using category historical baselines (mu, sigma):
rv_n     = clamp((z_clamped(rv, rv_mu, rv_sigma) + 3) / 6, 0, 1)
spread_n = clamp((z_clamped(spread_med, spread_mu, spread_sigma) + 3) / 6, 0, 1)
depth_n  = clamp((z_clamped(depth_instability, depth_mu, depth_sigma) + 3) / 6, 0, 1)
vol_n    = clamp((z_clamped(vol_spike, vol_mu, vol_sigma) + 3) / 6, 0, 1)
drift_n  = clamp(directional_drift / 3, 0, 1)
```

**Regime classification:**
```
HIGH_VOLATILITY = 0.40 * rv_n + 0.20 * vol_n + 0.20 * spread_n + 0.20 * depth_n
LOW_VOLATILITY  = 0.50 * (1-rv_n) + 0.20 * (1-spread_n) + 0.20 * (1-depth_n) + 0.10 * (1-vol_n)
TRENDING        = 0.45 * drift_n + 0.25 * vol_n + 0.15 * (1-spread_n) + 0.15 * (1-depth_n)
MANIPULATED     = 0.30 * spread_n + 0.30 * depth_n + 0.20 * vol_n + 0.20 * (1-drift_n)

regime_label = argmax of the four
regime_confidence = clamp(0.55 * top1 + 0.45 * (top1 - top2), 0, 1)
```

**Regime-based adjustments:**
```
HIGH_VOLATILITY:
  → chase_threshold × 0.85 (tighter — harder to enter)
  → max_position × 0.75 (smaller sizes)
  → min_signal_score + 4 (higher bar)

LOW_VOLATILITY:
  → chase_threshold × 1.10 (relaxed)
  → max_position × 1.00 (normal)
  → min_signal_score unchanged

TRENDING:
  → chase_threshold × 1.00
  → max_position × 1.10 (only for leader_score ≥ 75)
  → momentum intent penalty reduced from 0.80 to 0.90

MANIPULATED:
  → chase_threshold × 0.70 (very tight)
  → max_position × 0.50 (half size)
  → min_signal_score + 8 (very high bar)
  → REQUIRE trap_risk_score < 50 (or signal dies)
```

---

### Module 8: Latency Optimization (Adaptive Polling)

**Purpose:** Poll the most important markets fastest instead of treating all markets equally.

**Per-market priority score:**
```
poll_priority_raw = 0.35 * pre_signal_confidence
                  + 0.25 * clamp(active_tracked_wallets_in_market / 5, 0, 1)
                  + 0.20 * clamp(recent_volume_percentile, 0, 1)
                  + 0.20 * clamp(cross_platform_gap / 15, 0, 1)

poll_priority_score = score100(poll_priority_raw)
```

**Polling tiers:**
```
Tier 1: score ≥ 75  → poll every 2 seconds
Tier 2: 50-74       → poll every 5 seconds
Tier 3: 30-49       → poll every 15 seconds
Tier 4: below 30    → poll every 60 seconds
```

**Detection confidence (system health metric):**
```
websocket_alive   = 1 or 0
polling_freshness = 1 - clamp(seconds_since_last_poll / poll_interval, 0, 1)
source_redundancy = 1 if both websocket AND polling active, else 0.6

detection_confidence = clamp(
    0.45 * websocket_alive
  + 0.35 * polling_freshness
  + 0.20 * source_redundancy,
  0, 1
)

If detection_confidence < 0.60:
  → suppress high-urgency alerts (can't trust timing)
  → raise system warning: "⚠️ Detection confidence low — data may be stale"
  → Exception: cross-platform divergence alerts still fire (not timing-dependent)
```

---

### Unified Signal Score Integration

**All modules feed into one final score:**

```
final_signal_score = base_signal_score
    × intent_multiplier                                    ← Module 1
    × (0.85 + 0.15 * safe_div(copyability_score, 100, 0)) ← Module 3
    × (0.90 + 0.10 * safe_div(leader_score, 100, 0))      ← Module 6
    × (1.00 - 0.35 * safe_div(trap_risk_score, 100, 0))   ← Module 5
    × (0.90 + 0.10 * regime_confidence)                    ← Module 7

If pre_signal_flag was true before entry:   ← Module 4
    final_signal_score += 7

If cluster discount applies:                ← Module 2
    final_signal_score *= consensus_cluster_adjustment

final_signal_score = clamp(final_signal_score, 0, 100)
```

**Execution gating with quant modules:**
```
≥ 85  → HIGH CONVICTION — full recommended size, top alert priority
75-84 → STANDARD VALID — normal size and priority
65-74 → WATCH — reduced size (35% cut), lower priority
< 65  → NO ALERT — unless cross-platform divergence ≥ 10 or convergence signal
```

---

### Module Alert Additions

**Intent detection in alerts:**
```
Add to every insider trade alert:
"🧠 Intent: INFORMATIONAL (conf: 87%) | ×1.25 boost"
or
"🧠 Intent: MOMENTUM (conf: 72%) | ×0.80 penalty — entered after move"
```

**Trap warning in alerts:**
```
If trap_risk 55-74:
"🪤 Trap risk: 63 — reducing size 50%. Bids thinning, insider may exit."
```

**Pre-signal flag in alerts:**
```
If market was pre-flagged:
"📡 Pre-positioned: this market was flagged 45 min before entry (+7 pts)"
```

**Regime tag in alerts:**
```
"📊 Regime: HIGH_VOLATILITY (conf: 78%) — sizes reduced 25%, chase threshold tightened"
```

**Leader badge in alerts:**
```
If leader_score ≥ 80:
"👑 LEADER wallet — consistently enters before other top wallets follow"
```

**Copyability warning:**
```
If copyability < 60:
"⚡ Low copyability (52) — price moves fast after this wallet. Size reduced 35%."
```

### Insider Trade:
```
🟡 CENTINELA — INSIDER TRADE

◈ Len9311238 (Score: 97 | ↑ Rising | SNIPER)
📊 SCOTUS Ruling on Immigration
   → YES @ $0.28 | Size: $45,000
   🔹 First entry — new position

📈 Win Rate: 94% | Streak: 14W | Politics specialist
⏱ Timing: 48-72h pre-catalyst pattern
💧 Liquidity: A | Spread: 1.2% | Slippage: ~0.3%
🌐 Kalshi: $0.38 (+10pt gap — UNDERPRICED)
🔻 Dumb money check: DegenKing is on NO side (confirmation ✓)

💰 ENTRY:
   Conservative: $420 (1.0%)
   Standard:     $850 (2.1%)
   Aggressive:   $1,360 (3.4%)
   📌 LIMIT ORDER @ $0.28 (zero fees)
   🔨 Position build: entering 50% now, hold 50% for confirmation

📋 Bankroll: $40,200 | Deployed: 58% | Positions: 7/12
   Daily P&L: +$340 | State: 🟢 GREEN
⚠️ 1 other Politics position (correlation: moderate)

Reply: TOOK [amount] [conviction 1-5]
Reply: SKIP [reason]
```

### Expired Signal:
```
⏸ CENTINELA — SIGNAL EXPIRED

◈ GhostTrader entered YES @ $0.31
📊 SEC Crypto Ruling Q2
   Current price: $0.37 (+19.3% in 45 seconds)
   ❌ Chase risk triggered — DO NOT ENTER
   📉 Edge retention would be < 15%

Tracking phantom PnL for this signal.
```

### Dumb Money Fade:
```
🔻 CENTINELA — DUMB MONEY FADE

◈ FADE: DegenKing (Inverse: 88 | 24% WR | 340 trades)
📊 Bitcoin $200K by December
   → DegenKing bought YES @ $0.15
   → FADE: consider NO @ $0.85

📉 Lifetime: -$45,200 | Category: Crypto (18% WR — worst)
🔍 Smart money: no insiders on YES (clear to fade)

💰 Standard: $580 (1.4%) | 📌 LIMIT NO @ $0.85

Reply: TOOK [amount] [conviction 1-5]
```

### Convergence (highest conviction):
```
🎯 CENTINELA — CONVERGENCE

📊 Senate Infrastructure Bill → YES
   
   SMART MONEY buying YES:
   ◈ Len9311238 (97) — $45K YES @ $0.43
   ◈ NicheSniper (95) — $35K YES @ $0.44

   DUMB MONEY buying NO:
   ◈ DegenKing (inv:88) — $3K NO @ $0.57
   ◈ BagHolder99 (inv:82) — $2.2K NO @ $0.55
   
   🌐 Kalshi: YES @ $0.52 (+8pt gap — confirming)

💰 High conviction: $1,200 (3.0%)
   📌 LIMIT YES @ $0.44

This is the highest confidence signal Centinela can generate.

Reply: TOOK [amount] [conviction 1-5]
```

### Consensus:
```
🔥 CENTINELA — CONSENSUS

📊 Fed Rate Cut June 2026 → YES
   4 insiders in last 18h:
   ◈ Len9311238 (97) — $45K @ $0.28
   ◈ GhostTrader (93) — $28K @ $0.31
   ◈ Theo4 (92) — $15K @ $0.34
   ◈ QuietMoney (86) — $11K @ $0.33

   Combined: 92 | Capital: $99K
   🌐 Kalshi: $0.47 (+13pt gap)

💰 Standard: $1,200 (3.0%) | 📌 LIMIT @ $0.34

Reply: TOOK [amount] [conviction 1-5]
```

### Take Profit:
```
💰 CENTINELA — TAKE PROFIT

📊 SCOTUS Ruling on Immigration
   TP1 hit: +22% → selling 50%
   Entry: $0.28 → Current: $0.342
   Realized: +$94.50 | Remaining: $425

Holding rest for TP2 (+35%) or resolution.
```

### Stop Loss:
```
🔴 CENTINELA — STOP LOSS

📊 Bitcoin $200K by December
   Price: -17% AND insider (GhostTrader) EXITED
   Entry: $0.44 → Current: $0.365
   Loss: -$127.50

Thesis invalidated — insider no longer holds.
```

### WAIT:
```
⏳ CENTINELA — WAIT

◈ SilentEdge (88 | MOMENTUM) → YES @ $0.22
📊 Lakers Win NBA Finals
   Current: $0.245 (+11%)
   Limit placed: YES @ $0.23 (1 tick above insider)
   ⏱ Expires in 15 min if not filled
```

### Strategy State Change:
```
⚠️ CENTINELA — STATE: GREEN → YELLOW

📉 Rolling 30d PnL: -22% from peak
   Win rate: 54% (was 61%) | Slippage trending up

🔧 Auto: sizes reduced 50%
Review dashboard within 24 hours.
```

### Lockout:
```
🔴 CENTINELA — DAILY LOCKOUT

Loss: -$2,010 (-5.0%). Signals PAUSED until tomorrow.
Today: 4 trades, 2W 2L. Worst: Bitcoin $150K (-$890).

The watchman says: stand down.
```

---

## DATABASE SCHEMA

### Core
- **wallets** — id, address, handle, insider_score, inverse_score, copyability_score, leader_score, classification (sniper/momentum/mm/hedger/noise/dumb_money), wallet_type (smart/dumb/neutral), categories[], category_win_rates{}, notes, date_added, is_active, health_status, crowding_score, edge_retention_avg, wash_suspected (bool), cluster_id, cluster_confidence
- **wallet_scores_history** — wallet_id, score, inverse_score, component_scores{}, component_weights{}, classification, timestamp
- **trades** — id, wallet_id, market_id, market_name, side, size, price, timestamp, is_entry, is_exit, order_type, is_pending, is_first_entry, position_build_phase (early/mid/late), intent_type (informational/position_building/momentum/hedging/liquidity_provision/exit_liquidity), intent_confidence, intent_multiplier

### Markets
- **markets** — id, polymarket_id, gamma_id, question, category, status (active/resolved/disputed/voided), resolution_date, resolution_outcome, daily_volume, spread, liquidity_grade, quality_score, odds_yes, odds_no, tick_size, maker_fee, taker_fee, is_neg_risk, event_id, crowding_score
- **market_liquidity** — market_id, timestamp, bid_depth, ask_depth, spread, daily_volume, slippage_estimate_500, slippage_estimate_1000, slippage_estimate_5000, imbalance_score

### Signals & Alerts
- **alerts** — id, type (insider/consensus/dumb_money_fade/convergence/cross_platform/exit), priority (critical/high/standard/info), wallet_id, market_id, signal_side, message, sent_at, was_taken (bool), take_reason, skip_reason, conviction_level, outcome (win/loss/pending/expired), phantom_pnl, actual_pnl, signal_score, final_signal_score, intent_type, intent_multiplier, copyability_score, leader_score, trap_risk_score, regime_label, regime_confidence, pre_signal_flag (bool), cluster_adjustment, edge_retention_pct, chase_risk_triggered (bool), decision_engine_output (execute/skip/wait)
- **consensus_signals** — id, market_id, side, wallet_ids[], wallet_count, combined_score, total_capital, recommended_size, timestamp, outcome, resolved_at
- **convergence_signals** — id, market_id, smart_wallet_ids[], smart_side, smart_combined_score, dumb_wallet_ids[], dumb_side, dumb_combined_inverse_score, cross_platform_gap, total_edge_sources, timestamp, outcome

### Execution Quality
- **entry_quality** — id, alert_id, wallet_id, market_id, insider_entry_price, alert_price, estimated_user_entry, price_after_60s, price_after_5m, price_at_resolution, edge_retention_pct, slippage_actual, chase_risk_value, timestamp
- **signal_expirations** — id, alert_id, reason (chase/liquidity/slippage/timeout/wait_expired), insider_price, expiration_price, price_move_pct, timestamp
- **decision_log** — id, alert_id, step_reached (status/liquidity/slippage/wallet_quality/portfolio/correlation), step_result (pass/fail), fail_reason, final_output (execute/skip/wait), timestamp

### Money Management
- **bankroll** — id, total_capital, deployed_capital, available_capital, daily_pnl, weekly_pnl, daily_loss_limit, weekly_loss_limit, max_per_market_pct, max_per_category_pct, max_concurrent_positions, is_locked_out, lockout_until, lockout_reason, strategy_state (green/yellow/red)
- **positions** — id, my_trade_id, market_id, side, size, current_size (may be partial after TP1), entry_price, current_price, unrealized_pnl, pnl_pct, resolution_date, tp1_price, tp2_price, sl_conditional_price, sl_hard_price, time_entered, last_updated, correlation_group, insider_still_holds (bool), build_phase (50%/100%)
- **my_trades** — id, market_id, side, size, entry_price, exit_price, pnl, signal_source (insider/consensus/dumb_money/convergence/cross_platform), signal_type, alert_id, conviction_level (1-5), journal_pre, journal_post, timestamp, status (open/partial/closed), cost_basis, holding_period_days

### Dumb Money
- **dumb_money_wallets** — id, wallet_id, inverse_score, win_rate, total_trades, total_pnl, worst_categories[], best_categories[], active_last_30d (bool), backtest_fade_pnl, discovered_at, last_scored_at
- **dumb_money_signals** — id, wallet_id, market_id, dumb_side, fade_side, smart_money_conflict (bool), conflicting_wallet_ids[], signal_strength, timestamp, outcome
- **convergence_opportunities** — id, market_id, smart_wallets_on_side_a[], dumb_wallets_on_side_b[], smart_score, dumb_inverse_score, cross_platform_gap, total_edge_alignment, timestamp, alerted (bool)

### Intelligence
- **clusters** — id, wallet_ids[], correlation_score, shared_markets[], last_detected, is_active
- **discovery_candidates** — id, address, handle, auto_score, inverse_score, classification, wallet_type_suggestion (smart/dumb), score_breakdown{}, backtest_pnl, backtest_fade_pnl, status (pending/approved/rejected), discovered_at
- **cross_platform_markets** — id, polymarket_market_id, kalshi_market_id, event_description, match_confidence
- **cross_platform_prices** — id, cross_platform_market_id, polymarket_price, kalshi_price, price_gap, timestamp
- **overcrowding_metrics** — wallet_id, avg_price_reaction_time_seconds, trend_direction, measured_at

### Quantitative Modules
- **trade_intents** — id, trade_id, wallet_id, market_id, intent_type, confidence, raw_scores{informational, position_building, momentum, hedging, liquidity_provision, exit_liquidity}, intent_multiplier, features{z_size, post_move, spread_cross, passive_fill, seq_same_dir, seq_alt_dir, related_opp_positions, inventory_reduction, pre_move_norm}, timestamp
- **wallet_clusters** — id, cluster_id, wallet_id, cluster_confidence, pair_scores{}, joined_at
- **cluster_pairs** — id, wallet_a_id, wallet_b_id, pair_link_score, pair_confidence, co_market_rate, same_side_rate, timing_corr, size_similarity, repeat_pair_rate, n_shared_events, last_calculated
- **copyability_metrics** — wallet_id, t3_median, t5_median, t10_median, edge_retention, cv_t5, stability, copyability_raw, copyability_score, n_signals_evaluated, last_calculated
- **pre_signal_flags** — id, market_id, pre_signal_confidence, liq_growth, spread_tightening, vol_growth, price_drift, related_smart_activity, flagged_at, insider_entered_after (bool), insider_entry_delay_minutes, was_useful (bool)
- **trap_risk_events** — id, alert_id, trade_id, market_id, trap_risk_score, weak_bids, heavy_asks, wide_spread, price_pop, reversal_3m, insider_inv_reduction, action_taken (invalidated/reduced/deducted/none), timestamp
- **leader_metrics** — wallet_id, leader_events, follower_events, avg_follow_quality, median_lead_time_min, leader_score, last_calculated
- **market_regimes** — id, market_id, regime_label (high_vol/low_vol/trending/manipulated), regime_confidence, raw_scores{}, rv, spread_med, depth_instability, vol_spike, directional_drift, chase_multiplier, position_multiplier, min_score_adjustment, timestamp
- **regime_baselines** — category, rv_mu, rv_sigma, spread_mu, spread_sigma, depth_mu, depth_sigma, vol_mu, vol_sigma, sample_size, last_updated
- **poll_priority** — market_id, poll_priority_score, polling_tier (1/2/3/4), poll_interval_seconds, last_updated
- **detection_health** — id, websocket_alive (bool), polling_freshness, source_redundancy, detection_confidence, timestamp

### Tracking & Reporting
- **shadow_tracking** — id, alert_id, signal_type, was_taken (bool), skip_reason, phantom_pnl, actual_pnl, missed_opportunity, timestamp
- **edge_monitoring** — id, timestamp, rolling_30d_pnl, avg_edge_per_trade, avg_slippage, win_rate, win_rate_by_signal_type{}, strategy_state, position_size_multiplier
- **performance_reports** — id, period (weekly/monthly), start_date, end_date, total_pnl, win_rate, pnl_by_signal_type{insider, consensus, dumb_money, convergence, cross_platform}, trades_taken, trades_skipped, missed_opportunity_cost, top_wallets[], worst_dumb_money[], state_changes[], recommendations[], generated_at
- **scoring_calibrations** — id, old_weights{}, new_weights{}, correlation_data{}, calibrated_at

### System
- **system_health** — id, service_name, status (online/offline), last_heartbeat, uptime_pct, avg_latency_ms, last_disconnect, reconnect_count
- **backfill_log** — id, started_at, completed_at, trades_backfilled, wallets_affected, signals_detected
- **rate_limit_log** — id, endpoint, requests_made, throttle_events, priority_level, timestamp

---

## SYSTEM RELIABILITY

### Health Monitoring
- Heartbeat every 30 seconds: WebSocket, PostgreSQL, Redis, Telegram bot
- Auto-reconnect on WebSocket drop: exponential backoff (1s, 2s, 4s, 8s, max 60s)
- System offline alert: "⚠️ CENTINELA OFFLINE — reconnecting..."
- Recovery alert: "✅ CENTINELA BACK ONLINE — checking for missed trades..."

### Offline Recovery
On startup after any downtime:
1. Check last recorded trade timestamp
2. Query Data API for all tracked wallet trades since then
3. Backfill missed trades
4. Recalculate affected insider scores
5. Check for consensus signals that formed while offline
6. Send summary: "Offline 23 min. Backfilled 7 trades. 1 consensus signal detected."

### Rate Limit Management
Priority queue for API requests:
- P0: insider trade alerts, kill switch detection, convergence signals
- P1: consensus calculation, exit rule checks, dumb money conflict checks
- P2: wallet discovery, score recalculation, dumb money scanning
- P3: market pre-loading, backfill
- Exponential backoff on Cloudflare throttling
- Cache Gamma API responses (5-min TTL)

### Market Resolution
On market resolution:
1. Mark resolved in database
2. Calculate final P&L for all signal types
3. Update wallet win rates, insider scores, AND inverse scores
4. Close positions in portfolio
5. Free capital in bankroll manager
6. Log outcome for feedback loop — tag by signal source
- Disputed markets: freeze, don't count until resolved
- Voided markets: remove from all calculations

### Backups
- Daily automated database backup
- Weekly full SQL dump export
- Store backups externally (not on same server)

---

## BUILD PHASES (final — with trade management + dumb money)

### Phase 0: Paper Trading (Week 1)
```
Graduation Criteria:
- 50+ signals tracked (all types)
- Edge retention ≥ 40%
- Win rate ≥ 55% on paper trades
- Rolling 30-day phantom PnL positive
- At least 5 dumb money fades tracked with positive phantom PnL
- Minimum 4 weeks of data
→ Do NOT trade real money until ALL criteria met
```

### Phase 1: MVP Signals (Week 1-3)
1. Wallet tracker
2. Real-time trade feed (WebSocket)
3. Basic insider scoring
4. Telegram alerts
5. Cross-platform price comparison (Kalshi)
6. Trade decision engine (6-step waterfall)

### Phase 2: Execution Protection (Week 3-5)
7. Chase risk filter + signal expiration
8. Slippage capping (order book depth)
9. Entry quality tracking (edge retention)
10. Bankroll manager (limits, lockout)
11. Position size calculator (Kelly + slippage cap)
12. Trade management (limit entry, TP ladder, conditional SL, time exits)
13. Signal throttling + quiet hours

### Phase 3: Edge Expansion (Week 5-8)
14. Dumb money identification + inverse scoring
15. Dumb money fade signals + smart money conflict check
16. Convergence detection (smart + dumb opposite sides)
17. Consensus signals (3+ insiders)
18. Wallet classification (sniper/momentum/mm/hedger/noise/dumb_money)
19. First entry + position build detection
20. Overcrowding detection
21. Wash trade filter

### Phase 4: Refinement + Quant Foundation (Week 8-12)
22. Edge decay monitoring (GREEN/YELLOW/RED)
23. Scoring weight calibration (every 4 weeks)
24. Shadow tracking (phantom PnL)
25. Position building (50% → 100%)
26. Simultaneous signal priority ranking
27. Wallet discovery (smart AND dumb)
28. **Wallet clustering / syndicate detection** — pairwise link scoring, graph construction, consensus discount
29. Backtest engine (copy AND fade modes)
30. **Copyability scoring** — time-to-move model, wallet score integration
31. **Leader detection** — leader vs follower classification, signal bonus

### Phase 5: Quant Intelligence (Week 12-16)
32. **Intent detection** — classify every trade as informational/position_building/momentum/hedging/liquidity_provision/exit_liquidity with multipliers
33. **Market regime detection** — high_vol/low_vol/trending/manipulated with adaptive thresholds
34. **Regime baseline collection** — 30+ days historical data per category for z-score normalization
35. **Pre-position detection** — early warning flags on markets about to see insider activity
36. **Liquidity trap detection** — catch insiders using copy traders as exit liquidity
37. **Latency optimization** — adaptive polling tiers based on market priority score
38. **Unified signal score integration** — all modules feeding one deterministic formula

### Phase 6: Scale + Operations (Week 16+)
39. Order book intelligence
40. Resolution calendar
41. Correlation risk monitor
42. Entry window calculator
43. Market heat map
44. Trade journal + Telegram quick-entry
45. Performance reports by signal type AND by quant module contribution
46. Tax export
47. Dashboard polish + mobile PWA
48. AI catalyst scanner
49. News integration

---

## DASHBOARD PAGES (11 pages)

### MVP (Phase 3):
1. **Command Center** — bankroll, strategy state 🟢🟡🔴, live feed (smart + dumb tagged), positions, P&L, system health, detection confidence, edge stack alignment
2. **Smart Watchlist** — insider wallets, scores, classification, sparklines, edge retention, crowding, copyability score, leader badge
3. **Dumb Money Watchlist** — loser wallets, inverse scores, worst categories, backtest fade P&L, live activity feed with cross-reference results
4. **Wallet Detail** — full profile (smart or dumb), per-category breakdown, score history, intent distribution (what % of trades are informational vs hedging), copyability chart, leader/follower timeline, cluster membership
5. **My Positions** — live P&L, TP/SL proximity, build phase, insider-still-holds, time exit warnings, regime tag per market

### Expanded (Phase 4+):
6. **Consensus & Convergence** — ranked by total edge alignment, cluster-adjusted wallet counts, dumb money overlay
7. **Cross-Platform** — Polymarket vs Kalshi, divergence history
8. **Performance** — P&L by signal type, by intent type, by regime, shadow tracking, conviction analysis, module contribution breakdown
9. **Market Intelligence** — regime classification per active market, pre-signal flags, trap risk indicators, polling tier assignments
10. **Clusters** — network graph of wallet clusters, pairwise confidence scores, consensus discount impact
11. **Settings** — all thresholds, bankroll, dumb money config, intent weights, regime parameters, polling tiers, trap risk thresholds, strategy state overrides

### Design:
- polyscan-v3.jsx reference
- Dark: #0a0a0e | Cream: #f5ebd2
- #00ffaa green (smart) | #ff4466 red | #00e5ff cyan | #ffb84d amber | #b48eff purple | #ff6b9d pink (dumb money)
- Share Tech Mono + Outfit

---

## THE MATH (updated with dumb money)

```
Edge sources:

1. INSIDER SIGNALS
   Win rate: 60% | Winner: +35% | Loser: -25%
   Edge/trade: 0.110 | Trades/week: 6-8

2. DUMB MONEY FADES
   Win rate: 62% | Winner: +30% | Loser: -20%
   Edge/trade: 0.110 | Trades/week: 3-5

3. CONVERGENCE (smart + dumb opposite)
   Win rate: 72% | Winner: +35% | Loser: -20%
   Edge/trade: 0.196 | Trades/week: 1-2 (rare, high conviction)

4. CROSS-PLATFORM DIVERGENCE
   Win rate: 65% | Winner: +20% | Loser: -15%
   Edge/trade: 0.078 | Trades/week: 2-4

Blended:
- Capital: $30,000 | Deploy: 60% = $18K
- Blended edge: ~0.11/trade
- Avg position: ~$900 | Trades/week: 12-18
- Weekly: $900 × 15 × 0.11 = ~$1,485
- Monthly: ~$5,940

Projections:
- Conservative (months 1-3): $3,000-4,500/month
- Expected (months 4-6): $5,000-8,000/month
- Optimistic (months 6+): $8,000-12,000/month

Dumb money adds ~20-30% trade volume WITHOUT requiring speed.
Convergence is rare but pushes overall win rate up.
Cross-platform requires NO wallet tracking — pure math backup.

Validate: 8-12 weeks total (4-6 paper + 4-6 live small).
Do NOT quit other income until 3+ months profitable.
```

---

## FINAL NOTES

- Manual trading ONLY. Centinela recommends, Daniel decides. No auto-execution ever.
- LIMIT ORDERS ALWAYS. Zero maker fees. Build into every alert.
- Paper trade first. Graduate only when ALL criteria met.
- The edge is the STACK: insider + dumb money + convergence + cross-platform + money management + quant modules. Each layer compounds the others.
- Dumb money fading is the hidden gem. Everyone tracks winners. Nobody systematically tracks losers. This is your contrarian advantage.
- Convergence (smart + dumb opposite sides) = highest conviction. Size up. They're rare — when they appear, act.
- NEVER fade dumb money when smart money agrees with them. Smart trumps dumb always.
- Chase risk filter: signal expires = do not enter. Period. No chasing.
- Conditional stop losses respect insider conviction. Don't stop at -15% if the insider holds. Hard floor at -30% regardless.
- Position building: 50% → 100% on sniper first entries. Full size on consensus/convergence.
- Cross-platform divergence: safest edge. No speed needed. Pure math.
- Trade decision waterfall kills bad signals early. If it says SKIP, trust it.
- Track everything by signal type. If dumb money fading wins 65% but insider copying only wins 52%, shift resources.
- Strategy state circuit breaker protects capital. No override.
- Daily loss lockout. No override. The watchman says stand down.
- Recalibrate scoring weights every 4 weeks.
- Do NOT build quant modules (Phase 4-5) until Phase 1-3 are profitable. The quant layer amplifies an edge — it doesn't create one from nothing.
- **Intent detection is the single most impactful quant module.** It filters out 40-50% of false signals where insiders are hedging or providing liquidity. Build it first in the quant phase.
- **Trap detection protects against adversarial insiders.** Some wallets deliberately attract copy traders to use as exit liquidity. This module catches them.
- **Cluster detection prevents fake consensus.** One person splitting $100K across 4 wallets should count as 1 signal, not 4. The consensus discount formula handles this.
- **Copyability scoring tells you WHICH wallets to copy, not just WHO is good.** A 97-score wallet where price moves in 3 seconds is worthless to you. A 75-score wallet where price takes 5 minutes is gold.
- **Market regime detection makes the system adaptive.** Same rules in a calm market and a manipulated market will get you killed. Regime-specific thresholds prevent this.
- **Pre-position detection gives you a heads-up before signals fire.** Markets don't go from dead to insider entry — there are precursors. This module watches for them.
- **All quant formulas are bounded, normalized, and production-safe.** No unbounded outputs. Every score 0-100. Every confidence 0-1. Use the math primitives (clamp, safe_div, score100) everywhere.
- **Regime baselines need 30+ days of historical data per category.** Bootstrap these from API backfill before regime detection can work properly.
- **The unified signal score formula ties everything together.** base × intent × copyability × leader × (1 - trap) × regime + pre_signal + cluster_discount. One deterministic number. One decision.
- The watchman sees smart money. The watchman sees dumb money. The watchman sees the gap between platforms. The watchman reads intent, detects traps, identifies leaders, classifies regimes, and protects the bankroll above all else.
- Name: CENTINELA — "The Watchman Sees Everything"
