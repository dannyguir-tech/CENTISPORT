"""initial schema — create all tables from ORM metadata.

This migration creates every table defined by the SQLAlchemy models
imported in centinela.db.models.__init__.

Generated manually (not via autogenerate) because autogenerate requires
a live DB connection. To regenerate/customize in the future, run:

    alembic revision --autogenerate -m "<description>"

against a running Postgres.

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-04-16 00:00:00.000000
"""
from alembic import op

from centinela.db.base import Base
# Import all models to register them on Base.metadata
from centinela.db.models import *  # noqa: F401,F403


# revision identifiers, used by Alembic.
revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create all tables from the current ORM metadata."""
    Base.metadata.create_all(bind=op.get_bind())


def downgrade() -> None:
    """Drop all tables defined in metadata."""
    Base.metadata.drop_all(bind=op.get_bind())
