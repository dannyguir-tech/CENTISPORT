import { useState, useEffect, useRef } from "react";

const MOCK_WALLETS = [
  { address: "0x7a3...f91", handle: "Theo4", pnl: 842300, winRate: 0.87, trades: 312, avgSize: 4200, age: 485, categories: ["Politics", "Crypto"], insiderScore: 92, recentTrades: [{market:"Fed Rate Cut June 2026",side:"YES",size:15000,time:"2h ago",priceAtEntry:0.34,currentPrice:0.41},{market:"Trump Indictment Ruling",side:"NO",size:8500,time:"6h ago",priceAtEntry:0.72,currentPrice:0.75}], streak: 8, maxDrawdown: -12400, avgHoldTime: "3.2d", entryTiming: "24-48h pre-catalyst", pnlHistory: [12,18,15,22,28,25,34,31,38,42,45,52,58,55,62,68,72,78,84] },
  { address: "0xb2e...a44", handle: "SilentEdge", pnl: 623100, winRate: 0.82, trades: 478, avgSize: 2800, age: 390, categories: ["Sports", "Politics"], insiderScore: 88, recentTrades: [{market:"Lakers Win NBA Finals",side:"YES",size:12000,time:"1h ago",priceAtEntry:0.22,currentPrice:0.26},{market:"Bitcoin $150k by Sept",side:"YES",size:6000,time:"4h ago",priceAtEntry:0.18,currentPrice:0.21}], streak: 5, maxDrawdown: -18200, avgHoldTime: "1.8d", entryTiming: "12-24h pre-catalyst", pnlHistory: [8,12,10,18,22,19,26,30,28,35,38,42,48,52,55,58,62] },
  { address: "0xf1d...c87", handle: "Len9311238", pnl: 1247000, winRate: 0.94, trades: 89, avgSize: 28000, age: 620, categories: ["Politics"], insiderScore: 97, recentTrades: [{market:"SCOTUS Ruling on Immigration",side:"YES",size:45000,time:"12h ago",priceAtEntry:0.28,currentPrice:0.39},{market:"Senate Vote Infrastructure",side:"NO",size:22000,time:"1d ago",priceAtEntry:0.65,currentPrice:0.71}], streak: 14, maxDrawdown: -8900, avgHoldTime: "5.1d", entryTiming: "48-72h pre-catalyst", pnlHistory: [5,8,15,28,32,45,52,68,75,82,95,102,110,118,124] },
  { address: "0x3c9...e12", handle: "CryptoOracle", pnl: 418700, winRate: 0.79, trades: 567, avgSize: 1900, age: 510, categories: ["Crypto"], insiderScore: 74, recentTrades: [{market:"ETH Merge V2 Date",side:"YES",size:8000,time:"3h ago",priceAtEntry:0.45,currentPrice:0.48},{market:"SOL $500 by Dec",side:"NO",size:5500,time:"8h ago",priceAtEntry:0.82,currentPrice:0.85}], streak: 3, maxDrawdown: -31000, avgHoldTime: "2.4d", entryTiming: "6-12h pre-catalyst", pnlHistory: [10,14,12,18,16,22,20,28,25,32,30,36,38,40,42] },
  { address: "0x9af...b33", handle: "WhaleWatcher", pnl: 556200, winRate: 0.84, trades: 201, avgSize: 5100, age: 445, categories: ["Sports"], insiderScore: 85, recentTrades: [{market:"UFC 310 Main Event",side:"YES",size:18000,time:"30m ago",priceAtEntry:0.52,currentPrice:0.55},{market:"World Cup 2026 Winner",side:"YES",size:9000,time:"5h ago",priceAtEntry:0.16,currentPrice:0.18}], streak: 6, maxDrawdown: -15800, avgHoldTime: "1.2d", entryTiming: "4-6h pre-catalyst", pnlHistory: [6,10,15,18,22,28,30,35,38,42,45,48,52,55] },
  { address: "0xe7b...d56", handle: "PoliticsAlpha", pnl: 389400, winRate: 0.81, trades: 345, avgSize: 2200, age: 380, categories: ["Politics", "Crypto"], insiderScore: 71, recentTrades: [{market:"Newsom Presidential Run",side:"NO",size:7000,time:"2h ago",priceAtEntry:0.88,currentPrice:0.91}], streak: 4, maxDrawdown: -22100, avgHoldTime: "4.3d", entryTiming: "12-24h pre-catalyst", pnlHistory: [5,8,12,15,18,22,25,28,30,32,35,38,39] },
  { address: "0x1dd...f78", handle: "DegenKing", pnl: 178900, winRate: 0.68, trades: 892, avgSize: 980, age: 290, categories: ["Sports", "Crypto", "Politics"], insiderScore: 42, recentTrades: [{market:"BTC dominance above 60%",side:"YES",size:3000,time:"1h ago",priceAtEntry:0.55,currentPrice:0.53}], streak: -2, maxDrawdown: -45000, avgHoldTime: "0.8d", entryTiming: "Random", pnlHistory: [10,14,12,16,13,18,15,20,17,22,18,16,18] },
  { address: "0x5fa...a91", handle: "NicheSniper", pnl: 312600, winRate: 0.91, trades: 67, avgSize: 8400, age: 340, categories: ["Politics"], insiderScore: 95, recentTrades: [{market:"FDA Approval Drug X",side:"YES",size:35000,time:"6h ago",priceAtEntry:0.12,currentPrice:0.19}], streak: 11, maxDrawdown: -5200, avgHoldTime: "6.8d", entryTiming: "48h+ pre-catalyst", pnlHistory: [2,5,8,12,15,20,22,25,28,31] },
  { address: "0x8c2...e45", handle: "SportsBrain", pnl: 267800, winRate: 0.77, trades: 423, avgSize: 1500, age: 520, categories: ["Sports"], insiderScore: 68, recentTrades: [{market:"Celtics Win Eastern Conf",side:"YES",size:6000,time:"4h ago",priceAtEntry:0.38,currentPrice:0.40}], streak: 2, maxDrawdown: -19500, avgHoldTime: "1.5d", entryTiming: "6-12h pre-catalyst", pnlHistory: [4,7,10,12,15,18,20,22,24,25,26,27] },
  { address: "0x4b7...c23", handle: "GhostTrader", pnl: 891200, winRate: 0.89, trades: 134, avgSize: 12300, age: 410, categories: ["Crypto", "Politics"], insiderScore: 93, recentTrades: [{market:"SEC Crypto Ruling Q2",side:"YES",size:28000,time:"45m ago",priceAtEntry:0.31,currentPrice:0.37},{market:"China Taiwan Tensions",side:"NO",size:15000,time:"3h ago",priceAtEntry:0.78,currentPrice:0.82}], streak: 9, maxDrawdown: -11200, avgHoldTime: "4.7d", entryTiming: "24-48h pre-catalyst", pnlHistory: [8,15,22,30,38,45,52,60,68,72,78,85,89] },
  { address: "0x6e1...d89", handle: "QuietMoney", pnl: 445600, winRate: 0.83, trades: 256, avgSize: 3600, age: 470, categories: ["Politics"], insiderScore: 86, recentTrades: [{market:"UK Election Date",side:"YES",size:11000,time:"2h ago",priceAtEntry:0.42,currentPrice:0.46}], streak: 7, maxDrawdown: -13800, avgHoldTime: "3.9d", entryTiming: "24h pre-catalyst", pnlHistory: [5,10,15,18,22,28,32,35,38,42,44] },
  { address: "0x2af...b67", handle: "LiquidityKing", pnl: 134500, winRate: 0.72, trades: 1203, avgSize: 650, age: 600, categories: ["Sports", "Crypto", "Politics"], insiderScore: 31, recentTrades: [{market:"Multiple markets",side:"BOTH",size:800,time:"ongoing",priceAtEntry:0,currentPrice:0}], streak: 1, maxDrawdown: -8700, avgHoldTime: "0.3d", entryTiming: "Market maker", pnlHistory: [2,3,5,6,8,9,10,11,12,13,13,14] },
];

const C = {
  bg: "#0a0a0e",
  panel: "#0f0f14",
  card: "#12121a",
  border: "rgba(245,235,210,0.06)",
  borderHi: "rgba(245,235,210,0.12)",
  cream: "#f5ebd2",
  creamSoft: "rgba(245,235,210,0.65)",
  creamMuted: "rgba(245,235,210,0.35)",
  creamFaint: "rgba(245,235,210,0.15)",
  creamGhost: "rgba(245,235,210,0.07)",
  green: "#00ffaa",
  greenSoft: "rgba(0,255,170,0.7)",
  red: "#ff4466",
  cyan: "#00e5ff",
  amber: "#ffb84d",
  purple: "#b48eff",
};

const getScoreColor = (s) => s >= 90 ? C.green : s >= 75 ? C.cyan : s >= 60 ? C.amber : s >= 40 ? C.red : "#ff2244";
const getScoreLabel = (s) => s >= 90 ? "INSIDER" : s >= 75 ? "HIGH" : s >= 60 ? "MID" : s >= 40 ? "LOW" : "NOISE";
const formatMoney = (n) => { if (Math.abs(n) >= 1e6) return `$${(n/1e6).toFixed(2)}M`; if (Math.abs(n) >= 1e3) return `$${(n/1e3).toFixed(1)}K`; return `$${n}`; };

const Sparkline = ({ data, color, width = 90, height = 22 }) => {
  const max = Math.max(...data), min = Math.min(...data), range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / range) * (height - 2) - 1}`).join(" ");
  const area = pts + ` ${width},${height} 0,${height}`;
  const id = `sp-${color.replace(/[^a-z0-9]/gi, '')}`;
  return (
    <svg width={width} height={height} style={{ overflow: "visible", display: "block" }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={area} fill={`url(#${id})`} />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={width} cy={parseFloat(pts.split(" ").pop().split(",")[1])} r="2" fill={color} style={{ filter: `drop-shadow(0 0 3px ${color})` }} />
    </svg>
  );
};

const HexRing = ({ value, size = 50, sw = 3 }) => {
  const color = getScoreColor(value);
  const r = (size - sw) / 2, circ = 2 * Math.PI * r, off = circ - (value / 100) * circ;
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={C.creamGhost} strokeWidth={sw} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={sw} strokeDasharray={circ} strokeDashoffset={off} strokeLinecap="round" style={{ transition: "all 0.8s cubic-bezier(0.4,0,0.2,1)", filter: `drop-shadow(0 0 6px ${color}88)` }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
        <span style={{ fontSize: 13, fontWeight: 900, color, fontFamily: "'Share Tech Mono', monospace", lineHeight: 1 }}>{value}</span>
      </div>
    </div>
  );
};

const catTheme = {
  Politics: { bg: "rgba(180,142,255,0.08)", text: "#c4a8ff", border: "rgba(180,142,255,0.15)", dot: "#b48eff" },
  Crypto: { bg: "rgba(255,184,77,0.08)", text: "#ffd699", border: "rgba(255,184,77,0.15)", dot: "#ffb84d" },
  Sports: { bg: "rgba(0,229,255,0.08)", text: "#80f0ff", border: "rgba(0,229,255,0.15)", dot: "#00e5ff" },
};

const CatPill = ({ cat }) => {
  const t = catTheme[cat] || { bg: C.creamGhost, text: C.creamSoft, border: C.border, dot: C.cream };
  return (
    <span style={{ background: t.bg, color: t.text, border: `1px solid ${t.border}`, padding: "1px 7px 1px 5px", borderRadius: 3, fontSize: 9, fontWeight: 700, letterSpacing: 1, display: "inline-flex", alignItems: "center", gap: 4, textTransform: "uppercase" }}>
      <span style={{ width: 4, height: 4, borderRadius: "50%", background: t.dot, boxShadow: `0 0 5px ${t.dot}` }} />
      {cat}
    </span>
  );
};

const ScoreBadge = ({ score }) => {
  const color = getScoreColor(score);
  return (
    <span style={{ background: `${color}10`, color, border: `1px solid ${color}20`, padding: "2px 7px", borderRadius: 3, fontSize: 8, fontWeight: 800, letterSpacing: 1.5, boxShadow: score >= 85 ? `0 0 12px ${color}22` : "none" }}>{getScoreLabel(score)}</span>
  );
};

const GridBG = () => (
  <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", opacity: 0.3 }}>
    <div style={{ position: "absolute", inset: 0, backgroundImage: `linear-gradient(${C.border} 1px, transparent 1px), linear-gradient(90deg, ${C.border} 1px, transparent 1px)`, backgroundSize: "60px 60px" }} />
    <div style={{ position: "absolute", top: "-20%", left: "20%", width: 700, height: 700, background: `radial-gradient(circle, rgba(0,255,170,0.03) 0%, transparent 60%)` }} />
    <div style={{ position: "absolute", bottom: "-10%", right: "5%", width: 500, height: 500, background: `radial-gradient(circle, rgba(0,229,255,0.02) 0%, transparent 60%)` }} />
    <div style={{ position: "absolute", top: "30%", left: "-5%", width: 400, height: 400, background: `radial-gradient(circle, rgba(180,142,255,0.02) 0%, transparent 60%)` }} />
  </div>
);

const ScanLine = () => (
  <div style={{ position: "fixed", top: 0, left: 0, right: 0, height: "100vh", pointerEvents: "none", zIndex: 999, overflow: "hidden", opacity: 0.04 }}>
    <div style={{ position: "absolute", left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${C.green}, transparent)`, animation: "scanMove 4s linear infinite" }} />
  </div>
);

const WalletRow = ({ wallet, rank, onSelect, isSelected, delay }) => {
  const color = getScoreColor(wallet.insiderScore);
  const pnlColor = wallet.pnl >= 0 ? C.green : C.red;
  return (
    <div onClick={() => onSelect(wallet)} style={{
      display: "grid", gridTemplateColumns: "30px 1.5fr 120px 65px 55px 90px 54px",
      alignItems: "center", gap: 10, padding: "14px 18px",
      background: isSelected ? `linear-gradient(90deg, ${color}0a, transparent)` : "transparent",
      borderLeft: isSelected ? `2px solid ${color}` : "2px solid transparent",
      borderBottom: `1px solid ${C.border}`,
      cursor: "pointer", transition: "all 0.15s ease",
      animation: `rowIn 0.35s ease ${delay}s both`,
    }}
      onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = `rgba(245,235,210,0.02)`; }}
      onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = "transparent"; }}
    >
      <span style={{ fontSize: 11, fontWeight: 800, color: rank <= 3 ? color : C.creamFaint, fontFamily: "'Share Tech Mono', monospace" }}>{String(rank).padStart(2,'0')}</span>

      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.cream, letterSpacing: -0.3 }}>{wallet.handle}</span>
          <ScoreBadge score={wallet.insiderScore} />
        </div>
        <div style={{ display: "flex", gap: 4 }}>{wallet.categories.map(c => <CatPill key={c} cat={c} />)}</div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 3 }}>
        <span style={{ fontSize: 14, fontWeight: 800, color: pnlColor, fontFamily: "'Share Tech Mono', monospace" }}>{formatMoney(wallet.pnl)}</span>
        <Sparkline data={wallet.pnlHistory} color={pnlColor} />
      </div>

      <span style={{ fontSize: 14, fontWeight: 800, textAlign: "right", fontFamily: "'Share Tech Mono', monospace", color: wallet.winRate >= 0.85 ? C.green : wallet.winRate >= 0.75 ? C.cyan : C.cream }}>
        {(wallet.winRate*100).toFixed(0)}<span style={{ fontSize: 9, color: C.creamMuted }}>%</span>
      </span>

      <span style={{ fontSize: 12, textAlign: "right", fontFamily: "'Share Tech Mono', monospace", color: C.creamMuted }}>{wallet.trades}</span>

      <div style={{ height: 4, background: C.creamGhost, borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${wallet.insiderScore}%`, height: "100%", background: `linear-gradient(90deg, ${color}88, ${color})`, borderRadius: 2, boxShadow: `0 0 10px ${color}44`, transition: "width 0.8s ease" }} />
      </div>

      <HexRing value={wallet.insiderScore} size={44} sw={3} />
    </div>
  );
};

const DetailPanel = ({ wallet, onClose }) => {
  if (!wallet) return null;
  const color = getScoreColor(wallet.insiderScore);
  const stats = [
    { l: "PNL", v: formatMoney(wallet.pnl), c: C.green },
    { l: "WIN RATE", v: `${(wallet.winRate*100).toFixed(0)}%`, c: wallet.winRate >= 0.85 ? C.green : C.cyan },
    { l: "TRADES", v: wallet.trades, c: C.cream },
    { l: "AVG SIZE", v: formatMoney(wallet.avgSize), c: C.cream },
    { l: "STREAK", v: wallet.streak > 0 ? `${wallet.streak}W` : `${Math.abs(wallet.streak)}L`, c: wallet.streak > 0 ? C.green : C.red },
    { l: "MAX DD", v: formatMoney(wallet.maxDrawdown), c: C.red },
    { l: "HOLD", v: wallet.avgHoldTime, c: C.cream },
    { l: "AGE", v: `${wallet.age}d`, c: C.cream },
  ];

  return (
    <div style={{ background: C.panel, border: `1px solid ${C.borderHi}`, borderRadius: 12, overflow: "hidden", animation: "panelIn 0.3s ease", boxShadow: `0 0 40px rgba(0,0,0,0.4), inset 0 1px 0 ${C.border}` }}>
      <div style={{ background: `linear-gradient(90deg, ${color}06, transparent)`, borderBottom: `1px solid ${C.border}`, padding: "18px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <HexRing value={wallet.insiderScore} size={56} sw={3.5} />
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 22, fontWeight: 800, color: C.cream, letterSpacing: -0.5 }}>{wallet.handle}</span>
              <ScoreBadge score={wallet.insiderScore} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 5 }}>
              <span style={{ fontSize: 11, color: C.creamMuted, fontFamily: "'Share Tech Mono', monospace" }}>{wallet.address}</span>
              <span style={{ width: 3, height: 3, borderRadius: "50%", background: C.creamFaint }} />
              <span style={{ fontSize: 11, color, fontFamily: "'Share Tech Mono', monospace", fontWeight: 700 }}>⏱ {wallet.entryTiming}</span>
            </div>
          </div>
        </div>
        <button onClick={onClose} style={{ background: C.creamGhost, border: `1px solid ${C.border}`, borderRadius: 6, color: C.creamMuted, padding: "8px 18px", cursor: "pointer", fontSize: 10, fontWeight: 800, fontFamily: "inherit", letterSpacing: 2, transition: "all 0.15s ease" }}
          onMouseEnter={e => e.currentTarget.style.borderColor = C.creamMuted}
          onMouseLeave={e => e.currentTarget.style.borderColor = C.border}
        >CLOSE</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(8, 1fr)", borderBottom: `1px solid ${C.border}` }}>
        {stats.map((s, i) => (
          <div key={i} style={{ padding: "18px 10px", borderRight: i < 7 ? `1px solid ${C.border}` : "none", textAlign: "center" }}>
            <div style={{ fontSize: 8, color: C.creamFaint, fontWeight: 800, letterSpacing: 2, marginBottom: 8 }}>{s.l}</div>
            <div style={{ fontSize: 17, fontWeight: 900, color: s.c, fontFamily: "'Share Tech Mono', monospace" }}>{s.v}</div>
          </div>
        ))}
      </div>

      <div style={{ padding: "20px 24px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.green, boxShadow: `0 0 8px ${C.green}`, animation: "blink 2s ease infinite" }} />
          <span style={{ fontSize: 10, color: C.creamMuted, fontWeight: 800, letterSpacing: 3 }}>LIVE POSITIONS</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {wallet.recentTrades.map((t, i) => {
            const gain = t.currentPrice > t.priceAtEntry;
            const pct = t.priceAtEntry > 0 ? (((t.currentPrice - t.priceAtEntry) / t.priceAtEntry) * 100).toFixed(1) : "—";
            return (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "1.2fr 60px 80px 90px 80px", alignItems: "center", gap: 10, padding: "12px 16px", background: C.creamGhost, borderRadius: 8, border: `1px solid ${C.border}`, transition: "all 0.15s ease" }}
                onMouseEnter={e => e.currentTarget.style.borderColor = C.borderHi}
                onMouseLeave={e => e.currentTarget.style.borderColor = C.border}
              >
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.cream }}>{t.market}</div>
                  <div style={{ fontSize: 10, color: C.creamFaint, marginTop: 2, fontFamily: "'Share Tech Mono', monospace" }}>{t.time}</div>
                </div>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <span style={{ fontSize: 10, fontWeight: 900, letterSpacing: 2, color: t.side === "YES" ? C.green : t.side === "NO" ? C.red : C.creamMuted, padding: "3px 10px", background: t.side === "YES" ? `${C.green}0c` : t.side === "NO" ? `${C.red}0c` : "transparent", border: `1px solid ${t.side === "YES" ? `${C.green}18` : t.side === "NO" ? `${C.red}18` : "transparent"}`, borderRadius: 3 }}>{t.side}</span>
                </div>
                <span style={{ fontSize: 13, fontWeight: 700, color: C.cream, fontFamily: "'Share Tech Mono', monospace", textAlign: "right" }}>{formatMoney(t.size)}</span>
                <div style={{ textAlign: "right", fontFamily: "'Share Tech Mono', monospace" }}>
                  <span style={{ fontSize: 11, color: C.creamMuted }}>{t.priceAtEntry.toFixed(2)}</span>
                  <span style={{ fontSize: 12, color: gain ? C.green : C.red, margin: "0 5px" }}>→</span>
                  <span style={{ fontSize: 11, color: gain ? C.green : C.red, fontWeight: 700 }}>{t.currentPrice.toFixed(2)}</span>
                </div>
                <span style={{ fontSize: 13, fontWeight: 900, color: gain ? C.green : C.red, textAlign: "right", fontFamily: "'Share Tech Mono', monospace" }}>{gain ? "+" : ""}{pct}%</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [wallets] = useState(MOCK_WALLETS);
  const [selected, setSelected] = useState(null);
  const [sortBy, setSortBy] = useState("insiderScore");
  const [filterCat, setFilterCat] = useState("All");
  const [minWinRate, setMinWinRate] = useState(0);
  const [search, setSearch] = useState("");
  const [time, setTime] = useState(new Date());
  const [activeCount, setActiveCount] = useState(0);

  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { const t = setInterval(() => setActiveCount(c => c === 3 ? 0 : c + 1), 800); return () => clearInterval(t); }, []);

  const sorted = [...wallets]
    .filter(w => filterCat === "All" || w.categories.includes(filterCat))
    .filter(w => w.winRate >= minWinRate / 100)
    .filter(w => !search || w.handle.toLowerCase().includes(search.toLowerCase()) || w.address.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const topInsiders = wallets.filter(w => w.insiderScore >= 85).length;
  const totalPnl = wallets.reduce((s, w) => s + w.pnl, 0);
  const avgWin = wallets.reduce((s, w) => s + w.winRate, 0) / wallets.length;

  const btnStyle = (active) => ({
    background: active ? C.creamGhost : "transparent",
    border: `1px solid ${active ? C.borderHi : "transparent"}`,
    borderRadius: 5, padding: "6px 12px",
    color: active ? C.cream : C.creamMuted,
    fontSize: 11, fontWeight: 700, cursor: "pointer",
    fontFamily: "inherit", letterSpacing: 0.5,
    display: "flex", alignItems: "center", gap: 5,
    transition: "all 0.15s ease",
  });

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.cream, fontFamily: "'Outfit', sans-serif", position: "relative" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Share+Tech+Mono&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: ${C.creamGhost}; border-radius: 2px; }
        input:focus, select:focus { outline: none; border-color: ${C.creamMuted} !important; }
        @keyframes rowIn { from { opacity:0; transform:translateX(-12px); } to { opacity:1; transform:translateX(0); } }
        @keyframes panelIn { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        @keyframes blink { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
        @keyframes scanMove { 0% { top:-2px; } 100% { top:100vh; } }
        @keyframes glitch { 0%,100% { opacity:1; } 50% { opacity:0.85; transform:translateX(1px); } }
        @keyframes borderPulse { 0%,100% { border-color: ${C.border}; } 50% { border-color: ${C.borderHi}; } }
        select option { background: ${C.panel}; color: ${C.cream}; }
      `}</style>

      <GridBG />
      <ScanLine />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1120, margin: "0 auto", padding: "32px 24px" }}>
        {/* HEADER */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 36 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 3, marginBottom: 2 }}>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 4, color: C.creamFaint }}>SYSTEM</span>
              <span style={{ fontSize: 9, color: C.creamFaint, margin: "0 4px" }}>/</span>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 4, color: C.green }}>ONLINE</span>
              <div style={{ width: 5, height: 5, borderRadius: "50%", background: C.green, boxShadow: `0 0 8px ${C.green}`, marginLeft: 4, animation: "blink 2s ease infinite" }} />
            </div>
            <h1 style={{ fontSize: 36, fontWeight: 900, letterSpacing: -2, lineHeight: 1, marginBottom: 4 }}>
              CENTI<span style={{ color: C.green, textShadow: `0 0 30px ${C.green}33` }}>NELA</span>
            </h1>
            <p style={{ fontSize: 11, color: C.creamFaint, letterSpacing: 5, fontWeight: 600, textTransform: "uppercase" }}>The Watchman Sees Everything</p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
            <div style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: 22, color: C.creamFaint, letterSpacing: 4, fontWeight: 400 }}>
              {time.toLocaleTimeString('en-US', { hour12: false })}
            </div>
            <div style={{ display: "flex", gap: 4 }}>
              <span style={{ fontSize: 8, padding: "3px 8px", background: `${C.green}0a`, border: `1px solid ${C.green}18`, borderRadius: 3, color: C.green, fontWeight: 800, letterSpacing: 2 }}>DEMO MODE</span>
            </div>
            <div style={{ fontSize: 9, color: C.creamFaint, fontFamily: "'Share Tech Mono', monospace" }}>
              {time.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>
        </div>

        {/* STATS */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 28 }}>
          {[
            { l: "TRACKING", v: wallets.length, s: "wallets", c: C.cream, icon: "◎" },
            { l: "INSIDERS FOUND", v: topInsiders, s: "score ≥ 85", c: C.green, icon: "⬡" },
            { l: "COMBINED PNL", v: formatMoney(totalPnl), s: "all wallets", c: C.green, icon: "△" },
            { l: "AVG WIN RATE", v: `${(avgWin*100).toFixed(0)}%`, s: "portfolio", c: C.cyan, icon: "◇" },
          ].map((s, i) => (
            <div key={i} style={{
              background: `linear-gradient(135deg, ${C.creamGhost}, transparent)`,
              border: `1px solid ${C.border}`,
              borderRadius: 10, padding: "20px 18px",
              position: "relative", overflow: "hidden",
              animation: `borderPulse 4s ease ${i * 0.3}s infinite`,
            }}>
              <div style={{ position: "absolute", top: 8, right: 12, fontSize: 32, color: C.creamGhost, fontWeight: 300 }}>{s.icon}</div>
              <div style={{ fontSize: 8, color: C.creamFaint, fontWeight: 800, letterSpacing: 3, marginBottom: 10 }}>{s.l}</div>
              <div style={{ fontSize: 28, fontWeight: 900, color: s.c, fontFamily: "'Share Tech Mono', monospace", letterSpacing: -1, textShadow: s.c === C.green ? `0 0 20px ${C.green}22` : "none" }}>{s.v}</div>
              <div style={{ fontSize: 9, color: C.creamFaint, fontWeight: 600, marginTop: 4, letterSpacing: 1 }}>{s.s}</div>
            </div>
          ))}
        </div>

        {/* TOOLBAR */}
        <div style={{ display: "flex", gap: 8, marginBottom: 18, flexWrap: "wrap", alignItems: "center", padding: "10px 16px", background: C.creamGhost, border: `1px solid ${C.border}`, borderRadius: 10, backdropFilter: "blur(10px)" }}>
          <div style={{ position: "relative" }}>
            <span style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: C.creamFaint, fontSize: 12 }}>⌕</span>
            <input type="text" placeholder="Search wallet..." value={search} onChange={e => setSearch(e.target.value)}
              style={{ background: C.creamGhost, border: `1px solid ${C.border}`, borderRadius: 6, padding: "8px 12px 8px 28px", color: C.cream, fontSize: 12, width: 170, fontFamily: "inherit" }} />
          </div>

          <div style={{ width: 1, height: 22, background: C.border, margin: "0 2px" }} />

          {["All", "Politics", "Crypto", "Sports"].map(c => (
            <button key={c} onClick={() => setFilterCat(c)} style={btnStyle(filterCat === c)}>
              {c !== "All" && <span style={{ width: 5, height: 5, borderRadius: "50%", background: filterCat === c ? (catTheme[c]?.dot || C.cream) : C.creamFaint }} />}
              {c}
            </button>
          ))}

          <div style={{ width: 1, height: 22, background: C.border, margin: "0 2px" }} />

          <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ background: C.creamGhost, border: `1px solid ${C.border}`, borderRadius: 6, padding: "7px 10px", color: C.creamSoft, fontSize: 11, fontFamily: "inherit", cursor: "pointer", fontWeight: 600 }}>
            <option value="insiderScore">↓ Insider Score</option>
            <option value="pnl">↓ PnL</option>
            <option value="winRate">↓ Win Rate</option>
            <option value="trades">↓ Trades</option>
          </select>

          <div style={{ display: "flex", alignItems: "center", gap: 6, marginLeft: "auto" }}>
            <span style={{ fontSize: 9, color: C.creamFaint, fontWeight: 700, letterSpacing: 1 }}>MIN WIN</span>
            <input type="range" min={0} max={90} step={5} value={minWinRate} onChange={e => setMinWinRate(Number(e.target.value))} style={{ width: 55, accentColor: C.green }} />
            <span style={{ fontSize: 11, color: C.creamMuted, fontFamily: "'Share Tech Mono', monospace", width: 28 }}>{minWinRate}%</span>
          </div>
        </div>

        {/* COLUMN HEADERS */}
        <div style={{ display: "grid", gridTemplateColumns: "30px 1.5fr 120px 65px 55px 90px 54px", gap: 10, padding: "0 18px 8px", alignItems: "center" }}>
          {["#", "WALLET", "PNL", "WIN", "TXS", "SIGNAL", "SCORE"].map((h, i) => (
            <span key={h} style={{ fontSize: 8, color: C.creamFaint, fontWeight: 800, letterSpacing: 3, textAlign: i >= 2 && i <= 4 ? "right" : "left" }}>{h}</span>
          ))}
        </div>

        {/* WALLET TABLE */}
        <div style={{ border: `1px solid ${C.border}`, borderRadius: 10, overflow: "hidden", background: `linear-gradient(180deg, ${C.creamGhost}, transparent)`, marginBottom: 24 }}>
          {sorted.map((w, i) => (
            <WalletRow key={w.address} wallet={w} rank={i+1} onSelect={setSelected} isSelected={selected?.address === w.address} delay={i * 0.04} />
          ))}
          {sorted.length === 0 && (
            <div style={{ padding: 48, textAlign: "center", color: C.creamFaint, fontSize: 13, fontWeight: 600 }}>No wallets match filters</div>
          )}
        </div>

        {/* DETAIL */}
        {selected && <DetailPanel wallet={selected} onClose={() => setSelected(null)} />}

        {/* FOOTER */}
        <div style={{ marginTop: 32, padding: "16px 0", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 10, color: C.creamFaint, letterSpacing: 1 }}>Upload Wallet Master CSV to connect live data</span>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 8, color: C.creamFaint, fontFamily: "'Share Tech Mono', monospace", letterSpacing: 3 }}>CENTINELA v1.0</span>
            <div style={{ display: "flex", gap: 2 }}>
              {[0,1,2,3].map(i => <div key={i} style={{ width: 3, height: 8, borderRadius: 1, background: i <= activeCount ? C.green : C.creamGhost, transition: "background 0.3s ease" }} />)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
